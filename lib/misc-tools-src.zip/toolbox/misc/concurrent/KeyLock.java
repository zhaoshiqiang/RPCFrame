/**
 * @(#)KeyLock.java, 2009-3-12. 
 * 
 * Copyright 2009 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.misc.concurrent;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Logger;

import toolbox.misc.LogFormatter;
import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * @author zhangduo
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class KeyLock<T> {
    private static final Logger LOG = LogFormatter.getLogger(KeyLock.class);

    private Map<T, Condition> lockMap = new HashMap<T, Condition>();

    private Lock mapLock = new ReentrantLock();

    public void lock(T key, long timeout) {
        long startTime = System.currentTimeMillis();
        mapLock.lock();
        try {
            while (true) {
                Condition oldLock = lockMap.get(key);
                if (oldLock == null) {
                    lockMap.put(key, mapLock.newCondition());
                    return;
                }
                if (timeout > 0) {
                    long currentTime = System.currentTimeMillis();
                    if (currentTime - startTime >= timeout) {
                        throw new LockTimeoutException(
                                "failed to obtain lock for " + key + " in "
                                        + timeout + " ms");
                    }
                    try {
                        oldLock.await(timeout - (currentTime - startTime),
                                TimeUnit.MILLISECONDS);
                    } catch (InterruptedException e) {}
                } else {
                    try {
                        oldLock.await();
                    } catch (InterruptedException e) {}
                }
            }
        } finally {
            mapLock.unlock();
        }
    }

    public void unlock(T key) {
        mapLock.lock();
        try {
            Condition lock = lockMap.remove(key);
            if (lock == null) {
                LOG.warning("Failed to unlock key " + key);
                return;
            }
            lock.signalAll();
        } finally {
            mapLock.unlock();
        }
    }
}
