/**
 * @(#)AtomicRotateInteger.java, 2010-8-23. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.misc.concurrent;

import java.util.concurrent.atomic.AtomicInteger;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * @author zhangduo
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class AtomicRotateInteger extends Number {

    private static final long serialVersionUID = 2325517950344287942L;

    private int min;

    private int max;

    private AtomicInteger value;

    public AtomicRotateInteger(int min, int max, int initialValue) {
        if (min >= max) {
            throw new IllegalArgumentException();
        }
        if (initialValue < min || initialValue >= max) {
            throw new IllegalArgumentException();
        }
        this.min = min;
        this.max = max;
        value = new AtomicInteger(initialValue);
    }

    /**
     * Gets the current value.
     * 
     * @return the current value
     */
    public int get() {
        return value.get();
    }

    /**
     * Atomically increments by one the current value.
     * 
     * @return the previous value
     */
    public int getAndIncrement() {
        for (;;) {
            int current = get();
            int next = current + 1;
            if (next == max) {
                next = min;
            }
            if (value.compareAndSet(current, next)) {
                return current;
            }
        }
    }

    /**
     * Atomically decrements by one the current value.
     * 
     * @return the previous value
     */
    public int getAndDecrement() {
        for (;;) {
            int current = get();
            int next = current - 1;
            if (next < min) {
                next = max - 1;
            }
            if (value.compareAndSet(current, next)) {
                return current;
            }
        }
    }

    /**
     * Atomically increments by one the current value.
     * 
     * @return the updated value
     */
    public int incrementAndGet() {
        for (;;) {
            int current = get();
            int next = current + 1;
            if (next == max) {
                next = min;
            }
            if (value.compareAndSet(current, next)) {
                return next;
            }
        }
    }

    /**
     * Atomically decrements by one the current value.
     * 
     * @return the updated value
     */
    public int decrementAndGet() {
        for (;;) {
            int current = get();
            int next = current - 1;
            if (next < min) {
                next = max - 1;
            }
            if (value.compareAndSet(current, next)) {
                return next;
            }
        }
    }

    @Override
    public double doubleValue() {
        return value.doubleValue();
    }

    @Override
    public float floatValue() {
        return value.floatValue();
    }

    @Override
    public int intValue() {
        return value.intValue();
    }

    @Override
    public long longValue() {
        return value.longValue();
    }

}
