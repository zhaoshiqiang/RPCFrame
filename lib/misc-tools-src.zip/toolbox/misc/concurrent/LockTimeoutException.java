/**
 * @(#)LockTimeoutException.java, 2008-8-27. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.misc.concurrent;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * @author zhangkun
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class LockTimeoutException extends RuntimeException {
    private static final long serialVersionUID = -1238704503226345679L;

    public LockTimeoutException() {
        super();
    }

    public LockTimeoutException(String message, Throwable cause) {
        super(message, cause);
    }

    public LockTimeoutException(String message) {
        super(message);
    }

    public LockTimeoutException(Throwable cause) {
        super(cause);
    }

}
