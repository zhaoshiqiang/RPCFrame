/**
 * 
 */
package toolbox.misc.channel;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * Thrown when no running output-pipe is found during putting.
 * 
 * @author David
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class NoOutputPipeException extends Exception {
    private static final long serialVersionUID = -2572548840356874547L;
}
