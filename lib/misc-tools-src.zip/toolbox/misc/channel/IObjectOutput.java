package toolbox.misc.channel;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * The interface of outputting objects.
 * 
 * @author david
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public interface IObjectOutput {
    /**
     * Output some objects.
     * 
     * @param objects
     *            the objects to be output
     * @throws Exception
     *             if any error occurs
     */
    public void output(Object... objects) throws Exception;
}
