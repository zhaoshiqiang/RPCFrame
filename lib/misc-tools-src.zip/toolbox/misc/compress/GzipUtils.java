package toolbox.misc.compress;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * 这个类包含关于Gzip压缩的工具
 * 
 * @author Feng Jiang (Feng.a.Jiang@gmail.com)
 * @since Jan 5, 2007
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class GzipUtils {
    
    private static final int INIT_BUFFER_LEN = 1024 * 10;
    
    public static final int DEF_MAX_LEN = 1024 * 256;
    
    /**
     * 对一段buffer进行解压。
     * <p>
     * 如果输入buffer不能被GZIP解压，那么就返回null.<br>
     * 如果待解压的buffer超过了256K上限，那么返回已解压的那部分buffer，此时用户无法知道解压是否完成，或由于超过限制而终止。
     * 
     * @param in 待解压的byte流
     * @return 解压后的buffer。
     */
    public static byte[] uncompress(byte[] in) {
        return uncompress(in, DEF_MAX_LEN);
    }
    
    /**
     * 对一段buffer进行解压。
     * <p>
     * 如果输入buffer不能被GZIP解压，那么就返回null.<br>
     * 如果待解压的buffer超过了limit上限，那么返回已解压的那部分buffer，此时用户无法知道解压是否完成，或由于超过限制而终止。
     * 
     * @param in 待解压的byte流
     * @param limit 解压后的buffer上限
     * @return 解压后的buffer。
     */
    public static byte[] uncompress(byte[] in, int limit) {
        int read = 0;
        int len = INIT_BUFFER_LEN;
        int offset = 0;
        byte[] buffer = new byte[len];
        try {
            GZIPInputStream is = new GZIPInputStream(new ByteArrayInputStream(in));
            while( (read=is.read(buffer, offset, len-offset)) != -1 ){
                if(read == 0)
                    continue;// nothing read, but not finished.
                offset += read;
                if(offset < len)
                    continue;// contains free space.
                assert(offset == len);
                int newLen = Math.min(len*2, limit);
                if (newLen > len) {
                    byte[] newBuf = new byte[newLen];
                    System.arraycopy(buffer, 0, newBuf, 0, len);
                    buffer = null; // release memory
                    buffer = newBuf;
                    len = newLen;
                } else {
                    return buffer;
                }
            }
            byte[] res = new byte[offset];
            System.arraycopy(buffer, 0, res, 0, res.length);
            buffer = null;
            return res;
        } catch (IOException e) {
            return null;
        }
        
    }
    
    /**
     * 压缩一段buffer。如果不能压缩，则返回null.
     * 
     * @param in
     * @return
     */
    public static byte[] compress(byte[] in) {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        GZIPOutputStream gos;
        try {
            gos = new GZIPOutputStream(bos);
            gos.write(in);
            gos.close();
            bos.close();
            return bos.toByteArray();
        } catch (IOException e) {
            return null;
        } 
    }

    public static boolean mayBeGzipFormat(byte[] in) {
        if(in.length < 2)
            return false;
        return (in[0]==(byte)0x1f && in[1]==(byte)0x8b);
    }
    
    public static byte[] tryUncompress(byte[] in, int limit) {
        int read = 0;
        int len = INIT_BUFFER_LEN;
        int offset = 0;
        byte[] buffer = new byte[len];
        GZIPInputStream is = null;
        try {
            is = new GZIPInputStream(new ByteArrayInputStream(in));
            while( (read=is.read(buffer, offset, len-offset)) != -1 ){
                if(read == 0)
                    continue;// nothing read, but not finished.
                offset += read;
                if(offset < len)
                    continue;// contains free space.
                assert(offset == len);
                int newLen = Math.min(len*2, limit);
                if (newLen > len) {
                    byte[] newBuf = new byte[newLen];
                    System.arraycopy(buffer, 0, newBuf, 0, len);
                    buffer = null; // release memory
                    buffer = newBuf;
                    len = newLen;
                } else {
                    return buffer;
                }
            }
        } catch (IOException e) {
            //ignore
        } finally {
            if(is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                }
            }
        }
        byte[] res = new byte[offset];
        System.arraycopy(buffer, 0, res, 0, res.length);
        buffer = null;
        return res;
    }
}
