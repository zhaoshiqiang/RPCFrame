package toolbox.misc;

import java.io.IOException;
import java.security.MessageDigest;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * Simple util to do md5 digest.
 * 
 * @author river
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class MD5 {

    private static final char[] HEX_DIGITS = {
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd',
        'e', 'f'
    };

    /**
     * Return the string format of md5 digest(in lower case). utf-8 is the
     * encoding used during md5.
     * 
     * @see #digest(String, String)
     */
    public static String digest(String s) {
        return digest(s, "utf-8");
    }

    /**
     * Return the string format of md5 digest(in lower case).
     * 
     * @param s
     *            the source string
     * @param charset
     *            the charset used to convert string into bytes before digest
     * @return the digest in string format(lower case)
     */
    public static String digest(String s, String charset) {
        MessageDigest digester;
        try {
            digester = MessageDigest.getInstance("MD5");
        } catch (Exception e) {
            throw new RuntimeException("no md5 support", e);
        }

        try {
            digester.update(s.getBytes(charset));
        } catch (IOException e) {
            digester.update(s.getBytes());
        }

        byte[] digest = digester.digest();
        StringBuilder buf = new StringBuilder(digest.length * 2);
        for (int i = 0; i < digest.length; i++) {
            int b = digest[i];
            buf.append(HEX_DIGITS[(b >> 4) & 0xf]);
            buf.append(HEX_DIGITS[b & 0xf]);
        }
        return buf.toString();
    }

    /**
     * Return the low 8 bytes as long of md5 digest.
     * 
     * @param s
     * @param charset
     * @return
     */
    public static long longDigest(String s, String charset) {
        MessageDigest digester;
        try {
            digester = MessageDigest.getInstance("MD5");
        } catch (Exception e) {
            throw new RuntimeException("no md5 support", e);
        }

        try {
            digester.update(s.getBytes(charset));
        } catch (IOException e) {
            digester.update(s.getBytes());
        }

        byte[] digest = digester.digest();
        long value = 0;
        for (int i = 0; i < 8; i++)
            value |= ((digest[i] & 0xffL) << (8 * (7 - i)));
        return value;
    }

}
