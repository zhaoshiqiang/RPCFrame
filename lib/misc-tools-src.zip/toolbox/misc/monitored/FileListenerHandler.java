package toolbox.misc.monitored;

import java.io.File;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * File listeners notifier
 * 
 * @author why
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class FileListenerHandler extends AbstractListenerHandler<IFileListener> {

    public void fileChanged(File file, int evt) {
        notifyAllListeners(file, evt);
    }

    @Override
    protected void notifyListener(IFileListener listener, Object... args) {
        File file = (File) args[0];
        int evt = (Integer) args[1];
        listener.fileChanged(file, evt);
    }

}
