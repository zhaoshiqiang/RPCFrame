package toolbox.misc.monitored;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Arrays;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

@InterfaceAudience.Public
@InterfaceStability.Evolving
public class FileUtils {

    /**
     * 检查两个文件内容是否相同 (Copied from web-tools HttpResource)
     * 
     * @param f1
     * @param f2
     * @return
     * @throws IOException
     */
    public static boolean equals(File f1, File f2) throws IOException {
        if (f1.length() != f2.length())
            return false;

        FileInputStream is1 = new FileInputStream(f1);
        byte[] buf1;
        try {
            buf1 = new byte[is1.available()];
            is1.read(buf1);
        } finally {
            is1.close();
        }

        FileInputStream is2 = new FileInputStream(f2);
        byte[] buf2;
        try {
            buf2 = new byte[is2.available()];
            is2.read(buf2);
        } finally {
            is2.close();
        }

        return Arrays.equals(buf1, buf2);
    }

    /**
     * 检查文件f的内容是否与data相同
     * 
     * @param f
     * @param data
     * @return
     * @throws IOException
     */
    public static boolean equals(File f, byte[] data) throws IOException {
        if (f.length() != data.length)
            return false;

        FileInputStream is = new FileInputStream(f);
        byte[] buf;
        try {
            buf = new byte[is.available()];
            is.read(buf);
        } finally {
            is.close();
        }
        return Arrays.equals(buf, data);
    }

}
