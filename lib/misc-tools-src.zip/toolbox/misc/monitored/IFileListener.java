package toolbox.misc.monitored;

import java.io.File;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * 监听文件变化的监听器接口
 * 
 * @author why
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public interface IFileListener {
    public static final int EVT_FILE_CREATED = 1; // 文件新出现

    public static final int EVT_FILE_MODIFIED = 2; // 文件被修改

    public static final int EVT_FILE_REMOVED = 3; // 文件被移除

    void fileChanged(File file, int evt);
}
