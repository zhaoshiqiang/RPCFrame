/**
 * 
 */
package toolbox.misc.monitored;

import java.io.File;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import toolbox.misc.LogFormatter;
import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * 监听多个不同文件的检测器，只监控被注册的文件
 * 
 * @author why
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class MultiFilesMonitor {
    private static final Logger LOG = LogFormatter.getLogger(MultiFilesMonitor.class);

    class MonitorEntry {
        FileListenerHandler handler; // notifier

        long lastModified; // last modified time of the file

        public MonitorEntry(File file) {
            handler = new FileListenerHandler();
            this.lastModified = file.exists() ? file.lastModified() : -1;
        }
    }

    private ConcurrentHashMap<File, MonitorEntry> monitored = new ConcurrentHashMap<File, MonitorEntry>();

    public static final long DEFAULT_CHECK_INTERVAL = 1000 * 60; // 1 minute

    private ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(
            1, new ThreadFactory() {
                public Thread newThread(Runnable r) {
                    Thread t = new Thread(r, "files-monitor-thread");
                    t.setDaemon(true);
                    return t;
                }
            });

    public void startMonitor(long checkInterval) {
        scheduler.scheduleWithFixedDelay(new FilesMonitorNotifier(), 100,
                checkInterval, TimeUnit.MILLISECONDS);
    }

    public void stopMonitor() {
        scheduler.shutdown();
        while (!scheduler.isTerminated()) {
            try {
                scheduler.awaitTermination(2, TimeUnit.SECONDS);
            } catch (InterruptedException e) {
                LOG.log(Level.WARNING, "interrupted", e);
            }
        }
    }

    /**
     * register the file to monitored and the listener to notified
     * 
     * @param file
     * @param listener
     */
    public synchronized void registerFileListener(File file,
            IFileListener listener) {
        MonitorEntry entry = monitored.get(file);
        if (entry == null) {
            entry = new MonitorEntry(file);
            monitored.put(file, entry);
        }
        entry.handler.addListener(listener);
    }

    public synchronized void deregisterFileListener(File file,
            IFileListener listener) {
        MonitorEntry entry = monitored.get(file);
        if (entry != null) {
            entry.handler.removeListener(listener);
            if (entry.handler.getListenerCount() == 0) {
                monitored.remove(file);
            }
        }
    }

    private class FilesMonitorNotifier implements Runnable {

        public void run() {
            for (Map.Entry<File, MonitorEntry> entry: monitored.entrySet()) {
                File file = entry.getKey();
                MonitorEntry me = entry.getValue();
                if (file.exists()) {
                    long newModified = file.lastModified();
                    if (newModified != me.lastModified) {
                        int evt = me.lastModified == -1 ? IFileListener.EVT_FILE_CREATED
                                : IFileListener.EVT_FILE_MODIFIED;
                        me.lastModified = newModified;
                        me.handler.fileChanged(file, evt);
                    }
                } else if (me.lastModified != -1) {
                    me.lastModified = -1;
                    me.handler.fileChanged(file, IFileListener.EVT_FILE_REMOVED);
                }
            }
        }

    }

}
