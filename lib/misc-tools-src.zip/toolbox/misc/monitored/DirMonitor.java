package toolbox.misc.monitored;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * A monitor which checks periodically whether the files in a local file directory have changed.
 * 
 * NOTICE: 
 *     the listener parameter of FileMonitor.addListener should be a strong reference,
 * i.e. you should never call addListener(new XXFileListener()). you should use like this:
 *     
 *     private FileListener listener = new XXFileListener(); // class's member
 *     
 *     dirMonitor.addListener(listener); // in class's function
 *     
 * the life of listener should be the same with the it's owner.
 * 
 * @author why
 * @since 2007-5-16
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class DirMonitor implements IMonitoredFilesResource {

    public static final long DEFAULT_CHECK_INTERVAL = 1000 * 60; // 1 minute

    private ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(
            1, new ThreadFactory() {
                public Thread newThread(Runnable r) {
                    Thread t = new Thread(r, "dir-monitor-thread");
                    t.setDaemon(true);
                    return t;
                }
            });

    private FileListenerHandler listeners = new FileListenerHandler();

    private FilenameFilter filenameFilter;

    private File dir; // dir to monitor

    private ConcurrentHashMap<File, Long> files = new ConcurrentHashMap<File, Long>();

    public DirMonitor(File dir, FilenameFilter filenameFilter) {
        this(dir, filenameFilter, DEFAULT_CHECK_INTERVAL);
    }

    /**
     * @param dir
     *            directory to monitored
     * @param filenameFilter
     *            filename filter, null means all files in the dir is monitored
     * @param checkInterval
     *            check thread scheduled interval
     */
    public DirMonitor(File dir, FilenameFilter filenameFilter,
            long checkInterval) {
        this.dir = dir;
        this.filenameFilter = filenameFilter;

        files.clear();
        File[] fileArr = dir.listFiles(filenameFilter);
        for (File file: fileArr) {
            files.put(file, file.lastModified());
        }

        scheduler.scheduleWithFixedDelay(new FileMonitorNotifier(), 100,
                checkInterval, TimeUnit.MILLISECONDS);
    }

    public void registerListener(IFileListener listener) {
        listeners.addListener(listener);
    }

    private class FileMonitorNotifier implements Runnable {

        public void run() {
            // check those already in files Map
            Collection<File> resources = new ArrayList<File>(files.keySet());
            ArrayList<File> toRemove = new ArrayList<File>();
            for (Iterator<File> iter = resources.iterator(); iter.hasNext();) {
                File file = (File) iter.next();
                if (file.exists()) {
                    long lastModified = files.get(file).longValue();
                    long newModified = file.lastModified();

                    if (newModified != lastModified) {
                        files.put(file, newModified);
                        listeners.fileChanged(file,
                                IFileListener.EVT_FILE_MODIFIED);
                    }

                } else {
                    // file removed
                    //files.remove(file);
                    toRemove.add(file);
                    listeners.fileChanged(file, IFileListener.EVT_FILE_REMOVED);
                }
            }

            for (File file: toRemove) {
                files.remove(file);
            }

            // check new files
            File[] fileArr = dir.listFiles(filenameFilter);
            for (File file: fileArr) {
                if (!files.containsKey(file)) {
                    files.put(file, file.lastModified());
                    listeners.fileChanged(file, IFileListener.EVT_FILE_CREATED);
                }
            }

        }

    }

    public File[] getFiles() {
        return files.keySet().toArray(new File[files.size()]);
    }

}
