package toolbox.misc;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * Utility to define some units.
 * 
 * @author river
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class UnitUtils {

    public static final long SECOND = 1000;

    public static final long MINUTE = 60 * SECOND;

    public static final long HOUR = 60 * MINUTE;

    public static final long DAY = 24 * HOUR;

    public static final int MINUTE_SEC = 60;

    public static final int HOUR_SEC = 60 * MINUTE_SEC;

    public static final int DAY_SEC = 24 * HOUR_SEC;

    public static final long K = 1024L;

    public static final long M = 1024 * K;

    public static final long G = 1024 * M;

    /**
     * parse a size string, such as "1k", "2G", "3M", as a numeric long. "1k"
     * will be 1024.
     * 
     * @param sizeString
     *            the size string
     * @param def
     *            default value
     * @return the numeric size
     */
    public static long parseSize(String sizeString, long def) {
        if (sizeString == null || sizeString.length() == 0)
            return def;
        long unit = 1;
        char c = sizeString.charAt(sizeString.length() - 1);
        switch (c) {
            case 'g':
            case 'G':
                unit = G;
                break;
            case 'k':
            case 'K':
                unit = K;
                break;
            case 'M':
            case 'm':
                unit = M;
                break;
        }
        if (unit != 1)
            sizeString = sizeString.substring(0, sizeString.length() - 1);
        try {
            return unit * Long.parseLong(sizeString);
        } catch (Exception e) {
            return def;
        }
    }

    /**
     * Parse time string, such as "1m", "2d", into milliseconds,
     * 
     * @param timeString
     * @param def
     * @return
     */
    public static long parseTime(String timeString, long def) {
        if (timeString == null || timeString.length() == 0)
            return def;

        long unit = 1;
        char c = timeString.charAt(timeString.length() - 1);
        switch (c) {
            case 's':
            case 'S':
                unit = SECOND;
                break;
            case 'm':
            case 'M':
                unit = MINUTE;
                break;
            case 'h':
            case 'H':
                unit = HOUR;
                break;
            case 'd':
            case 'D':
                unit = DAY;
                break;
        }
        if (unit != 1)
            timeString = timeString.substring(0, timeString.length() - 1);
        try {
            return unit * Long.parseLong(timeString);
        } catch (Exception e) {
            return def;
        }
    }
}
