package toolbox.misc;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * 用于计算hashcode的工具。
 * 
 * @author Feng Jiang (Feng.a.Jiang@gmail.com)
 * @since Apr 9, 2007
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class HashUtils {

    public static final int SEED = 37;

    public static final int MULTIPLY = 19;

    public static int hashCode(Object... hashs) {
        int hash = SEED;
        for (int i = 0; i < hashs.length; i++)
            hash = hash * MULTIPLY + hashCode(hashs[i]);
        return hash;
    }

    public static int hashCode(Object object) {
        if (!object.getClass().isArray())
            return object.hashCode();

        if (object instanceof long[]) {
            return hashCode((long[]) object);
        } else if (object instanceof int[]) {
            return hashCode((int[]) object);
        } else if (object instanceof short[]) {
            return hashCode((short[]) object);
        } else if (object instanceof char[]) {
            return hashCode((char[]) object);
        } else if (object instanceof byte[]) {
            return hashCode((byte[]) object);
        } else if (object instanceof double[]) {
            return hashCode((double[]) object);
        } else if (object instanceof float[]) {
            return hashCode((float[]) object);
        } else if (object instanceof boolean[]) {
            return hashCode((boolean[]) object);
        } else {
            return hashCode((Object[]) object);
        }
    }

    public static int hashCode(int[] hashs) {
        int hash = SEED;
        for (int i = 0; i < hashs.length; i++) {
            hash = hash * MULTIPLY + hashCode(hashs[i]);
        }
        return hash;
    }

    public static int hashCode(long[] hashs) {
        int hash = SEED;
        for (int i = 0; i < hashs.length; i++) {
            hash = hash * MULTIPLY + hashCode(hashs[i]);
        }
        return hash;
    }

    public static int hashCode(short[] hashs) {
        int hash = SEED;
        for (int i = 0; i < hashs.length; i++) {
            hash = hash * MULTIPLY + hashCode(hashs[i]);
        }
        return hash;
    }

    public static int hashCode(char[] hashs) {
        int hash = SEED;
        for (int i = 0; i < hashs.length; i++) {
            hash = hash * MULTIPLY + hashCode(hashs[i]);
        }
        return hash;
    }

    public static int hashCode(byte[] hashs) {
        int hash = SEED;
        for (int i = 0; i < hashs.length; i++) {
            hash = hash * MULTIPLY + hashCode(hashs[i]);
        }
        return hash;
    }

    public static int hashCode(double[] hashs) {
        int hash = SEED;
        for (int i = 0; i < hashs.length; i++) {
            hash = hash * MULTIPLY + hashCode(hashs[i]);
        }
        return hash;
    }

    public static int hashCode(float[] hashs) {
        int hash = SEED;
        for (int i = 0; i < hashs.length; i++) {
            hash = hash * MULTIPLY + hashCode(hashs[i]);
        }
        return hash;
    }

    public static int hashCode(boolean[] hashs) {
        int hash = SEED;
        for (int i = 0; i < hashs.length; i++) {
            hash = hash * MULTIPLY + hashCode(hashs[i]);
        }
        return hash;
    }

}
