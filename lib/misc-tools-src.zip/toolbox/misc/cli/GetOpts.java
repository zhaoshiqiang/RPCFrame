package toolbox.misc.cli;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import toolbox.misc.UnitUtils;
import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * Parse the command line arguments into options. we can accept like args now.
 * There should be two types of arguments:
 * <ul>
 * <li>options: [-optname optvalue | -optname]
 * <li>pure values(remains): values without optname, and string "-" is also
 * regarded as pure value
 * </ul>
 * The control string tells how to process the options, for example,
 * "ab:[cd][ef]:" means:
 * <ul>
 * <li>there could be option "-a" without value
 * <li>there could be option "-b" with value after it, such as "-b xxx"
 * <li>there could be option "-cd" without value
 * <li>there could be option "-ef" with value after it
 * </ul>
 * So one reasonable command line could be
 * "-a -b value1 -cd -ef value2 -x1 -x2 ana_value1". Those anonymous option
 * which is not defined in the control string, for example, "-x1" and "-x2" in
 * the above string, should be also processed. Whether the anonymous option has
 * value is determined by where the argument after it is started with "-".
 * 
 * @author river
 * @deprecated use {@link Options} instead.
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class GetOpts {
    private Map<String, String[]> opts = new HashMap<String, String[]>();

    private List<String> remains = new ArrayList<String>();

    private Map<String, Boolean> controls = new HashMap<String, Boolean>();

    /**
     * Contruct option parser and parse the given args by controlString.
     * 
     * @param controlString
     * @param args
     */
    public GetOpts(String controlString, String[] args) {
        parseControls(controlString);
        parse(args);
    }

    /**
     * Parse the controlString into option definitions.
     * 
     * @param controlString
     */
    private void parseControls(String controlString) {
        int len = controlString.length();

        boolean stringArg = false;
        String lastControl = null;
        StringBuilder lastControlBuffer = new StringBuilder();

        for (int i = 0; i < len; i++) {
            char ch = controlString.charAt(i);
            if (stringArg) {
                if (ch == ']') {
                    stringArg = false;
                    lastControl = lastControlBuffer.toString();
                    lastControlBuffer.setLength(0);
                    controls.put(lastControl, false);
                } else {
                    lastControlBuffer.append(ch);
                    continue;
                }
            } else if (ch == '[') {
                stringArg = true;
            } else if (ch == ':') {
                if (lastControl != null)
                    controls.put(lastControl, true);
            } else {
                lastControl = String.valueOf(ch);
                controls.put(lastControl, false);
            }
        }
    }

    /**
     * Parse the arguments by option definitions.
     * 
     * @param args
     */
    private void parse(String[] args) {
        for (int i = 0; i < args.length; i++) {
            String arg = args[i];
            if (arg.startsWith("-") && arg.length() >= 2) {
                String opname = arg.substring(1);
                Boolean hasArg = controls.get(opname);
                String argValue = "";

                if (hasArg != null) {
                    if (hasArg) {
                        argValue = args[++i];
                    }
                } else {
                    // anonymous option
                    if (i + 1 < args.length) {
                        if (args[i + 1].length() < 2
                                || !args[i + 1].startsWith("-")) {
                            argValue = args[++i];
                        }
                    }
                }

                String[] oldOpt = opts.get(opname);
                String[] newOpt;
                if (oldOpt == null) {
                    newOpt = new String[] {
                        argValue
                    };
                } else {
                    newOpt = new String[oldOpt.length + 1];
                    System.arraycopy(oldOpt, 0, newOpt, 0, oldOpt.length);
                    newOpt[oldOpt.length] = argValue;
                }
                opts.put(opname, newOpt);
                remains.clear();
            } else {
                remains.add(arg);
            }
        }
    }

    /**
     * Return the last value of option, or null if no setting.
     * 
     * @param opname
     *            the name of option
     * @return the last value of option, or null if no setting
     */
    public String getOpt(String opname) {
        String[] opt = opts.get(opname);
        if (opt == null || opt.length == 0)
            return null;
        else
            return opt[opt.length - 1];
    }

    /**
     * Return the last value of option, or default value if no setting.
     * 
     * @param opname
     *            the name of option
     * @param def
     *            default value
     * @return The option value (string type)
     */
    public String getOpt(String opname, String def) {
        String result = getOpt(opname);
        return (result == null) ? def : result;
    }

    /**
     * Parse and return the option as int, or default if no option value or
     * number format error.
     * 
     * @param opname
     *            the name of option
     * @param def
     *            default value
     * @return the option value (int type)
     */
    public int getInt(String opname, int def) {
        String s = getOpt(opname);
        if (s == null)
            return def;

        try {
            return Integer.parseInt(s);
        } catch (Exception e) {
            return def;
        }
    }

    /**
     * Parse and return option as long, or default if no option value or number
     * format error.
     * 
     * @param opname
     *            the name of option
     * @param def
     *            default value
     * @return the option value (long type)
     */
    public long getLong(String opname, long def) {
        String s = getOpt(opname);
        if (s == null)
            return def;

        try {
            return Long.parseLong(s);
        } catch (Exception e) {
            return def;
        }
    }

    /**
     * Parse and return option as time(in milliseconds).
     * 
     * @param opname
     * @param def
     * @return
     */
    public long getTime(String opname, long def) {
        String s = getOpt(opname);
        if (s == null)
            return def;
        else {
            return UnitUtils.parseTime(s, def);
        }
    }

    /**
     * Parse and return option as size(in bytes).
     * 
     * @param opname
     * @param def
     * @return
     */
    public long getSize(String opname, long def) {
        String s = getOpt(opname);
        if (s == null)
            return def;
        else {
            return UnitUtils.parseSize(s, def);
        }
    }

    /**
     * Parse and return option as float, or default if no option value or number
     * format error.
     * 
     * @param opname
     *            the name of option
     * @param def
     *            default value
     * @return option value (float type)
     */
    public float getFloat(String opname, float def) {
        String s = getOpt(opname);
        if (s == null)
            return def;

        try {
            return Float.parseFloat(s);
        } catch (Exception e) {
            return def;
        }
    }

    /**
     * Parse and return option as double, or default if no option value or
     * number format error.
     * 
     * @param opname
     *            the name of the option
     * @param def
     *            default value
     * @return double value of an option
     */
    public double getDouble(String opname, double def) {
        String s = getOpt(opname);
        if (s == null)
            return def;

        try {
            return Double.parseDouble(s);
        } catch (Exception e) {
            return def;
        }

    }

    /**
     * Return all the values of option, or null if no setting.
     * 
     * @param opname
     *            the name of option
     * @return the option value (array of strings)
     */
    public String[] getOptValue(String opname) {
        return opts.get(opname);
    }

    /**
     * Check if one option is set.
     * 
     * @param c
     *            the name of option
     * @return whether the option is set
     */
    public boolean hasOption(String c) {
        return opts.get(c) != null;
    }

    /**
     * Return the number of remains.
     * 
     * @return number all the non-option arguments
     */
    public int getRemainsCount() {
        return remains.size();
    }

    /**
     * Return all the non-option arguments. If there is no non-option value,
     * zero-size string array should be returned.
     * 
     * @return all the non-option arguments, never returns null
     */
    public String[] getRemains() {
        String[] result = new String[remains.size()];
        remains.toArray(result);
        return result;
    }

    /**
     * Return the remained parameter at given index.
     * 
     * @param i
     *            the i-th remained parameter
     * @return the i-th remained parameter
     */
    public String getRemain(int i) {
        return remains.get(i);
    }

    public String toString() {
        StringBuilder builder = new StringBuilder();
        for (Iterator<String> it = opts.keySet().iterator(); it.hasNext();) {
            String c = it.next();
            builder.append(c).append(':').append(Arrays.toString(opts.get(c))).append(
                    ' ');
        }

        for (Iterator<String> it = remains.iterator(); it.hasNext();) {
            builder.append(it.next()).append(' ');
        }

        return builder.toString();
    }

}
