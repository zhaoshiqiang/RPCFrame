/**
 * @(#)NamePreserveRunnable.java, 2008-6-26. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.misc;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * Abstract runnable which change the thread name to runnable name during
 * execution.
 * 
 * @author river
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public abstract class NamePreserveRunnable implements Runnable {
    protected Object[] params;

    protected String name;

    /**
     * Create instance with given name.
     * 
     * @param name
     */
    public NamePreserveRunnable(String name) {
        this.name = name;
        this.params = new Object[0];
    }

    /**
     * Create instance with given name and parameters. The parameters field
     * <code>{@link #params}</code> can be accessed in subclass in method
     * {@link #execute()}.
     * 
     * @param name
     * @param params
     */
    public NamePreserveRunnable(String name, Object... params) {
        this.name = name;
        this.params = params;
    }

    private void setName(Thread t, String name) {
        try {
            t.setName(name);
        } catch (Exception e) {
            // probably security exception, ignore it
        }
    }

    /**
     * Subclass should implement this method instead of {@link Runnable#run()}.
     */
    protected abstract void execute();

    /**
     * This method is declared as final and deny rewriting.
     */
    public final void run() {
        Thread currentThread = Thread.currentThread();
        String threadName = currentThread.getName();

        // include session address in thread name
        String newName = this.name;
        setName(currentThread, newName);
        try {
            execute();
        } finally {
            setName(currentThread, threadName);
        }
    }

}
