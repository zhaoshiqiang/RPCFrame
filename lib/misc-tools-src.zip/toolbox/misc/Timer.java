/**
 * @(#)Timer.java, 2009-5-12. 
 * 
 * Copyright 2009 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.misc;

import java.util.HashSet;
import java.util.Set;
import java.util.logging.Logger;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * 计时器工具，方便为程序中的一段代码运行计时。
 * 
 * @author yixun
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class Timer {

    public static final Logger LOG = LogFormatter.getLogger(Timer.class);

    public static final String UNIT_DAY = "d";

    public static final String UNIT_HOUR = "h";

    public static final String UNIT_MINUTE = "m";

    public static final String UNIT_SECOND = "s";

    public static final String UNIT_MILLISECOND = "ms";

    private static final Set<String> VALID_UNIT_SET = new HashSet<String>();
    static {
        VALID_UNIT_SET.add(UNIT_DAY);
        VALID_UNIT_SET.add(UNIT_HOUR);
        VALID_UNIT_SET.add(UNIT_MINUTE);
        VALID_UNIT_SET.add(UNIT_SECOND);
        VALID_UNIT_SET.add(UNIT_MILLISECOND);
    }

    private long startTime;

    private long endTime;

    private long cost = 0;

    private String maxUnit;

    /**
     * 缺省构造函数。
     */
    public Timer() {
        this(UNIT_HOUR);
    }

    /**
     * 构造函数，设置计时器打印耗时的最大计量单位，可以是毫秒(ms)，秒(s)，分钟(m)，小时(h)
     * 或者天(d)，当设置最大计量单位为ms时，计时精度也为ms，否则计时精度都为s.
     * 
     * @param maxUnit
     */
    public Timer(String maxUnit) {
        if (!VALID_UNIT_SET.contains(maxUnit)) {
            throw new RuntimeException("error maxUnit params, it should be "
                    + UNIT_MILLISECOND + ", " + UNIT_SECOND + ", "
                    + UNIT_MINUTE + " or " + UNIT_HOUR);
        }
        this.maxUnit = maxUnit;
    }

    /**
     * 开始计时。
     * 
     * @author yixun
     */
    public void start() {
        startTime = System.currentTimeMillis();
    }

    /**
     * 结束计时，并累加耗时。
     * 
     * @author yixun
     */
    public void end() {
        endTime = System.currentTimeMillis();
        cost += endTime - startTime;
    }

    /**
     * 计时器清零。
     * 
     * @author yixun
     */
    public void clear() {
        this.startTime = 0;
        this.endTime = 0;
        this.cost = 0;
    }

    /**
     * 获得耗时，并以时，分，秒的形式打印耗时
     * 
     * @author yixun
     * @return
     */
    public long cost() {
        long costSeconds = cost / 1000;
        long costHour = costSeconds / 3600;
        long remains = costSeconds % 3600;
        long costMinute = remains / 60;
        long costSecond = remains % 60;
        if (maxUnit.equals(UNIT_MILLISECOND)) {
            LOG.info("cost: " + cost + "ms.");
        } else if (maxUnit.equals(UNIT_SECOND)) {
            LOG.info("cost: " + costSeconds + "s.");
        } else if (maxUnit.equals(UNIT_MINUTE)) {
            LOG.info("cost: " + (costHour * 60 + costMinute) + "m" + costSecond
                    + "s.");
        } else if (maxUnit.equals(UNIT_HOUR)) {
            LOG.info("cost: " + costHour + "h" + costMinute + "m" + costSecond
                    + "s");
        } else if (maxUnit.equals(UNIT_DAY)) {
            long day = costHour / 24;
            costHour = costHour % 24;
            LOG.info("cost: " + day + "d" + costHour + "h" + costMinute + "m"
                    + costSecond + "s");
        }
        return cost;
    }
}
