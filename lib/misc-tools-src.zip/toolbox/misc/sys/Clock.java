/**
 * @(#)Clock.java, 2007-11-24. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.misc.sys;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * Clock interface to replace {@link System#currentTimeMillis()}, so we can
 * easily control the time in testcases.
 * 
 * @author river
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class Clock {

    /**
     * Interface for clock, inherits this interface to implement your clock.
     * 
     * @see StandardClock
     * @author river
     */
    @InterfaceAudience.Public
    @InterfaceStability.Evolving
    public static interface ClockIface {
        public long currentTimeMillis();
    }

    /**
     * Standard clock implementation, return the time by call
     * {@link System#currentTimeMillis()}.
     * 
     * @author river
     */
    @InterfaceAudience.Public
    @InterfaceStability.Evolving
    public static class StandardClock implements ClockIface {
        public final long currentTimeMillis() {
            return System.currentTimeMillis();
        }
    }

    /**
     * Manual clock whose time only changed when setTime called.
     * 
     * @author river
     */
    @InterfaceAudience.Public
    @InterfaceStability.Evolving
    public static class ManualClock implements ClockIface {
        private long current = System.currentTimeMillis();

        public long currentTimeMillis() {
            return current;
        }

        public void setTime(long current) {
            this.current = current;
        }

        public void advance(long a) {
            this.current += a;
        }

    }

    private static StandardClock standardClock = new StandardClock();

    private static ClockIface clock = standardClock;

    /**
     * Set the clock implementation, or null to use system clock.
     * 
     * @param impl
     */
    public static void setClock(ClockIface impl) {
        clock = impl == null ? standardClock : impl;
    }

    /**
     * Return current time in milliseconds.
     * 
     * @return
     */
    public static long currentTimeMillis() {
        return clock.currentTimeMillis();
    }

}
