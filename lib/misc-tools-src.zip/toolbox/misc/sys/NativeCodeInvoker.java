package toolbox.misc.sys;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * 用于调用外部程序的工具类，可以比较方便地设置/获取执行程序的输入输出.
 * 
 * @author river
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class NativeCodeInvoker {
    private Process process;

    private OutputStream stdout;

    private OutputStream stderr;

    private InputStream stdin;

    private File workDir;

    public NativeCodeInvoker() {
        stdout = System.out;
        stdin = System.in;
        stderr = System.err;
    }

    /**
     * 设置程序的标准输出，程序输出的数据会写入到这个标准输出中.
     * 
     * @param os
     *            输出流
     */
    public void setStdOut(OutputStream os) {
        stdout = os;
    }

    /**
     * 获取程序当前的标准输出.
     * 
     * @return 标准输出的句柄
     */
    public OutputStream getStdOut() {
        return stdout;
    }

    /**
     * 设置程序的标准输入，程序执行过程中的会从这里读取标准输入. 默认是系统的标准输入。如果不使用应该设置成NULL,
     * 否则调用结束后会有不退出的PipedOut进程
     * 
     * @param in
     */
    public void setStdIn(InputStream in) {
        stdin = in;
    }

    public InputStream getStdIn() {
        return stdin;
    }

    /**
     * 设置程序的标准错误输出.
     * 
     * @param os
     */
    public void setStdErr(OutputStream os) {
        stderr = os;
    }

    public OutputStream getStdErr() {
        return stderr;
    }

    /**
     * 设置程序的执行路径.
     * 
     * @param dir
     */
    public void setWorkDir(File dir) {
        workDir = dir;
    }

    /**
     * 执行给定的命令.
     * 
     * @param command
     * @throws IOException
     */
    public void exec(String command) throws IOException {
        if (workDir == null)
            process = Runtime.getRuntime().exec(command);
        else
            process = Runtime.getRuntime().exec(command, null, workDir);

        Thread t = new Thread(new PipeOut(process.getInputStream(), stdout),
                "ProcessToStdout");
        t.setDaemon(true);
        t.start();

        t = new Thread(new PipeOut(process.getErrorStream(), stderr),
                "ProcessToStdErr");
        t.setDaemon(true);
        t.start();

        if (stdin != null) {
            t = new Thread(new PipeOut(stdin, process.getOutputStream()),
                    "ProcessFromStdin");
            t.setDaemon(true);
            t.start();
        }
    }

    /**
     * 等待程序执行完成.
     * 
     * @return 程序的返回值
     * @throws InterruptedException
     */
    public int waitFor() throws InterruptedException {
        if (process != null)
            return process.waitFor();
        else
            return -1;
    }

    /**
     * 返回程序的返回值.
     */
    public int getExitValue() {
        return process.exitValue();
    }

    /**
     * 中止程序的执行.
     */
    public void close() {
        if (process != null)
            process.destroy();
        process = null;
    }

    /**
     * 直接执行一个命令，并且得到它的输出.
     * 
     * @param command
     * @throws IOException
     */
    public static Result execute(String command, File workDir)
            throws IOException {
        return execute(command, workDir, new byte[0]);
    }

    /**
     * 执行执行一个命令，使用指定的输入数据，并且得到它的输出.
     * 
     * @param command
     * @param stdin
     * @throws IOException
     */
    public static Result execute(String command, File workDir, byte[] stdin)
            throws IOException {
        NativeCodeInvoker invoker = new NativeCodeInvoker();
        invoker.setStdIn(new ByteArrayInputStream(stdin));
        ByteArrayOutputStream stdout = new ByteArrayOutputStream();
        ByteArrayOutputStream stderr = new ByteArrayOutputStream();
        invoker.setStdErr(stderr);
        invoker.setStdOut(stdout);
        invoker.setWorkDir(workDir);
        invoker.exec(command);

        int exitValue = -1;
        try {
            exitValue = invoker.waitFor();
        } catch (InterruptedException e) {}

        return new Result(stdout.toByteArray(), stderr.toByteArray(), exitValue);
    }

    @InterfaceAudience.Public
    @InterfaceStability.Evolving
    public static class Result {
        private byte[] stdout;

        private byte[] stderr;

        private int exitValue;

        public Result(byte[] stdout, byte[] stderr, int exitValue) {
            this.stdout = stdout;
            this.stderr = stderr;
            this.exitValue = exitValue;
        }

        public int getExitValue() {
            return exitValue;
        }

        public byte[] getStdout() {
            return stdout;
        }

        public String getStdoutAsString(String charset) {
            if (charset == null) {
                return new String(stdout);
            } else {
                try {
                    return new String(stdout, charset);
                } catch (IOException e) {
                    return new String(stdout);
                }
            }
        }

        public byte[] getStderr() {
            return stderr;
        }

        public String getStderrAsString(String charset) {
            if (charset == null) {
                return new String(stderr);
            } else {
                try {
                    return new String(stderr, charset);
                } catch (IOException e) {
                    return new String(stderr);
                }
            }
        }
    }

    private static class PipeOut implements Runnable {
        private InputStream in;

        private OutputStream out;

        public PipeOut(InputStream in, OutputStream out) {
            this.in = in;
            this.out = out;
        }

        public void run() {
            byte[] buffer = new byte[1024];
            int len;
            try {
                while ((len = in.read(buffer)) > 0) {
                    if (out != null) {
                        out.write(buffer, 0, len);
                        out.flush();
                    }
                }
            } catch (IOException e) {}
        }

    }

}
