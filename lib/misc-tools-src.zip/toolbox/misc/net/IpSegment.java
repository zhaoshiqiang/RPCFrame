package toolbox.misc.net;

import java.util.Comparator;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

@InterfaceAudience.Public
@InterfaceStability.Evolving
public class IpSegment {
    private int start;

    private int end;

    private String property;

    public IpSegment(int start, int end) {
        this(start, end, null);
    }

    public IpSegment(int start, int end, String property) {
        assert (end >= start);
        this.start = start;
        this.end = end;
        this.property = (property == null || property.length() == 0) ? ""
                : property;
    }

    public int getStartIp() {
        return start;
    }

    public int getEndIp() {
        return end;
    }

    public boolean contains(int ip) {
        return ip >= start && ip <= end;
    }

    public String getProperty() {
        return property;
    }

    public int hashCode() {
        return start;
    }

    public boolean equals(Object o) {
        if (o == null || !(o instanceof IpSegment))
            return false;
        if (o == this)
            return true;
        IpSegment other = (IpSegment) o;
        return (this.start == other.start) && (this.end == other.end);
    }

    public String toString() {
        return IpUtils.formatIp(start) + "-" + IpUtils.formatIp(end)
                + (property == null ? "" : " " + property);
    }

    @InterfaceAudience.Public
    @InterfaceStability.Evolving
    public static class StartComparator implements Comparator<IpSegment> {

        public int compare(IpSegment seg1, IpSegment seg2) {
            long first = seg1.start;
            long second = seg2.start;
            return (first == second) ? 0 : ((first - second > 0) ? 1 : -1);
        }
    }
}
