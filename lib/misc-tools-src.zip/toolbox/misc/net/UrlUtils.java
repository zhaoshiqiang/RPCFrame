package toolbox.misc.net;

import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Collections;
import java.util.HashSet;
import java.util.PriorityQueue;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * 和Url相关的工具
 * 
 * @author zhanglh
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class UrlUtils {

    private static final Pattern PROTOCOL_PATTERN = Pattern.compile(""
            + "(^[a-zA-Z]+)://.+");

    /**
     * Get a URL from a String that is probably a URL or a shortened URL
     * 
     * @param input
     * @return null if the String is probably not a URL
     */
    public static URI probablyUrl(String input) {
        if (input == null) {
            return null;
        }
        input = input.trim();
        Matcher protocolMatcher = PROTOCOL_PATTERN.matcher(input);
        String protocol = "http";
        int hostStart = 0;
        if (protocolMatcher.matches()) {
            protocol = protocolMatcher.group(1);
            hostStart = protocol.length() + 3;
        }
        try {
            URI url = new URI(protocol + "://" + input.substring(hostStart));
            String host = getHostFromUrl(url.toString());
            if (IpUtils.isIPv4(host)) {
                try {
                    InetAddress addr = InetAddress.getByName(host);
                    if (IpUtils.isWideAreaEndpoint(addr)) {
                        return url;
                    }
                } catch (Exception e) {
                    return null;
                }
            }
            String[] words = host.split("\\.");
            if (words.length < 2) {
                return null;
            }
            String lastWord = words[words.length - 1].toLowerCase();
            if (!DomainUtils.COUNTRY_SET.contains(lastWord)
                    && !DomainUtils.GROUP_SET.contains(lastWord)) {
                return null;
            }
            return url;
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Split the url into protocol(0), hostname(1), path(2).
     * 
     * @param url
     * @return a string array (length=3), e.g. http://xxx.com/yy/zz/kk protocol:
     *         http hostname: xxx.com path: yy/zz/kk
     */
    public static String[] splitUrl(String url) {
        String[] result = new String[3];

        int i1 = url.indexOf("//");
        if (i1 == -1) {
            result[0] = "http";
            i1 = 0;
        } else {
            if (i1 > 0) {
                result[0] = url.substring(0, i1 - 1);
            } else {
                result[0] = "http";
            }
            i1 = i1 + 2;
        }

        int i2 = url.indexOf('/', i1);
        if (i2 == -1) {
            result[1] = url.substring(i1);
            i2 = url.length();
            result[2] = "";
        } else {
            result[1] = url.substring(i1, i2);
            i2++;
            result[2] = url.substring(i2);
        }
        return result;
    }

    /**
     * 把protocol, hostname, path连在一起成为一个url
     */
    public static String combineUrl(String protocol, String hostname,
            String path) {
        StringBuilder sb = new StringBuilder();
        if (path.charAt(0) == '/') {
            sb.append(protocol).append("://").append(hostname).append(path);
        } else {
            sb.append(protocol).append("://").append(hostname).append("/").append(
                    path);
        }

        return sb.toString();
    }

    static BitSet legalChars = new BitSet(1024);
    static {
        legalChars.set('?');
        legalChars.set('/');
        legalChars.set(';');
        legalChars.set(':');
        legalChars.set('@');
        legalChars.set('&');
        legalChars.set('=');
        legalChars.set('+');
        legalChars.set('$');
        legalChars.set(',');

        // alpha
        for (int i = 'a'; i <= 'z'; i++) {
            legalChars.set(i);
        }
        for (int i = 'A'; i <= 'Z'; i++) {
            legalChars.set(i);
        }

        // digit
        for (int i = '0'; i <= '9'; i++) {
            legalChars.set(i);
        }

        // mark
        legalChars.set('-');
        legalChars.set('_');
        legalChars.set('.');
        legalChars.set('!');
        legalChars.set('~');
        legalChars.set('*');
        legalChars.set('\'');
        legalChars.set('(');
        legalChars.set(')');

        legalChars.set('%');
    }

    private static final char[] HEX = new char[] {
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D',
        'E', 'F'
    };

    /**
     * 将url中的非ascii部分用UTF8表示.
     * 
     * @deprecated use {@link #encodeUrl(String, String)} instead.
     * @param url
     * @return encode成UTF8以后的字符串
     * @throws UnsupportedEncodingException
     */
    public static String encodeToUTF8(String url)
            throws UnsupportedEncodingException {
        StringBuilder builder = new StringBuilder(url.length() * 9);
        int strlen = url.length();

        char c;
        byte b;
        for (int i = 0; i < strlen; i++) {
            c = url.charAt(i);
            if (legalChars.get(c)) {
                builder.append(c);
            } else {
                if ((c >= 0x0001) && (c <= 0x007F)) {
                    b = (byte) c;
                    builder.append('%').append(HEX[(b >> 4) & 0x0f]).append(
                            HEX[b & 0x0f]);
                } else if (c > 0x07FF) {
                    b = (byte) (0xE0 | ((c >> 12) & 0x0F));
                    builder.append('%').append(HEX[(b >> 4) & 0x0f]).append(
                            HEX[b & 0x0f]);
                    b = (byte) (0x80 | ((c >> 6) & 0x3F));
                    builder.append('%').append(HEX[(b >> 4) & 0x0f]).append(
                            HEX[b & 0x0f]);
                    b = (byte) (0x80 | ((c >> 0) & 0x3F));
                    builder.append('%').append(HEX[(b >> 4) & 0x0f]).append(
                            HEX[b & 0x0f]);
                } else {
                    b = (byte) (0xC0 | ((c >> 6) & 0x1F));
                    builder.append('%').append(HEX[(b >> 4) & 0x0f]).append(
                            HEX[b & 0x0f]);
                    b = (byte) (0x80 | ((c >> 0) & 0x3F));
                    builder.append('%').append(HEX[(b >> 4) & 0x0f]).append(
                            HEX[b & 0x0f]);
                }
            }
        }
        return builder.toString();
    }

    private static final int ENCODE_BATCH_SIZE = 8;

    /**
     * Encode the url by gbk charset.
     * 
     * @param url
     * @return
     */
    public static String encodeUrl(String url, String charset) {
        StringBuilder builder = new StringBuilder(url.length() * 9);
        int strlen = url.length();

        CharsetEncoder encoder = Charset.forName(charset).newEncoder();

        CharBuffer charBuffer = CharBuffer.allocate(ENCODE_BATCH_SIZE);
        ByteBuffer byteBuffer = ByteBuffer.allocate(ENCODE_BATCH_SIZE * 4);

        int index = 0;
        while (index < strlen) {
            char ch = url.charAt(index++);
            if (legalChars.get(ch)) {
                builder.append(ch);
            } else {
                charBuffer.clear();
                charBuffer.put(ch);
                int bufLen = 1;
                while (index < strlen && bufLen < ENCODE_BATCH_SIZE) {
                    ch = url.charAt(index++);
                    if (legalChars.get(ch)) {
                        // put back the legal character
                        index--;
                        break;
                    } else {
                        charBuffer.put(ch);
                        bufLen++;
                    }
                }
                byteBuffer.clear();
                charBuffer.flip();
                encoder.encode(charBuffer, byteBuffer, true);
                byteBuffer.flip();
                int byteNumber = byteBuffer.limit();
                for (int i = 0; i < byteNumber; i++) {
                    byte b = byteBuffer.get();
                    builder.append('%').append(HEX[(b >> 4) & 0x0f]).append(
                            HEX[b & 0x0f]);
                }
            }
        }
        return builder.toString();
    }

    /**
     * 得到一个url的path部分 e.g., "http://www.sohu.com/index.jsp?sid=1", returns
     * "/index.jsp".
     * 
     * @param url
     *            the url
     * @return the path part of the url
     */
    public static String getPathFromUrl(String url) {
        int i1 = url.indexOf("//");
        if (i1 == -1) {
            i1 = 0;
        } else {
            i1 = i1 + 2;
        }

        int i2 = url.indexOf('/', i1);
        if (i2 < 0) {
            return "";
        } else {
            int i3 = url.indexOf('?', i2);
            if (i3 < 0)
                return url.substring(i2);
            else
                return url.substring(i2, i3);
        }
    }

    /**
     * Return the whole query part of a url. e.g.,
     * "http://www.sohu.com/index.jsp?sid=1", returns "/index.jsp?sid=1".
     * "http://www.sohu.com/index.jsp", returns "/index.jsp".
     * 
     * @param url
     *            the url
     * @return the query part of a url XXX
     *         这里的query的含义和通常的(rfc2396上的)query含义不太一样。 rfc上的query是?之后的部分,
     *         而这里的query还包含了path的一部分
     */
    public static String getQueryFromUrl(String url) {
        int pos = url.indexOf("//");
        if (pos >= 0) {
            pos = pos + 2;
        } else {
            pos = 0;
        }
        if (pos < url.length() - 1) {
            int pos1 = url.indexOf('/', pos);
            if (pos1 >= 0) {
                return url.substring(pos1);
            } else {
                return "/";
            }
        } else {
            return "/";
        }
    }

    /**
     * 得到url的query部分。这里的query是指'?'之后的部分 如果'?'不存在，返回""
     * 
     * @param url
     *            the url
     * @return the pure query part of a url
     */
    public static String getPureQueryFromUrl(String url) {
        int pos = url.indexOf('?');
        if (pos < 0)
            return "";
        return url.substring(pos + 1);
    }

    @InterfaceAudience.Public
    @InterfaceStability.Evolving
    public static class UrlParam {
        public final String key;

        public final String value;

        public UrlParam(String key, String value) {
            this.key = key;
            this.value = value;
        }

        @Override
        public String toString() {
            return "<" + key + "," + value + ">";
        }

    }

    /**
     * extract params from url return null if no param is found
     * 
     * @param url
     * @return
     */
    public static ArrayList<UrlParam> getParams(String url) {
        int pos = url.indexOf('?');
        if (pos < 0 || pos >= url.length() - 1)
            return null;

        String query = url.substring(pos + 1);
        String[] params = query.split("&");
        if (params.length < 1)
            return null;
        ArrayList<UrlParam> list = new ArrayList<UrlParam>();
        for (String param: params) {
            if (param.length() < 1)
                continue;
            int eqIndex = param.indexOf("=");
            if (eqIndex < 0) {
                list.add(new UrlParam(param, ""));
            } else if (eqIndex >= param.length() - 1) {
                list.add(new UrlParam(param.substring(0, eqIndex), ""));
            } else if (eqIndex == 0) {
                list.add(new UrlParam("", param.substring(eqIndex + 1)));
            } else {
                list.add(new UrlParam(param.substring(0, eqIndex),
                        param.substring(eqIndex + 1)));
            }
        }
        return list;

    }

    /**
     * Returns the hostname from the url.
     * <p>
     * http://www.abc.com/news/1.html -> www.abc.com<br>
     * news.123.com.cn/who.com -> news.123.com.cn<br>
     * 
     * @param url
     *            the url
     * @return hostname in the url
     */
    public static String getHostFromUrl(String url) {
        // get host name part of URL
        int i1 = url.indexOf("//");

        int start = 0;
        if (i1 >= 0)
            start = i1 + 2;
        if (start >= url.length())
            return "";

        int i2 = url.indexOf('/', i1 + 2);
        int i3 = url.indexOf(':', i1 + 2);
        i2 = i2 == -1 ? url.length() : i2;
        i3 = i3 == -1 ? url.length() : i3;
        int end = i2 < i3 ? i2 : i3;

        return url.substring(start, end);
    }

    /**
     * Returns protocol and host in a url
     * 
     * @param url
     *            the url
     * @return the protocol and host
     */
    public static String getProtocolHostFromUrl(String url) {
        int i1 = url.indexOf("//");
        if (i1 == -1)
            return null;
        int i2 = url.indexOf('/', i1 + 2);
        int i3 = url.indexOf(':', i1 + 2);
        if (i2 == -1)
            i2 = url.length();
        if (i3 == -1)
            i3 = url.length();
        int end = i2 < i3 ? i2 : i3;
        return url.substring(0, end);
    }

    /**
     * Returns host and port in a url
     * 
     * @param url
     *            the url
     * @return the host and port
     */
    public static String getProtocolHostPortFromUrl(String url) {
        int i1 = url.indexOf("//");
        if (i1 == -1)
            return null;
        int i2 = url.indexOf('/', i1 + 2);
        if (i2 == -1)
            i2 = url.length();
        return url.substring(0, i2);
    }

    /**
     * returns protocol in the url
     */
    public static String getProtocol(String url) {
        int i = url.indexOf("://");
        if (i == -1)
            return null;
        else
            return url.substring(0, i);
    }

    /**
     * Returns the level of host in a url.
     * 
     * @see {@link DomainUtils#getHostLevel(String)}
     */
    public static int getHostLevel(String url) {
        String host = getHostFromUrl(url);
        return DomainUtils.getHostLevel(host);
    }

    /**
     * returns the level of host in a url
     * 
     * @param url
     *            the url string
     * @param ignoreWWW
     *            whether ignore leading www in hostname
     * @return host level
     * @see {@link DomainUtils#getHostLevel(String, boolean)}
     */
    public static int getHostLevel(String url, boolean ignoreWWW) {
        String host = getHostFromUrl(url);
        return DomainUtils.getHostLevel(host, ignoreWWW);
    }

    /**
     * Returns the dir level of a url http://www.sohu.com/ -> 0
     * http://www.sohu.com/user -> 0 http://www.sohu.com/user/ -> 1
     * http://www.sohu.com/1/2 -> 1 http://www.sohu.com/1/2/ -> 2
     * http://www.sohu.com/1/2/3/ -> 3
     * 
     * @author yemingjiang XXX 这个level的定义看着有些别扭
     */
    public static int getPathLevel(String url) {
        String path = getPathFromUrl(url);
        int num = 0;
        for (int i = 1; i < path.length(); i++) {
            if (path.charAt(i) == '/')
                num++;
        }
        return num;
    }

    /**
     * whether two url are from the same host
     */
    public static boolean isSameHost(String url1, String url2) {
        String host1 = getHostFromUrl(url1);
        String host2 = getHostFromUrl(url2);
        if (host1 == null || host2 == null)
            // This is a wrong url
            return false;
        return host1.equals(host2);
    }

    /**
     * whether two url are from the same host using the same protocol
     */
    public static boolean isSameProtocolHost(String url1, String url2) {
        String host1 = getProtocolHostFromUrl(url1);
        String host2 = getProtocolHostFromUrl(url2);
        if (host1 == null || host2 == null)
            // This is a wrong url
            return false;
        return host1.equals(host2);
    }

    /**
     * Gets domain of a URL until to specific level. For example, if:<br>
     * http://news.abc.com/index.html or news.abc.com (not legal or normalized) <br>
     * The result is: abc.com
     * 
     * @param url
     *            the url
     * @param level
     *            of domain wanted
     * @return the domain of this url
     * @author houjiliang(@rd.netease.com)
     */
    public static String getDomainFromUrl(String url, int level) {
        String host = getHostFromUrl(url);
        return host == null ? null : DomainUtils.getDomain(host, level);
    }

    /**
     * Gets domain of a URL. For example, if input: http://news.abc.com The
     * result is: abc.com
     * 
     * @param url
     * @return the domain of this url
     * @author 侯吉亮
     */
    public static String getDomainFromUrl(String url) {
        return getDomainFromUrl(url, 1);
    }

    /**
     * Gets domain name of a url. For example: http://abc.good.com.cn/index.html
     * -> good news.163.com -> 163
     */
    public static String getDomainNameFromUrl(String url) {
        String domain = getDomainFromUrl(url, 1);
        if (IpUtils.isIPv4(domain)) {
            return domain;
        }
        int dot = domain.indexOf(".");
        if (dot > 0) {
            return domain.substring(0, dot);
        }
        return "";
    }

    private static Pattern HOSTNAME_PATTERN = Pattern.compile("^[^\\.]?[\\w\\-\\_\\.]+\\.[a-zA-Z]+$");

    /**
     * @deprecated 这个函数没有对ip类的host进行判断。使用
     *             {@link DomainUtils#isValidHost(String)}
     */
    public static boolean isLegalHostname(String url) {
        return HOSTNAME_PATTERN.matcher(url).matches();
    }

    /**
     * Whether a url looks like a chinese url
     * 
     * @deprecated 这个函数用处不明确而且写的不太好，这种特定用途的函数不应该放到公共的工具 包里
     */
    public static boolean isLikeChineseUrl(String link) {
        link = link.toLowerCase();
        try {
            URL url = new URL(link);
            String host = url.getHost();
            if (containKeyword(host, "cn"))
                return true;
            if (containKeyword(host, "chinese"))
                return true;
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * This method is used to check if a string A contains a keyword B. The
     * differece between this method withc String.indexOf() is: if a
     * char-sequence S1 contains a char-sequence S2, S2 may not a single word.
     * For example, String S1 "aabbcna" contains String "cn", but we cannot say
     * "cn" is a keyword in S1. But if S1 is like "aa.cn-ccb", then, ok, we can
     * say S1 has a word "cn". So this method is used to find keyword, not just
     * char-sequence matching.
     * 
     * @param str
     *            The string in which you want to find
     * @param keyword
     *            The string you want to find from the "str"
     * @return if it find return true. otherwise false.
     * @deprecated 这个实现不好，而且有问题
     */
    public static boolean containKeyword(String str, String keyword) {
        int pos = str.indexOf(keyword);
        if (pos >= 0) {
            if (pos == 0) {
                if (pos + 2 >= str.length())
                    return true;
                char c1 = str.charAt(pos + 2);
                if ((c1 >= '0' && c1 <= '9') || (c1 >= 'a' && c1 <= 'z'))
                    return false;
                else
                    return true;
            } else {
                char c1 = str.charAt(pos - 1);
                if ((c1 >= '0' && c1 <= '9') || (c1 >= 'a' && c1 <= 'z'))
                    return false;
                if (pos + 2 >= str.length())
                    return true;
                char c2 = str.charAt(pos + 2);
                if ((c2 >= '0' && c2 <= '9') || (c2 >= 'a' && c2 <= 'z'))
                    return false;
                return true;
            }
        } else
            return false;
    }

    private static int getHostIndex(String url) {
        int i1 = url.indexOf("//");
        if (i1 == -1)
            return -1;
        int i2 = url.indexOf('/', i1 + 2);
        int i3 = url.indexOf(':', i1 + 2);
        if (i2 == -1)
            i2 = url.length();
        if (i3 == -1)
            i3 = url.length();
        return i2 < i3 ? i2 : i3;
    }

    private static int getHostPortIndex(String url) {
        int i1 = url.indexOf("//");
        if (i1 == -1)
            return -1;
        int i2 = url.indexOf('/', i1 + 2);
        if (i2 == -1)
            i2 = url.length();
        return i2;
    }

    private static int getPageIndex(String url, int host_index) {
        if (host_index == url.length())
            // the page is empty
            return host_index;
        int index = url.indexOf("?");
        if (index == -1)
            return url.length();
        else
            return index;
    }

    private static String arrageParameters(String url, int index) {
        if (index == url.length() || index == url.length() - 1)
            return "";
        int now = index + 1;
        ArrayList<String> pset = new ArrayList<String>();
        while (true) {
            int next = url.indexOf("&", now);
            if (next == -1)
                next = url.length();
            String ps = url.substring(now, next);
            int pindex = ps.indexOf("=");
            if (pindex == -1)
                pindex = ps.length();
            pset.add(ps.substring(0, pindex));
            if (next == url.length())
                break;
            else
                now = next + 1;
        }
        Collections.sort(pset);
        StringBuilder result = new StringBuilder();

        for (int i = 0; i < pset.size(); i++) {
            result.append(pset.get(i));
            if (i != pset.size() - 1)
                result.append("&");
        }
        return result.toString();
    }

    /**
     * Is this a dynamic url
     */
    public static boolean isDynamicURL(String url) {
        return url.indexOf('?') > 0;
    }

    /**
     * Get the host template part of a url. For example, give this url
     * "http://www.a.com/a1234/ab23/a.html?b=1&a=2", it returns
     * "http://www.a.com"
     * 
     * @param url
     *            The url to be processed
     * @return The host template
     */
    public static String getHostTemplate(String url) {
        int host_index = getHostIndex(url);
        if (host_index == -1)
            return null;
        else
            return url.substring(0, host_index);
    }

    /**
     * Get the static template part of a url. For example, give this url
     * "http://www.a.com/a1234/ab23/a.html?b=1&a=2", it returns
     * "http://www.a.com/a1234/ab23/a.html"
     * 
     * @param url
     *            The url to be processed
     * @return The static part of a url as a template
     */
    public static String getStaticTemplate(String url) {
        int host_index = getHostPortIndex(url);
        if (host_index == -1)
            return null;
        int page_index = getPageIndex(url, host_index);
        return url.substring(0, page_index);
    }

    /**
     * Get the dynamic template part of a url. For example, give this url
     * "http://www.a.com/a1234/ab23/a.html?b=1&a=2", it returns
     * "http://www.a.com/a1234/ab23/a.html?a&b". Note that the parameters in the
     * return value are sorted
     * 
     * @param url
     *            The url to be processed
     * @return The whole dynamic template by removing parameter values
     */
    public static String getDynamicTemplate(String url) {
        int host_index = getHostPortIndex(url);
        if (host_index == -1)
            return null;
        int page_index = getPageIndex(url, host_index);
        String parameters = arrageParameters(url, page_index);
        // sort parameter names
        if (parameters.length() != 0)
            return url.substring(0, page_index) + "?" + parameters;
        else
            return url.substring(0, page_index);
    }

    /**
     * Get the query template part of a url. For example, give this url
     * "http://www.a.com/a1234/ab23/a.html?b=1&a=2", it returns
     * "/a1234/ab23/a.html?a&b". Note that the parameters in the return value
     * are sorted.
     * 
     * @param url
     *            The url to be processed
     * @return The query template by removing parameter values
     */
    public static String getQueryTemplate(String url) {
        int host_index = getHostPortIndex(url);
        if (host_index == -1)
            return null;
        int page_index = getPageIndex(url, host_index);
        String parameters = arrageParameters(url, page_index);
        // sort parameter names
        if (parameters.length() != 0)
            return url.substring(host_index, page_index) + '?' + parameters;
        else
            return url.substring(host_index, page_index);
    }

    /**
     * 作用：1. 除去path中的数字; 2. remove the file name. 3. re-organize the parameters.
     * 
     * @param str
     * @return
     * @throws MalformedURLException
     */
    public static String calcTemplateForClean(String str)
            throws MalformedURLException {
        URL url = new URL(str);
        char[] chars = url.getPath().toCharArray();
        StringBuilder sb = new StringBuilder();

        int i = chars.length;
        while (--i >= 0) { // skip
            if (chars[i] == '/')
                break;
        }
        for (int j = 0; j <= i; j++) {
            if (chars[j] >= '0' && chars[j] <= '9')
                continue;
            sb.append(chars[j]);
        }
        String path = sb.toString();

        String query = url.getQuery();
        if (query == null) {
            return url.getProtocol() + "://" + url.getHost() + path;
        } else {
            String pairs[] = query.split("&");
            PriorityQueue<String> q = new PriorityQueue<String>();
            for (String pair: pairs) {
                String[] parts = pair.split("=");
                if (parts.length > 0) {
                    String name = parts[0];
                    q.add(name);
                }
            }
            String q1 = "";
            while (q.size() > 0) {
                if (q.size() > 1)
                    q1 += q.poll() + "&";
                else
                    q1 += q.poll();
            }

            return url.getProtocol() + "://" + url.getHost() + path + "?" + q1;
        }
    }

    /**
     * get the file type of a url such as: html, mp3, jpg, etc.
     * 
     * @param url
     *            url must be a legal and normalized URL.
     * @return the url type
     */
    public static String getUrlType(String url) {
        int lastSlash = url.lastIndexOf('/');
        if (url.charAt(lastSlash - 1) == '/')
            return "";

        int queMark = url.lastIndexOf('?');
        if (queMark < 0)
            queMark = url.length();

        if (lastSlash > queMark)
            return "";

        int lastPeriod = url.lastIndexOf('.', queMark);
        if (lastPeriod < lastSlash)
            return "";
        return url.substring(lastPeriod + 1, queMark);
    }

    /**
     * 得到urlFile, 即path的最后一部分 url = http://xxx.yyy.com/zzz/aaa.html 返回 :
     * aaa.html url = http://xxx.yyy.com/zzz/ 返回 : ""
     * 
     * @param url
     *            url<strong>应该</strong>是经过url normalize后的
     * @return urlFile
     */
    public static String getUrlFile(String url) {
        int lindex = url.lastIndexOf('/');
        if (lindex == -1) {
            return "";
        }

        int queryIndex = url.indexOf('?', lindex);
        if (queryIndex < 0) {
            queryIndex = url.length();
        }

        if (url.charAt(lindex - 1) != '/') {
            return url.substring(lindex + 1, queryIndex);
        }

        return "";
    }

    /**
     * return the string while trimming the tail of the url here tail means the
     * urlFile and query, for example the tail of http://xxx.com/a.htm is a.htm
     */
    public static String trimTail(String url) {
        int lindex = url.lastIndexOf('/');
        if (lindex == -1) {
            return "";
        }
        if (lindex != 0 && url.charAt(lindex - 1) != '/') {
            return url.substring(0, lindex + 1);
        }

        return url;
    }

    private static final String[] HomePagePrefix = new String[] {
        "index", "default", "main"
    };

    private static final String[] HomePageSuffix = new String[] {
        "asp", "php", "jsp", "html", "htm", "shtml", "shtm", "aspx"
    };

    private static Set<String> HOMEPAGE_URLS = new HashSet<String>();
    static {
        HOMEPAGE_URLS.add("/");
        for (String prefix: HomePagePrefix) {
            for (String suffix: HomePageSuffix)
                HOMEPAGE_URLS.add("/" + prefix + "." + suffix);
        }

    }

    /**
     * whether this link is the home page of a host, such as: www.163.com
     * 
     * @deprecated use {@link #isHomePageForHost(String, boolean)} instead
     */
    public static boolean isHomePageForHost(String link) {
        String path = getPathFromUrl(link);
        if (path.length() == 0 || HOMEPAGE_URLS.contains(path))
            return true;
        return false;
    }

    /**
     * determine if a url is a index url such as Http://www.sina.com.cn/ or
     * http://www.sina.com.cn/index.htm
     * 
     * @deprecated use {@link #isIndexUrl(String, boolean)} instead
     */
    public static boolean isIndexUrl(String link) {
        String path = getPathFromUrl(link);
        if (path.length() == 0)
            return false;

        path = path.toLowerCase();
        for (String suffix: HOMEPAGE_URLS) {
            if (path.endsWith(suffix)) {
                return true;
            }
        }

        return false;
    }

    /**
     * normalize the index url by remove the index suffix such as "index.htm"
     * etc and remove query
     */
    public static String indexUrlNormalize(String link) {
        return indexUrlNormalize(link, true);
    }

    /**
     * 对index url进行normalize，去掉index后缀如"index.htm"之类，并去掉query 对非index url不做改动
     * 
     * @param url
     *            需要normalize的url, <strong>应该</strong>是已经urlnormalize后的
     * @param processEmptyFile
     *            是否对空的filename(path以'/'结尾)的url进行处理(去掉query)
     * @return 对index进行处理后的url
     */
    public static String indexUrlNormalize(String url, boolean processEmptyFile) {
        int queryPos = url.indexOf('?');
        int pathEndPos = url.length();
        if (queryPos > 0) {
            pathEndPos = queryPos;
        }

        // file name start pos
        int filePos = url.lastIndexOf('/', pathEndPos);
        if (filePos < 0)
            return url;

        String filename = url.substring(filePos, pathEndPos).toLowerCase();
        if (filename.length() == 1 && !processEmptyFile)
            return url;

        if (HOMEPAGE_URLS.contains(filename)) {
            return url.substring(0, filePos + 1);
        }

        return url;
    }

    /**
     * 判断一个页面是不是对应host的首页 如http://www.163.com/,
     * http://www.163.com/index.htm是www.163.com的home page,
     * 而http://www.163.com/a/index.htm 则不是 如果allowQuery为true,
     * 则http://www.163.com/?sid=1这类带query的也可以判为homepage 如果allowQuery为false,
     * 则不能判为homepage
     * 
     * @param url
     *            要判断的url, url<strong>应该</strong>是已经normalize之后的
     * @param allowQuery
     *            是否允许query存在
     * @return 是否是homepage
     */
    public static boolean isHomePageForHost(String url, boolean allowQuery) {
        // index of "://"
        int pos = url.indexOf(':');
        // index of path start
        pos = url.indexOf('/', pos + 3);
        if (pos < 0)
            return true;
        int queryPos = url.indexOf('?', pos);
        int pathEndPos = url.length();
        if (queryPos > 0) {
            if (!allowQuery) {
                return false;
            }
            pathEndPos = queryPos;
        }

        String path = url.substring(pos, pathEndPos).toLowerCase();
        return HOMEPAGE_URLS.contains(path);
    }

    /**
     * 判断一个url是不是indexl url, 即path结尾是/index.html, /main.asp等 和
     * {@link #isHomePageForHost(String, boolean)}的区别是isIndexUrl允许url中有多级path
     * 
     * @param url
     *            要判断的url, url<strong>应该</strong>是已经normalize之后的
     * @param allowQuery
     *            是否允许query存在
     * @return 是否是index url
     */
    public static boolean isIndexUrl(String url, boolean allowQuery) {
        return isIndexUrl(url, allowQuery, false);
    }

    /**
     * 判断一个url是不是index url, 即path结尾是/index.html, /main.asp等
     * 如http://163.com/a/index.html 和http://163.com/ 都是index url
     * allowQuery和allowEmptyFile可以设置是否允许Query和空的FileName
     * http://163.com/a/index.html?id=1，如果allowQuery为true，则返回true,否则返回false
     * http://163.com/a/b/ 如果allowEmptyFile为true, 否则返回false
     * 
     * @param url
     *            要判断的url, url<strong>应该</strong>是已经normalize之后的
     * @param allowQuery
     *            是否允许query存在
     * @param allowEmptyFile
     *            是否允许空的filename，即path以'/'结尾
     * @return 是否是index url
     */
    public static boolean isIndexUrl(String url, boolean allowQuery,
            boolean allowEmptyFile) {
        // index of "://"
        int pos = url.indexOf(':');
        // index of path start
        pos = url.indexOf('/', pos + 3);
        if (pos < 0)
            return true;
        int queryPos = url.indexOf('?', pos);
        int pathEndPos = url.length();
        if (queryPos > 0) {
            if (!allowQuery) { // 是否允许 http://163.com/?sid=1 这样的
                return false;
            }
            pathEndPos = queryPos;
        }

        // file name start pos
        int filePos = url.lastIndexOf('/', pathEndPos);

        String filename = url.substring(filePos, pathEndPos).toLowerCase();
        if (filename.length() == 1) {
            if (pos == filePos) // http://163.com/ 这样path为空的是index url
                return true;
            return allowEmptyFile; // 是否允许 http://163.com/a/ 这样的 
        } else {
            return HOMEPAGE_URLS.contains(filename);
        }
    }

    /**
     * 判断一个站点是不是domain site。 ip site 算是domain site 如果一个域名为 abc.com 则
     * www.abc.com算是domain site，abc.com 也算是domain site。 但是
     * www.ef.abc.com就不算是domain site ef.abc.com也不算是domain site，这类型的算是sub site
     * 
     * @param hostName
     *            站点名
     * @return 是否是domain site
     */
    public static boolean isDomainSite(String hostName) {
        String domainName = getDomainFromUrl(hostName);
        if (IpUtils.isIPv4(hostName))
            return true;
        boolean isDomainSite = domainName.equals(hostName)
                || hostName.equals("www." + domainName);
        return isDomainSite;
    }

}
