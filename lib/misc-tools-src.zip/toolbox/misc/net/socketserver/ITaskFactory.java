/**
 * @(#)ITaskFactory.java, 2008-6-21. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.misc.net.socketserver;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * task factory
 * 
 * @author ares
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public interface ITaskFactory {

    public ITask createTask();

}
