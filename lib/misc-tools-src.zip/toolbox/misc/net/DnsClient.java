package toolbox.misc.net;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;

import toolbox.misc.LogFormatter;
import toolbox.misc.cli.OptionParseException;
import toolbox.misc.cli.Options;
import toolbox.misc.sys.NativeCodeInvoker;
import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * Query dns by jndi. If several dns server provided, queries should be balanced
 * with "round-robin" policy among them.
 * 
 * @author river
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class DnsClient {
    private static final Logger LOG = LogFormatter.getLogger(DnsClient.class);

    public static final int POLICY_ROUNDROBIN = 1;

    public static final int POLICY_PARTITION = 2;

    private String[] servers;

    private boolean[] active;

    private long initialTimeout = 8000;

    private int retries = 2;

    private int policy = POLICY_ROUNDROBIN;

    private AtomicInteger pos = new AtomicInteger(0);

    private static Map<String, InetAddress> hostIpMap = new HashMap<String, InetAddress>();

    public DnsClient(String[] servers) {
        this.servers = servers;
        this.active = new boolean[servers.length];
        Arrays.fill(active, true);
    }

    /**
     * Set the initial time out, default is 8s. Timeout during retries should be
     * "initialTimeout"-"initialTimeout * 2"-"initialTimeout * 4" - "...".
     * 
     * @param value
     */
    public void setInitialTimeout(long value) {
        this.initialTimeout = value;
    }

    /**
     * Set the retry times, default is 2.
     * 
     * @param value
     */
    public void setRetries(int value) {
        this.retries = value;
    }

    /**
     * Set the dns server selection policy.
     * 
     * @see #POLICY_PARTITION
     * @see #POLICY_ROUNDROBIN
     * @param policy
     */
    public void setPolicy(int policy) {
        this.policy = policy;
    }

    /**
     * Check if the given string is ip address.
     * 
     * @param s
     * @return
     */
    private boolean isIpAddress(String s) {
        int len = s.length();
        if (len > 15)
            return false;

        int partNumber = 0;
        for (int i = 0; i < len; i++) {
            char c = s.charAt(i);
            if (c == '.') {
                partNumber++;
            } else if (c < '0' || c > '9') {
                return false;
            }
        }
        return true;
    }

    private String roundrobin() {
        int selection = pos.getAndIncrement();
        int probed = 0;
        do {
            int i = selection % servers.length;
            if (active[i]) {
                return servers[i];
            }
            selection++;
            probed++;
        } while (probed < servers.length);
        return null;
    }

    private String partition(String host) {
        int hash = host.hashCode() & Integer.MAX_VALUE;
        int probed = 0;
        do {
            int selected = hash % servers.length;
            if (active[selected]) {
                return servers[selected];
            }
            hash = hash >> 1;
        } while (probed < servers.length);
        return null;
    }

    /**
     * Select one dns server from server pool for the given hostname.
     * 
     * @param host
     *            the host name
     * @return the dns server selected
     * @throws NamingException
     */
    public String selectDnsServer(String host) throws NamingException {
        String server;
        if (policy == POLICY_ROUNDROBIN) {
            server = roundrobin();
        } else {
            server = partition(host);
        }
        if (server == null) {
            throw new NamingException("cannot find active dns server");
        }
        return server;
    }

    /**
     * query the "A" records for given host name.
     * 
     * @param host
     * @return InetAddress found
     * @throws NamingException
     *             if dns server error or dns query failed, if the exception is
     *             NameNotFoundException, it means that cannot find this entry
     *             in dns; or CommunicationException, means dns query timeout or
     *             dns server failed.
     */
    public InetAddress[] query(String host) throws NamingException {
        return query(host, selectDnsServer(host));
    }

    public static void setHostIp(String host, InetAddress addr) {
        hostIpMap.put(host, addr);
    }

    /**
     * Query the "A" records for given hostname in given server.
     * 
     * @param host
     *            host name
     * @param server
     *            dns server
     * @return the InetAddresses of a host
     * @throws NamingException
     */
    public InetAddress[] query(String host, String server)
            throws NamingException {
        if (hostIpMap.containsKey(host))
            return new InetAddress[] {
                hostIpMap.get(host)
            };

        if (isIpAddress(host)) {
            try {
                return new InetAddress[] {
                    InetAddress.getByName(host)
                };
            } catch (UnknownHostException e) {
                //impossible to reach here
                throw new NamingException("address convertion error : "
                        + e.toString());
            }
        }

        Hashtable<String, String> env = new Hashtable<String, String>();
        env.put(Context.INITIAL_CONTEXT_FACTORY,
                "com.sun.jndi.dns.DnsContextFactory");
        env.put(Context.PROVIDER_URL, "dns://" + server);
        env.put("com.sun.jndi.dns.timeout.initial",
                String.valueOf(initialTimeout));
        env.put("com.sun.jndi.dns.timeout.retries", String.valueOf(retries));

        DirContext ctx = new InitialDirContext(env);
        Attributes attrs;
        attrs = ctx.getAttributes(host, new String[] {
            "A"
        });

        List<InetAddress> list = new ArrayList<InetAddress>(1);
        for (NamingEnumeration ae = attrs.getAll(); ae.hasMoreElements();) {
            Attribute attr = (Attribute) ae.nextElement();
            for (Enumeration ve = attr.getAll(); ve.hasMoreElements();) {
                String address = (String) ve.nextElement();
                try {
                    // convert ip address in string format to InetAddress, no dns query 
                    // should be emitted when InetAddress.getByName(host) called with ip address
                    list.add(InetAddress.getByName(address));
                } catch (UnknownHostException e) {
                    //it is simply impossible to reach here
                    LOG.warning("cannot parse address returned by naming service : "
                            + address);
                }
            }
        }
        return list.toArray(new InetAddress[list.size()]);
    }

    public static void loadSystemSetting(List<String> list) {
        boolean IS_WINDOWS = System.getProperty("os.name").toUpperCase().startsWith(
                "WIN");
        if (IS_WINDOWS) {
            loadSystemSettingWindows(list);
        } else {
            loadSystemSettingLinux(list);
        }
    }

    /**
     * On windows, we load dns setting from output of command "ipconfig/all".
     * 
     * @param list
     */
    private static void loadSystemSettingWindows(List<String> list) {
        try {
            NativeCodeInvoker.Result result = NativeCodeInvoker.execute(
                    "cmd /c ipconfig /all", new File("."));
            Pattern startPattern = Pattern.compile("\\s+DNS Servers[\\s\\.]+:\\s+([\\d\\.]+)\\s*");
            Pattern entryPattern = Pattern.compile("\\s+([\\d\\.]+)\\s*");

            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    new ByteArrayInputStream(result.getStdout())));
            String line;
            while ((line = reader.readLine()) != null) {
                Matcher matcher = startPattern.matcher(line);
                if (matcher.matches()) {
                    list.add(matcher.group(1));
                    while ((line = reader.readLine()) != null) {
                        matcher = entryPattern.matcher(line);
                        if (matcher.matches()) {
                            list.add(matcher.group(1));
                        } else {
                            break;
                        }
                    }
                }
            }
        } catch (IOException e) {}
    }

    /**
     * On linux system, we load dns setting from "/etc/resolv.conf".
     * 
     * @param list
     */
    private static void loadSystemSettingLinux(List<String> list) {
        File file = new File("/etc/resolv.conf");
        if (!file.canRead()) {
            LOG.warning("cannot read " + file);
            return;
        }

        Pattern pattern = Pattern.compile("\\s*nameserver\\s+([\\d\\.]+)\\s*");
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    new FileInputStream(file)));
            try {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (line.startsWith(";"))
                        continue;
                    Matcher matcher = pattern.matcher(line);
                    if (matcher.matches()) {
                        list.add(matcher.group(1));
                    }
                }
            } finally {
                reader.close();
            }
        } catch (IOException e) {
            LOG.log(Level.WARNING, "load system configuration from file "
                    + file + " failed", e);
        }
    }

    public static void main(String[] args) throws Exception {
        /*
         * Process arguments
         */
        Options options = new Options();
        options.withOption("s", "server", "set the address of dns-server");
        options.addParam("host", "The hostname to be queried").etcParam();
        options.setMinimalParamCount(1);

        try {
            options.parse(args);
        } catch (OptionParseException e) {
            System.out.println("error: " + e.getMessage());
            options.printHelpInfo(System.out, "dnsclient");
        }

        /*
         * Querying
         */
        String[] servers = options.getOpt("s");
        String[] hosts = options.getRemains();

        DnsClient client = new DnsClient(servers);
        client.setPolicy(DnsClient.POLICY_PARTITION);
        for (String host: hosts) {
            String server = client.selectDnsServer(host);
            long start = System.currentTimeMillis();
            InetAddress[] addrs = client.query(host, server);
            long end = System.currentTimeMillis();
            System.out.println("Query " + host + " in server " + server
                    + " costs " + (end - start) + "ms.");

            for (InetAddress addr: addrs) {
                System.out.println(addr);
            }
        }

    }
}
