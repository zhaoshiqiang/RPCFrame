package toolbox.misc.net;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

@InterfaceAudience.Public
@InterfaceStability.Evolving
public class ChineseIpSegments extends IpSegments {
    private List<IpSegment> segments = new ArrayList<IpSegment>();

    static HashSet<String> provinceSet = new HashSet<String>(300);

    private final String[] provinces = new String[] {
        "北京市", "上海市", "天津市", "重庆市", "河北省", "山西省", "辽宁省", "吉林省", "黑龙江省", "江苏省",
        "浙江省", "安徽省", "福建省", "江西省", "山东省", "河南省", "湖北省", "湖南省", "广东省", "海南省",
        "四川省", "贵州省", "云南省", "陕西省", "甘肃省", "青海省", "内蒙古", "广西", "西藏", "宁夏", "新疆"
    };

    public ChineseIpSegments() {
        super();
        for (String province: provinces) {
            provinceSet.add(province);
        }

    }

    public void load(File file) throws IOException, ParseException {
        FileInputStream is = new FileInputStream(file);
        try {
            load(is);
        } finally {
            is.close();
        }
    }

    public void load(InputStream is, String charset) throws IOException,
            ParseException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(is,
                charset));
        try {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.startsWith("#") || line.length() == 0) {
                    continue;
                } // else go on
                IpSegment segment = parse(line);
                if (segment != null)
                    segments.add(segment);
            } // end of while
        } finally {
            // do something
        } // end of try
        IpSegment[] segs = new IpSegment[0];
        segs = segments.toArray(segs);
        super.add(segs);
    }

    private static Pattern PATTERN = Pattern.compile("([\\d\\.]+)\\s+([\\d\\.]+)\\s+(.*)");

    public static IpSegment parse(String s) throws ParseException {
        String property = null;
        Matcher matcher = PATTERN.matcher(s);
        if (matcher.matches()) {
            int start = IpUtils.parseIp(matcher.group(1));
            int end = IpUtils.parseIp(matcher.group(2));
            String location = matcher.group(3);
            if (location != null && !location.equals("")) {
                String[] strs = location.split(" ");
                if (strs[0].length() >= 3
                        && provinceSet.contains(strs[0].substring(0, 3)))
                    property = strs[0].substring(0, 3);
                else if (strs[0].length() >= 2
                        && provinceSet.contains(strs[0].substring(0, 2)))
                    property = strs[0].substring(0, 2);
                else if (strs[0].length() >= 4
                        && provinceSet.contains(strs[0].substring(0, 4)))
                    property = strs[0].substring(0, 4);
                //else property still is null.
            } //else the property is still null
            if (property != null)
                return new IpSegment(start, end, property);
            else
                return null;
        } else
            return null;
    }
}
