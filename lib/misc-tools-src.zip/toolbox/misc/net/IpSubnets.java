package toolbox.misc.net;

import java.io.PrintStream;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * Implemented using B-Tree, 用来表示一段IP地址
 * 
 * @author fjiang
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class IpSubnets {

    protected Node root;

    public IpSubnets() {
        root = new Node(null, 0);
    }

    public void insert(int ip, int range) {
        Node cur = root;
        if (cur.getType() == Node.ALL)
            return;
        for (int i = 0; i < range; i++) {
            int t = (ip >>> (31 - i)) & 0x1;
            if (t == 0) {
                if (cur.getZero() == null)
                    cur.newZero();
                if (cur.getType() == Node.ALL)
                    return;
                if (cur.getZero().getType() == Node.ALL)
                    return;
                cur = cur.getZero();
            } else if (t == 1) {
                if (cur.getOne() == null)
                    cur.newOne();
                if (cur.getType() == Node.ALL)
                    return;
                if (cur.getOne().getType() == Node.ALL)
                    return;
                cur = cur.getOne();
            }
        }
        cur.setAll();
    }

    public boolean get(int ip) {
        Node cur = root;
        if (cur.getType() == Node.ALL)
            return true;
        for (int i = 0; i < 32; i++) {
            int t = (ip >>> (31 - i)) & 0x1;
            if (t == 0) {
                if (cur.getZero() == null)
                    return false;
                cur = cur.getZero();
            } else if (t == 1) {
                if (cur.getOne() == null)
                    return false;
                cur = cur.getOne();
            }
            if (cur.getType() == Node.ALL)
                return true;
        }
        return true;
    }

    public void dump(PrintStream out) {
        dump(out, root, 0, 0);
    }

    private void dump(PrintStream out, Node n, int ip, int level) {
        if (n.getType() == Node.ALL) {
            ip = ip << (32 - level);
            int[] addr = new int[4];
            addr[0] = ((ip >>> 24) & 0xFF);
            addr[1] = ((ip >>> 16) & 0xFF);
            addr[2] = ((ip >>> 8) & 0xFF);
            addr[3] = (ip & 0xFF);
            String sip = addr[0] + "." + addr[1] + "." + addr[2] + "."
                    + addr[3];
            out.println(sip + "/" + level);
            return;
        }
        if (n.getZero() != null) {
            dump(out, n.getZero(), ip << 1, level + 1);
        }
        if (n.getOne() != null) {
            dump(out, n.getOne(), (ip << 1) + 1, level + 1);
        }
    }

}

class Node implements Cloneable {
    public static final int ALL = 1;

    public static final int NODE = 2;

    private int type = NODE;

    private Node dad = null; //root's dad = null

    private Node zero = null;

    private Node one = null;

    public long childs = 0; //total number of its children. FULL = 2^(33-level)-2

    public int level = 0; //root = 0

    public Node(Node dad, int level) {
        this.dad = dad;
        this.level = level;
    }

    public Node(Node other) {
        setNode(other);
    }

    public void setNode(Node other) {
        this.type = other.type;
        this.dad = other.dad;
        if (other.zero != null)
            this.zero = new Node(other.zero);
        if (other.one != null)
            this.one = new Node(other.one);
        this.childs = other.childs;
        this.level = other.level;
    }

    public void setAll() {
        type = ALL;
        zero = null;
        one = null;
    }

    public int getType() {
        return type;
    }

    public void newZero() {
        updateDads();
        childs++;
        if (childs == getFull()) {
            setAll();
            return;
        }
        zero = new Node(this, level + 1);
    }

    public void newOne() {
        updateDads();
        childs++;
        if (childs == getFull()) {
            setAll();
            return;
        }
        one = new Node(this, level + 1);
    }

    private void updateDads() {
        Node cur = this;
        while ((cur = cur.dad) != null) {
            cur.childs++;
            if (cur.childs == cur.getFull())
                cur.setAll();
        }
    }

    public Node getZero() {
        return zero;
    }

    public Node getOne() {
        return one;
    }

    public long getFull() {
        return (1 << (33 - level)) - 2;
    }

}
