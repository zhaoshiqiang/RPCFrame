package toolbox.misc.net;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * IP segments container for search. FIXME: how to use this?
 * 
 * @author river
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class IpSegments {

    private List<IpSegment> segments = new ArrayList<IpSegment>();

    private Comparator<IpSegment> comparator = new IpSegment.StartComparator();

    private boolean intersect = false;

    public IpSegments() {

    }

    public IpSegments(boolean intersect) {
        this.intersect = intersect;
    }

    private static Pattern PATTERN1 = Pattern.compile("([\\d\\.]+)\\s*\\-\\s*([\\d\\.]+)\\s*(.*)");

    private static Pattern PATTERN2 = Pattern.compile("([\\d\\.]+)/(\\d+)\\s*(.*)");

    private static Pattern PATTERN3 = Pattern.compile("([\\d\\.]+)\\s+(\\d+)\\s*(.*)");

    private static IpSegment parse1(String s) throws ParseException {
        Matcher matcher = PATTERN1.matcher(s);
        if (matcher.matches()) {
            int start = IpUtils.parseIp(matcher.group(1));
            int end = IpUtils.parseIp(matcher.group(2));
            String property = matcher.group(3);
            return new IpSegment(start, end, property);
        } else
            return null;
    }

    private static IpSegment parse2(String s) throws ParseException {
        Matcher matcher = PATTERN2.matcher(s);
        if (matcher.matches()) {
            int start = IpUtils.parseIp(matcher.group(1));
            int bits = Integer.parseInt(matcher.group(2));
            int end = start | (1 << bits - 1);
            start = start & ~(1 << bits - 1);
            String property = matcher.group(3);
            return new IpSegment(start, end, property);
        } else {
            return null;
        }
    }

    private static IpSegment parse3(String s) throws ParseException {
        Matcher matcher = PATTERN3.matcher(s);
        if (matcher.matches()) {
            int start = IpUtils.parseIp(matcher.group(1));
            int count = Integer.parseInt(matcher.group(2));
            int end = start + count - 1;
            String property = matcher.group(3);
            return new IpSegment(start, end, property);
        } else {
            return null;
        }

    }

    /**
     * This method can accept ip segments in format
     * "xxx.xxx.xxx.xxx-xxx.xxx.xxx.xxx, xxx.xxx.xxx.xxx/xx and xxx.xxx.xxx.xxx xxx"
     * .
     * 
     * @param s
     * @return ip segments
     * @throws ParseException
     */
    public static IpSegment parse(String s) throws ParseException {
        IpSegment segment = parse1(s);
        if (segment == null) {
            segment = parse2(s);
            if (segment == null) {
                segment = parse3(s);
            }
        }

        if (segment == null) {
            throw new ParseException("cannot parse ip segments " + s, 0);
        } else {
            return segment;
        }
    }

    public void load(File file) throws IOException, ParseException {
        FileInputStream is = new FileInputStream(file);
        try {
            load(is);
        } finally {
            is.close();
        }
    }

    public void load(InputStream is) throws IOException, ParseException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(is,
                "UTF-8"));
        try {
            String line;

            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.startsWith("#") || line.length() == 0) {
                    continue;
                }
                IpSegment segment = parse(line);
                segments.add(segment);
            }
        } finally {
            Collections.sort(segments, comparator);
        }
    }

    public void add(IpSegment[] segs) {
        for (IpSegment seg: segs) {
            segments.add(seg);
        }
        Collections.sort(segments, comparator);
    }

    public void add(IpSegments other) {
        for (IpSegment seg: other.segments) {
            segments.add(seg);
        }
        Collections.sort(segments, comparator);
    }

    public IpSegment search(int ip) {
        IpSegment key = new IpSegment(ip, ip);
        int index = Collections.binarySearch(segments, key, comparator);
        if (index >= 0) {
            return segments.get(index);
        } else {
            int insertPoint = -(index + 1);
            int startPoint = intersect ? 0 : (insertPoint > 0 ? insertPoint - 1
                    : 0);
            for (int i = startPoint; i < insertPoint; i++) {
                IpSegment segment = segments.get(i);
                if (segment.contains(ip))
                    return segment;
            }
        }
        return null;
    }

    public boolean contains(int ip) {
        return search(ip) != null;
    }

}
