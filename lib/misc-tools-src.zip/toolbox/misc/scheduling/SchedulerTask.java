/**
 * @(#)SchedulerTask.java, 2007-10-8. Copyright 2007 Yodao, Inc. All rights
 *                         reserved. YODAO PROPRIETARY/CONFIDENTIAL. Use is
 *                         subject to license terms.
 */
package toolbox.misc.scheduling;

import java.util.TimerTask;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * @author zhangduo
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public abstract class SchedulerTask {
    final byte[] lock = new byte[0];

    int state = VIRGIN;

    static final int VIRGIN = 0;

    static final int SCHEDULED = 1;

    static final int CANCELLED = 2;

    TimerTask timerTask;

    protected SchedulerTask() {}

    public abstract void run();

    public boolean cancel() {
        synchronized (lock) {
            if (timerTask != null) {
                timerTask.cancel();
            }
            boolean result = (state == SCHEDULED);
            state = CANCELLED;
            return result;
        }
    }

    public long scheduledExecutionTime() {
        synchronized (lock) {
            return timerTask == null ? 0 : timerTask.scheduledExecutionTime();
        }
    }

}
