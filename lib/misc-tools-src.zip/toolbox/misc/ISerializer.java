package toolbox.misc;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * The object that can serialize an object.
 * 
 * @author david
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public interface ISerializer<T> {
    /**
     * Reads data from the input and compose an object.
     * 
     * @param in
     *            the data input
     * @throws IOException
     *             if an I/O error occurs
     */
    public T readObject(DataInput in) throws IOException;

    /**
     * Serializes the object into the output
     * 
     * @param out
     *            the data output
     * @param o
     *            the object to be serialized
     * @throws IOException
     *             if an I/O error occurs
     */
    public void writeObject(DataOutput out, T o) throws IOException;
}
