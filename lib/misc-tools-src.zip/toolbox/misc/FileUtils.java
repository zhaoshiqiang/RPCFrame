package toolbox.misc;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Reader;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.regex.Pattern;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * File Utilties (Utility functions to deal with files, dirs, etc.)
 * <p>
 * Copyright (c) 2006, Outfox Team.
 * <p>
 * Created Nov 18, 2006
 * 
 * @author Li Zhuang (zl@rd.netease.com, zl@cs.berkeley.edu)
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class FileUtils {

    private static final boolean WINDOWS;
    static {
        String os = System.getProperty("os.name");
        WINDOWS = os != null && os.toLowerCase().startsWith("win");
    }

    /**
     * Delete one tree.
     * 
     * @param dir
     */
    public static boolean fullyDelete(File dir) {
        if (!dir.exists())
            return true;

        if (dir.isDirectory()) {
            File[] childs = dir.listFiles();
            for (File c: childs) {
                if (!fullyDelete(c))
                    return false;
            }
        }
        return dir.delete();
    }

    /**
     * Sort the files by the length of name, then by the dictionary order of
     * names. Sorting is done in place.
     */
    public static void sortByNameLength(File[] files) {
        Arrays.sort(files, new Comparator<File>() {
            public int compare(File o1, File o2) {
                String n1 = o1.getName();
                String n2 = o2.getName();
                int len1 = n1.length();
                int len2 = n2.length();
                if (len1 == len2)
                    return n1.compareTo(n2);
                else if (len1 < len2)
                    return -1;
                else
                    return 1;
            }
        });
    }

    /**
     * Save data to local file.
     * 
     * @param file
     * @param content
     * @throws IOException
     */
    public static void saveBytesToLocalFile(File file, byte[] content)
            throws IOException {
        FileOutputStream fos = new FileOutputStream(file);
        try {
            fos.write(content);
        } finally {
            fos.close();
        }
    }

    /**
     * Read out content of local file.
     * 
     * @param file
     * @return the content as byte array
     * @throws IOException
     */
    public static byte[] readBytesFromLocalFile(File file) throws IOException {
        FileInputStream fis = new FileInputStream(file);
        try {
            byte[] buf = new byte[fis.available()];
            fis.read(buf);
            return buf;
        } finally {
            fis.close();
        }
    }

    /**
     * Read out content of local file as a string.
     * 
     * @param file
     *            the file to read
     * @return the content as string
     * @throws IOException
     *             when read error occurs
     */
    public static String readStringFromLocalFile(File file) throws IOException {
        return readStringFromLocalFile(file, null);
    }

    /**
     * Read out content of local file as a string.
     * 
     * @param file
     *            the file to read
     * @param enc
     *            encoding name
     * @return the content as string
     * @throws IOException
     *             when read error occurs
     */
    public static String readStringFromLocalFile(File file, String enc)
            throws IOException {
        FileInputStream fis = new FileInputStream(file);
        try {
            StringBuilder ans = new StringBuilder();
            BufferedReader reader;
            if (enc == null)
                reader = new BufferedReader(new InputStreamReader(fis));
            else
                reader = new BufferedReader(new InputStreamReader(fis, enc));
            try {
                String s;
                while ((s = reader.readLine()) != null) {
                    ans.append(s).append('\n');
                }
                return ans.toString();
            } finally {
                reader.close();
            }
        } finally {
            fis.close();
        }
    }

    /**
     * save content to local file
     * 
     * @param file
     *            the file to write
     * @throws IOException
     *             when write error occurs
     */
    public static void saveStringToLocalFile(File file, String content)
            throws IOException {
        saveBytesToLocalFile(file, content.getBytes("utf-8"));
    }

    /**
     * Is a string represent an absolute path
     */
    public static boolean isAbsolutePath(String s) {
        return s.startsWith("/") || s.startsWith("\\")
                || (WINDOWS && s.length() > 1 && s.charAt(1) == ':');
    }

    /**
     * Combine parent and child into a new String for path.
     * 
     * @param parent
     *            The parent.
     * @param child
     *            The child.
     * @return A new path string after combining.
     */
    public static String combinePath(String... paths) {
        StringBuilder buf = new StringBuilder();
        for (int i = 0; i < paths.length - 1; i++) {
            String s = paths[i];
            if (s.length() == 0)
                continue;
            buf.append(s);
            if (!s.endsWith("/") && !s.endsWith("\\")) {
                buf.append(File.separator);
            }
        }
        if (paths.length > 0) {
            buf.append(paths[paths.length - 1]);
        }
        String result = buf.toString();
        result = result.replace('/', File.separatorChar);
        result = result.replace('\\', File.separatorChar);
        return result;
    }

    /**
     * List files which match include pattern and do not match exclude pattern.
     * 
     * @param dir
     * @param include
     * @param exclude
     * @return
     */
    public static File[] listFiles(File dir, String[] include, String[] exclude) {
        return dir.listFiles(new PatternFilenameFilter(include, exclude));
    }

    /**
     * Reader using <code>System.in</code>. Method <code>close()</code> of this
     * object do nothing, so it won't affect the underlined
     * <code>System.in</code>.
     */
    public static final BufferedReader STDIN = new BufferedReader(
            new InputStreamReader(System.in)) {
        @Override
        public void close() throws IOException {
            // avoid close System.in
        }
    };

    /**
     * Writer using <code>System.out</code>. Method <code>close()</code> of this
     * object do nothing, so it won't affect the underlined
     * <code>System.out</code>.
     */
    public static final PrintWriter STDOUT = new PrintWriter(
            new OutputStreamWriter(System.out), true) {

        @Override
        public void close() {
            // avoid close System.out
            this.flush();
        }
    };

    /**
     * Open reader for path, and return {@link #STDIN} directly if variable
     * <code>path</code> equals "stdin".
     * 
     * @param path
     * @return
     * @throws IOException
     */
    public static BufferedReader createReader(String path) throws IOException {
        if (path.equalsIgnoreCase("stdin")) {
            return STDIN;
        } else {
            return new BufferedReader(new InputStreamReader(
                    new FileInputStream(path), "UTF-8"));
        }
    }

    /**
     * Open writer for path, and return {@link #STDOUT} directly if variable
     * <code>path</code> equals "stdout".
     * 
     * @param path
     * @return
     * @throws IOException
     */
    public static PrintWriter createWriter(String path) throws IOException {
        if (path.equalsIgnoreCase("stdout")) {
            return STDOUT;
        } else {
            return new PrintWriter(new OutputStreamWriter(new FileOutputStream(
                    path), "UTF-8"), true);
        }
    }

    private static class PatternFilenameFilter implements FilenameFilter {
        private List<Pattern> includePatterns = new LinkedList<Pattern>();

        private List<Pattern> excludePatterns = new LinkedList<Pattern>();

        public PatternFilenameFilter(String[] includes, String[] excludes) {
            for (String p: includes) {
                includePatterns.add(Pattern.compile(p));
            }
            for (String p: excludes) {
                excludePatterns.add(Pattern.compile(p));
            }
        }

        public boolean accept(File dir, String name) {
            if (!excludePatterns.isEmpty()) {
                for (Pattern p: excludePatterns) {
                    if (p.matcher(name).matches())
                        return false;
                }
            }

            if (!includePatterns.isEmpty()) {
                for (Pattern p: includePatterns) {
                    if (p.matcher(name).matches()) {
                        return true;
                    }
                }
                return false;
            }

            return true;
        }
    }

    /**
     * Open text file and iterate the lines. Refer to {@link LineFile} for more
     * document.
     * 
     * @see LineFile
     * @param file
     * @param charset
     * @param trimLine
     * @param ignoreEmptyLine
     * @param commentChars
     * @return
     * @throws IOException
     */
    public static LineFile openLineFile(File file, String charset,
            boolean trimLine, boolean ignoreEmptyLine, String commentChars)
            throws IOException {
        LineFile instance = new LineFile(file, charset);
        instance.setTrimLine(trimLine);
        instance.setIgnoreEmptyLine(ignoreEmptyLine);
        instance.setCommentChars(commentChars);
        return instance;
    }

    /**
     * Open text file and iterator the lines. Refer to {@link LineFile} for more
     * document.
     * 
     * @param is
     * @param charset
     * @param trimLine
     * @param ignoreEmptyLine
     * @param commentChars
     * @return
     * @throws IOException
     */
    public static LineFile openLineFile(InputStream is, String charset,
            boolean trimLine, boolean ignoreEmptyLine, String commentChars)
            throws IOException {
        LineFile instance = new LineFile(is, charset);
        instance.setTrimLine(trimLine);
        instance.setIgnoreEmptyLine(ignoreEmptyLine);
        instance.setCommentChars(commentChars);
        return instance;
    }

    /**
     * Open text file and iterator the lines. Refer to {@link LineFile} for more
     * document.
     * 
     * @param reader
     * @param trimLine
     * @param ignoreEmptyLine
     * @param commentChars
     * @return
     * @throws IOException
     */
    public static LineFile openLineFile(Reader reader, boolean trimLine,
            boolean ignoreEmptyLine, String commentChars) throws IOException {
        LineFile instance = new LineFile(reader);
        instance.setTrimLine(trimLine);
        instance.setIgnoreEmptyLine(ignoreEmptyLine);
        instance.setCommentChars(commentChars);
        return instance;
    }

    /**
     * Text file which could be iterated line by line. By this utility, we could
     * read the lines of text file like: <code>
     *   LineFile f = new Line("input.txt", "utf-8");
     *   for (String line : f) {
     *     ... // process the line
     *   }
     *   f.checkLastError();
     * </code> Be careful with the last call to
     * {@link LineFile#checkLastError()}. Because iterator interface could not
     * throw {@link IOException}, we must call this method to check if any
     * exception occur during iteration.
     * 
     * @author river
     */
    @InterfaceAudience.Public
    @InterfaceStability.Evolving
    public static class LineFile implements Iterable<String> {
        private BufferedReader reader;

        private IOException lastException = null;

        private boolean ignoreEmptyLine = false;

        private boolean trimLine = false;

        private String commentChars = "";

        /**
         * Open the file, and the file should be closed by calling
         * {@link #close()}.
         * 
         * @param file
         * @param charset
         * @throws IOException
         */
        public LineFile(File file, String charset) throws IOException {
            reader = new BufferedReader(new InputStreamReader(
                    new FileInputStream(file), charset));
        }

        /**
         * Create reader on given input stream. The underlined input stream
         * should be closed by calling {@link #close()}.
         * 
         * @param is
         * @param charset
         * @throws IOException
         */
        public LineFile(InputStream is, String charset) throws IOException {
            reader = new BufferedReader(new InputStreamReader(is, charset));
        }

        /**
         * Create buffered reader on given reader. The underlined reader should
         * be closed by calling {@link #close()}.
         * 
         * @param reader
         * @throws IOException
         */
        public LineFile(Reader reader) throws IOException {
            if (reader instanceof BufferedReader) {
                this.reader = (BufferedReader) reader;
            } else {
                this.reader = new BufferedReader(reader);
            }
        }

        /**
         * Set if we should ignore empty line, this check will be on trimed line
         * if we open the trim flag by calling {@link #setTrimLine(boolean)}.
         * 
         * @param value
         */
        public void setIgnoreEmptyLine(boolean value) {
            this.ignoreEmptyLine = value;
        }

        /**
         * Set if we should trim each line before any processing or checking.
         * 
         * @param value
         */
        public void setTrimLine(boolean value) {
            this.trimLine = value;
        }

        /**
         * Set the chars of comments, such as "#;".
         * 
         * @param commentChars
         */
        public void setCommentChars(String commentChars) {
            this.commentChars = commentChars;
        }

        public void close() throws IOException {
            reader.close();
        }

        /**
         * This method will throw the last exception during iteration.
         * 
         * @throws IOException
         */
        public void checkLastError() throws IOException {
            if (lastException != null) {
                throw lastException;
            }
        }

        public Iterator<String> iterator() {
            return new LineIter();
        }

        private class LineIter implements Iterator<String> {

            private String nextString = null;

            private boolean endOfFile = false;

            /**
             * Read the next line, and ignore the empty line or comment line if
             * the flags are turned on.
             * 
             * @return
             * @throws IOException
             */
            private String getNextValidString() throws IOException {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (trimLine)
                        line = line.trim();
                    if (line.length() == 0) {
                        if (!ignoreEmptyLine)
                            break;
                    } else {
                        if (commentChars.length() == 0
                                || commentChars.indexOf(line.charAt(0)) < 0) {
                            break;
                        }
                    }
                }

                return line;
            }

            public boolean hasNext() {
                if (endOfFile)
                    return false;
                if (nextString == null) {
                    try {
                        nextString = getNextValidString();
                    } catch (IOException e) {
                        lastException = e;
                    }

                    if (nextString == null) {
                        endOfFile = true;
                        return false;
                    } else {
                        return true;
                    }
                } else {
                    return true;
                }
            }

            public String next() {
                if (nextString == null) {
                    if (!hasNext())
                        throw new NoSuchElementException();
                }
                String ret = nextString;
                nextString = null;
                return ret;
            }

            public void remove() {
                throw new AbstractMethodError(
                        "file line iterator do not support remove()");
            }

        }

    }

}
