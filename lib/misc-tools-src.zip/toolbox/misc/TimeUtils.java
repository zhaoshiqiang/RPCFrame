package toolbox.misc;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * @author Feng Jiang (Feng.a.Jiang@gmail.com)
 * @since Apr 11, 2007
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class TimeUtils {

    private static final SimpleDateFormat rfc1123Formatter = new SimpleDateFormat(
            "EEE, d MMM yyyy HH:mm:ss 'GMT'", Locale.US);

    private static final SimpleDateFormat digitalFormatter = new SimpleDateFormat(
            "yyMMdd-HH:mm:ss", Locale.US);

    /**
     * 将"毫秒"时间单位格式化成RFC1123标准。
     * <p>
     * 例如：Sun, 21 Aug 2002 13:56:03 GMT
     * 
     * @param time
     * @return
     */
    public static String formatTimeAsRfc1123(long time) {
        //        if(time < 0)
        //            throw new IllegalArgumentException("The time parameter cannot be less than 0.");
        return rfc1123Formatter.format(new Date(time));
    }

    /**
     * 将"秒"时间单位格式化成RFC1123标准。
     * <p>
     * 例如：Sun, 21 Aug 2002 13:56:03 GMT
     * 
     * @param time
     * @return
     */
    public static String formatTimeInSecAsRfc1123(int time) {
        //        if(time < 0)
        //            throw new IllegalArgumentException("The time parameter cannot be less than 0.");
        return rfc1123Formatter.format(new Date(time * 1000L));
    }

    /**
     * 根据"毫秒"返回数字格式的时间。
     * <p>
     * 例如：031124-15:40:30
     * 
     * @param time
     * @return
     */
    public static String formatTimeAsDigital(long time) {
        //        if(time < 0)
        //            throw new IllegalArgumentException("The time parameter cannot be less than 0.");
        return digitalFormatter.format(new Date(time));
    }

    /**
     * 根据"秒"返回数字格式的时间。
     * <p>
     * 例如：031124-15:40:30
     * 
     * @param time
     * @return
     */
    public static String formatTimeInSecAsDigital(int time) {
        //        if(time < 0)
        //            throw new IllegalArgumentException("The time parameter cannot be less than 0.");
        return digitalFormatter.format(new Date(time * 1000L));
    }

    /**
     * 得到系统当前时间，单位是秒。
     * 
     * @return
     */
    public static int currentTimeSec() {
        return (int) (System.currentTimeMillis() / 1000);
    }

    public static String getTime(long t) {
        StringBuffer time = new StringBuffer();
        long left = t;
        long day = left / UnitUtils.DAY;
        left = left % UnitUtils.DAY;
        long hour = left / UnitUtils.HOUR;
        left = left % UnitUtils.HOUR;
        long min = left / UnitUtils.MINUTE;
        left = left % UnitUtils.MINUTE;
        long second = left / UnitUtils.SECOND;
        if (day != 0)
            time.append(day + "d");
        if (hour != 0)
            time.append(hour + "h");
        if (min != 0)
            time.append(min + "m");
        if (second != 0)
            time.append(second + "s");
        return time.toString();
    }

}
