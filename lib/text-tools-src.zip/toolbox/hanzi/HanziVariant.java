package toolbox.hanzi;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * 获取一个汉字是否具有简体形式或变体字
 * <p>
 * <ul>
 * <li>getSimplifiedForm() 获取汉字的简体形式字符，如：龍（龙）、匯（汇）、瀋（沈）。如果没有，则返回NON_VARIANT。
 * 对于具有简体形式的汉字，通常会进行替换，必须保证这种替换不会引起错误，因此对于具有
 * 简体形式但本身又具有特定含义的汉字将不进行简化，而是提供变体形式，例如：著（着）、 乾（干）、...</li>
 * <li>getVariants() 获取汉字的常用变体字，如：锺（钟）、著（着）、堃（坤）。如果没有，则返回NON_VARIANT。
 * 变体字与原汉字通常具有相同或相似的语义，在某些时候可以互换使用，特别是不同地区 的汉字使用，如“広岛”（广岛）、“业馀”（业余）。
 * 对两个汉字A和B，如果A是B的变体，则B也为A的变体，但在实际使用时，仅提供罕见字到 常见字的变形（根据汉字频率）。</li>
 * </ul>
 * 
 * @author Li Fei
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class HanziVariant {
    /**
     * Char indicating no variant
     */
    public static final char NON_VARIANT = '\u0000';

    private static final char LOWER_HANZI_BOUND = '\u3400';

    private static final char UPPER_HANZI_BOUND = '\u9FFF';

    private static final char[] variants;

    private static boolean isLoaded = false;
    static {
        variants = new char[UPPER_HANZI_BOUND - LOWER_HANZI_BOUND + 1];
        for (int i = 0; i < variants.length; i++) {
            variants[i] = NON_VARIANT;
        }

        InputStream is = HanziVariant.class.getResourceAsStream("hanzivariants.properties");
        if (is == null) {
            System.out.println("Cannot find code table in classpath");
        } else {
            try {
                try {
                    loadHanziVariants(is);
                    isLoaded = true;
                } finally {
                    is.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Constructor
     * 
     * @exception IllegalStateException
     *                if resources cannot be loaded
     */
    public HanziVariant() {
        if (!isLoaded) {
            throw new IllegalStateException(
                    "HanziVariant initialization failed!");
        }
    }

    /**
     * Get the simplified form of a hanzi if it has
     * 
     * @param ch
     *            the hanzi to find
     * @return the simplified form of hanzi if it has; or NON_VARIANT, if ch is
     *         not a hanzi or it does not have simplified form
     * @see HanziVariant#NON_VARIANT
     */
    public char getSimplifiedForm(char ch) {
        if ((ch < LOWER_HANZI_BOUND) || (ch > UPPER_HANZI_BOUND)) {
            return NON_VARIANT;
        }

        int var = variants[ch - LOWER_HANZI_BOUND];
        if ((var == NON_VARIANT) || (var > 0x7FFF)) {
            return NON_VARIANT;
        } else {
            return (char) (var + LOWER_HANZI_BOUND - 1);
        }
    }

    /**
     * Get the common variant of a hanzi if it has
     * 
     * @param ch
     *            the hanzi to find
     * @return the common variant of a hanzi if it has; or NON_VARIANT, if ch is
     *         not a hanzi or it does not have common variant
     * @see HanziVariant#NON_VARIANT
     */
    public char getVariants(char ch) {
        if ((ch < LOWER_HANZI_BOUND) || (ch > UPPER_HANZI_BOUND)) {
            return NON_VARIANT;
        }

        int var = variants[ch - LOWER_HANZI_BOUND];
        if ((var == NON_VARIANT) || (var < 0x8000)) {
            return NON_VARIANT;
        } else {
            return (char) (var - 0x8000 + LOWER_HANZI_BOUND - 1);
        }
    }

    /**
     * Load hanzi variants
     * 
     * @param in
     *            the input stream
     * @exception IOException
     *                if any I/O error occurs.
     */
    private static void loadHanziVariants(InputStream in) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(
                new BufferedInputStream(in), "UTF-8"));

        try {
            String line;
            while ((line = reader.readLine()) != null) {
                if ((line.length() == 0) || line.startsWith("#")) {
                    continue;
                }
                if (line.length() != 3) {
                    continue;
                }

                char src = line.charAt(0);
                if ((src < LOWER_HANZI_BOUND) || (src > UPPER_HANZI_BOUND)) {
                    continue;
                }
                int pos = src - LOWER_HANZI_BOUND;

                char dest = line.charAt(1);
                if ((dest < LOWER_HANZI_BOUND) || (dest > UPPER_HANZI_BOUND)) {
                    continue;
                }
                // range of val: [1, 0x6C00]; less than 0x7FFF
                int val = dest - LOWER_HANZI_BOUND + 1;

                boolean isSimplified = line.charAt(2) == '-';
                if (!isSimplified) {
                    val += 0x8000;
                }

                variants[pos] = (char) val;
            }
        } finally {
            reader.close();
        }
    }
}
