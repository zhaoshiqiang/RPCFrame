package toolbox.text.util;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * convert between int/long/bytes and hex string Copyright (c) 2006, Outfox Team
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class HexString {

    /**
     * Convert a bytes array to a hex string without adding ' ' between bytes
     * 
     * @param bytes
     *            The byte array
     * @return The hex string
     */
    public static String bytesToHexNoSpace(byte[] bytes) {
        return bytesToHexNoSpace(bytes, 0, bytes.length);
    }

    /**
     * Convert a bytes array to a hex string without adding ' ' between bytes
     * 
     * @param buf
     *            The byte array
     * @param off
     *            Offset in the byte array
     * @param len
     *            Length from the offset
     * @return The hex string
     */
    public static String bytesToHexNoSpace(byte[] buf, int off, int len) {
        StringBuilder builder = new StringBuilder(len * 2);
        for (int i = 0; i < len; i++) {
            byte b = buf[off + i];
            builder.append(Digits.charDigit((b >> 4) & 0x0f));
            builder.append(Digits.charDigit(b & 0x0f));
        }
        return builder.toString();
    }

    /**
     * Convert a bytes array to a hex string with ' ' between bytes
     * 
     * @param bytes
     *            The byte array
     * @return The hex string
     */
    public static String bytesToHex(byte[] bytes) {
        return bytesToHex(bytes, 0, bytes.length);
    }

    /**
     * Convert a bytes array to a hex string with ' ' between bytes
     * 
     * @param buf
     *            The byte array
     * @param off
     *            Offset in the byte array
     * @param len
     *            Length from the offset
     * @return The hex string
     */
    public static String bytesToHex(byte[] buf, int off, int len) {
        StringBuilder builder = new StringBuilder(len * 2);
        for (int i = 0; i < len; i++) {
            byte b = buf[off + i];
            builder.append(Digits.charDigit((b >> 4) & 0x0f));
            builder.append(Digits.charDigit(b & 0x0f));
            builder.append(' ');
        }
        if (builder.length() > 0)
            builder.setLength(builder.length() - 1);
        return builder.toString();
    }

    /**
     * Convert an int to unsigned, 0-padded, 8-digit hex.
     */
    public static String intToPaddedHex(int x) {
        char[] buf = new char[8];
        for (int i = 0; i < 4; i++) {
            int shift = ((3 - i) << 3);
            buf[(i << 1)] = Digits.charDigit((x >> (shift + 4)) & 0xf);
            buf[(i << 1) + 1] = Digits.charDigit((x >> shift) & 0xf);
        }
        return new String(buf);
    }

    /**
     * Convert an int to unsigned, 0-padded, 8-digit hex.
     */
    public static String longToPaddedHex(long x) {
        char[] buf = new char[16];
        for (int i = 0; i < 8; i++) {
            int shift = ((7 - i) << 3);
            buf[(i << 1)] = Digits.charDigit((int) ((x >> (shift + 4)) & 0xf));
            buf[(i << 1) + 1] = Digits.charDigit((int) ((x >> shift) & 0xf));
        }
        return new String(buf);
    }

    /**
     * Convert a string of hex to a byte array
     * 
     * @param hex
     *            The string of hex
     * @return The byte array
     */
    public static byte[] hexToBytes(String hex) {
        byte[] ans = new byte[hex.length() / 2];
        for (int i = 0; i < hex.length() / 2; i++) {
            ans[i] = (byte) Integer.parseInt(hex.substring(i * 2, i * 2 + 2),
                    16);
        }
        return ans;
    }

    /**
     * Parses the string returned by {@link #intToPaddedHex(int)}.
     * 
     * @param s
     *            An 8-digit hex
     * @return The integer represented by the hex string
     * @throws NumberFormatException
     */
    public static int paddedHexToInt(String s) throws NumberFormatException {
        while (s.length() < 8) {
            s = "0" + s;
        }
        int r = 0;
        for (int i = 0; i < 8; i++) {
            char c = s.charAt(i);
            int shift = (7 - i) << 2;
            if (c >= '0' && c <= '9') {
                r |= ((c - '0') << shift);
            } else if (c >= 'a' && c <= 'f') {
                r |= ((c - 'a' + 10) << shift);
            } else if (c >= 'A' && c <= 'F') {
                r |= ((c - 'A' + 10) << shift);
            } else {
                throw new NumberFormatException("Bad hex character: " + c);
            }
        }
        return r;
    }

    /**
     * Parses the string returned by {@link #longToPaddedHex(long)}.
     * 
     * @param s
     *            An 16-digit hex
     * @return The long represented by the hex string
     * @throws NumberFormatException
     */
    public static long paddedHexToLong(String s) throws NumberFormatException {
        long result = 0;
        int shift = 0;
        for (int i = s.length() - 1; i >= 0; i--) {
            char c = s.charAt(i);

            int value;
            if (c >= '0' && c <= '9') {
                value = c - '0';
            } else if (c >= 'a' && c <= 'f') {
                value = c - 'a' + 10;
            } else if (c >= 'A' && c <= 'F') {
                value = c - 'A' + 10;
            } else {
                throw new NumberFormatException("Bad hex character: " + c);
            }
            result = result | ((long) value << shift);

            shift += 4;
        }
        return result;
    }

}
