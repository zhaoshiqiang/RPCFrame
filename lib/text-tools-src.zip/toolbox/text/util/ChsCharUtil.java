/**
 * @(#)CCharUtil.java, 2007-5-23. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.text.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * 处理中文数字，将其转化为对应的值；处理中文操作符，进制单位等
 * 
 * @author mounttai
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class ChsCharUtil {

    private final static HashMap<Character, Integer> cnumMap = new HashMap<Character, Integer>();

    /**
     * 判断是不是中文的数字
     * 
     * @param ch
     * @return
     */
    public final static boolean isCNum(char ch) {
        return cnumMap.containsKey(ch);
    }

    /**
     * 给定一个中文字符，得到它对应的值
     * 
     * @param ch
     * @return
     */
    public final static int getIValue(char ch) {
        return cnumMap.get(ch);
    }

    private final static HashMap<Character, Double> cjzMap = new HashMap<Character, Double>();

    /**
     * 判断是不是中文的进制
     * 
     * @param ch
     * @return
     */
    public final static boolean isCJZChar(char ch) {
        return cjzMap.containsKey(ch);
    }

    /**
     * 给定一个进制，得到它对应的值，比如：十，对应10.0
     * 
     * @param ch
     * @return
     */
    public final static double getDValue(char ch) {
        return cjzMap.get(ch);
    }

    private final static HashMap<String, String> copMap = new HashMap<String, String>();

    /**
     * 判断一个字符串是不是一个中文操作符
     * 
     * @param op
     * @return
     */
    public final static boolean isCOP(String op) {
        return copMap.containsKey(op);
    }

    /**
     * 给定一个中文操作符，得到它对应的操作符
     * 
     * @param oldOp
     * @return
     */
    public final static String getOP(String oldOp) {
        return copMap.get(oldOp);
    }

    private final static ArrayList<Character> jzArray = new ArrayList<Character>();

    /**
     * 初始化
     */
    static {
        // 数字表
        cnumMap.put('零', 0);
        cnumMap.put('一', 1);
        cnumMap.put('二', 2);
        cnumMap.put('两', 2);
        cnumMap.put('三', 3);
        cnumMap.put('四', 4);
        cnumMap.put('五', 5);
        cnumMap.put('六', 6);
        cnumMap.put('七', 7);
        cnumMap.put('八', 8);
        cnumMap.put('九', 9);

        // 进制表
        cjzMap.put('十', 10.0);
        cjzMap.put('百', 100.0);
        cjzMap.put('千', 1000.0);
        cjzMap.put('万', 10000.0);
        cjzMap.put('亿', 100000000.0);
        cjzMap.put('兆', 1000000000000.0);
        cjzMap.put('京', 10000000000000000.0);

        // 为了截断求整数的字符串
        jzArray.add('京');
        jzArray.add('兆');
        jzArray.add('亿');
        jzArray.add('万');

        // 运算符表
        copMap.put("加", "+");
        copMap.put("加上", "+");
        copMap.put("减", "-");
        copMap.put("减去", "-");
        copMap.put("乘", "*");
        copMap.put("乘以", "*");
        copMap.put("乘上", "*");
        copMap.put("除", "/");
        copMap.put("除去", "/");
        copMap.put("除以", "/");
        copMap.put("除掉", "/");
    }

    // 将中文运算符号里边的所有字符加入到这个串中
    private final static String cOPString = "加上减去乘以除掉";

    /**
     * 判断是不是中文运算符号里边的字符。。。。
     * 
     * @param op
     * @return
     */
    public static boolean isCOpChar(char ch) {
        return cOPString.contains(String.valueOf(ch));
    }

    /**
     * 判断是不是中文的"."
     * 
     * @param ch
     * @return
     */
    public static boolean isCDot(char ch) {
        return ch == '点';
    }

    /**
     * 判断是不是合法的中文数字字符
     * 
     * @param ch
     * @return
     */
    public static boolean isValidCNumber(char ch) {
        return isCNum(ch) || isCJZChar(ch) || isCDot(ch);
    }

    /**
     * 求如这样的形式：[*千][*百][*十][零]*的表达式的值
     * 
     * @param token
     * @param jz
     * @return
     * @throws ChsUtilException
     */
    private static double getSubCIntValue(String token, Character jz)
            throws ChsUtilException {
        // 如果第一个字符不是中文数字
        if (!ChsCharUtil.isCNum(token.charAt(0))) {
            throw new ChsUtilException(
                    "the first char should be a chinese number");
        }
        double result = 0;
        int tIdx = 0;
        boolean bEnd = false;
        while (tIdx < token.length()) {
            double tmpResult = ChsCharUtil.getIValue(token.charAt(tIdx));
            int tmpIdx = tIdx + 1;
            if (tmpIdx < token.length()) {
                if (ChsCharUtil.isCJZChar(token.charAt(tmpIdx))) {
                    char ch = token.charAt(tmpIdx);
                    if (!(ch == '千' || ch == '百' || ch == '十'))
                        throw new ChsUtilException("exception");
                    tmpResult = tmpResult
                            * ChsCharUtil.getDValue(token.charAt(tmpIdx));
                    tIdx++;
                    bEnd = false;
                } else {
                    if (token.charAt(tIdx) != '零') { // "一百零四"合法，"一百三四"非法
                        bEnd = true; // 如果数字后边没有出现进制的话，说明已经到了末尾
                    }
                }
            } else {
                if (bEnd)
                    throw new ChsUtilException(
                            "tow chinese number can't be together");
            }
            result += tmpResult;
            tIdx++;
        }

        if (jz != null) {
            result = result * ChsCharUtil.getDValue(jz);
        }
        return result;
    }

    /**
     * 计算中文整数的值，计算方法如下： 因为十，百，千的地位和万，亿，兆，京的地位不一样，
     * 所以将整个字符串拆成这样的形式[*****京][*****兆][****亿][****万]**的格式， 对每一段，分别求值，然后所有值相加
     * 
     * @param token
     * @return
     * @throws ParserException
     */
    private static double getCIntValue(String token) throws ChsUtilException {
        if (token.length() == 0) {
            throw new ChsUtilException("length should be greater than 0");
        }
        double result = 0;
        int jzIdx = 0;

        String token1 = token;

        while (jzIdx < jzArray.size()) {
            char jz = jzArray.get(jzIdx);
            if (token1.contains(String.valueOf(jz))) { //里边顺序含有"京兆亿万"
                int pos = token1.indexOf(jz);
                String sub = token1.substring(0, pos);
                result += getSubCIntValue(sub, jz); // 得到这部分结果
                token1 = token1.substring(token1.indexOf(jz) + 1);
            }
            jzIdx++;
        }

        return result + getSubCIntValue(token1, null);
    }

    /**
     * 对于一串如"四五六"的字符串，返回它们作为小数部的值，如"四五六"=0.456
     * 
     * @param token
     * @return
     * @throws ParserException
     */
    private static double getCDecValue(String token) throws ChsUtilException {
        double result = 0.0;
        double factor = 0.1;
        for (int i = 0; i < token.length(); i++) {
            if (!ChsCharUtil.isCNum(token.charAt(i)))
                throw new ChsUtilException(
                        "the first char should be a chinese number");
            result = result + ChsCharUtil.getIValue(token.charAt(i)) * factor;
            factor = factor * 0.1;
        }

        return result;
    }

    /**
     * 判断是不是中文小数
     * 
     * @param token
     * @return
     */
    private static boolean isCDecimal(String token) {
        int len = token.length();
        for (int i = 0; i < len; i++) {
            if (token.charAt(i) == '点')
                return true;
        }
        return false;
    }

    /**
     * 对于一串中文数字和进制，得到它的值
     * 
     * @param token
     * @return
     * @throws ParserException
     * @throws ChsUtilException
     */
    public static double getCValue(String token) throws ChsUtilException {
        double result = 0.0;
        if (ChsCharUtil.isCDecimal(token)) { // 是中文小数
            String intPart = token.substring(0, token.indexOf('点'));
            result += ChsCharUtil.getCIntValue(intPart);

            String decPart = token.substring(token.indexOf('点') + 1);
            result += ChsCharUtil.getCDecValue(decPart);

        } else { // 是中文整数
            result += ChsCharUtil.getCIntValue(token);
        }
        return result;
    }

    public static void main(String[] argv) {
        String expr;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter an empty string to stop");
        for (;;) {
            System.out.println("输入中文数字:");
            try {
                expr = br.readLine();
                expr = expr.trim();
                if (expr.equals(""))
                    break;
                System.out.println("Result: " + ChsCharUtil.getCIntValue(expr));
                System.out.println();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ChsUtilException e) {
                e.printStackTrace();
            }
        }
    }
}
