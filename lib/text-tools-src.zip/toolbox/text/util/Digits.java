/**
 * @(#)Digits.java, 2012-1-20. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.text.util;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * This class contains all possible chars for representing a number as a String
 * 
 * @author zhangduo
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public final class Digits {

    private static final char[] digits = {
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd',
        'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r',
        's', 't', 'u', 'v', 'w', 'x', 'y', 'z'
    };

    /**
     * Return the char representing of a int number.
     * <p>
     * The max digit allowed is 35(we only have 36 chars 0-9 and a-z)
     * 
     * @param digit
     * @return
     */
    public static char charDigit(int digit) {
        return digits[digit];
    }
}
