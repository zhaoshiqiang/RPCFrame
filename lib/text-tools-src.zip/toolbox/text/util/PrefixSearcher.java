package toolbox.text.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Set;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;
import toolbox.text.patternsearch.StringLengthComparator;

/**
 * Compile a set of prefix, and check whether a string start with one of the
 * prefixes. The isPrefixInSet function is thread safe. The compile function
 * should call at the begining
 * 
 * @author Mingjiang Ye (yemingjiang@rd.netease.com). Copyright (c) 2006, Outfox
 *         Team
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class PrefixSearcher {

    protected static final int DEFAULT_HASHMAP_CAPACITY = 16;

    protected static final float DEFAULT_HASHMAP_LOAD_FACTOR = 0.5f;

    protected HashMap<String, ArrayList<String>> prefixMap = new HashMap<String, ArrayList<String>>(
            DEFAULT_HASHMAP_CAPACITY, DEFAULT_HASHMAP_LOAD_FACTOR);

    protected int minLen = 0;

    /**
     * pre-process the pattern set
     * 
     * @param prefixSet
     *            The Prefix String set to be match.
     * @return true of false
     */
    public boolean compile(Set<String> prefixSet) {
        if (prefixSet.size() <= 0)
            return false;

        minLen = Integer.MAX_VALUE;
        for (String prefix: prefixSet) {
            if (minLen > prefix.length())
                minLen = prefix.length();
        }
        if (minLen < 2)
            return false;

        for (String prefix: prefixSet) {
            String key = prefix.substring(0, minLen);
            ArrayList<String> prefixLst = prefixMap.get(key);
            if (prefixLst == null) {
                prefixLst = new ArrayList<String>();
                prefixMap.put(key, prefixLst);
            }
            prefixLst.add(prefix);
        }

        // we have to sort the prefixLst to make sure the longest prefix will match first
        StringLengthComparator comp = new StringLengthComparator();
        for (ArrayList<String> lst: prefixMap.values()) {
            Collections.sort(lst, comp);
        }

        return true;
    }

    /**
     * get the matched prefix, return null if not hit
     * 
     * @param text
     *            The text to be searched.
     */
    public String getHitPrefix(String text) {
        if (text.length() < minLen)
            return null;
        ArrayList<String> prefixLst = prefixMap.get(text.substring(0, minLen));
        if (prefixLst == null)
            return null;

        // scan the prefix has the same substring key
        for (String prefix: prefixLst) {
            int prefixLen = prefix.length();
            // if the text longer than prefix length
            if (prefixLen <= text.length()) {
                boolean match = true;
                // compare from end to start
                for (int i = prefixLen - 1; i >= minLen; i--) {
                    if (text.charAt(i) != prefix.charAt(i)) {
                        match = false;
                        break;
                    }
                }
                if (match)
                    return prefix;
            }
        }
        return null;
    }

    /**
     * search the text for the prefix.
     * 
     * @param text
     *            The text to be searched.
     */
    public boolean isPrefixInSet(String text) {
        if (getHitPrefix(text) == null)
            return false;
        return true;
    }
}
