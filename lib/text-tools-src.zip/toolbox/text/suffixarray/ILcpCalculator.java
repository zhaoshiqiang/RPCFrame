package toolbox.text.suffixarray;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * the interface of the LCP calculator, LCP is the logest common prefix length
 * between Text(SuffixArray[i-1], n)~Text(SuffixArray[i], n) input the original
 * text and the suffix array, output the lcp array
 * 
 * @author Mingjiang Ye (yemingjiang@rd.netease.com). Copyright (c) 2006, Outfox
 *         Team
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public interface ILcpCalculator {

    /**
     * return the result in given SuffixArray
     * 
     * @param text
     *            string to be construct suffix array
     * @param sa
     *            the suffix array of the text
     * @param lcp
     *            lcp Array to store the result
     * @return successful or not
     */
    boolean getLcpArray(String text, int[] sa, int[] lcp);

    /**
     * return the result in given SuffixArray
     * 
     * @param text
     *            string to be construct suffix array
     * @param sa
     *            the suffix array of the text
     * @param size
     *            the size of the text and suffix array
     * @param lcp
     *            lcp Array to store the result
     * @return successful or not
     */
    boolean getLcpArray(char[] text, int[] sa, int size, int[] lcp);
}
