package toolbox.text.suffixarray;

import java.util.HashMap;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * the factory of the suffix array algorithm and the lcp algorithm
 * 
 * now only support 
 *                suffix array algorithm (1) ks
 *                lcp algorithm :(1) ksasai (2) manzini
 * 
 * @author Mingjiang Ye (yemingjiang@rd.netease.com).
 * 
 * Copyright (c) 2006, Outfox Team
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class SuffixArrayFactory {
    public static final String KS_SUFFIXARRAY_ALGORLTHM = "karkkainen-Sanders";

    public static final String KASAI_LCP_ALGORLTHM = "kasai";

    public static final String MANZINI_LCP_ALGORLTHM = "manzini";

    protected static final HashMap<String, Class<? extends ISuffixArrayConstructor>> constructorMap;

    protected static final HashMap<String, Class<? extends ILcpCalculator>> lcpCalMap;

    static {
        constructorMap = new HashMap<String, Class<? extends ISuffixArrayConstructor>>();
        constructorMap.put(KS_SUFFIXARRAY_ALGORLTHM, KSConstructor.class);

        lcpCalMap = new HashMap<String, Class<? extends ILcpCalculator>>();
        lcpCalMap.put(KASAI_LCP_ALGORLTHM, KasaiLcpCalculator.class);
        lcpCalMap.put(MANZINI_LCP_ALGORLTHM, ManziniLcpCalculator.class);

    }

    /**
     * create the suffix array algorithm
     * 
     * @param name
     *            the name of the algorithm
     * @return the ISuffixArrayConstructor object
     */
    public static ISuffixArrayConstructor createConstructor(String name) {
        Class<? extends ISuffixArrayConstructor> clz = constructorMap.get(name);
        if (clz == null)
            return null;

        ISuffixArrayConstructor constructor;
        try {
            constructor = clz.newInstance();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            return null;
        }

        return constructor;
    }

    /**
     * create the lcp algorithm
     * 
     * @param name
     *            the name of the algorithm
     * @return the ILcpCalculator object
     */
    public static ILcpCalculator createLcpAlg(String name) {
        Class<? extends ILcpCalculator> clz = lcpCalMap.get(name);
        if (clz == null)
            return null;

        ILcpCalculator calculator;
        try {
            calculator = clz.newInstance();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            return null;
        }

        return calculator;
    }

}
