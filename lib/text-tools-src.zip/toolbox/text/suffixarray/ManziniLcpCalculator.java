package toolbox.text.suffixarray;

import java.util.Arrays;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;


/**
 * Manzini LCP algorithm for lcp calculater
 * 
 * it will take O(n) time , no temporarily memory need
 * number of character in text, the size of lcp array is 4n
 * 
 * it is about 13% slower than KasaiLcpCalculator for large text
 * but it should be more slower for small text and large alphabet size 
 * 
 * For more information see 
 * - Two Space Saving Tricks for Linear Time LCP Array Computation
 *         by Giovanni Manzini(04)
 * 
 * refactor from C++ code in the paper
 * 
 * @author Mingjiang Ye (yemingjiang@rd.netease.com).
 * 
 * Copyright (c) 2006, Outfox Team
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class ManziniLcpCalculator implements ILcpCalculator {

    protected int[] alphabetCount = new int[Character.MAX_VALUE];

    protected int[] alphabetCumCount = new int[Character.MAX_VALUE];

    /**
     * return the result in given SuffixArray
     * 
     * @param text
     *            string to be construct suffix array
     * @param sa
     *            the suffix array of the text
     * @param lcp
     *            lcp Array to store the result
     * @return successful or not
     */
    public boolean getLcpArray(String text, int[] sa, int[] lcp) {
        // TODO Auto-generated method stub
        // init rank array
        char[] content = text.toCharArray();
        return getLcpArray(content, sa, text.length(), lcp);
    }

    /**
     * return the result in given SuffixArray
     * 
     * @param text
     *            string to be construct suffix array
     * @param sa
     *            the suffix array of the text
     * @param size
     *            the size of the text and suffix array
     * @param lcp
     *            lcp Array to store the result
     * @return successful or not
     */
    public boolean getLcpArray(char[] text, int[] sa, int size, int[] lcp) {

        int j, nextk = -1;
        // compute rank_next map
        int k = Sa2RankNext(text, sa, size, lcp); // k is the rank of 0
        int h = 0;

        for (int i = 0; i < size; i++) {
            nextk = lcp[k]; // read nextk before it is overwritten
            if (k > 0) {
                j = sa[k - 1];
                while (i + h < size && j + h < size
                        && text[i + h] == text[j + h])
                    h++;
                lcp[k] = h; // h is the lcp, write it to lcp[k];  
            } else
                lcp[k] = -1;

            if (h > 0)
                h--;
            k = nextk;
        }

        return true;
    }

    public int Sa2RankNext(char[] text, int[] sa, int size, int[] rankNext) {
        // fill the alphabetCumCount
        fillCumcount(text, size);

        // caulate RankNext
        int eos_pos = 0, j = 0;
        j = alphabetCumCount[text[size - 1]]++; // this is bwt[0]
        rankNext[j] = 0;
        char c = 0;
        for (int i = 0; i < size; i++) {
            if (sa[i] == 0)
                eos_pos = i;
            else {
                c = text[sa[i] - 1];
                j = alphabetCumCount[c]++;
                rankNext[j] = i;
            }
        }
        return eos_pos;
    }

    protected void fillCumcount(char[] text, int size) {
        // count the occ of every alpha
        Arrays.fill(alphabetCount, (char) 0);
        // occur number of every charcter
        for (int i = 0; i < size; i++)
            alphabetCount[text[i]]++;
        // cum number of charter k , = alphabetCount[0]＋....alphabetCount[k-1]
        alphabetCumCount[0] = 0;
        for (int i = 1; i < Character.MAX_VALUE; i++)
            alphabetCumCount[i] = alphabetCumCount[i - 1]
                    + alphabetCount[i - 1];
    }

    public static void main(String args[]) throws Exception {
        // run the constructor
        KSConstructor skew = new KSConstructor();
        int[] sa = new int[18];
        String text = "mississippi";
        char[] temp = new char[text.length() + 20];
        text.getChars(0, text.length(), temp, 0);
        System.out.println(skew.getSuffixArray(temp, text.length(), sa));
        for (int i = 0; i < text.length(); i++)
            System.out.println(text.substring(sa[i]));

        System.out.print("SA  :\t");
        for (int i = 0; i < text.length(); i++)
            System.out.print(sa[i] + "\t");
        System.out.println();

        System.out.print("RANK:\t");
        int rank[] = new int[11];
        for (int i = 0; i < text.length(); i++)
            rank[sa[i]] = i;
        for (int i = 0; i < text.length(); i++)
            System.out.print(rank[i] + "\t");
        System.out.println();

        System.out.print("RKNT:\t");
        int ranknt[] = new int[100];
        for (int i = 0; i < text.length(); i++) {
            int index = sa[i] + 1;
            if (index == text.length())
                ranknt[i] = -1;
            else
                ranknt[i] = rank[index];
        }
        for (int i = 0; i < text.length(); i++)
            System.out.print(ranknt[i] + "\t");
        System.out.println();

        //run the lcp caculator
        ManziniLcpCalculator manzini = new ManziniLcpCalculator();
        int[] lcp = new int[100];
        System.out.print("LCP:\t");
        manzini.getLcpArray(temp, sa, text.length(), lcp);
        for (int i = 0; i < text.length(); i++)
            System.out.print(lcp[i] + "\t");
    }

}
