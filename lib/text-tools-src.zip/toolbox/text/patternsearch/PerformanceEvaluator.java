package toolbox.text.patternsearch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.TreeSet;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * evaluator the performance of each pattern search algorithm
 * only for this toolbox developer 
 *
 * @author Mingjiang Ye (yemingjiang@rd.netease.com).
 * 
 * Copyright (c) 2006, Outfox Team
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class PerformanceEvaluator {

    public static byte[] getFileContent(File file) {
        FileInputStream in;
        byte[] content = null;
        try {
            in = new FileInputStream(file);
            content = new byte[(int) file.length()];
            int len = in.read(content);
            assert len == file.length();
            in.close();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return content;
    }

    protected String readText(File dir) throws UnsupportedEncodingException {
        FileFilter filter = new FileFilter() {
            public boolean accept(File file) {
                if (file.getName().toLowerCase().endsWith("parsed"))
                    return true;
                return false;
            }
        };
        File[] textFiles = dir.listFiles(filter);

        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < textFiles.length; i++) {
            byte[] content = getFileContent(textFiles[i]);
            String temp = new String(content, "utf8");
            builder.append(temp);
        }

        return builder.toString();
    }

    protected TreeSet<String> readHotWord(File hotwordFile) throws IOException {
        TreeSet<String> hotWords = new TreeSet<String>();
        FileInputStream fis;
        fis = new FileInputStream(hotwordFile);
        BufferedReader reader = new BufferedReader(new InputStreamReader(fis,
                "utf-8"));
        try {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim().toLowerCase();
                if (line.length() > 0 && !line.startsWith("#")
                        && !hotWords.contains(line)) {
                    hotWords.add(line);
                }
            } // while
        } finally {
            fis.close();
        }
        return hotWords;
    }

    public void run() throws IOException {
        String text = readText(new File("./dataset"));
        IPatternSearcher searcher;

        TreeSet<String> set = readHotWord(new File(
                "./dataset/spam_hotwords.txt"));

        System.out.println(" total text size is" + text.length()
                + " characters");

        System.out.println(" run java regex ");
        searcher = PatternSearcherFactory
                .createPatternSearcher(PatternSearcherFactory.JAVA_REGEX_PATTERN_SEARCHER);
        searcher.compile(set, 1);
        runTest(searcher, text);
        System.out.println();

        System.out.println(" run AHO_CORASICK_SEARCHER");
        searcher = PatternSearcherFactory
                .createPatternSearcher(PatternSearcherFactory.AHO_CORASICK_SEARCHER);
        searcher.compile(set, 1);
        runTest(searcher, text);
        System.out.println();
    }

    protected void runTest(IPatternSearcher searcher, String text) {
        // TODO Auto-generated method stub
        long start = System.currentTimeMillis();
        searcher.search(text);
        long time = System.currentTimeMillis() - start;
        float speed = text.length() * 1000.0f / time;
        System.out.println("time is :" + time + " msec," + "speed is" + speed
                + " char/sec");

    }

    public static void main(String args[]) throws Exception {

        PerformanceEvaluator evaluator = new PerformanceEvaluator();

        evaluator.run();
    }

}
