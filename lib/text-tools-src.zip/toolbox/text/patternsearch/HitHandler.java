package toolbox.text.patternsearch;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * check whether the input string match the pattern once matched , stop search
 * and record the first hit string
 * 
 * @author Mingjiang Ye (yemingjiang@rd.netease.com).
 * 
 * Copyright (c) 2006, Outfox Team
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class HitHandler implements IMatchHandler {

    protected boolean hitFlag = false;

    protected String hitStr = null;

    /**
     * Called by StringSearch upon a hit.
     * 
     * @param startIndex
     *            The startindex of the hit
     * @param term
     *            The term that was found
     * @return true the search will continue false the search will stopped
     */
    public boolean foundAt(int startIndex, String term) {
        // TODO Auto-generated method stub
        hitFlag = true;
        hitStr = term;
        return false;
    }

    /**
     * @return whether the input string matchecd the pattern set
     */
    public boolean isHit() {
        return hitFlag;
    }

    /**
     * @return the hit string , null if not hit
     */
    public String getHitStr() {
        return hitStr;
    }

    /**
     * clear the matched result
     */
    public void clear() {
        hitFlag = false;
        hitStr = null;
    }

}
