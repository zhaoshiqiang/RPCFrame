package toolbox.text.patternsearch;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * counter the match result in the input string
 * 
 * @author Mingjiang Ye (yemingjiang@rd.netease.com).
 * 
 * Copyright (c) 2006, Outfox Team
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class CounterHandler implements IMatchHandler {

    protected int counter = 0;

    /**
     * Called by StringSearch upon a hit.
     * 
     * @param startIndex
     *            The startindex of the hit
     * @param term
     *            The term that was found
     * @return true the search will continue false the search will stopped
     */
    public boolean foundAt(int startIndex, String term) {
        counter++;
        return true;
    }

    /**
     * @return the number of the match result
     */
    public int getCounter() {
        return counter;
    }

    /**
     * clear the counter
     */
    public void ClearCounter() {
        counter = 0;
    }

}
