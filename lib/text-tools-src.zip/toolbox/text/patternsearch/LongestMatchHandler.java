package toolbox.text.patternsearch;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * record the longest matched pattern in text, only record the first longest
 * pattern
 * 
 * @author Mingjiang Ye (yemingjiang@rd.netease.com).
 * 
 * Copyright (c) 2006, Outfox Team
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class LongestMatchHandler implements IMatchHandler {

    protected boolean hitFlag = false;

    protected String hitStr = null;

    /**
     * Called by StringSearch upon a hit.
     * 
     * @param startIndex
     *            The startindex of the hit
     * @param term
     *            The term that was found
     * @return true the search will continue false the search will stopped
     */
    public boolean foundAt(int startIndex, String term) {
        if (!hitFlag || (hitFlag && (term.length() > hitStr.length())))
            hitStr = term;
        hitFlag = true;
        return true;
    }

    /**
     * @return whether the input string matchecd the pattern set
     */
    public boolean isHit() {
        return hitFlag;
    }

    /**
     * @return the hit string , null if not hit
     */
    public String getHitStr() {
        return hitStr;
    }

    /**
     * clear the matched result
     */
    public void clear() {
        hitFlag = false;
        hitStr = null;
    }
}
