/**
 * @(#)CharHashMap.java, 2011-5-20. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.text.patternsearch;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * 利用数组实现的 key 为 char 类型的 map。<br />
 * 相比 hashmap，优点是：
 * <ul> 
 *  <li> 快，没有了碰撞之类的检测，纯查表 </li>
 *  <li> 实现简单 </li>
 * </ul>
 * 
 * XXX : 没有完全实现接口 {@link Map}，主要考虑如下： <br />
 * <ol>
 *   <li> 这个 text 包里面使用的只是 map 中的简单接口 </li>
 *   <li> 能相互作用的视图(set views)实现麻烦，既然没有用到就不想实现了 </li>
 * </ol> 
 * 
 * modified : 将查一个长度为 65536 的表改成查 2 级表，在稀疏的情况下，能节约较多内存。
 * 
 * @author jiangfy
 *
 */
class CharMap<V> {
    
    private Object [][] values = new Object[256][]; // 低 8位 x 高8位
    private int size = 0;

    /**
     * size of map
     * @return
     */
    public int size() {
        return size;
    }

    /**
     * test whether map is empty
     * @return
     */
    public boolean isEmpty() {
        return size == 0;
    }

    /**
     * same as {@link Map#containsKey(Object)}
     * @param key
     * @return
     */
    public boolean containsKey(Object key) {
        Character k = (Character)key;
        int v = k.charValue();
        int low = v & 0xff;
        if (values[low] != null) {
            int high = (v & 0xff00) >> 8;
            return values[low][high] != null;
        }
        return false;
    }

    /**
     * same as {@link Map#get(Object)}
     * @param key
     * @return
     */
    @SuppressWarnings("unchecked")
    public V get(Object key) {
        Character k = (Character)key;
        int v = k.charValue();
        int low = v & 0xff;
        if (values[low] != null) {
            int high = (v & 0xff00) >> 8;
            return (V) values[low][high];
        }
        return null;
    }

    /**
     * same as {@link Map#put(Object, Object)}
     * @param key
     * @param value
     * @return
     */
    @SuppressWarnings("unchecked")
    public V put(Character key, V value) {
        int v = key.charValue();
        int high = (v & 0xff00) >> 8;
        int low = v & 0xff;
        if (values[low] == null) {
            values[low] = new Object[256];
        }
        
        V pre = (V) values[low][high];
        values[low][high] = value;
        if (pre == null)
            size ++;
        return pre;
    }

    /**
     * same as {@link Map#remove(Object)}
     * @param key
     * @return
     */
    @SuppressWarnings("unchecked")
    public V remove(Object key) {
        Character k = (Character)key;
        int v = k.charValue();
        int low = v & 0xff;
        
        if (values[low] != null) {
            int high = (v & 0xff00) >> 8;
            V val = (V) values[low][high];
            values[low][high] = null;
            if (val != null) {
                size --;
            }
            return val;
        }
        return null;
    }

    /**
     * same as {@link Map#putAll(Map)}
     * @param m
     */
    @SuppressWarnings({
        "rawtypes", "unchecked"
    })
    public void putAll(Map<? extends Character, ? extends V> m) {
        for (Map.Entry entry : m.entrySet()) {
            put((Character)entry.getKey(), (V)entry.getValue());
        }
    }

    /**
     * same as {@link Map#clear()}
     */
    public void clear() {
        for (int i = 0; i < values.length; i ++)
            values[i] = null;
        size = 0;
    }

    /**
     * get a set of all keys, change of set has no effect on map
     * @return
     */
    public Set<Character> keySet() {
        HashSet<Character> set = new HashSet<Character>();
        for (int i = 0; i < values.length; i ++) { //low
            if (values[i] != null) {
                for (int j = 0; j < values[i].length; j ++) { // high
                    if (values[i][j] != null)
                        set.add(Character.valueOf((char)(j << 8 + i)));
                }
            }
        }
        return set;
    }

    /**
     * get a collection of all values, change of the collection has no effect on map
     * @return
     */
    @SuppressWarnings("unchecked")
    public Collection<V> values() {
        Collection<V> col = new ArrayList<V>();
        for (int i = 0; i < values.length; i ++) {
            if (values[i] != null) {
                for (Object o : values[i]) {
                    if (o != null)
                        col.add((V)o);
                }
            }
        }
        return col;
    }

    /**
     * get a set of all <k,v> entries, change of set has no effect on map
     * @return
     */
    @SuppressWarnings({
        "unchecked", "rawtypes"
    })
    public Set<Map.Entry<Character, V>> entrySet() {
        HashSet<Map.Entry<Character, V>> set = new HashSet<Map.Entry<Character,V>>();
        
        for (int i = 0; i < values.length; i ++) {
            if (values[i] != null) {
                Map.Entry<Character, V> entry = new MyEntry((char)i, (V)values[i]);
                set.add(entry);
            }
        }
        
        return set;
    }
    
    /**
     * entry, see {@link Map.Entry}
     *
     * @author jiangfy
     *
     * @param <V>
     */
    static class MyEntry<V> implements Map.Entry<Character, V> {
        
        private Character key;
        private V value;
        
        public MyEntry(Character key, V value) {
            this.key = key;
            this.value = value;
        }

        @Override
        public Character getKey() {
            return key;
        }

        @Override
        public V getValue() {
            return value;
        }

        @Override
        public V setValue(V value) {
            this.value = value;
            return value;
        }
        
    }
}
