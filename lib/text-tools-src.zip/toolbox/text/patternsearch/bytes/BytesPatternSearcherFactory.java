package toolbox.text.patternsearch.bytes;

import java.util.HashMap;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * the factory of the pattern searcher algorithm
 * 
 * now only support (1) java regex (2) Aho-corasick, (3) WuManber
 * 
 * @author Mingjiang Ye (yemingjiang@rd.netease.com), David
 * 
 * Copyright (c) 2006, Outfox Team
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class BytesPatternSearcherFactory {

    public static final String JAVA_REGEX_PATTERN_SEARCHER = "regex";

    public static final String WU_MANBER_SEARCHER = "wu-manber";

    public static final String AHO_CORASICK_SEARCHER = "aho-corasick";

    protected static final HashMap<String, Class<?>> searcherMap = new HashMap<String, Class<?>>();
    
    static {
        searcherMap.put(AHO_CORASICK_SEARCHER, AhoCorasickBytesSearcher.class);

    }

    /**
     * Creates a bytes pattern searcher algorithm
     * 
     * @param name  the name of the algorithm
     * @return the IBytesPatternSearcher instance if success, null if the 
     *         specified algorithm was not found, of creation failed.
     */
    public static IBytesPatternSearcher createPatternSearcher(String name) {
        Class<?> clz = searcherMap.get(name);
        if (clz == null)
            return null;

        IBytesPatternSearcher searcher;
        try {
            searcher = (IBytesPatternSearcher) clz.newInstance();
        } catch (Exception e) {
            return null;
        }

        return searcher;
    }
}
