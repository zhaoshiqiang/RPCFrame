package toolbox.text.patternsearch.bytes;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Set;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;


/**
 * Aho-Corasick text search algorithm implementation
 * 
 * NOTE: For more information visit -
 * http://www.cs.uku.fi/~kilpelai/BSA05/lectures/slides04.pdf
 * 
 * refeactor from C# code found in internet
 * 
 * note: when the one pattern A is substring of the other pattern B if ( A is
 * suffix of B) output is just B else output is A and B if you want only output
 * B, you should write an IMatchHandler to ommit it
 * 
 * (1)pattern: "abc" "bcd" text: "abcd" match: "abc" "bcd" (2) pattern: "in"
 * "ain" text: "main" match: only "ain" (3) pattern: "ai" "ain" "main" text:
 * "main" match: "ai" "main"
 * 
 * David:
 *   The algorithm was copied from AhoCorasickSearcher, but some modification
 *   was made for optimization for byte searching
 * 
 * @author Mingjiang Ye (yemingjiang@rd.netease.com), David
 * 
 * Copyright (c) 2006, Outfox Team
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class AhoCorasickBytesSearcher extends AbstractBytesPatternSearcher {

    // / Root of keyword tree
    protected TreeNode _root;

    public AhoCorasickBytesSearcher() {
        super();
    }

    /**
     * pre-process the pattern set
     * 
     * @param words
     *            The String set to be match.
     * @param params
     *            the specific params for each algorithm
     * @return true of false
     */
    public boolean compile(Set<byte[]> words, Object... params) {
        if (words.size() <= 0)
            return false;

        buildTree(words);
        return true;
    }

    /**
     * search the text for the pattern set.
     * 
     * @param text
     *            The text to be searched.
     */
    public void search(byte[] text) {
        TreeNode ptr = _root;
        int index = 0;

        while (index < text.length) {
            TreeNode trans = null;
            while (trans == null) {
                trans = ptr.getTransition(text[index]);
                if (ptr == _root)
                    break;
                if (trans == null)
                    ptr = ptr.getFailure();
            }

            if (trans != null)
                ptr = trans;

            /*
             * for (String found : ptr.getResults()) { if (!
             * handler.foundAt(index - found.length() + 1, found)) return; }
             */

            // only match the longest
            byte[][] results = ptr.getResults();
            if (results.length > 0) {
                byte[] found = results[0];
                if (!handler.foundAt(index - found.length + 1, found))
                    return;
            }
            index++;
        }
    }

    /**
     * Build tree from specified keywords
     */
    protected void buildTree(Set<byte[]> words) {
        // Build keyword tree and transition function
        _root = new TreeNode(null, (byte) 0);

        for (byte[] pattern: words) {
            // add pattern to tree
            TreeNode nd = _root;
            for (int i = 0; i < pattern.length; i++) {
                byte c = pattern[i];
/*                
                TreeNode ndNew = null;
                for (TreeNode trans: nd.getTransitions()) {
                    if (trans.getByte() == c) {
                        ndNew = trans;
                        break;
                    }
                }
*/
                TreeNode ndNew = nd.getTransition(c);
                if (ndNew == null) {
                    ndNew = new TreeNode(nd, c);
                    nd.addTransition(ndNew);
                }
                nd = ndNew;
            }
            nd.addResult(pattern);
        }

        // Find failure functions
        ArrayList<TreeNode> nodes = new ArrayList<TreeNode>();

        // level 1 nodes - fail to root node
        for (TreeNode nd: _root.getTransitions()) {
            nd.setFailure(_root);
            for (TreeNode trans: nd.getTransitions())
                nodes.add(trans);
        }
        // other nodes - using BFS
        while ((nodes.size() != 0)) {
            ArrayList<TreeNode> newNodes = new ArrayList<TreeNode>();
            for (TreeNode nd: nodes) {
                TreeNode r = nd.getParent().getFailure();
                byte c = nd.getByte();

                while (r != null && !r.containsTransition(c))
                    r = r.getFailure();

                if (r == null)
                    nd.setFailure(_root);
                else {
                    nd.setFailure(r.getTransition(c));
                    for (byte[] result: nd.getFailure().getResults())
                        nd.addResult(result);
                }

                // add child nodes to BFS list
                for (TreeNode child: nd.getTransitions())
                    newNodes.add(child);
            } // for nd
            nodes = newNodes;
        } // while
        _root.setFailure(_root);
    }

    /**
     * String Length Comparator, compare the string with their length, reverse 
     * order
     *
     * @author Mingjiang Ye (yemingjiang@rd.netease.com), David
     * 
     * Copyright (c) 2006, Outfox Team
     */
    private static class StringLengthComparator implements Comparator<byte[]> {

        public int compare(byte[] str1, byte[] str2) {
            return str2.length - str1.length;
        }
    }
    
    /**
     * Interal class of the node in ahocorasick tree
     * @author David
     */
    private class TreeNode {

        protected byte inputChar;

        protected TreeNode parent;

        protected TreeNode failure;

        protected TreeNode[] transitionsAr;

        protected ArrayList<byte[]> results;

        protected byte[][] resultsAr;

        protected TreeNode[] transHash;

        protected Comparator<byte[]> resultComparator = 
            new StringLengthComparator();

        public TreeNode(TreeNode parent, byte c) {
            this.inputChar = c;
            this.parent = parent;
            this.results = new ArrayList<byte[]>();
            this.resultsAr = new byte[0][];
            this.transitionsAr = null;
            this.transHash = new TreeNode[256];
        }

        // Adds pattern ending in this node
        public void addResult(byte[] result) {
            if (results.contains(result))
                return;
            results.add(result);
            resultsAr = results.toArray(new byte[results.size()][]);
            // we will sort it by string length
            Arrays.sort(resultsAr, resultComparator);
        }

        // Adds trabsition node
        public void addTransition(TreeNode node) {
            transHash[node.inputChar & 0xff] = node;
            transitionsAr = null;
        }

        public TreeNode getTransition(byte c) {
            return transHash[c & 0xff];
        }

        public boolean containsTransition(byte c) {
            return getTransition(c) != null;
        }

        public byte getByte() {
            return inputChar;
        }

        public TreeNode getParent() {
            return parent;
        }

        public TreeNode getFailure() {
            return failure;
        }

        public void setFailure(TreeNode node) {
            this.failure = node;
        }

        public TreeNode[] getTransitions() {
            if (transitionsAr == null) {
                int cnt = 0;
                for (int i = 0; i < transHash.length; i ++)
                    if (transHash[i] != null)
                        cnt ++;
                transitionsAr = new TreeNode[cnt];
                cnt = 0;
                for (int i = 0; i < transHash.length; i ++)
                    if (transHash[i] != null)
                        transitionsAr[cnt ++] = transHash[i];
            } // if
            
            return transitionsAr;
        }

        public byte[][] getResults() {
            return resultsAr;
        }
    }

}
