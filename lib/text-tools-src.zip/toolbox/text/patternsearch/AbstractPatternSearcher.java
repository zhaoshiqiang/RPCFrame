package toolbox.text.patternsearch;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * Abstract class that defines a pattern searcher implements setHandler function
 * 
 * @author Mingjiang Ye (yemingjiang@rd.netease.com).
 *
 * Copyright (c) 2006, Outfox Team
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public abstract class AbstractPatternSearcher implements IPatternSearcher {

    protected IMatchHandler handler;

    /**
     * the defualt constructor
     */
    public AbstractPatternSearcher() {}

    /**
     * set a new match handler to the pattern search.
     * 
     * @param handler
     *            The IMatchHandler to be called when a match occur.
     * @return the old IMatchHandler, if doesn't have on ,return null
     */
    public IMatchHandler setHandler(IMatchHandler handler) {
        IMatchHandler oldHandler = this.handler;
        this.handler = handler;
        return oldHandler;
    }

    /**
     * get current using handler of the pattern search.
     * 
     * @return return the current using IMatchHandler
     */
    public IMatchHandler getHandler() {
        return this.handler;
    }

    /**
     * add thread-safe method for serach,should be overwirted.
     * @param text
     * @param handler
     */
    public void search(String text,IMatchHandler handler){
        throw new RuntimeException("not implemented  in child class.");
    }
    
}
