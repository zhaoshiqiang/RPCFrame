package toolbox.text.patternsearch;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Set;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * Wu-Manber text search algorithm implementation For more information visit A
 * FAST ALGORITHM FOR MULTI-PATTERN SEARCHING,Sun Wu,Udi Manber,1994 params:
 * suffix block size- B, usually 2 or 3 prefix block size -B', usually 2 Notice,
 * it will be efficient if the minum length of the strings in pattern is large
 * if small than 2 , the algorithm can't work if small than 5, i think
 * AhoCorasick will be better it is a heruistic algorithm ,the worst case
 * performance is bad but it is said that the average performance is good
 * 
 * @author Mingjiang Ye (yemingjiang@rd.netease.com). Copyright (c) 2006, Outfox
 *         Team
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class WuManberSearcher extends AbstractPatternSearcher {

    /*
     * public static final int DEFAULT_INTERNAL_BUFFER_SIZE = 1*1024 + 1;
     * protected char[] tempCharBuffer = new char[DEFAULT_INTERNAL_BUFFER_SIZE];
     */

    public static final int DEFAULT_SUFFIX_BLOCK_SIZE = 2;

    public static final int DEFAULT_PREFFIX_BLOCK_SIZE = 2;

    public static final int MIN_BLOCK_SZIE = 2;

    protected int minPatternLen = 0;

    protected int suffixBlockSize = 0;

    protected int prefixBlockSize = DEFAULT_PREFFIX_BLOCK_SIZE;;

    protected int[] shiftTable;

    protected int[] hashTableIndex;

    protected String[] patternTable;

    protected int[] prefixTable;

    protected HashMap<ITextBlock, Integer> blockMap;

    protected ITextBlock tempBlock;

    /**
     * compile
     * 
     * @param words
     *            the search pattern
     * @param params
     *            optional, params[0] is the suffix block size ,default is 2
     * @return true if the search should continue
     */
    public boolean compile(Set<String> words, Object... params) {
        boolean initFlag = initAlgParam(params);
        if (!initFlag)
            return false;

        if (words.size() <= 0)
            return false;

        minPatternLen = getMinPatternLen(words);
        if (minPatternLen < suffixBlockSize || minPatternLen < prefixBlockSize)
            return false;

        // build the suffix block to index mapping
        buildBlockHashMap(words);

        // building the shift tables
        buildShiftTable(words);

        // building the hash table
        buildHashTable(words);

        return true;
    }

    /**
     * internal class for string comparator, compare the string with their
     * length
     * 
     * @author yemingjiang
     */
    class StrLenComparator implements Comparator<String> {

        public int compare(String str1, String str2) {
            return str1.length() - str2.length();
        }
    }

    @SuppressWarnings("unchecked")
    protected void buildHashTable(Set<String> words) {
        int range = blockMap.size();
        ArrayList<String>[] patterns = new ArrayList[range];
        for (int i = 0; i < range; i++)
            patterns[i] = new ArrayList<String>();

        char[] wordContent = new char[minPatternLen];
        for (String word: words) {
            word.getChars(0, minPatternLen, wordContent, 0);
            int hash = hashBlock(wordContent, minPatternLen - 1);
            patterns[hash].add(word);
        }

        Comparator<String> StrLenComparator = new StrLenComparator();

        for (int i = 0; i < range; i++) {
            Collections.sort(patterns[i], StrLenComparator);
        }

        hashTableIndex = new int[range + 1];
        patternTable = new String[words.size()];
        prefixTable = new int[words.size()];
        int index = 0;
        for (int i = 0; i < range; i++) {
            hashTableIndex[i] = index;
            for (int j = 0; j < patterns[i].size(); j++) {
                patternTable[index] = (String) patterns[i].get(j);
                prefixTable[index] = (patternTable[index].charAt(0) << 16)
                        | patternTable[index].charAt(1);
                index++;
            }
        }
        hashTableIndex[range] = words.size();
    }

    protected void buildBlockHashMap(Set<String> words) {
        int numBlock = (minPatternLen - suffixBlockSize + 1);
        blockMap = new HashMap<ITextBlock, Integer>(
                words.size() * numBlock * 2, 0.2f);
        int index = 0;
        for (String word: words) {
            char[] wordContent = new char[minPatternLen];
            word.getChars(0, minPatternLen, wordContent, 0);
            for (int blockEnd = minPatternLen - 1; blockEnd >= suffixBlockSize - 1; blockEnd--) {
                ITextBlock block = createTextBlock(suffixBlockSize);
                block.set(wordContent, blockEnd);
                if (blockMap.get(block) == null) {
                    blockMap.put(block, index++);
                }
            }
        }
        tempBlock = createTextBlock(suffixBlockSize);
    }

    protected int hashBlock(String input, int blockEnd) {
        try {
            ITextBlock textBlock = (ITextBlock) tempBlock.clone();
            textBlock.set(input, blockEnd);
            Integer temp = blockMap.get(textBlock);
            if (temp == null)
                return -1;
            return temp;
        } catch (Exception e) {
            return -1;
        }
    }

    protected int hashBlock(char[] input, int blockEnd) {
        try {
            ITextBlock textBlock = (ITextBlock) tempBlock.clone();
            textBlock.set(input, blockEnd);
            Integer temp = blockMap.get(textBlock);
            if (temp == null)
                return -1;
            return temp;
        } catch (Exception e) {
            return -1;
        }
    }

    protected void buildShiftTable(Set<String> words) {
        shiftTable = new int[blockMap.size()];
        // the init is minPatternLen - 1- suffixBlockSize
        Arrays.fill(shiftTable, minPatternLen - suffixBlockSize + 1);
        char[] wordContent = new char[minPatternLen];

        for (String word: words) {
            word.getChars(0, minPatternLen, wordContent, 0);
            for (int blockEnd = minPatternLen - 1; blockEnd >= suffixBlockSize - 1; blockEnd--) {
                int hash = hashBlock(wordContent, blockEnd);
                if (shiftTable[hash] >= minPatternLen - 1 - blockEnd)
                    shiftTable[hash] = minPatternLen - 1 - blockEnd;
            }
        }
    }

    protected boolean initAlgParam(Object[] params) {
        suffixBlockSize = DEFAULT_SUFFIX_BLOCK_SIZE;
        if (params.length >= 1)
            suffixBlockSize = (Integer) params[0];
        if (suffixBlockSize < MIN_BLOCK_SZIE)
            return false;
        return true;
    }

    protected int getMinPatternLen(Set<String> words) {
        int min = Integer.MAX_VALUE;
        for (String word: words)
            min = word.length() < min ? word.length() : min;
        return min;
    }

    /*
     * public void search(String text) { int textLen = text.length() ; if (
     * textLen < minPatternLen) return; if ( text.length() <=
     * DEFAULT_INTERNAL_BUFFER_SIZE) searchSmallText(text); else
     * searchBigText(text); } public void searchSmallText(String text) { int
     * textLen = text.length() ; int maxShift = minPatternLen - suffixBlockSize +
     * 1; text.getChars(0, textLen,tempCharBuffer, 0); int blockEnd =
     * minPatternLen-1; while (blockEnd < textLen){ int hash = hashBlock(
     * tempCharBuffer, blockEnd); int shift =
     * (hash==-1?maxShift:shiftTable[hash]); if ( shift == 0){ int start =
     * blockEnd-minPatternLen+1; int text_prefix = (tempCharBuffer[start]<<16)|tempCharBuffer[start+1];
     * int from = hashTableIndex[hash]; int end = hashTableIndex[hash+1]; for(
     * int i = from ; i < end; i++){ if ( text_prefix != prefixTable[i] || start +
     * patternTable[i].length() > textLen) continue; boolean found = true; for (
     * int k = 0 ; k < patternTable[i].length() ; k++) if (
     * patternTable[i].charAt(k) != tempCharBuffer[start+k]){ found = false;
     * break; } // call the function to deal with if( found){ if ( !
     * handler.foundAt(start, patternTable[i])) return; } } shift = 1; }
     * blockEnd += shift; } }
     */

    /**
     * thread-safe method.
     */
    public void search(String text, IMatchHandler handler) {
        int textLen = text.length();

        int maxShift = minPatternLen - suffixBlockSize + 1;
        int blockEnd = minPatternLen - 1;

        while (blockEnd < textLen) {
            int hash = hashBlock(text, blockEnd);
            int shift = (hash == -1 ? maxShift : shiftTable[hash]);
            if (shift == 0) {
                int start = blockEnd - minPatternLen + 1;
                int text_prefix = (text.charAt(start) << 16)
                        | text.charAt(start + 1);
                int from = hashTableIndex[hash];
                int end = hashTableIndex[hash + 1];
                for (int i = from; i < end; i++) {
                    if (text_prefix != prefixTable[i]
                            || start + patternTable[i].length() > textLen)
                        continue;
                    boolean found = true;
                    for (int k = 0; k < patternTable[i].length(); k++)
                        if (patternTable[i].charAt(k) != text.charAt(start + k)) {
                            found = false;
                            break;
                        }
                    // call the function to deal with
                    if (found) {
                        if (!handler.foundAt(start, patternTable[i]))
                            return;
                    }
                }
                shift = 1;
            }
            blockEnd += shift;
        }
    }

    public void search(String text) {
        search(text, handler);
    }

    protected ITextBlock createTextBlock(int blockSize) {
        if (blockSize == 2)
            return new TwoTextBlock();
        else if (blockSize == 3)
            return new ThreeTextBlock();
        else
            return new MultiTextBlock(blockSize);
    }

    /**
     * internal interface of the text block for wumanber
     * 
     * @author yemingjiang
     */
    interface ITextBlock {
        public void set(char[] text, int blockEnd);

        public void set(String text, int blockEnd);

        public Object clone() throws CloneNotSupportedException;

    }

    /**
     * internal class for text block of 2 char
     * 
     * @author yemingjiang
     */
    class TwoTextBlock implements ITextBlock, Cloneable {
        protected char first;

        protected char second;

        @Override
        public boolean equals(Object obj) {
            if (obj instanceof TwoTextBlock) {
                TwoTextBlock block = (TwoTextBlock) obj;
                return (first == block.first && second == block.second);
            }
            return false;
        }

        public void set(String text, int blockEnd) {
            this.first = text.charAt(blockEnd - 1);
            this.second = text.charAt(blockEnd);
        }

        public void set(char[] text, int blockEnd) {
            this.first = text[blockEnd - 1];
            this.second = text[blockEnd];
        }

        @Override
        public int hashCode() {
            return (first << 16 | second);
        }

        public String toString() {
            StringBuilder builder = new StringBuilder();
            builder.append(first);
            builder.append(second);
            return builder.toString();
        }

        public Object clone() throws CloneNotSupportedException {
            return super.clone();
        }
    }

    /**
     * internal class for text block of 3 char
     * 
     * @author yemingjiang
     */
    class ThreeTextBlock implements ITextBlock, Cloneable {

        protected char first;

        protected char second;

        protected char third;

        public void set(char[] text, int blockEnd) {
            this.first = text[blockEnd - 2];
            this.second = text[blockEnd - 1];
            this.third = text[blockEnd];
        }

        @Override
        public boolean equals(Object obj) {
            if (obj instanceof ThreeTextBlock) {
                ThreeTextBlock block = (ThreeTextBlock) obj;
                return (first == block.first && second == block.second && third == block.third);
            }
            return false;
        }

        @Override
        public int hashCode() {
            return (first * 31 + second) * 31 + third;
        }

        public String toString() {
            StringBuilder builder = new StringBuilder();
            builder.append(first);
            builder.append(second);
            builder.append(third);

            return builder.toString();
        }

        public void set(String text, int blockEnd) {
            this.first = text.charAt(blockEnd - 2);
            this.second = text.charAt(blockEnd - 1);
            this.third = text.charAt(blockEnd);

        }

        public Object clone() throws CloneNotSupportedException {
            return super.clone();
        }

    }

    /**
     * internal class for text block of multiple char
     * 
     * @author yemingjiang
     */
    class MultiTextBlock implements ITextBlock, Cloneable {

        protected int size;

        protected char[] text;

        protected int blockEnd;

        public MultiTextBlock(int size) {
            this.size = size;
        }

        public void set(String text, int blockEnd) {
            throw new RuntimeException("not support");
        }

        public void set(char[] text, int blockEnd) {
            this.text = text;
            this.blockEnd = blockEnd;
        }

        @Override
        public String toString() {
            return new String(text, (blockEnd - size + 1), size);
        }

        @Override
        public boolean equals(Object obj) {
            if (obj instanceof MultiTextBlock) {
                MultiTextBlock block = (MultiTextBlock) obj;
                for (int i = 0; i < size; i++)
                    if (text[blockEnd - i] != block.text[block.blockEnd - i])
                        return false;
                return true;
            }
            return false;
        }

        @Override
        public int hashCode() {
            int h = 0;
            int end = blockEnd;
            for (int i = 0; i < size; i++) {
                h = 31 * h + text[end--];
            }
            return h;
        }

        public Object clone() throws CloneNotSupportedException {
            return super.clone();
        }
    }

}
