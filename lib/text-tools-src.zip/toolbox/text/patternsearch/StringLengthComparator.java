package toolbox.text.patternsearch;

import java.util.Comparator;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * String Length Comparator, compare the string with their length,reverse order
 *
 * @author Mingjiang Ye (yemingjiang@rd.netease.com).
 * 
 * Copyright (c) 2006, Outfox Team
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class StringLengthComparator implements Comparator<String> {

    public int compare(String str1, String str2) {
        return str2.length() - str1.length();
    }
}
