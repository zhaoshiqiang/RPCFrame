package toolbox.lang;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * Some utilities for ligature processing.
 * Public methods:
 *   String expand(char)
 *   String expand(string)
 *   
 * Refer to javadoc of the method for more details. 
 * @author david
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class LigatureUtils {
    private static String[] ORIG_EXPAND = {
            "ﬀ", "ff",
            "ᵫ", "ue",
            "ﬀ", "ff",
            "ﬁ", "fi",
            "ﬂ", "fl",
            "ﬃ", "ffi",
            "ﬄ", "ffl",
            "ﬅ", "ft",
            "ﬆ", "st",
            "Ĳ", "IJ",
            "ĳ", "ij",
    };
    private static String[] ligatTable;
    private static int minLigat;
    private static int maxLigat;
    static {
        minLigat = 0xFFFF;
        maxLigat = 0;
        for (int i = 0; i < ORIG_EXPAND.length; i += 2) {
            int ch = 0xFFFF & ORIG_EXPAND[i].charAt(0);
            if (ch < minLigat) {
                minLigat = ch;
            }
            if (ch > maxLigat) {
                maxLigat = ch;
            }
        } // for i
        
        ligatTable = new String[maxLigat - minLigat + 1];
        for (int i = 0; i < ORIG_EXPAND.length; i += 2) {
            int ch = 0xFFFF & ORIG_EXPAND[i].charAt(0);
            ligatTable[ch - minLigat] = ORIG_EXPAND[i + 1]; 
        } // for i
    }
    /**
     * Returns the expanded letters for a ligature. null if the specified ch
     * is not a ligature.
     * @param ch  the ligature
     * @return the expanded letters for a ligature. null if the specified ch
     *         is not a ligature.
     */
    public static String expand(char ch) {
        int c = ch & 0xFFFF;
        if (c < minLigat || ch > maxLigat) {
            return null;
        }
        return ligatTable[c - minLigat];
    }
    /**
     * Expands the text string which may contains ligatures.
     * 
     * The implementation is optimized so that no extra small object is created
     * if no ligature is found in the input text string.
     * 
     * @param str  the original string
     * @return  the expaned string
     */
    public static String expand(String str) {
        // the string-builder if there exists any lagature in str. 
        StringBuilder res = null;
        for (int i = 0; i < str.length(); i ++) {
            char ch = str.charAt(i);
            String exp = expand(ch);
            if (exp == null) {
               if (res != null) {
                   // res is non-null, append ch to it
                   res.append(ch);
               }
            } else {
                // append the expanded letters
                if (res == null) {
                    res = new StringBuilder(str.length() + exp.length() - 1);
                    if (i > 0) {
                        res.append(str.subSequence(0, i));
                    }
                } // if
                res.append(exp);
            } // else
        } // for i
        if (res != null) {
            // the string was expanded
            return res.toString();
        } else {
            // no ligature found, original string is returned
            return str;
        }
    }
}
