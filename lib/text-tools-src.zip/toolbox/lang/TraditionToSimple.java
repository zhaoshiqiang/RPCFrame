package toolbox.lang;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * Converter to conver traditional chinese to simple chinese.
 * 
 * @author river
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class TraditionToSimple {

    private static CodeTable codeTable;
    static {
        codeTable = new CodeTable();
        InputStream is = TraditionToSimple.class.getResourceAsStream("t2s.properties");
        if (is == null) {
            throw new RuntimeException("cannot find code table in classpath");
        } else {
            try {
                try {
                    codeTable.load(is);
                } finally {
                    is.close();
                }
            } catch (IOException e) {
                throw new RuntimeException("load code table failed", e);
            }
        }
    }

    /**
     * Convert all the chars in buf from traditional chinese to simple chinese.
     * Converted data is saved back to the buffer.
     * @see #convert(char[], int, int)
     * @param buf
     */
    public static void convert(char[] buf) {
        codeTable.convert(buf, 0, buf.length);
    }

    /**
     * Convert chars in buffer from traditional chinese to simple chinese.
     * Converted data is saved back to the buffer.
     * @param buf
     * @param offset
     * @param count
     */
    public static void convert(char[] buf, int offset, int count) {
        codeTable.convert(buf, offset, count);
    }

    /**
     * Convert one string from traditional chinese to simple chinese, the converted string
     * is returned.
     * 
     * @param buf
     * @return
     */
    public static String convert(String buf) {
        return codeTable.convert(buf);
    }

    /**
     * Check if one character is traditional chinese.
     * @param c
     * @return
     */
    public static boolean isTraditionalChinese(int c) {
        return codeTable.isTraditionalChinese(c);
    }
    
    /**
     * Get the code table used.
     * @return
     */
    public static CodeTable getCodeTable() {
        return codeTable;
    }
    
    @InterfaceAudience.Public
    @InterfaceStability.Stable
    public static class Code implements Comparable<Code> {
        private char src;

        private char dst;

        public Code(char src, char dst) {
            this.src = src;
            this.dst = dst;
        }

        public int compareTo(Code o) {
            Code other = (Code) o;
            return src - other.src;
        }

    }

    /**
     * {@link CodeTable} save the convertion table in single table and choice table. The data
     * structure is :
     * <code>
     *                   [single-table]                  
     * [min]--               c1                               
     *                       c2                            [choice-table]
     *                       c3(negative)-------------------    m1
     *                       c4                                 
     *                       c5(negative)-------------------    m2
     *                       ...                               ...
     * [max] ---             cn
     * </code>
     * The single table is one array, the positive data in it is one char, and the negative data
     * int it is one index to choicetable. To convert one char <code>ch</code> : 
     * <code>
     *       converted = singleTable[min + ch];
     *       if (converted < 0) {
     *           converted = choiceTable[-converted-1].convert(ch);
     *       }
     * </code>
     * 
     * @author river
     *
     */
    @InterfaceAudience.Public
    @InterfaceStability.Stable
    public static class CodeTable {
        
        int[] singleTable;
        int min;
        int max;
        List<MultiChoice> choices = new ArrayList<MultiChoice>();

        /**
         * Choice is a multi-char convertion rule. such as ["ac", "bd"].
         *
         * @author river
         *
         */
        private static class Choice {
            char[] src;
            char[] dst;

            public Choice(char[] src, char[] dst) {
                this.src = src;
                this.dst = dst;
            }

            public int length() {
                return src.length;
            }

            /**
             * Match if the data at <code>offset</code> is equals to
             * the source of this choice.
             * @param buf
             * @param offset
             * @return
             */
            public boolean match(char[] buf, int offset) {
                int bufLen = buf.length;
                if (bufLen - offset < src.length)
                    return false;

                for (int i = 0; i < src.length; i++) {
                    if (buf[offset + i] != src[i])
                        return false;
                }

                for (int i = 0; i < src.length; i++)
                    buf[offset + i] = dst[i];
                
                return true;
            }
        }

        private static class MultiChoice {
            private List<Choice> choices = new ArrayList<Choice>();

            public void add(Choice c) {
                int i = 0;
                for (; i < choices.size(); i++) {
                    if (choices.get(i).length() < c.length())
                        break;
                }
                choices.add(i, c);
            }

            public int match(char[] buf, int offset) {
                for (int i = 0; i < choices.size(); i++) {
                    Choice c = choices.get(i);
                    if (c.match(buf, offset)) {
                        return c.length();
                    }
                }
                return 1;
            }

        }

        public CodeTable() {
            min = Integer.MAX_VALUE;
            max = Integer.MIN_VALUE;
            singleTable = new int[0];
        }

        /**
         * 读入码表文件. 码表文件的格式是： <char_from><charto1><charto2>...
         * 
         * @param in
         *            InputSteam of the code file
         * @throws IOException
         */
        public void load(InputStream in) throws IOException {
            Map<Character, MultiChoice> map = new HashMap<Character, MultiChoice>();

            List<Code> tmpList = new ArrayList<Code>(1024);

            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    new BufferedInputStream(in), "UTF-8"));
            try {
                String line;

                while ((line = reader.readLine()) != null) {
                    if (line.startsWith("#") || line.length() == 0)
                        continue;
                    
                    if (line.length() == 2) {
                        Code code = new Code(line.charAt(0), line.charAt(1));
                        if (code.src != code.dst)
                            tmpList.add(code);
                    } else if (line.length() % 2 == 0) {
                        char[] src = new char[line.length() / 2];
                        System.arraycopy(line.toCharArray(), 0, src, 0,
                                src.length);
                        char[] dst = new char[line.length() / 2];
                        System.arraycopy(line.toCharArray(), src.length, dst,
                                0, dst.length);
                        MultiChoice choice = map.get(line.charAt(0));
                        if (choice == null) {
                            choice = new MultiChoice();
                            map.put(line.charAt(0), choice);
                        }
                        choice.add(new Choice(src, dst));
                    }
                }
            } finally {
                reader.close();
            }

            Collections.sort(tmpList);
            if (tmpList.size() == 0) {
                min = Integer.MAX_VALUE;
                max = Integer.MIN_VALUE;
            } else {
                min = tmpList.get(0).src;
                max = tmpList.get(tmpList.size() - 1).src;
                int tableLength = max - min + 1;
                singleTable = new int[tableLength];

                for (int i = 0; i < tableLength; i++)
                    singleTable[i] = (char) (min + i);

                for (Code code: tmpList) {
                    MultiChoice choice = map.get(code.src);
                    if (choice != null) {
                        choice.add(new Choice(new char[] {code.src}, 
                                new char[] {code.dst }));
                        choices.add(choice);
                        singleTable[code.src - min] = (-1) * choices.size();
                    } else {
                        singleTable[code.src - min] = code.dst;
                    }
                }
            }

        }

        /**
         * 由于是一对一的转换，我们直接将结果写回原来的buffer.
         * 
         * @param buf
         */
        public void convert(char[] buf, int offset, int count) {
            int end = offset + count;
            if (end > buf.length)
                end = buf.length;

            for (int i = offset; i < end; i++) {
                char c = buf[i];
                if (c >= min && c <= max) {
                    int d = singleTable[c - min];
                    if (d < 0) {
                        i += (choices.get((-1) * d - 1).match(buf, i) - 1);
                    } else {
                        buf[i] = (char) singleTable[c - min];
                    }
                }
            }
        }
        
        /**
         * Check if one character is traditional chinese.
         * @param ch
         * @return
         */
        public boolean isTraditionalChinese(int ch) {
            if (ch < min || ch > max) return false;
            return singleTable[ch-min] != ch;
        }

        public String convert(String s) {
            char[] buf = s.toCharArray();
            convert(buf, 0, buf.length);
            return new String(buf);
        }
    }

}
