package toolbox.lang;

import java.util.HashMap;
import java.util.HashSet;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * constant values related to Chinese language
 * 
 * @author zl,qipeng
 *
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class ChnConstant {

    private final static HashMap<Integer, Integer> eqTable =
        new HashMap<Integer, Integer>();

    /**
     * UTF character set values, included (i.e. [int[0],int[1]])
     * All of below are taken from http://www.unicode.org/chargs/PDF/*.pdf
     * \u0000 - \u1FFF: Alphabets
     * \u2000 - \u2FFF: Symbols and punctuation
     * \u3000 - \u33FF: CJK auxiliary
     * \u3400 - \u4dbf: CJK ideographs, ext. A
     * \u4E00 - \u9FFF: CJK unified ideographs
     * \uAC00 - \uD7A3: Hangul syllables
     * \uF900 - \uFAFF: CJK compatibility ideographs
     * 
     * Type of different chars:
     *   int CT_CHN_CHAR = 0;
     *   int CT_ENG_CHAR = 1;
     *   int CT_ARB_DIGIT = 2;
     *   int CT_CHN_DIGIT = 3;
     *   int CT_CHN_DIGIT_EXT = 4;
     *   int CT_OTHER_ASIAN_CHAR = 5;
     *   int CT_OTHER_LATIN_CHAR = 6;
     *   int CT_SPECIAL_NUM = 7;
     *   int CT_SPECIAL_SINGLE = 8;
     */
    // delimiter
    public final static int[][] UTF_DELIMITER = {
        {0x3001, 0xff64}, // 、
        {0x002c, 0x201a, 0xff0c, 0xff61}, // , ， 
        {0x002e, 0x2024, 0x3002, 0xff0e, 0x00b7}, // . . 。  more to see p4 of U0080.pdf
        {0x003a, 0xff1a, '∶'}, // : 
        {0x003b, 0xff1b}, // ;
        {0x0021, 0xff01}, // !    
        {0x003f, 0xff1f}, // ?
        {0x2026}, // …
        {0x2047}, // ??
        {0x2048}, // ?!
        {0x2049},  // !?
        {'/', '／'}, {'%', '％'} // just to be put in eq table
    };
    public final static int[][] UTF_DELIMITER_EXT = {
        {0x201d, 0x275e, 0x230b, 0x300d, 0x300f, 0x301e, 0xff63}, // ”
        {0x003e, 0x203a, 0x232a, 0x3009, 0x300b}, // > ＞ ＞ ＞ 》
        {0x0029, 0xff09}, // )
        {0x005d, 0x27e7, 0x3011, 0x3015, 0x3017, 0x3019, 0x301b}  // ]
    };
    private static HashSet<Integer> delimiters = new HashSet<Integer>(); 
    static {
        for (int i=0; i<UTF_DELIMITER.length; i++) {
            delimiters.add(new Integer(UTF_DELIMITER[i][0]));
            for (int j=1; j<UTF_DELIMITER[i].length; j++) {
                eqTable.put(new Integer(UTF_DELIMITER[i][j]), 
                        new Integer(UTF_DELIMITER[i][0]));
                delimiters.add(new Integer(UTF_DELIMITER[i][j]));
            }
        }
    }
    public static boolean isDelimiter(char c) {
        int i = (int) (c & 0xffff);
        return delimiters.contains(new Integer(i));
    }

    // digits: combine adjcent digits as a number
    public final static int[] UTF_ASCII_DIGIT_RANGE = {
        0x0030, 0x0039
    }; // 0~9

    public final static int[] UTF_FULL_WIDTH_DIGIT_RANGE = {
        0xff10, 0xff19
    }; // 0~9, UFF00.pdf

    public final static int[] UTF_ASCII_DIGIT_QUAL = {
        0x3001, 0xff64, // 、
        0x002c, 0x201a, 0xff0c, 0xff61, // , ， 
        0x002e, 0x2024, 0x3002, 0xff0e, 0x00b7, // . . 。 
        0x003a, 0xff1a, '∶', // :
        '/', '／', '%', '％', '‰'
    };

    private static HashSet<Integer> asciiQuals = new HashSet<Integer>();
    static {
        // digits    
        for (int i = UTF_FULL_WIDTH_DIGIT_RANGE[0]; i <= UTF_FULL_WIDTH_DIGIT_RANGE[1]; i++) {
            eqTable.put(new Integer(i), new Integer(UTF_ASCII_DIGIT_RANGE[0]
                    + (i - UTF_FULL_WIDTH_DIGIT_RANGE[0])));
        }
        for (int i = 0; i < UTF_ASCII_DIGIT_QUAL.length; i++) {
            asciiQuals.add(UTF_ASCII_DIGIT_QUAL[i]);
        }
    }

    public static boolean isArabicDigits(char c) {
        int i = (int) (c & 0xffff);
        if (i >= UTF_ASCII_DIGIT_RANGE[0] && i <= UTF_ASCII_DIGIT_RANGE[1])
            return true;
        return false;
    }

    public static boolean isArabicQuals(char c) {
        int i = (int) (c & 0xffff);
        return asciiQuals.contains(i);
    }

    public final static char[] UTF_CHN_DIGIT = {
        0x3007, 0x4e00, 0x4e8c, 0x4e09, 0x56db, 0x4e94, 0x516d, 0x4e03, 0x516b,
        0x4e5d, 0x96f6, 0x25cb, '两'
    }; // 0~九 零 ○ 两

    public final static char[] UTF_CHN_QUAL = {
        0x5341, 0x767e, 0x4f70, 0x5343, 0x4edf, 0x4e07, 0x4ebf, 0x5146, 0x51e0
    }; // 十百佰千仟万亿兆 几

    private static HashSet<Integer> chnDigits = new HashSet<Integer>();

    private static HashSet<Integer> chnQuals = new HashSet<Integer>();
    static {
        for (int i = 0; i < UTF_CHN_DIGIT.length; i++) {
            chnDigits.add(new Integer(UTF_CHN_DIGIT[i]));
        }
        for (int i = 0; i < UTF_CHN_QUAL.length; i++) {
            chnQuals.add(new Integer(UTF_CHN_QUAL[i]));
            chnDigits.add(new Integer(UTF_CHN_QUAL[i]));
        }
    }

    public static boolean isChineseDigits(char c) {
        int i = (int) (c & 0xffff);
        return chnDigits.contains(new Integer(i));
    }

    public static boolean isChineseQuals(char c) {
        int i = (int) (c & 0xffff);
        return chnQuals.contains(new Integer(i));
    }

    // special numbers:mark directly as a number
    public final static int[] UTF_LATIN_SPECIAL_NUMBER = {
        0x00bc, 0x00bd, 0x00be
    }; // 1/4, 1/2, 3/4, from U0080.pdf

    public final static int[] UTF_CHN_SPECIAL_NUMBER = {
        0x3038, 0x3039, 0x303a
    }; // 10 20 30

    public static boolean isSpecialNum(char c) {
        return false; // TODO
    }

    /** \u0000 - \u1FFF: Alphabets */
    // English alphabets: combine nearby chars as a English word
    public final static int[] UTF_ALPHABET_UPPER_RANGE = {
        0x0041, 0x005a
    }; // A~Z

    public final static int[] UTF_ALPHABET_LOWER_RANGE = {
        0x0061, 0x007a
    }; // a~z

    public final static int[] UTF_FULL_WIDTH_UPPER_RANGE = {
        0xff21, 0xff3a
    }; // A~Z, UFF00.pdf

    public final static int[] UTF_FULL_WIDTH_LOWER_RANGE = {
        0xff41, 0xff5a
    }; // a~z, UFF00.pdf
    static {
        for (int i = UTF_FULL_WIDTH_UPPER_RANGE[0]; i <= UTF_FULL_WIDTH_UPPER_RANGE[1]; i++) {
            eqTable.put(new Integer(i), new Integer(UTF_ALPHABET_UPPER_RANGE[0]
                    + (i - UTF_FULL_WIDTH_UPPER_RANGE[0])));
        }
        for (int i = UTF_FULL_WIDTH_LOWER_RANGE[0]; i <= UTF_FULL_WIDTH_LOWER_RANGE[1]; i++) {
            eqTable.put(new Integer(i), new Integer(UTF_ALPHABET_LOWER_RANGE[0]
                    + (i - UTF_FULL_WIDTH_LOWER_RANGE[0])));
        }
    }
 
    public static boolean isEnglishAlphabet(char c) {
        int i = (int) (c & 0xffff);
        if ((i >= UTF_ALPHABET_UPPER_RANGE[0] && i <= UTF_ALPHABET_UPPER_RANGE[1])
                || (i >= UTF_ALPHABET_LOWER_RANGE[0] && i <= UTF_ALPHABET_LOWER_RANGE[1])) {
            return true;
        }
        return false;
    }

    // Other latin letters, european alphabets and other languages:
    //   combine nearby chars as a word, but we may not index these strange words
    public final static int[][] UTF_LATIN_LETTER_RANGE = {
        {
            0x00c0, 0x00d6
        }, // U0080.pdf
        {
            0x00d8, 0x00f6
        }, // U0080.pdf
        {
            0x00f8, 0x02b8
        }, // U0080.pdf~U02B0.pdf
        {
            0x02de, 0x02e4
        }, // U02B0.pdf
        {
            0x0370, 0x1fff
        } // U0370.pdf~U1F00.pdf
    };

    public static boolean isOtherAlphabet(char c) {
        int i = (int) (c & 0xffff);
        for (int j = 0; j < UTF_LATIN_LETTER_RANGE.length; j++) {
            if (i >= UTF_LATIN_LETTER_RANGE[j][0]
                    && i <= UTF_LATIN_LETTER_RANGE[j][1]) {
                return true;
            }
        }
        return false;
        
    }

    /** \u3000 - \u33FF: CJK auxiliary
     *  \u3400 - \u4dbf: CJK ideographs, ext. A
     *  \u4E00 - \u9FFF: CJK unified ideographs
     *  \uAC00 - \uD7A3: Hangul syllables
     *  \uF900 - \uFAFF: CJK compatibility ideographs */
    // CJK unified ideographs, Han characters used in China, Korea, Taiwan and Vietnam   
    public final static int[] UTF_CHN_CHAR_RANGE = {
        0x4e00, 0x9fff
    }; // U4E00.pdf

    public final static int[] UTF_CHN_EXT_CHAR_RANGE = {
        0x3400, 0x4dbf
    }; // U3400.pdf

    public final static int[] UTF_CHN_CPT_CHAR_RANGE = {
        0xf900, 0xfaff
    }; // UF900.pdf

    public static boolean isChineseChar(char c) {
        int i = (int) (c & 0xffff);
        if (i >= UTF_CHN_CHAR_RANGE[0] && i <= UTF_CHN_CHAR_RANGE[1]) {
            return true;
        }
        if (i >= UTF_CHN_EXT_CHAR_RANGE[0] && i <= UTF_CHN_EXT_CHAR_RANGE[1]) {
            return true;
        }
        if (i >= UTF_CHN_CPT_CHAR_RANGE[0] && i <= UTF_CHN_CPT_CHAR_RANGE[1]) {
            return true;
        }
        return false;
    }

    // Other asia language
    public final static int[][] UTF_OTHER_ASIAN_RANGE = {
        {
            0x3040, 0x31ff
        }, {
            0xac00, 0xd7a3
        }
    };

    // according nsUnicodeRange.cpp of firefox 
    // Japanese 
    public final static int[][] UTF_JP_RANGE = {
        {
            0x3040, 0x30ff
        }
    };

    public final static int[][] UTF_KO_RANGE = {
        {
            0x1100, 0x11ff
        }, {
            0x3130, 0x318f
        }, {
            0xac00, 0xd7a3
        }
    };

    public final static int[][] UTF_RU_RANGE = {
        {
            0x0401, 0x0401
        }, {
            0x0451, 0x0451
        }, {
            0x0410, 0x044F
        }
    };

    public final static int[] UTF_ASCII_RANGE = {0x0001, 0x007f}; // 0~9

    public static boolean isAsciiChar(char c){
        int i = (int) (c & 0xffff);
        if ( i>=UTF_ASCII_RANGE[0] && i<=UTF_ASCII_RANGE[1]) {
            return true;
        }
        return false;
    }

    public static boolean isJapaneseChar(char c) {
        int i = (int) (c & 0xffff);
        for (int j = 0; j < UTF_JP_RANGE.length; j++) {
            if (i >= UTF_JP_RANGE[j][0] && i <= UTF_JP_RANGE[j][1]) {
                return true;
            }
        }
        return false;
    }

    /**
     * @deprecated  use isKoreanChar instead.
     */
    @Deprecated
    public static boolean isKoreaChar(char c){
        return isKoreanChar(c);
    }

    /**
     * Returns whether a give character is a Korean character.
     * 
     * @param c
     *            the char
     * @return whether a give character is a Korean character
     */
    public static boolean isKoreanChar(char c) {
        int i = (int) (c & 0xffff);
        for (int j = 0; j < UTF_KO_RANGE.length; j++) {
            if (i >= UTF_KO_RANGE[j][0] && i <= UTF_KO_RANGE[j][1]) {
                return true;
            }
        }
        return false;
    }

    /**
     * Returns whether a give character is a Russian character.
     * 
     * @param c
     *            the char
     * @return whether a give character is a Russian character
     */
    public static boolean isRussianChar(char c) {
        int i = (int) (c & 0xffff);
        for (int j = 0; j < UTF_RU_RANGE.length; j++) {
            if (i >= UTF_RU_RANGE[j][0] && i <= UTF_RU_RANGE[j][1]) {
                return true;
            }
        }
        return false;
    }
    
    public static boolean isOtherAsianChar(char c) {
        int i = (int) (c & 0xffff);
        for (int j = 0; j < UTF_OTHER_ASIAN_RANGE.length; j++) {
            if (i >= UTF_OTHER_ASIAN_RANGE[j][0]
                    && i <= UTF_OTHER_ASIAN_RANGE[j][1]) {
                return true;
            }
        }
        return false;
    }

    public static char getEquivChar(char c) {
        int i = (int) (c & 0xffff);
        Integer r = eqTable.get(new Integer(i));
        if (r == null) {
            return c;
        } else {
            return (char) r.intValue();
        }
    }

}
