package toolbox.lang;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * Language definitions, use one byte to store language code.
 * 
 * @author river liq qipeng
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class LanguageConsts {

    /**
     * Simple chinese.
     * 
     * @deprecated Use {@link #LANG_SIMPLE_CHINESE} instead.
     */
    public static final byte LANG_CN = 0;

    /**
     * Simple chinese.
     */
    public static final byte LANG_SIMPLE_CHINESE = 0;

    /**
     * Traditional chinese.
     */
    public static final byte LANG_TRADITIONAL_CHINESE = 1;

    /**
     * Traditional chinese.
     * 
     * @deprecated Use {@link #LANG_TRADITIONAL_CHINESE} instead
     */
    public static final byte LANG_BIG5 = 1;

    /**
     * English language.
     */
    public static final byte LANG_ENG = 2;

    /**
     * Japanese language.
     */
    public static final byte LANG_JP = 3;

    /**
     * Korean language.
     */
    public static final byte LANG_KR = 4;

    /**
     * French language.
     */
    public static final byte LANG_FR = 5;

    /**
     * Russian language.
     */
    public static final byte LANG_RU = 6;

    /**
     * Spanish language.
     */
    public static final byte LANG_SP = 7;

    /**
     * German language.
     */
    public static final byte LANG_GE = 8;

    /**
     * Unknown language.
     */
    public static final byte LANG_UNKNOWN = 10;

    /**
     * Other language.
     */
    public static final byte LANG_OTHER = 0x10;

    /**
     * Other Indo Euro language.
     */
    public static final byte LANG_OTHER_EURO = 0x11;

    /**
     * Invalid Language value used only by markDb
     */
    public static final byte LANG_INVALID = -1;

    /**
     * Return the name of language.
     * 
     * @param lang
     * @return
     */
    public static String getLanguageName(byte lang) {
        switch (lang) {
            case LANG_SIMPLE_CHINESE:
                return "Simple Chinese";
            case LANG_TRADITIONAL_CHINESE:
                return "Traditional Chinese";
            case LANG_ENG:
                return "English";
            case LANG_JP:
                return "Japanese";
            case LANG_KR:
                return "Korean";
            case LANG_FR:
                return "French";
            case LANG_RU:
                return "Russian";
            case LANG_SP:
                return "Spanish";
            case LANG_GE:
                return "German";
            case LANG_UNKNOWN:
                return "Unknown Language";
            case LANG_OTHER:
                return "Other Language";
            case LANG_OTHER_EURO:
                return "Other Eurpo Language";
        }
        return "Illegal Language ID";
    }

}
