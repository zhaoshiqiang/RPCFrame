package toolbox.lang.encdetect;

import java.nio.charset.Charset;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * encoding detector only for html pages. it will use meta information on the
 * base of detecting raw bytes
 * 
 * @author xudq
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class HtmlEncodingDetector {
    private static final int CHUNK_SIZE = 3000;

    //"<meta\\s+([^>]*http-equiv=\"?content-type\"?[^>]*)>",
    private static Pattern metaPattern = Pattern.compile(
            "<meta\\s+([^>]*http-equiv\\s*=[\\s\"\']*content-type[^>]*)>",
            Pattern.CASE_INSENSITIVE);

    private static Pattern charsetPattern = Pattern.compile(
            "charset\\s*=\\s*([a-z][_\\-0-9a-z]*)", Pattern.CASE_INSENSITIVE);

    // the charset we should pay more attention
    public static final Set<String> FUZZY_CHARSETS = new HashSet<String>();
    static {
        // the following four are canonical names of GB2312
        FUZZY_CHARSETS.add("GB2312");
        FUZZY_CHARSETS.add("CSGB2312");

        // the following four are canonical names of GBK
        FUZZY_CHARSETS.add("GBK");
        FUZZY_CHARSETS.add("CP936");
        FUZZY_CHARSETS.add("MS936");
        FUZZY_CHARSETS.add("WINDOWS-936");

        // the following four are canonical names of BIG5
        FUZZY_CHARSETS.add("BIG5");
        FUZZY_CHARSETS.add("CSBIG5");

        FUZZY_CHARSETS.add("UTF-8");
        FUZZY_CHARSETS.add("UTF-16");
    }

    public static String sniffCharacterEncoding(byte [] content) {
        return sniffCharacterEncoding(content, 0, content.length);
    }
    
    /**
     * sniff CharacterEncoding from meta
     * 
     * @param content
     *            raw bytes
     * @return character encoding from meta information, null if sniff nothing
     *         or sniff an illegal charset; GB2312 will be considered to be GBK
     */
    public static String sniffCharacterEncoding(byte[] content, int offset, int len) {
        int length = len < CHUNK_SIZE ? len : CHUNK_SIZE;

        String str = new String(content, offset, length);

        Matcher metaMatcher = metaPattern.matcher(str);
        String encoding = null;
        if (metaMatcher.find()) {
            Matcher charsetMatcher = charsetPattern.matcher(metaMatcher.group(1));
            if (charsetMatcher.find())
                encoding = charsetMatcher.group(1);
        }
        if (encoding != null) {
            encoding = encoding.toUpperCase();
            // set the encoding to be null if JVM
            // does not support this encoding
            if (Charset.isSupported(encoding) == false) {
                encoding = null;
            }
        }

        // here we must change GB2312 to GBK encoding
        // for JVM consider GB2312 do not support traditional
        // chinese, but windows consider GB2312 support it.
        if (encoding != null && encoding.equalsIgnoreCase("GB2312")) {
            encoding = "GBK";
        }
        return encoding;
    }

    /**
     * determine whether this encoding should be detected if encoding is null or
     * it is contained in FUZZY_CHARSETS we detect encoding from raw bytes
     * 
     * @param encoding
     * @return
     */
    private static boolean shouldBeDetected(String encoding) {
        if (encoding == null || encoding.length() == 0) {
            return true;
        }
        if (FUZZY_CHARSETS.contains(encoding)) {
            return true;
        }
        return false;
    }

    public static EncodingGuess detectEncoding(byte [] content, int checkLength) {
        if (checkLength > content.length) checkLength = content.length;
        return detectEncoding(content, 0, content.length, checkLength);
    }
    
    /**
     * Guess the charset of content.
     * 
     * @param content
     *            raw bytes
     * @param checkLength
     *            the length used to detect encoding, 2048 is suggested
     * @return the detected encoding as EncodingGuess object's name; if can not
     *         determine, it will return "OTHER" with probability 80 as
     *         EncodingGuess object's name
     */
    public static EncodingGuess detectEncoding(byte[] content, int offset, int length, int checkLength) {
        try {
            String sniff = sniffCharacterEncoding(content, offset, checkLength < length ? checkLength : length);
            String encoding;
            int probability;
            if (shouldBeDetected(sniff)) {
                EncodingGuess encodingGuess = EncodingDetector.detectEncoding(
                        content, offset, length, checkLength);
                encoding = encodingGuess.name;
                probability = encodingGuess.probability;
                if (FUZZY_CHARSETS.contains(sniff)
                        && sniff.equalsIgnoreCase("UTF-8") == false
                        && FUZZY_CHARSETS.contains(encoding.toUpperCase()) == false
                        && encoding.equalsIgnoreCase("Unicode") == false) {
                    encoding = sniff;
                    probability = 95;
                }
            } else {
                encoding = sniff;
                probability = 95;
            }

            if (encoding.equals("OTHER")) {
                probability = 80;
            }
            return new EncodingGuess(encoding, probability, sniff);
        } catch (Exception e) {
            return new EncodingGuess("OTHER", 80, null);
        }
    }
}
