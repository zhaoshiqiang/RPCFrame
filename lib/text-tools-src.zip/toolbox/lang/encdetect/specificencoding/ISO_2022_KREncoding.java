package toolbox.lang.encdetect.specificencoding;

import toolbox.lang.encdetect.Encoding;
import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * Korean
 * 
 * @author xudq
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class ISO_2022_KREncoding implements Encoding {

    public final String getName() {
        return "ISO-2022-KR";
    }

    public final int probability(byte[] rawtext, int offset, int size,
            int checkLength) {
        int end = offset + size;
        for (int i = offset; i < end; i++) {
            if (i + 3 < end && rawtext[i] == 0x1b
                    && (char) rawtext[i + 1] == '$'
                    && (char) rawtext[i + 2] == ')'
                    && (char) rawtext[i + 3] == 'C') {
                return 100;
            }
        }
        return 0;
    }

}
