/*
 * Copyright (c) 2005, Yitao Duan, Jimmy Su, Feng Zhou and Li Zhuang Created on
 * Aug 21, 2005
 */

package toolbox.lang.encdetect.specificencoding;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import toolbox.lang.encdetect.Encoding;
import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * Simplified Chinese, GBKEncoding
 * 
 * @author ET,xudq
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class GBKEncoding implements Encoding {
    private static int[][] GBKFreq = new int[126][191];
    static {
        initialize_frequencies();
    }

    public final String getName() {
        return "GBK";
    }

    /*
     * argument: pointer to byte array Returns : number from 0 to 100
     * representing probability text in array uses GBK encoding
     */
    public final int probability(byte[] rawtext, int offset, int size,
            int checkLength) {
        int dbchars = 1, gbchars = 1;
        long gbfreq = 0, totalfreq = 1;
        float rangeval = 0, freqval = 0;
        int row, column;

        // Stage 1: Check to see if characters fit into acceptable ranges
        int end = offset + size;
        for (int i = offset; i < end - 1; i++) {
            // System.err.println(rawtext[i]);
            if (rawtext[i] >= 0) {
                // asciichars++;
            } else {
                dbchars++;
                if (dbchars >= checkLength) {
                    break;
                }
//                System.out.println(Integer.toHexString(rawtext[i]) + " "+Integer.toHexString(rawtext[i+1]));
//                int tmp = (int)rawtext[i+1] & 0xFF;
//                tmp = tmp << 8;tmp += ((int)rawtext[i] & 0xFF );
//                tmp = tmp & 0x0000FFFF;
//                System.out.println((char)tmp);
//                System.out.println(Integer.toHexString(tmp));
                
                if ((byte) 0xA1 <= rawtext[i] && rawtext[i] <= (byte) 0xF7
                        && // Original GB range
                        (byte) 0xA1 <= rawtext[i + 1]
                        && rawtext[i + 1] <= (byte) 0xFE) {
                    gbchars++;
                    totalfreq += 500;
                    row = rawtext[i] + 256 - 0xA1;
                    column = rawtext[i + 1] + 256 - 0xA1;

                    //System.out.println("original row "+row+" column "+column);
                    if (GB2312Encoding.GBFreq[row][column] != 0) {
                        gbfreq += GB2312Encoding.GBFreq[row][column];
                    } else if (15 <= row && row < 55) {
                        gbfreq += 200;
                    }
                } else if ((byte) 0x81 <= rawtext[i] && rawtext[i] <= (byte) 0xFE && // Extended GB range
                        (((byte) 0x80 <= rawtext[i + 1] && rawtext[i + 1] <= (byte) 0xFE) 
                                || ((byte) 0x40 <= rawtext[i + 1] && rawtext[i + 1] <= (byte) 0x7E))) {
                    gbchars++;
                    totalfreq += 500;
                    row = rawtext[i] + 256 - 0x81;
                    if (0x40 <= rawtext[i + 1] && rawtext[i + 1] <= 0x7E) {
                        column = rawtext[i + 1] - 0x40;
                    } else {
                        column = rawtext[i + 1] + 256 - 0x40;
                    }
                    // System.out.println("extended row " + row + " column " +
                    // column + " rawtext[i] " + rawtext[i]);
                    if (GBKFreq[row][column] != 0) {
                        gbfreq += GBKFreq[row][column];
                    }
                }
                i++;
            }
        }
        rangeval = 50 * ((float) gbchars / (float) dbchars);
        freqval = 50 * ((float) gbfreq / (float) totalfreq);
        //System.out.println("rangeval:" + rangeval + "---freqval: " + freqval);
        //System.out.println("rangeval:" + rangeval + "---freqval: " + freqval);
        return (int) (rangeval + freqval + 0.5);
    }

    public static void main(String[] args) throws IOException {
        if (args.length < 1) {
            System.out.println("Usage: GBKEncoding filename [numbytes]");
            System.exit(1);
        }

        File file = new File(args[0]);
        FileInputStream stream = new FileInputStream(file);

        int len = 100000;
        if (args.length > 1) {
            try {
                len = Integer.parseInt(args[1]);
            } catch (NumberFormatException e) {}
        }

        len = Math.min(len, (int) file.length());

        byte[] rawtext = new byte[len];
        stream.read(rawtext, 0, len);
        stream.close();
        GBKEncoding encoding = new GBKEncoding();
        System.out.println("File: " + file + ". Examined " + len + " bytes. "
                + encoding.getName() + " probability: "
                + encoding.probability(rawtext, 0, rawtext.length, len));
    }

    /**
     * initiate the frequency of GBK chars
     */
    private static void initialize_frequencies() {
        for (int i = 0; i < 126; i++) {
            for (int j = 0; j < 191; j++) {
                GBKFreq[i][j] = 0;
            }
        }

        // the frequency of GBK chars
        GBKFreq[52][132] = 600;
        GBKFreq[73][135] = 599;
        GBKFreq[49][123] = 598;
        GBKFreq[77][146] = 597;
        GBKFreq[81][123] = 596;
        GBKFreq[82][144] = 595;
        GBKFreq[51][179] = 594;
        GBKFreq[83][154] = 593;
        GBKFreq[71][139] = 592;
        GBKFreq[64][139] = 591;
        GBKFreq[85][144] = 590;
        GBKFreq[52][125] = 589;
        GBKFreq[88][25] = 588;
        GBKFreq[81][106] = 587;
        GBKFreq[81][148] = 586;
        GBKFreq[62][137] = 585;
        GBKFreq[94][0] = 584;
        GBKFreq[1][64] = 583;
        GBKFreq[67][163] = 582;
        GBKFreq[20][190] = 581;
        GBKFreq[57][131] = 580;
        GBKFreq[29][169] = 579;
        GBKFreq[72][143] = 578;
        GBKFreq[0][173] = 577;
        GBKFreq[11][23] = 576;
        GBKFreq[61][141] = 575;
        GBKFreq[60][123] = 574;
        GBKFreq[81][114] = 573;
        GBKFreq[82][131] = 572;
        GBKFreq[67][156] = 571;
        GBKFreq[71][167] = 570;
        GBKFreq[20][50] = 569;
        GBKFreq[77][132] = 568;
        GBKFreq[84][38] = 567;
        GBKFreq[26][29] = 566;
        GBKFreq[74][187] = 565;
        GBKFreq[62][116] = 564;
        GBKFreq[67][135] = 563;
        GBKFreq[5][86] = 562;
        GBKFreq[72][186] = 561;
        GBKFreq[75][161] = 560;
        GBKFreq[78][130] = 559;
        GBKFreq[94][30] = 558;
        GBKFreq[84][72] = 557;
        GBKFreq[1][67] = 556;
        GBKFreq[75][172] = 555;
        GBKFreq[74][185] = 554;
        GBKFreq[53][160] = 553;
        GBKFreq[123][14] = 552;
        GBKFreq[79][97] = 551;
        GBKFreq[85][110] = 550;
        GBKFreq[78][171] = 549;
        GBKFreq[52][131] = 548;
        GBKFreq[56][100] = 547;
        GBKFreq[50][182] = 546;
        GBKFreq[94][64] = 545;
        GBKFreq[106][74] = 544;
        GBKFreq[11][102] = 543;
        GBKFreq[53][124] = 542;
        GBKFreq[24][3] = 541;
        GBKFreq[86][148] = 540;
        GBKFreq[53][184] = 539;
        GBKFreq[86][147] = 538;
        GBKFreq[96][161] = 537;
        GBKFreq[82][77] = 536;
        GBKFreq[59][146] = 535;
        GBKFreq[84][126] = 534;
        GBKFreq[79][132] = 533;
        GBKFreq[85][123] = 532;
        GBKFreq[71][101] = 531;
        GBKFreq[85][106] = 530;
        GBKFreq[6][184] = 529;
        GBKFreq[57][156] = 528;
        GBKFreq[75][104] = 527;
        GBKFreq[50][137] = 526;
        GBKFreq[79][133] = 525;
        GBKFreq[76][108] = 524;
        GBKFreq[57][142] = 523;
        GBKFreq[84][130] = 522;
        GBKFreq[52][128] = 521;
        GBKFreq[47][44] = 520;
        GBKFreq[52][152] = 519;
        GBKFreq[54][104] = 518;
        GBKFreq[30][47] = 517;
        GBKFreq[71][123] = 516;
        GBKFreq[52][107] = 515;
        GBKFreq[45][84] = 514;
        GBKFreq[107][118] = 513;
        GBKFreq[5][161] = 512;
        GBKFreq[48][126] = 511;
        GBKFreq[67][170] = 510;
        GBKFreq[43][6] = 509;
        GBKFreq[70][112] = 508;
        GBKFreq[86][174] = 507;
        GBKFreq[84][166] = 506;
        GBKFreq[79][130] = 505;
        GBKFreq[57][141] = 504;
        GBKFreq[81][178] = 503;
        GBKFreq[56][187] = 502;
        GBKFreq[81][162] = 501;
        GBKFreq[53][104] = 500;
        GBKFreq[123][35] = 499;
        GBKFreq[70][169] = 498;
        GBKFreq[69][164] = 497;
        GBKFreq[109][61] = 496;
        GBKFreq[73][130] = 495;
        GBKFreq[62][134] = 494;
        GBKFreq[54][125] = 493;
        GBKFreq[79][105] = 492;
        GBKFreq[70][165] = 491;
        GBKFreq[71][189] = 490;
        GBKFreq[23][147] = 489;
        GBKFreq[51][139] = 488;
        GBKFreq[47][137] = 487;
        GBKFreq[77][123] = 486;
        GBKFreq[86][183] = 485;
        GBKFreq[63][173] = 484;
        GBKFreq[79][144] = 483;
        GBKFreq[84][159] = 482;
        GBKFreq[60][91] = 481;
        GBKFreq[66][187] = 480;
        GBKFreq[73][114] = 479;
        GBKFreq[85][56] = 478;
        GBKFreq[71][149] = 477;
        GBKFreq[84][189] = 476;
        GBKFreq[104][31] = 475;
        GBKFreq[83][82] = 474;
        GBKFreq[68][35] = 473;
        GBKFreq[11][77] = 472;
        GBKFreq[15][155] = 471;
        GBKFreq[83][153] = 470;
        GBKFreq[71][1] = 469;
        GBKFreq[53][190] = 468;
        GBKFreq[50][135] = 467;
        GBKFreq[3][147] = 466;
        GBKFreq[48][136] = 465;
        GBKFreq[66][166] = 464;
        GBKFreq[55][159] = 463;
        GBKFreq[82][150] = 462;
        GBKFreq[58][178] = 461;
        GBKFreq[64][102] = 460;
        GBKFreq[16][106] = 459;
        GBKFreq[68][110] = 458;
        GBKFreq[54][14] = 457;
        GBKFreq[60][140] = 456;
        GBKFreq[91][71] = 455;
        GBKFreq[54][150] = 454;
        GBKFreq[78][177] = 453;
        GBKFreq[78][117] = 452;
        GBKFreq[104][12] = 451;
        GBKFreq[73][150] = 450;
        GBKFreq[51][142] = 449;
        GBKFreq[81][145] = 448;
        GBKFreq[66][183] = 447;
        GBKFreq[51][178] = 446;
        GBKFreq[75][107] = 445;
        GBKFreq[65][119] = 444;
        GBKFreq[69][176] = 443;
        GBKFreq[59][122] = 442;
        GBKFreq[78][160] = 441;
        GBKFreq[85][183] = 440;
        GBKFreq[105][16] = 439;
        GBKFreq[73][110] = 438;
        GBKFreq[104][39] = 437;
        GBKFreq[119][16] = 436;
        GBKFreq[76][162] = 435;
        GBKFreq[67][152] = 434;
        GBKFreq[82][24] = 433;
        GBKFreq[73][121] = 432;
        GBKFreq[83][83] = 431;
        GBKFreq[82][145] = 430;
        GBKFreq[49][133] = 429;
        GBKFreq[94][13] = 428;
        GBKFreq[58][139] = 427;
        GBKFreq[74][189] = 426;
        GBKFreq[66][177] = 425;
        GBKFreq[85][184] = 424;
        GBKFreq[55][183] = 423;
        GBKFreq[71][107] = 422;
        GBKFreq[11][98] = 421;
        GBKFreq[72][153] = 420;
        GBKFreq[2][137] = 419;
        GBKFreq[59][147] = 418;
        GBKFreq[58][152] = 417;
        GBKFreq[55][144] = 416;
        GBKFreq[73][125] = 415;
        GBKFreq[52][154] = 414;
        GBKFreq[70][178] = 413;
        GBKFreq[79][148] = 412;
        GBKFreq[63][143] = 411;
        GBKFreq[50][140] = 410;
        GBKFreq[47][145] = 409;
        GBKFreq[48][123] = 408;
        GBKFreq[56][107] = 407;
        GBKFreq[84][83] = 406;
        GBKFreq[59][112] = 405;
        GBKFreq[124][72] = 404;
        GBKFreq[79][99] = 403;
        GBKFreq[3][37] = 402;
        GBKFreq[114][55] = 401;
        GBKFreq[85][152] = 400;
        GBKFreq[60][47] = 399;
        GBKFreq[65][96] = 398;
        GBKFreq[74][110] = 397;
        GBKFreq[86][182] = 396;
        GBKFreq[50][99] = 395;
        GBKFreq[67][186] = 394;
        GBKFreq[81][74] = 393;
        GBKFreq[80][37] = 392;
        GBKFreq[21][60] = 391;
        GBKFreq[110][12] = 390;
        GBKFreq[60][162] = 389;
        GBKFreq[29][115] = 388;
        GBKFreq[83][130] = 387;
        GBKFreq[52][136] = 386;
        GBKFreq[63][114] = 385;
        GBKFreq[49][127] = 384;
        GBKFreq[83][109] = 383;
        GBKFreq[66][128] = 382;
        GBKFreq[78][136] = 381;
        GBKFreq[81][180] = 380;
        GBKFreq[76][104] = 379;
        GBKFreq[56][156] = 378;
        GBKFreq[61][23] = 377;
        GBKFreq[4][30] = 376;
        GBKFreq[69][154] = 375;
        GBKFreq[100][37] = 374;
        GBKFreq[54][177] = 373;
        GBKFreq[23][119] = 372;
        GBKFreq[71][171] = 371;
        GBKFreq[84][146] = 370;
        GBKFreq[20][184] = 369;
        GBKFreq[86][76] = 368;
        GBKFreq[74][132] = 367;
        GBKFreq[47][97] = 366;
        GBKFreq[82][137] = 365;
        GBKFreq[94][56] = 364;
        GBKFreq[92][30] = 363;
        GBKFreq[19][117] = 362;
        GBKFreq[48][173] = 361;
        GBKFreq[2][136] = 360;
        GBKFreq[7][182] = 359;
        GBKFreq[74][188] = 358;
        GBKFreq[14][132] = 357;
        GBKFreq[62][172] = 356;
        GBKFreq[25][39] = 355;
        GBKFreq[85][129] = 354;
        GBKFreq[64][98] = 353;
        GBKFreq[67][127] = 352;
        GBKFreq[72][167] = 351;
        GBKFreq[57][143] = 350;
        GBKFreq[76][187] = 349;
        GBKFreq[83][181] = 348;
        GBKFreq[84][10] = 347;
        GBKFreq[55][166] = 346;
        GBKFreq[55][188] = 345;
        GBKFreq[13][151] = 344;
        GBKFreq[62][124] = 343;
        GBKFreq[53][136] = 342;
        GBKFreq[106][57] = 341;
        GBKFreq[47][166] = 340;
        GBKFreq[109][30] = 339;
        GBKFreq[78][114] = 338;
        GBKFreq[83][19] = 337;
        GBKFreq[56][162] = 336;
        GBKFreq[60][177] = 335;
        GBKFreq[88][9] = 334;
        GBKFreq[74][163] = 333;
        GBKFreq[52][156] = 332;
        GBKFreq[71][180] = 331;
        GBKFreq[60][57] = 330;
        GBKFreq[72][173] = 329;
        GBKFreq[82][91] = 328;
        GBKFreq[51][186] = 327;
        GBKFreq[75][86] = 326;
        GBKFreq[75][78] = 325;
        GBKFreq[76][170] = 324;
        GBKFreq[60][147] = 323;
        GBKFreq[82][75] = 322;
        GBKFreq[80][148] = 321;
        GBKFreq[86][150] = 320;
        GBKFreq[13][95] = 319;
        GBKFreq[0][11] = 318;
        GBKFreq[84][190] = 317;
        GBKFreq[76][166] = 316;
        GBKFreq[14][72] = 315;
        GBKFreq[67][144] = 314;
        GBKFreq[84][44] = 313;
        GBKFreq[72][125] = 312;
        GBKFreq[66][127] = 311;
        GBKFreq[60][25] = 310;
        GBKFreq[70][146] = 309;
        GBKFreq[79][135] = 308;
        GBKFreq[54][135] = 307;
        GBKFreq[60][104] = 306;
        GBKFreq[55][132] = 305;
        GBKFreq[94][2] = 304;
        GBKFreq[54][133] = 303;
        GBKFreq[56][190] = 302;
        GBKFreq[58][174] = 301;
        GBKFreq[80][144] = 300;
        GBKFreq[85][113] = 299;

    }
}
