package toolbox.lang.encdetect.specificencoding;

import toolbox.lang.encdetect.Encoding;
import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * Chinese
 * 
 * @author xudq
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class ISO_2022_CNEncoding implements Encoding {

    public final String getName() {
        return "ISO-2022-CN";
    }

    /*
     * Argument: byte array 
     * Returns : number from 0 to 100 representing probability 
     * text in array uses ISO 2022-CN
     * encoding WORKS FOR BASIC CASES, BUT STILL NEEDS MORE WORK
     */
    public final int probability(byte[] rawtext, int offset, int size,
            int checkLength) {
        int dbchars = 1, isochars = 1;
        long isofreq = 0, totalfreq = 1;
        float rangeval = 0, freqval = 0;
        int row, column;

        // Check to see if characters fit into acceptable ranges
        // and have expected frequency of use

        int end = offset + size;
        for (int i = offset; i < end - 1; i++) {
            if (rawtext[i] == (byte) 0x1B && i + 3 < end) { // Escape
                                                                    // char ESC
                if (rawtext[i + 1] == (byte) 0x24 && rawtext[i + 2] == 0x29
                        && rawtext[i + 3] == (byte) 0x41) { // GB Escape $ ) A
                    i += 4;
                    while (rawtext[i] != (byte) 0x1B) {
                        dbchars++;
                        if ((0x21 <= rawtext[i] && rawtext[i] <= 0x77)
                                && (0x21 <= rawtext[i + 1] && rawtext[i + 1] <= 0x77)) {
                            isochars++;
                            row = rawtext[i] - 0x21;
                            column = rawtext[i + 1] - 0x21;
                            totalfreq += 500;
                            if (GB2312Encoding.GBFreq[row][column] != 0) {
                                isofreq += GB2312Encoding.GBFreq[row][column];
                            } else if (15 <= row && row < 55) {
                                isofreq += 200;
                            }
                            i++;
                        }
                        i++;
                    }
                } else if (i + 3 < end && rawtext[i + 1] == (byte) 0x24
                        && rawtext[i + 2] == (byte) 0x29
                        && rawtext[i + 3] == (byte) 0x47) {
                    // CNS Escape $ ) G
                    i += 4;
                    while (rawtext[i] != (byte) 0x1B) {
                        dbchars++;
                        if ((byte) 0x21 <= rawtext[i]
                                && rawtext[i] <= (byte) 0x7E
                                && (byte) 0x21 <= rawtext[i + 1]
                                && rawtext[i + 1] <= (byte) 0x7E) {
                            isochars++;
                            totalfreq += 500;
                            row = rawtext[i] - 0x21;
                            column = rawtext[i + 1] - 0x21;
                            if (EUC_TWEncoding.EUC_TWFreq[row][column] != 0) {
                                isofreq += EUC_TWEncoding.EUC_TWFreq[row][column];
                            } else if (35 <= row && row <= 92) {
                                isofreq += 150;
                            }
                            i++;
                        }
                        i++;
                    }
                }
                if (rawtext[i] == (byte) 0x1B && i + 2 < end
                        && rawtext[i + 1] == (byte) 0x28
                        && rawtext[i + 2] == (byte) 0x42) { // ASCII: ESC ( B
                    i += 2;
                }
            }
        }
        rangeval = 50 * ((float) isochars / (float) dbchars);
        freqval = 50 * ((float) isofreq / (float) totalfreq);

        // System.out.println("isochars dbchars isofreq totalfreq " + isochars +
        // " " + dbchars + " " + isofreq + " " + totalfreq + " " + rangeval + "
        // " + freqval);

        return (int) (rangeval + freqval + 0.5);
    }


}
