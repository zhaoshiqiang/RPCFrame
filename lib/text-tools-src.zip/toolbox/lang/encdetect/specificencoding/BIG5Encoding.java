/*
 * Copyright (c) 2005,
 *  Yitao Duan, Jimmy Su, Feng Zhou and Li Zhuang
 *
 * Created on Aug 21, 2005
 */
package toolbox.lang.encdetect.specificencoding;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import toolbox.lang.encdetect.Encoding;
import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * Traditional Chinese BIG5Encoding
 * 
 * @author ET,xudq
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class BIG5Encoding implements Encoding {
    //Frequency table to hold the Big5 character frequencies
    private static int Big5Freq[][] = new int[94][158];
    
    static {
        initialize_frequencies();
    }

    public final String getName() {
        return "BIG5";
    }

    /**
     * Argument: byte array
     * Returns : number from 0 to 100 representing probability
     * text in array uses Big5 encoding
     */
    public final int probability(byte[] rawtext, int offset, int size,
            int checkLength) {
        int dbchars = 1, bfchars = 1;
        float rangeval = 0, freqval = 0;
        long bffreq = 0, totalfreq = 1;
        int row, column;

        // Check to see if characters fit into acceptable ranges

        int end = offset + size;
        for (int i = offset; i < end - 1; i++) {
            if (rawtext[i] >= 0) {
                // asciichars++;
            } else {
                dbchars++;
                if (dbchars >= checkLength){
                    break;
                }
                if ((byte) 0xA1 <= rawtext[i] && rawtext[i] <= (byte) 0xF9
                        && (((byte) 0x40 <= rawtext[i + 1] && rawtext[i + 1] <= (byte) 0x7E)
                                || ((byte) 0xA1 <= rawtext[i + 1] && rawtext[i + 1] <= (byte) 0xFE))) {
                    bfchars++;
                    totalfreq += 500;
                    row = rawtext[i] + 256 - 0xA1;
                    if (0x40 <= rawtext[i + 1] && rawtext[i + 1] <= 0x7E) {
                        column = rawtext[i + 1] - 0x40;
                    } else {
                        column = rawtext[i + 1] + 256 - 0x61;
                    }
                    if (Big5Freq[row][column] != 0) {
                        bffreq += Big5Freq[row][column];
                    } else if (3 <= row && row <= 37) {
                        bffreq += 200;
                    }
                }
                i++;
            }
        }
        rangeval = 50 * ((float) bfchars / (float) dbchars);
        freqval = 50 * ((float) bffreq / (float) totalfreq);
        //System.out.println("rangeval:" + rangeval + "---freqval: " + freqval);
        return (int) (rangeval + freqval + 0.5);
    }

    public static void main(String[] args) throws IOException {
        if (args.length < 1) {
            System.out.println("Usage: BIG5Encoding filename [numbytes]");
            System.exit(1);
        }

        File file = new File(args[0]);
        FileInputStream stream = new FileInputStream(file);

        int len = 100000;
        if (args.length > 1) {
            try {
                len = Integer.parseInt(args[1]);
            } catch (NumberFormatException e) {
            }
        }

        len = Math.min(len, (int) file.length());

        byte[] rawtext = new byte[len];
        stream.read(rawtext, 0, len);
        stream.close();
        BIG5Encoding encoding = new BIG5Encoding();
        
        System.out.println("File: " + file + ". Examined " + len + " bytes. "
                + encoding.getName() + " probability: "
                + encoding.probability(rawtext, 0, rawtext.length, len));
    }

    /**
     * initiate the frequecy of big5 chars
     *
     */
    private static void initialize_frequencies(){
        for (int i = 0; i < 94; i++) {
            for (int j = 0; j < 158; j++) {
                Big5Freq[i][j] = 0;
            }
        }
        Big5Freq[9][89] = 600;
        Big5Freq[11][15] = 599;
        Big5Freq[3][66] = 598;
        Big5Freq[6][121] = 597;
        Big5Freq[3][0] = 596;
        Big5Freq[5][82] = 595;
        Big5Freq[3][42] = 594;
        Big5Freq[5][34] = 593;
        Big5Freq[3][8] = 592;
        Big5Freq[3][6] = 591;
        Big5Freq[3][67] = 590;
        Big5Freq[7][139] = 589;
        Big5Freq[23][137] = 588;
        Big5Freq[12][46] = 587;
        Big5Freq[4][8] = 586;
        Big5Freq[4][41] = 585;
        Big5Freq[18][47] = 584;
        Big5Freq[12][114] = 583;
        Big5Freq[6][1] = 582;
        Big5Freq[22][60] = 581;
        Big5Freq[5][46] = 580;
        Big5Freq[11][79] = 579;
        Big5Freq[3][23] = 578;
        Big5Freq[7][114] = 577;
        Big5Freq[29][102] = 576;
        Big5Freq[19][14] = 575;
        Big5Freq[4][133] = 574;
        Big5Freq[3][29] = 573;
        Big5Freq[4][109] = 572;
        Big5Freq[14][127] = 571;
        Big5Freq[5][48] = 570;
        Big5Freq[13][104] = 569;
        Big5Freq[3][132] = 568;
        Big5Freq[26][64] = 567;
        Big5Freq[7][19] = 566;
        Big5Freq[4][12] = 565;
        Big5Freq[11][124] = 564;
        Big5Freq[7][89] = 563;
        Big5Freq[15][124] = 562;
        Big5Freq[4][108] = 561;
        Big5Freq[19][66] = 560;
        Big5Freq[3][21] = 559;
        Big5Freq[24][12] = 558;
        Big5Freq[28][111] = 557;
        Big5Freq[12][107] = 556;
        Big5Freq[3][112] = 555;
        Big5Freq[8][113] = 554;
        Big5Freq[5][40] = 553;
        Big5Freq[26][145] = 552;
        Big5Freq[3][48] = 551;
        Big5Freq[3][70] = 550;
        Big5Freq[22][17] = 549;
        Big5Freq[16][47] = 548;
        Big5Freq[3][53] = 547;
        Big5Freq[4][24] = 546;
        Big5Freq[32][120] = 545;
        Big5Freq[24][49] = 544;
        Big5Freq[24][142] = 543;
        Big5Freq[18][66] = 542;
        Big5Freq[29][150] = 541;
        Big5Freq[5][122] = 540;
        Big5Freq[5][114] = 539;
        Big5Freq[3][44] = 538;
        Big5Freq[10][128] = 537;
        Big5Freq[15][20] = 536;
        Big5Freq[13][33] = 535;
        Big5Freq[14][87] = 534;
        Big5Freq[3][126] = 533;
        Big5Freq[4][53] = 532;
        Big5Freq[4][40] = 531;
        Big5Freq[9][93] = 530;
        Big5Freq[15][137] = 529;
        Big5Freq[10][123] = 528;
        Big5Freq[4][56] = 527;
        Big5Freq[5][71] = 526;
        Big5Freq[10][8] = 525;
        Big5Freq[5][16] = 524;
        Big5Freq[5][146] = 523;
        Big5Freq[18][88] = 522;
        Big5Freq[24][4] = 521;
        Big5Freq[20][47] = 520;
        Big5Freq[5][33] = 519;
        Big5Freq[9][43] = 518;
        Big5Freq[20][12] = 517;
        Big5Freq[20][13] = 516;
        Big5Freq[5][156] = 515;
        Big5Freq[22][140] = 514;
        Big5Freq[8][146] = 513;
        Big5Freq[21][123] = 512;
        Big5Freq[4][90] = 511;
        Big5Freq[5][62] = 510;
        Big5Freq[17][59] = 509;
        Big5Freq[10][37] = 508;
        Big5Freq[18][107] = 507;
        Big5Freq[14][53] = 506;
        Big5Freq[22][51] = 505;
        Big5Freq[8][13] = 504;
        Big5Freq[5][29] = 503;
        Big5Freq[9][7] = 502;
        Big5Freq[22][14] = 501;
        Big5Freq[8][55] = 500;
        Big5Freq[33][9] = 499;
        Big5Freq[16][64] = 498;
        Big5Freq[7][131] = 497;
        Big5Freq[34][4] = 496;
        Big5Freq[7][101] = 495;
        Big5Freq[11][139] = 494;
        Big5Freq[3][135] = 493;
        Big5Freq[7][102] = 492;
        Big5Freq[17][13] = 491;
        Big5Freq[3][20] = 490;
        Big5Freq[27][106] = 489;
        Big5Freq[5][88] = 488;
        Big5Freq[6][33] = 487;
        Big5Freq[5][139] = 486;
        Big5Freq[6][0] = 485;
        Big5Freq[17][58] = 484;
        Big5Freq[5][133] = 483;
        Big5Freq[9][107] = 482;
        Big5Freq[23][39] = 481;
        Big5Freq[5][23] = 480;
        Big5Freq[3][79] = 479;
        Big5Freq[32][97] = 478;
        Big5Freq[3][136] = 477;
        Big5Freq[4][94] = 476;
        Big5Freq[21][61] = 475;
        Big5Freq[23][123] = 474;
        Big5Freq[26][16] = 473;
        Big5Freq[24][137] = 472;
        Big5Freq[22][18] = 471;
        Big5Freq[5][1] = 470;
        Big5Freq[20][119] = 469;
        Big5Freq[3][7] = 468;
        Big5Freq[10][79] = 467;
        Big5Freq[15][105] = 466;
        Big5Freq[3][144] = 465;
        Big5Freq[12][80] = 464;
        Big5Freq[15][73] = 463;
        Big5Freq[3][19] = 462;
        Big5Freq[8][109] = 461;
        Big5Freq[3][15] = 460;
        Big5Freq[31][82] = 459;
        Big5Freq[3][43] = 458;
        Big5Freq[25][119] = 457;
        Big5Freq[16][111] = 456;
        Big5Freq[7][77] = 455;
        Big5Freq[3][95] = 454;
        Big5Freq[24][82] = 453;
        Big5Freq[7][52] = 452;
        Big5Freq[9][151] = 451;
        Big5Freq[3][129] = 450;
        Big5Freq[5][87] = 449;
        Big5Freq[3][55] = 448;
        Big5Freq[8][153] = 447;
        Big5Freq[4][83] = 446;
        Big5Freq[3][114] = 445;
        Big5Freq[23][147] = 444;
        Big5Freq[15][31] = 443;
        Big5Freq[3][54] = 442;
        Big5Freq[11][122] = 441;
        Big5Freq[4][4] = 440;
        Big5Freq[34][149] = 439;
        Big5Freq[3][17] = 438;
        Big5Freq[21][64] = 437;
        Big5Freq[26][144] = 436;
        Big5Freq[4][62] = 435;
        Big5Freq[8][15] = 434;
        Big5Freq[35][80] = 433;
        Big5Freq[7][110] = 432;
        Big5Freq[23][114] = 431;
        Big5Freq[3][108] = 430;
        Big5Freq[3][62] = 429;
        Big5Freq[21][41] = 428;
        Big5Freq[15][99] = 427;
        Big5Freq[5][47] = 426;
        Big5Freq[4][96] = 425;
        Big5Freq[20][122] = 424;
        Big5Freq[5][21] = 423;
        Big5Freq[4][157] = 422;
        Big5Freq[16][14] = 421;
        Big5Freq[3][117] = 420;
        Big5Freq[7][129] = 419;
        Big5Freq[4][27] = 418;
        Big5Freq[5][30] = 417;
        Big5Freq[22][16] = 416;
        Big5Freq[5][64] = 415;
        Big5Freq[17][99] = 414;
        Big5Freq[17][57] = 413;
        Big5Freq[8][105] = 412;
        Big5Freq[5][112] = 411;
        Big5Freq[20][59] = 410;
        Big5Freq[6][129] = 409;
        Big5Freq[18][17] = 408;
        Big5Freq[3][92] = 407;
        Big5Freq[28][118] = 406;
        Big5Freq[3][109] = 405;
        Big5Freq[31][51] = 404;
        Big5Freq[13][116] = 403;
        Big5Freq[6][15] = 402;
        Big5Freq[36][136] = 401;
        Big5Freq[12][74] = 400;
        Big5Freq[20][88] = 399;
        Big5Freq[36][68] = 398;
        Big5Freq[3][147] = 397;
        Big5Freq[15][84] = 396;
        Big5Freq[16][32] = 395;
        Big5Freq[16][58] = 394;
        Big5Freq[7][66] = 393;
        Big5Freq[23][107] = 392;
        Big5Freq[9][6] = 391;
        Big5Freq[12][86] = 390;
        Big5Freq[23][112] = 389;
        Big5Freq[37][23] = 388;
        Big5Freq[3][138] = 387;
        Big5Freq[20][68] = 386;
        Big5Freq[15][116] = 385;
        Big5Freq[18][64] = 384;
        Big5Freq[12][139] = 383;
        Big5Freq[11][155] = 382;
        Big5Freq[4][156] = 381;
        Big5Freq[12][84] = 380;
        Big5Freq[18][49] = 379;
        Big5Freq[25][125] = 378;
        Big5Freq[25][147] = 377;
        Big5Freq[15][110] = 376;
        Big5Freq[19][96] = 375;
        Big5Freq[30][152] = 374;
        Big5Freq[6][31] = 373;
        Big5Freq[27][117] = 372;
        Big5Freq[3][10] = 371;
        Big5Freq[6][131] = 370;
        Big5Freq[13][112] = 369;
        Big5Freq[36][156] = 368;
        Big5Freq[4][60] = 367;
        Big5Freq[15][121] = 366;
        Big5Freq[4][112] = 365;
        Big5Freq[30][142] = 364;
        Big5Freq[23][154] = 363;
        Big5Freq[27][101] = 362;
        Big5Freq[9][140] = 361;
        Big5Freq[3][89] = 360;
        Big5Freq[18][148] = 359;
        Big5Freq[4][69] = 358;
        Big5Freq[16][49] = 357;
        Big5Freq[6][117] = 356;
        Big5Freq[36][55] = 355;
        Big5Freq[5][123] = 354;
        Big5Freq[4][126] = 353;
        Big5Freq[4][119] = 352;
        Big5Freq[9][95] = 351;
        Big5Freq[5][24] = 350;
        Big5Freq[16][133] = 349;
        Big5Freq[10][134] = 348;
        Big5Freq[26][59] = 347;
        Big5Freq[6][41] = 346;
        Big5Freq[6][146] = 345;
        Big5Freq[19][24] = 344;
        Big5Freq[5][113] = 343;
        Big5Freq[10][118] = 342;
        Big5Freq[34][151] = 341;
        Big5Freq[9][72] = 340;
        Big5Freq[31][25] = 339;
        Big5Freq[18][126] = 338;
        Big5Freq[18][28] = 337;
        Big5Freq[4][153] = 336;
        Big5Freq[3][84] = 335;
        Big5Freq[21][18] = 334;
        Big5Freq[25][129] = 333;
        Big5Freq[6][107] = 332;
        Big5Freq[12][25] = 331;
        Big5Freq[17][109] = 330;
        Big5Freq[7][76] = 329;
        Big5Freq[15][15] = 328;
        Big5Freq[4][14] = 327;
        Big5Freq[23][88] = 326;
        Big5Freq[18][2] = 325;
        Big5Freq[6][88] = 324;
        Big5Freq[16][84] = 323;
        Big5Freq[12][48] = 322;
        Big5Freq[7][68] = 321;
        Big5Freq[5][50] = 320;
        Big5Freq[13][54] = 319;
        Big5Freq[7][98] = 318;
        Big5Freq[11][6] = 317;
        Big5Freq[9][80] = 316;
        Big5Freq[16][41] = 315;
        Big5Freq[7][43] = 314;
        Big5Freq[28][117] = 313;
        Big5Freq[3][51] = 312;
        Big5Freq[7][3] = 311;
        Big5Freq[20][81] = 310;
        Big5Freq[4][2] = 309;
        Big5Freq[11][16] = 308;
        Big5Freq[10][4] = 307;
        Big5Freq[10][119] = 306;
        Big5Freq[6][142] = 305;
        Big5Freq[18][51] = 304;
        Big5Freq[8][144] = 303;
        Big5Freq[10][65] = 302;
        Big5Freq[11][64] = 301;
        Big5Freq[11][130] = 300;
        Big5Freq[9][92] = 299;
        Big5Freq[18][29] = 298;
        Big5Freq[18][78] = 297;
        Big5Freq[18][151] = 296;
        Big5Freq[33][127] = 295;
        Big5Freq[35][113] = 294;
        Big5Freq[10][155] = 293;
        Big5Freq[3][76] = 292;
        Big5Freq[36][123] = 291;
        Big5Freq[13][143] = 290;
        Big5Freq[5][135] = 289;
        Big5Freq[23][116] = 288;
        Big5Freq[6][101] = 287;
        Big5Freq[14][74] = 286;
        Big5Freq[7][153] = 285;
        Big5Freq[3][101] = 284;
        Big5Freq[9][74] = 283;
        Big5Freq[3][156] = 282;
        Big5Freq[4][147] = 281;
        Big5Freq[9][12] = 280;
        Big5Freq[18][133] = 279;
        Big5Freq[4][0] = 278;
        Big5Freq[7][155] = 277;
        Big5Freq[9][144] = 276;
        Big5Freq[23][49] = 275;
        Big5Freq[5][89] = 274;
        Big5Freq[10][11] = 273;
        Big5Freq[3][110] = 272;
        Big5Freq[3][40] = 271;
        Big5Freq[29][115] = 270;
        Big5Freq[9][100] = 269;
        Big5Freq[21][67] = 268;
        Big5Freq[23][145] = 267;
        Big5Freq[10][47] = 266;
        Big5Freq[4][31] = 265;
        Big5Freq[4][81] = 264;
        Big5Freq[22][62] = 263;
        Big5Freq[4][28] = 262;
        Big5Freq[27][39] = 261;
        Big5Freq[27][54] = 260;
        Big5Freq[32][46] = 259;
        Big5Freq[4][76] = 258;
        Big5Freq[26][15] = 257;
        Big5Freq[12][154] = 256;
        Big5Freq[9][150] = 255;
        Big5Freq[15][17] = 254;
        Big5Freq[5][129] = 253;
        Big5Freq[10][40] = 252;
        Big5Freq[13][37] = 251;
        Big5Freq[31][104] = 250;
        Big5Freq[3][152] = 249;
        Big5Freq[5][22] = 248;
        Big5Freq[8][48] = 247;
        Big5Freq[4][74] = 246;
        Big5Freq[6][17] = 245;
        Big5Freq[30][82] = 244;
        Big5Freq[4][116] = 243;
        Big5Freq[16][42] = 242;
        Big5Freq[5][55] = 241;
        Big5Freq[4][64] = 240;
        Big5Freq[14][19] = 239;
        Big5Freq[35][82] = 238;
        Big5Freq[30][139] = 237;
        Big5Freq[26][152] = 236;
        Big5Freq[32][32] = 235;
        Big5Freq[21][102] = 234;
        Big5Freq[10][131] = 233;
        Big5Freq[9][128] = 232;
        Big5Freq[3][87] = 231;
        Big5Freq[4][51] = 230;
        Big5Freq[10][15] = 229;
        Big5Freq[4][150] = 228;
        Big5Freq[7][4] = 227;
        Big5Freq[7][51] = 226;
        Big5Freq[7][157] = 225;
        Big5Freq[4][146] = 224;
        Big5Freq[4][91] = 223;
        Big5Freq[7][13] = 222;
        Big5Freq[17][116] = 221;
        Big5Freq[23][21] = 220;
        Big5Freq[5][106] = 219;
        Big5Freq[14][100] = 218;
        Big5Freq[10][152] = 217;
        Big5Freq[14][89] = 216;
        Big5Freq[6][138] = 215;
        Big5Freq[12][157] = 214;
        Big5Freq[10][102] = 213;
        Big5Freq[19][94] = 212;
        Big5Freq[7][74] = 211;
        Big5Freq[18][128] = 210;
        Big5Freq[27][111] = 209;
        Big5Freq[11][57] = 208;
        Big5Freq[3][131] = 207;
        Big5Freq[30][23] = 206;
        Big5Freq[30][126] = 205;
        Big5Freq[4][36] = 204;
        Big5Freq[26][124] = 203;
        Big5Freq[4][19] = 202;
        Big5Freq[9][152] = 201;
    }
}
