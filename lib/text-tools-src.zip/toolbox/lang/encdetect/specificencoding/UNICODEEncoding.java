package toolbox.lang.encdetect.specificencoding;

import toolbox.lang.encdetect.Encoding;
import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * unicode, can express many languages
 * 
 * @author xudq
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class UNICODEEncoding implements Encoding {

    public final String getName() {
        return "UNICODE";
    }

    /*
     * Make sure the char at offset is the first char of the file
     * Function: utf16_probability 
     * Argument: byte array 
     * Returns : number from 0 to 100 representing probability
     * text in array uses UTF-16 encoding of Unicode, 
     * guess based on BOM
     * NOT VERY GENERAL, NEEDS MUCH MORE WORK
     */
    public final int probability(byte[] rawtext, int offset, int size,
            int checkLength) {
        if (size > 1
                && (((byte) 0xFE == rawtext[offset] && (byte) 0xFF == rawtext[offset+1]) || // Big-endian
                ((byte) 0xFF == rawtext[offset] && (byte) 0xFE == rawtext[offset+1]))) { // Little-endian
            return 100;
        }
        return 0;
    }

}
