/*
 * Copyright (c) 2005,
 *  Yitao Duan, Jimmy Su, Feng Zhou and Li Zhuang
 *
 * Created on Aug 21, 2005
 */
package toolbox.lang.encdetect.specificencoding;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import toolbox.lang.encdetect.Encoding;
import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * Simplified Chinese,GB2312Encoding
 * 
 * @author ET,xudq
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class GB2312Encoding implements Encoding {
    static int[][] GBFreq = new int[94][94];
    static{
        initialize_frequencies();
    }
    public final String getName() {
        return "GBK";
    }
    
    /*
     * Argument: pointer to byte array 
     * Returns : number from 0 to 100 representing probability 
     * text in array uses GB-2312 encoding
     */
    public final int probability(byte[] rawtext, int offset, int size,
            int checkLength) {
        int dbchars = 1, gbchars = 1;
        long gbfreq = 0, totalfreq = 1;
        float rangeval = 0, freqval = 0;
        int row, column;

        // Stage 1: Check to see if characters fit into acceptable ranges
        int end = offset + size;
        for (int i = offset; i < end - 1; i++) {
            // System.err.println(rawtext[i]);
            if (rawtext[i] >= 0) {
                // asciichars++;
            } else {
                dbchars++;
                if(dbchars >= checkLength){
                    break;
                }
                if ((byte) 0xA1 <= rawtext[i] && rawtext[i] <= (byte) 0xF7
                        && (byte) 0xA1 <= rawtext[i + 1]
                        && rawtext[i + 1] <= (byte) 0xFE) {
                    gbchars++;
                    totalfreq += 500;
                    row = rawtext[i] + 256 - 0xA1;
                    column = rawtext[i + 1] + 256 - 0xA1;
                    if (GBFreq[row][column] != 0) {
                        gbfreq += GBFreq[row][column];
                    } else if (15 <= row && row < 55) {
                        // In GB high-freq character range
                        gbfreq += 200;
                    }

                }
                i++;
            }
        }
        rangeval = 50 * ((float) gbchars / (float) dbchars);
        freqval = 50 * ((float) gbfreq / (float) totalfreq);

        return (int) (rangeval + freqval + 0.5);
    }

    public static void main(String[] args) throws IOException {
        if (args.length < 1) {
            System.out.println("Usage: GB2312Encoding filename [numbytes]");
            System.exit(1);
        }

        File file = new File(args[0]);
        FileInputStream stream = new FileInputStream(file);

        int len = 100000;
        if (args.length > 1) {
            try {
                len = Integer.parseInt(args[1]);
            } catch (NumberFormatException e) {}
        }

        len = Math.min(len, (int) file.length());

        byte[] rawtext = new byte[len];
        stream.read(rawtext, 0, len);
        stream.close();
        GB2312Encoding encoding = new GB2312Encoding();
        System.out.println("File: " + file + ". Examined " + len + " bytes. "
                + encoding.getName() + " probability: "
                + encoding.probability(rawtext, 0, rawtext.length, len));
    }
    private static void initialize_frequencies(){
        for (int i = 0; i < 94; i++) {
            for (int j = 0; j < 94; j++) {
                GBFreq[i][j] = 0;
            }
        }
        
        GBFreq[20][35] = 599;
        GBFreq[49][26] = 598;
        GBFreq[41][38] = 597;
        GBFreq[17][26] = 596;
        GBFreq[32][42] = 595;
        GBFreq[39][42] = 594;
        GBFreq[45][49] = 593;
        GBFreq[51][57] = 592;
        GBFreq[50][47] = 591;
        GBFreq[42][90] = 590;
        GBFreq[52][65] = 589;
        GBFreq[53][47] = 588;
        GBFreq[19][82] = 587;
        GBFreq[31][19] = 586;
        GBFreq[40][46] = 585;
        GBFreq[24][89] = 584;
        GBFreq[23][85] = 583;
        GBFreq[20][28] = 582;
        GBFreq[42][20] = 581;
        GBFreq[34][38] = 580;
        GBFreq[45][9] = 579;
        GBFreq[54][50] = 578;
        GBFreq[25][44] = 577;
        GBFreq[35][66] = 576;
        GBFreq[20][55] = 575;
        GBFreq[18][85] = 574;
        GBFreq[20][31] = 573;
        GBFreq[49][17] = 572;
        GBFreq[41][16] = 571;
        GBFreq[35][73] = 570;
        GBFreq[20][34] = 569;
        GBFreq[29][44] = 568;
        GBFreq[35][38] = 567;
        GBFreq[49][9] = 566;
        GBFreq[46][33] = 565;
        GBFreq[49][51] = 564;
        GBFreq[40][89] = 563;
        GBFreq[26][64] = 562;
        GBFreq[54][51] = 561;
        GBFreq[54][36] = 560;
        GBFreq[39][4] = 559;
        GBFreq[53][13] = 558;
        GBFreq[24][92] = 557;
        GBFreq[27][49] = 556;
        GBFreq[48][6] = 555;
        GBFreq[21][51] = 554;
        GBFreq[30][40] = 553;
        GBFreq[42][92] = 552;
        GBFreq[31][78] = 551;
        GBFreq[25][82] = 550;
        GBFreq[47][0] = 549;
        GBFreq[34][19] = 548;
        GBFreq[47][35] = 547;
        GBFreq[21][63] = 546;
        GBFreq[43][75] = 545;
        GBFreq[21][87] = 544;
        GBFreq[35][59] = 543;
        GBFreq[25][34] = 542;
        GBFreq[21][27] = 541;
        GBFreq[39][26] = 540;
        GBFreq[34][26] = 539;
        GBFreq[39][52] = 538;
        GBFreq[50][57] = 537;
        GBFreq[37][79] = 536;
        GBFreq[26][24] = 535;
        GBFreq[22][1] = 534;
        GBFreq[18][40] = 533;
        GBFreq[41][33] = 532;
        GBFreq[53][26] = 531;
        GBFreq[54][86] = 530;
        GBFreq[20][16] = 529;
        GBFreq[46][74] = 528;
        GBFreq[30][19] = 527;
        GBFreq[45][35] = 526;
        GBFreq[45][61] = 525;
        GBFreq[30][9] = 524;
        GBFreq[41][53] = 523;
        GBFreq[41][13] = 522;
        GBFreq[50][34] = 521;
        GBFreq[53][86] = 520;
        GBFreq[47][47] = 519;
        GBFreq[22][28] = 518;
        GBFreq[50][53] = 517;
        GBFreq[39][70] = 516;
        GBFreq[38][15] = 515;
        GBFreq[42][88] = 514;
        GBFreq[16][29] = 513;
        GBFreq[27][90] = 512;
        GBFreq[29][12] = 511;
        GBFreq[44][22] = 510;
        GBFreq[34][69] = 509;
        GBFreq[24][10] = 508;
        GBFreq[44][11] = 507;
        GBFreq[39][92] = 506;
        GBFreq[49][48] = 505;
        GBFreq[31][46] = 504;
        GBFreq[19][50] = 503;
        GBFreq[21][14] = 502;
        GBFreq[32][28] = 501;
        GBFreq[18][3] = 500;
        GBFreq[53][9] = 499;
        GBFreq[34][80] = 498;
        GBFreq[48][88] = 497;
        GBFreq[46][53] = 496;
        GBFreq[22][53] = 495;
        GBFreq[28][10] = 494;
        GBFreq[44][65] = 493;
        GBFreq[20][10] = 492;
        GBFreq[40][76] = 491;
        GBFreq[47][8] = 490;
        GBFreq[50][74] = 489;
        GBFreq[23][62] = 488;
        GBFreq[49][65] = 487;
        GBFreq[28][87] = 486;
        GBFreq[15][48] = 485;
        GBFreq[22][7] = 484;
        GBFreq[19][42] = 483;
        GBFreq[41][20] = 482;
        GBFreq[26][55] = 481;
        GBFreq[21][93] = 480;
        GBFreq[31][76] = 479;
        GBFreq[34][31] = 478;
        GBFreq[20][66] = 477;
        GBFreq[51][33] = 476;
        GBFreq[34][86] = 475;
        GBFreq[37][67] = 474;
        GBFreq[53][53] = 473;
        GBFreq[40][88] = 472;
        GBFreq[39][10] = 471;
        GBFreq[24][3] = 470;
        GBFreq[27][25] = 469;
        GBFreq[26][15] = 468;
        GBFreq[21][88] = 467;
        GBFreq[52][62] = 466;
        GBFreq[46][81] = 465;
        GBFreq[38][72] = 464;
        GBFreq[17][30] = 463;
        GBFreq[52][92] = 462;
        GBFreq[34][90] = 461;
        GBFreq[21][7] = 460;
        GBFreq[36][13] = 459;
        GBFreq[45][41] = 458;
        GBFreq[32][5] = 457;
        GBFreq[26][89] = 456;
        GBFreq[23][87] = 455;
        GBFreq[20][39] = 454;
        GBFreq[27][23] = 453;
        GBFreq[25][59] = 452;
        GBFreq[49][20] = 451;
        GBFreq[54][77] = 450;
        GBFreq[27][67] = 449;
        GBFreq[47][33] = 448;
        GBFreq[41][17] = 447;
        GBFreq[19][81] = 446;
        GBFreq[16][66] = 445;
        GBFreq[45][26] = 444;
        GBFreq[49][81] = 443;
        GBFreq[53][55] = 442;
        GBFreq[16][26] = 441;
        GBFreq[54][62] = 440;
        GBFreq[20][70] = 439;
        GBFreq[42][35] = 438;
        GBFreq[20][57] = 437;
        GBFreq[34][36] = 436;
        GBFreq[46][63] = 435;
        GBFreq[19][45] = 434;
        GBFreq[21][10] = 433;
        GBFreq[52][93] = 432;
        GBFreq[25][2] = 431;
        GBFreq[30][57] = 430;
        GBFreq[41][24] = 429;
        GBFreq[28][43] = 428;
        GBFreq[45][86] = 427;
        GBFreq[51][56] = 426;
        GBFreq[37][28] = 425;
        GBFreq[52][69] = 424;
        GBFreq[43][92] = 423;
        GBFreq[41][31] = 422;
        GBFreq[37][87] = 421;
        GBFreq[47][36] = 420;
        GBFreq[16][16] = 419;
        GBFreq[40][56] = 418;
        GBFreq[24][55] = 417;
        GBFreq[17][1] = 416;
        GBFreq[35][57] = 415;
        GBFreq[27][50] = 414;
        GBFreq[26][14] = 413;
        GBFreq[50][40] = 412;
        GBFreq[39][19] = 411;
        GBFreq[19][89] = 410;
        GBFreq[29][91] = 409;
        GBFreq[17][89] = 408;
        GBFreq[39][74] = 407;
        GBFreq[46][39] = 406;
        GBFreq[40][28] = 405;
        GBFreq[45][68] = 404;
        GBFreq[43][10] = 403;
        GBFreq[42][13] = 402;
        GBFreq[44][81] = 401;
        GBFreq[41][47] = 400;
        GBFreq[48][58] = 399;
        GBFreq[43][68] = 398;
        GBFreq[16][79] = 397;
        GBFreq[19][5] = 396;
        GBFreq[54][59] = 395;
        GBFreq[17][36] = 394;
        GBFreq[18][0] = 393;
        GBFreq[41][5] = 392;
        GBFreq[41][72] = 391;
        GBFreq[16][39] = 390;
        GBFreq[54][0] = 389;
        GBFreq[51][16] = 388;
        GBFreq[29][36] = 387;
        GBFreq[47][5] = 386;
        GBFreq[47][51] = 385;
        GBFreq[44][7] = 384;
        GBFreq[35][30] = 383;
        GBFreq[26][9] = 382;
        GBFreq[16][7] = 381;
        GBFreq[32][1] = 380;
        GBFreq[33][76] = 379;
        GBFreq[34][91] = 378;
        GBFreq[52][36] = 377;
        GBFreq[26][77] = 376;
        GBFreq[35][48] = 375;
        GBFreq[40][80] = 374;
        GBFreq[41][92] = 373;
        GBFreq[27][93] = 372;
        GBFreq[15][17] = 371;
        GBFreq[16][76] = 370;
        GBFreq[51][12] = 369;
        GBFreq[18][20] = 368;
        GBFreq[15][54] = 367;
        GBFreq[50][5] = 366;
        GBFreq[33][22] = 365;
        GBFreq[37][57] = 364;
        GBFreq[28][47] = 363;
        GBFreq[42][31] = 362;
        GBFreq[18][2] = 361;
        GBFreq[43][64] = 360;
        GBFreq[23][47] = 359;
        GBFreq[28][79] = 358;
        GBFreq[25][45] = 357;
        GBFreq[23][91] = 356;
        GBFreq[22][19] = 355;
        GBFreq[25][46] = 354;
        GBFreq[22][36] = 353;
        GBFreq[54][85] = 352;
        GBFreq[46][20] = 351;
        GBFreq[27][37] = 350;
        GBFreq[26][81] = 349;
        GBFreq[42][29] = 348;
        GBFreq[31][90] = 347;
        GBFreq[41][59] = 346;
        GBFreq[24][65] = 345;
        GBFreq[44][84] = 344;
        GBFreq[24][90] = 343;
        GBFreq[38][54] = 342;
        GBFreq[28][70] = 341;
        GBFreq[27][15] = 340;
        GBFreq[28][80] = 339;
        GBFreq[29][8] = 338;
        GBFreq[45][80] = 337;
        GBFreq[53][37] = 336;
        GBFreq[28][65] = 335;
        GBFreq[23][86] = 334;
        GBFreq[39][45] = 333;
        GBFreq[53][32] = 332;
        GBFreq[38][68] = 331;
        GBFreq[45][78] = 330;
        GBFreq[43][7] = 329;
        GBFreq[46][82] = 328;
        GBFreq[27][38] = 327;
        GBFreq[16][62] = 326;
        GBFreq[24][17] = 325;
        GBFreq[22][70] = 324;
        GBFreq[52][28] = 323;
        GBFreq[23][40] = 322;
        GBFreq[28][50] = 321;
        GBFreq[42][91] = 320;
        GBFreq[47][76] = 319;
        GBFreq[15][42] = 318;
        GBFreq[43][55] = 317;
        GBFreq[29][84] = 316;
        GBFreq[44][90] = 315;
        GBFreq[53][16] = 314;
        GBFreq[22][93] = 313;
        GBFreq[34][10] = 312;
        GBFreq[32][53] = 311;
        GBFreq[43][65] = 310;
        GBFreq[28][7] = 309;
        GBFreq[35][46] = 308;
        GBFreq[21][39] = 307;
        GBFreq[44][18] = 306;
        GBFreq[40][10] = 305;
        GBFreq[54][53] = 304;
        GBFreq[38][74] = 303;
        GBFreq[28][26] = 302;
        GBFreq[15][13] = 301;
        GBFreq[39][34] = 300;
        GBFreq[39][46] = 299;
        GBFreq[42][66] = 298;
        GBFreq[33][58] = 297;
        GBFreq[15][56] = 296;
        GBFreq[18][51] = 295;
        GBFreq[49][68] = 294;
        GBFreq[30][37] = 293;
        GBFreq[51][84] = 292;
        GBFreq[51][9] = 291;
        GBFreq[40][70] = 290;
        GBFreq[41][84] = 289;
        GBFreq[28][64] = 288;
        GBFreq[32][88] = 287;
        GBFreq[24][5] = 286;
        GBFreq[53][23] = 285;
        GBFreq[42][27] = 284;
        GBFreq[22][38] = 283;
        GBFreq[32][86] = 282;
        GBFreq[34][30] = 281;
        GBFreq[38][63] = 280;
        GBFreq[24][59] = 279;
        GBFreq[22][81] = 278;
        GBFreq[32][11] = 277;
        GBFreq[51][21] = 276;
        GBFreq[54][41] = 275;
        GBFreq[21][50] = 274;
        GBFreq[23][89] = 273;
        GBFreq[19][87] = 272;
        GBFreq[26][7] = 271;
        GBFreq[30][75] = 270;
        GBFreq[43][84] = 269;
        GBFreq[51][25] = 268;
        GBFreq[16][67] = 267;
        GBFreq[32][9] = 266;
        GBFreq[48][51] = 265;
        GBFreq[39][7] = 264;
        GBFreq[44][88] = 263;
        GBFreq[52][24] = 262;
        GBFreq[23][34] = 261;
        GBFreq[32][75] = 260;
        GBFreq[19][10] = 259;
        GBFreq[28][91] = 258;
        GBFreq[32][83] = 257;
        GBFreq[25][75] = 256;
        GBFreq[53][45] = 255;
        GBFreq[29][85] = 254;
        GBFreq[53][59] = 253;
        GBFreq[16][2] = 252;
        GBFreq[19][78] = 251;
        GBFreq[15][75] = 250;
        GBFreq[51][42] = 249;
        GBFreq[45][67] = 248;
        GBFreq[15][74] = 247;
        GBFreq[25][81] = 246;
        GBFreq[37][62] = 245;
        GBFreq[16][55] = 244;
        GBFreq[18][38] = 243;
        GBFreq[23][23] = 242;
        GBFreq[38][30] = 241;
        GBFreq[17][28] = 240;
        GBFreq[44][73] = 239;
        GBFreq[23][78] = 238;
        GBFreq[40][77] = 237;
        GBFreq[38][87] = 236;
        GBFreq[27][19] = 235;
        GBFreq[38][82] = 234;
        GBFreq[37][22] = 233;
        GBFreq[41][30] = 232;
        GBFreq[54][9] = 231;
        GBFreq[32][30] = 230;
        GBFreq[30][52] = 229;
        GBFreq[40][84] = 228;
        GBFreq[53][57] = 227;
        GBFreq[27][27] = 226;
        GBFreq[38][64] = 225;
        GBFreq[18][43] = 224;
        GBFreq[23][69] = 223;
        GBFreq[28][12] = 222;
        GBFreq[50][78] = 221;
        GBFreq[50][1] = 220;
        GBFreq[26][88] = 219;
        GBFreq[36][40] = 218;
        GBFreq[33][89] = 217;
        GBFreq[41][28] = 216;
        GBFreq[31][77] = 215;
        GBFreq[46][1] = 214;
        GBFreq[47][19] = 213;
        GBFreq[35][55] = 212;
        GBFreq[41][21] = 211;
        GBFreq[27][10] = 210;
        GBFreq[32][77] = 209;
        GBFreq[26][37] = 208;
        GBFreq[20][33] = 207;
        GBFreq[41][52] = 206;
        GBFreq[32][18] = 205;
        GBFreq[38][13] = 204;
        GBFreq[20][18] = 203;
        GBFreq[20][24] = 202;
        GBFreq[45][19] = 201;
        GBFreq[18][53] = 200;
        
        //add some special tag by xudq
        //add frequent table symbol, 
        //such as #BOX DRAWINGS LIGHT VERTICAL AND HORIZONTAL
        for(int i = 0xA4;i <= 0xEF;i++){
            GBFreq[8][i-0xA1] = 200;
        }
        //add frequent chinese punctuation
        GBFreq[0][3] = 200;
        GBFreq[2][0] = 200;
        GBFreq[2][3] = 200;
        GBFreq[0][12] = 200;//A1AD
        GBFreq[2][7] = 200;//A3A8
        GBFreq[2][8] = 200;//A3A9
        GBFreq[0][9] = 200;//A1AA
        GBFreq[0][29] = 200;//A1BE
        GBFreq[0][30] = 200;//A1BF
        GBFreq[2][25] = 200;//A3BA
        GBFreq[0][13] = 200;//A1AE
        GBFreq[0][14] = 200;//A1AF
        GBFreq[0][15] = 200;//A1B0
        GBFreq[0][16] = 200;//A1B1
        GBFreq[0][21] = 200;//A1B6
        GBFreq[0][22] = 200;//A1B7
        GBFreq[2][11] = 200;//A3AC
        GBFreq[0][2] = 200;//A1A3
        GBFreq[0][1] = 200;//A1A2
        GBFreq[2][30] = 200;//A3BF
        
        GBFreq[0][10] = 200;//A1AB
        GBFreq[2][31] = 200;//A3C0
        GBFreq[2][2] = 200;//A3A3
        GBFreq[2][4] = 200;//A3A5
        GBFreq[2][5] = 200;//A3A6
        GBFreq[0][32] = 200;//A1C1
        GBFreq[2][12] = 200;//A3AD
        GBFreq[2][28] = 200;//A3BD
        GBFreq[2][10] = 200;//A3AB
        GBFreq[2][59] = 200;//A3DC
        GBFreq[2][91] = 200;//A3FC
        GBFreq[2][26] = 200;//A3BB
    }
}
