/*
 * Copyright (c) 2005, Yitao Duan, Jimmy Su, Feng Zhou and Li Zhuang Created on
 * Aug 21, 2005
 */
package toolbox.lang.encdetect;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import toolbox.lang.encdetect.specificencoding.*;
import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * An ecoding detector.
 * 
 * @author ET, xudq
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class EncodingDetector {
    public static boolean verbose = false;

    private static final GB2312Encoding gb2312Encoding = new GB2312Encoding();

    private static final GBKEncoding gbkEncoding = new GBKEncoding();

    private static final HZEncoding hzEncoding = new HZEncoding();

    private static final BIG5Encoding big5Encoding = new BIG5Encoding();

    private static final EUC_TWEncoding euc_twEncoding = new EUC_TWEncoding();

    private static final ISO_2022_CNEncoding iso_2022_cnEncoding = new ISO_2022_CNEncoding();

    private static final UTF8Encoding utf8Encoding = new UTF8Encoding();

    private static final UNICODEEncoding unicodeEncoding = new UNICODEEncoding();

    private static final EUC_KREncoding euc_krEncoding = new EUC_KREncoding();

    private static final CP949Encoding cp949Encoding = new CP949Encoding();

    private static final ISO_2022_KREncoding iso_2022_krEncoding = new ISO_2022_KREncoding();

    private static final ASCIIEncoding asciiEncoding = new ASCIIEncoding();

    private static final SJISEncoding sjisEncoding = new SJISEncoding();

    private static final EUC_JPEncoding euc_jpEncoding = new EUC_JPEncoding();

    private static final ISO_2022_JPEncoding iso_2022_jpEncoding = new ISO_2022_JPEncoding();

    private EncodingDetector() {}

    /**
     * guess the encoding according to address the address can be either url or
     * file path
     * 
     * @param address
     * @param maxlen
     * @return The EncodingGuess result
     * @throws IOException
     */
    public static EncodingGuess detectEncoding(String address, int maxlen)
            throws IOException {
        if (address.startsWith("http://") == true) {
            try {
                return detectEncoding(new URL(address), maxlen);
            } catch (Exception e) {
                if (verbose)
                    System.err.println("Bad URL " + e.toString());
                return new EncodingGuess("", 0, null);
            }
        } else {
            File file = new File(address);
            FileInputStream stream = new FileInputStream(file);

            int len = Math.min(maxlen, (int) file.length());

            byte[] rawtext = new byte[len];
            len = stream.read(rawtext, 0, len);
            stream.close();
            return detectEncoding(rawtext, 0, len, len);
        }
    }

    public static EncodingGuess detectEncoding(URL url, int maxlen) {
        byte[] rawtext = new byte[maxlen];
        InputStream stream;
        try {
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();

            urlConnection.setReadTimeout(10000); // 10s timeout
            urlConnection.connect();
            stream = urlConnection.getInputStream();

            int bytesread = stream.read(rawtext, 0, rawtext.length);
            if (verbose)
                System.out.println("Bytes read: " + bytesread);

            stream.close();
            return detectEncoding(rawtext, 0, bytesread, bytesread);
        } catch (Exception e) {
            if (verbose)
                System.err.println("Error loading or using URL " + e.toString());
            return new EncodingGuess("", 0, null);
        }
    }

    public static EncodingGuess detectEncoding(byte[] data, int checkLength) {
        return detectEncoding(data, 0, data.length, checkLength);
    }

    /**
     * detect the encoding, return new EncodingGuess(OTHER,0) while detector can
     * not determine what encoding it is.
     * 
     * @param rawtext
     * @param offset
     * @param size
     * @param checkLength
     * @return the encoding guess result
     */
    public static EncodingGuess detectEncoding(byte[] rawtext, int offset,
            int size, int checkLength) {
        int[] scores = new int[Encodings.TOTALTYPES];
        int index, maxscore = 0;
        int encoding_guess = Encodings.OTHER;

        // Assign Scores
        scores[Encodings.GB2312] = gb2312Encoding.probability(rawtext, offset,
                size, checkLength);
        scores[Encodings.GBK] = gbkEncoding.probability(rawtext, offset, size,
                checkLength);
        if (scores[Encodings.GBK] > 80) {
            return new EncodingGuess(Encodings.codings[Encodings.GBK],
                    scores[Encodings.GBK], null);
        }

        scores[Encodings.UTF8] = utf8Encoding.probability(rawtext, offset,
                size, checkLength);
        if (scores[Encodings.UTF8] > 90) {
            return new EncodingGuess(Encodings.codings[Encodings.UTF8],
                    scores[Encodings.UTF8], null);
        }

        scores[Encodings.HZ] = hzEncoding.probability(rawtext, offset, size,
                checkLength);
        scores[Encodings.BIG5] = big5Encoding.probability(rawtext, offset,
                size, checkLength);
        scores[Encodings.EUC_TW] = euc_twEncoding.probability(rawtext, offset,
                size, checkLength);
        scores[Encodings.ISO_2022_CN] = iso_2022_cnEncoding.probability(
                rawtext, offset, size, checkLength);
        scores[Encodings.UNICODE] = unicodeEncoding.probability(rawtext,
                offset, size, checkLength);

        scores[Encodings.EUC_KR] = euc_krEncoding.probability(rawtext, offset,
                size, checkLength);
        scores[Encodings.CP949] = cp949Encoding.probability(rawtext, offset,
                size, checkLength);
        scores[Encodings.JOHAB] = 0;
        scores[Encodings.ISO_2022_KR] = iso_2022_krEncoding.probability(
                rawtext, offset, size, checkLength);

        scores[Encodings.ASCII] = asciiEncoding.probability(rawtext, offset,
                size, checkLength);

        scores[Encodings.SJIS] = sjisEncoding.probability(rawtext, offset,
                size, checkLength);
        scores[Encodings.EUC_JP] = euc_jpEncoding.probability(rawtext, offset,
                size, checkLength);
        scores[Encodings.ISO_2022_JP] = iso_2022_jpEncoding.probability(
                rawtext, offset, size, checkLength);

        scores[Encodings.UNICODET] = 0;
        scores[Encodings.UNICODES] = 0;
        scores[Encodings.ISO_2022_CN_GB] = 0;
        scores[Encodings.ISO_2022_CN_CNS] = 0;

        scores[Encodings.OTHER] = 0;

        // Tabulate Scores
        for (index = 0; index < Encodings.TOTALTYPES; index++) {
            if (verbose) {
                System.out.println("Encoding " + Encodings.codings[index]
                        + " score " + scores[index]);
            }
            if (scores[index] > maxscore) {
                encoding_guess = index;
                maxscore = scores[index];
            }
        }

        // Return OTHER if nothing scored above 50
        if (maxscore <= 50) {
            encoding_guess = Encodings.OTHER;
        }
        // we believe GBK more
        if (scores[Encodings.GBK] >= 70
                && scores[encoding_guess] < 85
                && (encoding_guess == Encodings.EUC_JP
                        || encoding_guess == Encodings.EUC_KR || encoding_guess == Encodings.EUC_TW)) {
            encoding_guess = Encodings.GBK;
        }
        // we believe euc_XX if it reachese above 60
        if (scores[encoding_guess] < 60
                && (encoding_guess == Encodings.EUC_JP
                        || encoding_guess == Encodings.EUC_KR || encoding_guess == Encodings.EUC_TW)) {
            encoding_guess = Encodings.OTHER;
        }

        return new EncodingGuess(Encodings.codings[encoding_guess],
                scores[encoding_guess], null);
    }

    public static TreeSet<EncodingGuess> detectAllEncodings(byte[] rawtext,
            int offset, int size, int checkLength) {
        TreeSet<EncodingGuess> guesses = new TreeSet<EncodingGuess>();
        int score = 0;

        score = gb2312Encoding.probability(rawtext, offset, size, checkLength);
        guesses.add(new EncodingGuess(Encodings.codings[Encodings.GB2312],
                score, null));

        score = gbkEncoding.probability(rawtext, offset, size, checkLength);
        guesses.add(new EncodingGuess(Encodings.codings[Encodings.GBK], score,
                null));

        score = hzEncoding.probability(rawtext, offset, size, checkLength);
        guesses.add(new EncodingGuess(Encodings.codings[Encodings.HZ], score,
                null));

        score = big5Encoding.probability(rawtext, offset, size, checkLength);
        guesses.add(new EncodingGuess(Encodings.codings[Encodings.BIG5], score,
                null));

        score = euc_twEncoding.probability(rawtext, offset, size, checkLength);
        guesses.add(new EncodingGuess(Encodings.codings[Encodings.EUC_TW],
                score, null));

        score = iso_2022_cnEncoding.probability(rawtext, offset, size,
                checkLength);
        guesses.add(new EncodingGuess(Encodings.codings[Encodings.ISO_2022_CN],
                score, null));

        score = utf8Encoding.probability(rawtext, offset, size, checkLength);
        guesses.add(new EncodingGuess(Encodings.codings[Encodings.UTF8], score,
                null));

        score = unicodeEncoding.probability(rawtext, offset, size, checkLength);
        guesses.add(new EncodingGuess(Encodings.codings[Encodings.UNICODE],
                score, null));

        score = euc_krEncoding.probability(rawtext, offset, size, checkLength);
        guesses.add(new EncodingGuess(Encodings.codings[Encodings.EUC_KR],
                score, null));

        score = cp949Encoding.probability(rawtext, offset, size, checkLength);
        guesses.add(new EncodingGuess(Encodings.codings[Encodings.CP949],
                score, null));

        score = iso_2022_krEncoding.probability(rawtext, offset, size,
                checkLength);
        guesses.add(new EncodingGuess(Encodings.codings[Encodings.ISO_2022_KR],
                score, null));

        score = asciiEncoding.probability(rawtext, offset, size, checkLength);
        guesses.add(new EncodingGuess(Encodings.codings[Encodings.ASCII],
                score, null));

        score = sjisEncoding.probability(rawtext, offset, size, checkLength);
        guesses.add(new EncodingGuess(Encodings.codings[Encodings.SJIS], score,
                null));

        score = euc_jpEncoding.probability(rawtext, offset, size, checkLength);
        guesses.add(new EncodingGuess(Encodings.codings[Encodings.EUC_JP],
                score, null));

        score = iso_2022_jpEncoding.probability(rawtext, offset, size,
                checkLength);
        guesses.add(new EncodingGuess(Encodings.codings[Encodings.ISO_2022_JP],
                score, null));

        return guesses;
    }

    /**
     * Parse the character encoding from the specified content type header. If
     * the content type is null, or there is no explicit character encoding,
     * <code>null</code> is returned. This method was copy from
     * org.apache.catalina.util.RequestUtil is licensed under the Apache
     * License, Version 2.0 (the "License").
     * 
     * @param contentType
     *            a content type header
     */
    public static String readEncodingFromContentType(String contentType) {
        if (contentType == null)
            return (null);
        int start = contentType.indexOf("charset=");
        if (start < 0)
            return (null);
        String encoding = contentType.substring(start + 8);
        int end = encoding.indexOf(';');
        if (end >= 0)
            encoding = encoding.substring(0, end);
        encoding = encoding.trim();
        if ((encoding.length() > 2) && (encoding.startsWith("\""))
                && (encoding.endsWith("\"")))
            encoding = encoding.substring(1, encoding.length() - 1);
        return (encoding.trim());
    }

    private static Pattern metaPattern = Pattern.compile(
            "<meta\\s+([^>]*http-equiv=[\"\']?content-type[\"\']?[^>]*)>",
            Pattern.CASE_INSENSITIVE);

    private static Pattern charsetPattern = Pattern.compile(
            "charset=\\s*([a-z][_\\-0-9a-z]*)", Pattern.CASE_INSENSITIVE);

    /**
     * Get the character encoding from html content (using the first a couple
     * bytes in content). Typical number of range is 1000 bytes, but some
     * documents have meta tag well past the first 1000 bytes. (e.g.
     * http://cn.promo.yahoo.com/customcare/music.html)
     * 
     * @param content
     *            The bytes array of content
     * @param range
     *            The range of content used to read charset
     * @return The charset type
     */
    @SuppressWarnings("deprecation")
    public static String readEncodingFromContent(byte[] content, int range) {
        int length = content.length < range ? content.length : range;
        // We don't care about non-ASCII parts so that it's sufficient to just 
        // inflate each byte to a 16-bit value by padding. For instance, the 
        // sequence {0x41, 0x82, 0xb7} will be turned into {U+0041, U+0082, U+00B7}. 
        String str = new String(content, 0, 0, length);
        Matcher metaMatcher = metaPattern.matcher(str);
        String encoding = null;
        if (metaMatcher.find()) {
            Matcher charsetMatcher = charsetPattern.matcher(metaMatcher.group(1));
            if (charsetMatcher.find()) {
                encoding = new String(charsetMatcher.group(1));
            }
        }
        return encoding;
    }

    public static void main(String[] args) throws IOException {
        String filename = null;

        if (args.length < 1) {
            System.out.println("Usage: EncodingDetector [-n len ] filename");
            System.exit(1);
        }

        int len = 1000;

        for (int i = 0; i < args.length;) {
            String arg = args[i++];
            if (arg.startsWith("-")) {
                if (arg.equals("-n")) {
                    try {
                        arg = args[i++];
                        len = Integer.parseInt(arg);
                    } catch (NumberFormatException e) {
                        len = 1000;
                    }
                }
            } else {
                filename = arg;
            }
        }

        System.out.println("File: " + filename + ", max bytes to be examined: "
                + len + ". Encoding: "
                + EncodingDetector.detectEncoding(filename, len));
    }

}
