package toolbox.lang.utils;

import toolbox.lang.LanguageConsts;
import toolbox.lang.LanguageDetector;
import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * 中文语言检测工具
 * 
 * @author liq
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class ChineseUtils implements LanguageUtils {

    @Override
    public byte getLanguageType() {
        return LanguageConsts.LANG_SIMPLE_CHINESE;
    }

    @Override
    public boolean hit(CharSequence sentence, int[] counts, double[] other) {
        // 判断是否是中文
        int chinese = counts[LanguageDetector.CT_SIMPLE_CHINESE]
                + counts[LanguageDetector.CT_TRADITIONAL_CHINESE];
        double cn = (double) chinese
                / (double) counts[LanguageDetector.CT_EAST_ASIAN];
        if (cn > 0.8) {
            return true;
        }
        return false;
    }
}
