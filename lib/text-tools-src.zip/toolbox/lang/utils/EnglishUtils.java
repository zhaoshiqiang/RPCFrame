package toolbox.lang.utils;

import toolbox.lang.LanguageConsts;
import toolbox.lang.LanguageDetector;
import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * 英文语言检测工具
 * 
 * @author liq
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class EnglishUtils implements LanguageUtils {

    @Override
    public byte getLanguageType() {
        return LanguageConsts.LANG_ENG;
    }

    @Override
    public boolean hit(CharSequence sentence, int[] counts, double[] other) {
        //判断是否是英文
        double en = other[LanguageDetector.OTHER_WESTERN_WORD]
                / (other[LanguageDetector.OTHER_WESTERN_WORD] + other[LanguageDetector.OTHER_EAST_ASIAN_WORD]);
        if (en > 0.95) {
            double western = ((double) counts[LanguageDetector.CT_LATIN])
                    / counts[LanguageDetector.CT_WESTERN];
            if (western > 0.01) {
                return false;
            } else {
                return true;
            }
        }
        return false;
    }

}
