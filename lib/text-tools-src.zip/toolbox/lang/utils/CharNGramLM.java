package toolbox.lang.utils;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * 5元的字符语言模型，用于进行语言识别（不考虑大小写）
 * 
 * 语言模型存储在ARPA格式中，格式为(prob,bow均为概率的log值)
 * prob(c1, c2, ..., cn) gram(c1, c2, ..., cn) bow(c1, c2, ..., cn) 
 * 
 * 加载后语言模型用类似SRILM的方式存储在Trie树中。
 * 计算公式为：
 * prob(cn | c1, c2, ..., cn-1) = 
 * | count(c1, c2, ..., cn) > 0  prob(c1, c2, ..., cn)
 * | else                        bow(c1, c2, ..., cn-1) + prob(c2, ..., cn)
 * 
 * @author qipeng
 *
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class CharNGramLM {
    
    /**
     * 空格字符
     */
    private static final char SPACE = 0;
    
    /**
     * 未登录字符
     */
    private static final char UNK = 1;
    
    /**
     * 当前语言模型对应的语言类型
     */
    private byte langId;
    
    /**
     * 语言模型阶数
     */
    private int order;
    
    /**
     * 语言模型字符字典，将字符映射成1-n的序列
     */
    private Map<Character, Character> dict;

    /**
     * 存储语言模型的Trie数
     */
    private TrieTree<ProbValue> lmTree = new TrieTree<ProbValue>();
 
    /**
     * Constructor
     * @param langId
     */
    public CharNGramLM(byte langId) {
        this.langId = langId;
    }
    
    /**
     * @return the langId
     */
    public byte getLangId() {
        return langId;
    }

    /**
     * @return the order
     */
    public int getOrder() {
        return order;
    }
    
    /**
     * set the order
     * @param order
     */
    public void setOrder(int order) {
        this.order = order;
    }
    
    /**
     * 计算一段文本的在该语言模型下的概率
     * 
     * @param text
     * @return
     */
    public double getLogProb(CharSequence text) {
        return getLogProb(text, 0, text.length());
    }
    /*
    private Map<String, Double> gramCache = new HashMap<String, Double>();
    */
    private StringBuffer idBuffer =  new StringBuffer();
    
    /**
     * 对输入的文本做预处理，以空格为单位，过滤掉不含有任何字母的token，主要是避免短文本
     * 计算时数字的影响。
     * @param text
     * @param offset
     * @param len
     * @param textBuffer
     */
    public static void preProcess(CharSequence text, int offset, int len, 
            StringBuffer textBuffer) {
        textBuffer.setLength(0);
        int lastSpIndex = 1;
        // 在字符串前后添加空格，过滤掉不含任何字符的token
        textBuffer.append(' ');
        boolean ignore = true;
        for (int i = offset ; i < len; i++) {
            if (Character.isWhitespace(text.charAt(i))) {
                if (ignore) {
                    textBuffer.setLength(lastSpIndex);
                } else {
                    textBuffer.append(' ');
                    lastSpIndex = textBuffer.length();
                }
                ignore = true;
            } else {
                // char -> id
                textBuffer.append(text.charAt(i));
            }
            if (Character.isLetter(text.charAt(i))) {
                ignore = false;
            }
        }
        if (ignore) {
            textBuffer.setLength(lastSpIndex);
        }
        if (textBuffer.charAt(textBuffer.length() - 1) != ' ') {
            textBuffer.append(' ');
        }
        if (textBuffer.length() == 2) {
            textBuffer.setLength(0);
        }
    }
    
    /**
     * 计算一段文本在该语言模型下的概率
     * 首先对输入的文本做预处理
     * 然后计算语言模型的概率
     * @param text
     * @param offset
     * @param len
     * @return
     */
    public double getLogProb(CharSequence text, int offset, int len) {
        idBuffer.setLength(0);
        for (int i = offset; i < len; i++) {
            idBuffer.append(charToid(text.charAt(i)));
        }
        return getLogProb(idBuffer);
    }
    
    /**
     * 计算一段字符串的ngram概率
     * 
     * @param idBuffer
     * @return
     */
    private double getLogProb(StringBuffer idBuffer) {
        if (idBuffer.length() == 0) {
            return 0;
        }
        double total = 0.0;
        for (int i = idBuffer.length() - 1; i >= 0; i--) {
            /*if (gramCache.containsKey(ngramBuffer.toString())) {
                total += gramCache.get(ngramBuffer.toString());
                continue;
            }*/
            // 逆序遍历字符序列，gram(wn, wn-1, ...,w2, w1)
            double prob = 0.0;
            double bow = 0.0;
            int k = 1;
            TrieTree<ProbValue> node = lmTree;
            boolean toContinue = true;
            // 沿着wn-1,...w2,w1路径检索
            while (toContinue) {
                // 检查wn是否在当前节点中，是则设置概率为prob
                ProbValue value = node.getValue();
                if (value != null) {
                    double tmp = value.getProb(idBuffer.charAt(i));
                    if (tmp < 0.0) {
                        bow = 0.0;
                        prob = tmp;
                    }
                }
                // 检索完毕，退出
                if (k == order || i - k < 0) {
                    break;
                }
                // 记录当前的bow
                node = node.getChild(idBuffer.charAt(i - k));
                if (node == null || node.value == null) {
                    toContinue = false;
                    break;
                }
                bow = node.value.getBow();
                k++;
            }
            /*if (gramCache.size() < 200000) {
                gramCache.put(ngramBuffer.toString(), prob + bow);
            }*/
            total += (prob + bow);
        }
        return total;
    }
    
    /**
     * 加载指定路径的ngram语言模型，语言模型的格式是ARPA格式。
     * 1) 存在bow的ngram，将<ngram(c1, c2,...cn), bow(c1, c2,...,cn)>存入Trie树中
     * 2) 一元gram, 将<ngram(c1), prob(c1)>存入Trie树的根节点中
     * 3) 大于一元的gram, 将<ngram(cn-1, ..., c1), prob(c1, c2,...,cn)>存入树中
     * 
     * @param path
     */
    public void loadLM(String path) throws Exception {
        InputStream in = 
            CharNGramLM.class.getResourceAsStream(path);
        BufferedReader reader = new BufferedReader(new InputStreamReader(in));
        String line = null;
        Pattern pat = Pattern.compile("ngram\\s*(\\d+)=\\s*(\\d+)");
        List<Integer> counts = new ArrayList<Integer>();
        while ((line = reader.readLine()) != null) {
            line = line.trim();
            if (line.length() == 0 || line.contains("\\data\\")) {
                continue;
            }
            Matcher m = pat.matcher(line);
            if (!m.matches()) {
                break;
            }
            counts.add(Integer.parseInt(m.group(2)));
        }
        order = counts.size();
        int index = 0;
        char id = 0;
        ProbValue gram1 = new ProbValue();
        dict = new HashMap<Character, Character>(counts.get(0));
        StringBuffer ngramBuffer = new StringBuffer();
        for( ; line != null; line = reader.readLine()) {
            ngramBuffer.setLength(0);
            if (line.trim().length() == 0) {
                continue;
            }
            if (line.contains("-grams")) {
                index++;
                continue;
            }
            if (line.contains("\\end")) {
                break;
            }
            String[] items = line.split("\\s+");
            if (index == 1) {
                if (items.length < 2) {
                    return;
                }
                if (items[1].equals("<s>")) {
                    dict.put(SPACE, id);
                } else if (items[1].equals("<unk>")) {
                    dict.put(UNK, id);
                } else {
                    dict.put(items[1].charAt(0), id);
                }
                gram1.setProb(id, Double.parseDouble(items[0]));
                if (items.length == 3) {
                    ProbValue probValue = new ProbValue();
                    probValue.setBow(Double.parseDouble(items[2]));
                    ngramBuffer.append(id);
                    lmTree.put(ngramBuffer, probValue);
                }
                id++;
            } else {
                for (int i = 1; i < index + 1; i++) {
                    ngramBuffer.append(charToid(items[i]));
                }
                reverse(ngramBuffer);
                if (items.length > index + 1) {
                    ProbValue probValue = new ProbValue();
                    probValue.setBow(Double.parseDouble(items[index + 1]));
                    lmTree.put(ngramBuffer, probValue);
                }
                ngramBuffer.deleteCharAt(0);
                ProbValue probValue = lmTree.get(ngramBuffer);
                if (probValue == null) {
                    probValue = new ProbValue();
                }
                probValue.setProb(charToid(items[index]), 
                        Double.parseDouble(items[0]));
                lmTree.put(ngramBuffer, probValue);
            }
        }
        lmTree.setValue(gram1);
    }
    
    /**
     * 逆序当前字符串
     * @param sb
     */
    private void reverse(StringBuffer sb) {
        for (int i = 0; i < sb.length() / 2; i++) {
            char ch = sb.charAt(i);
            sb.setCharAt(i, sb.charAt(sb.length() - 1 - i));
            sb.setCharAt(sb.length() - 1 - i, ch);
        }
    }
    
    /**
     * 将字符转换为id
     * @param str
     * @return
     */
    private char charToid(String str) {
        if (str.equals("<s>")) {
            return dict.get(SPACE);
        } else if (str.equals("<unk>")) {
            return dict.get(UNK);
        } else {
            return dict.get(str.charAt(0));
        }
    }
    
    /**
     * 将字符转换为id
     * @param ch
     * @return
     */
    private char charToid(char ch) {
        ch = Character.toLowerCase(ch);
        if (ch == ' ') {
            return dict.get(SPACE);
        } else if (dict.containsKey(ch)) {
            return dict.get(ch);
        } 
        return dict.get(UNK);
    }
    
    /**
     * 存储语言模型概率和折扣概率数据结构
     *
     * @author qipeng
     *
     */
    private static class ProbValue {
        
        /**
         * 概率模型的折扣值
         */
        private double bow;
        
        /**
         * 存储概率模型的数据
         */
        private double[] probs;
        
        private char offset = 0;
        
        /**
         * Constructor
         */
        public ProbValue() {
        }

        /**
         * @return the bow
         */
        public double getBow() {
            return bow;
        }

        /**
         * @param bow the bow to set
         */
        public void setBow(double bow) {
            this.bow = bow;
        }

        /**
         * @return the probs
         */
        public double getProb(char index) {
            if (probs == null || index < offset 
                    || index >= probs.length + offset) {
                return 0.0;
            }
            return probs[index - offset];
        }
        
        /**
         * @param probs the probs to set
         */
        public void setProb(char index, double prob) {
            if (probs == null) {
                probs = new double[index + 1];
                offset = index;
            }
            if (index >= (probs.length + offset)) {
                double[] tmp = new double[index + 1 - offset];
                System.arraycopy(probs, 0, tmp, 0, probs.length);
                probs = tmp;
            } else if (index < offset) {
                double[] tmp = new double[offset - index + probs.length];
                System.arraycopy(probs, 0, tmp, offset - index, probs.length);
                probs = tmp;
                offset = index;
            }
            this.probs[index - offset] = prob;
        }
        
    }

    /**
     * 存储ngram信息的Trie树
     *
     * @author qipeng
     *
     * @param <T>
     */
    private static class TrieTree<T> {
        
        /**
         * 当前节点对应的值
         */
        private T value;
        
        /**
         * 孩子节点
         */
        private Map<Character, TrieTree<T>> childsMap;

        /**
         * Constructor
         */
        public TrieTree() {
        }
        
        /**
         * value setter
         * @param value
         */
        public void setValue(T value) {
            this.value = value;
        }
        
        /**
         * value getter
         * @return
         */
        public T getValue() {
            return value;
        }
        
        /**
         * 查询当前节点的孩子节点
         * @param ch
         * @return
         */
        public TrieTree<T> getChild(char ch) {
            if (childsMap == null) {
                return null;
            }
            return childsMap.get(ch);
        }
        
        /**
         * 添加字符串到当前trie树中
         * @param key
         * @param value
         */
        public void put(CharSequence key, T value) {
            put(key, 0, key.length(), value);
        }
        
        /**
         * 添加字符串到当前trie树中
         * @param key
         * @param offset
         * @param end
         * @param value
         */
        public void put(CharSequence key, int offset, int end, T value) {
            if (key == null || offset > end || end <= 0) {
                return;
            }
            if (value == null) {
                return;
            }
            
            if (offset == end) {
                this.value = value;
                return;
            }
            char ch = key.charAt(offset);
            if (childsMap == null) {
                childsMap = new HashMap<Character, TrieTree<T>>(4, 1.0f);
            }
            TrieTree<T> child = childsMap.get(ch);
            if (child == null) {
                child = new TrieTree<T>();
            }
            child.put(key, offset + 1, end, value);
            childsMap.put(ch, child);
        }
        
        /**
         * 查找指定关键字的指
         * @param key
         * @return
         */
        public T get(CharSequence key) {
            return get(key, 0, key.length());
        }
        
        /**
         * 查找指定关键字的指
         * @param key
         * @param offset
         * @param end
         * @return
         */
        public T get(CharSequence key, int offset, int end) {
            if (key == null || offset > end) {
                return null;
            }
            if (offset == end) {
                return value;
            }
            char ch = key.charAt(offset);
            if (childsMap == null) {
                return null;
            }
            TrieTree<T> child = childsMap.get(ch);
            if (child == null) {
                return null;
            } 
            return child.get(key, offset + 1, end);
        }
    }
}


