/**
 * @(#)IndoEuropClassifier.java, 2011-3-23. 
 * 
 * Copyright 2011 Youdao, Inc. All rights reserved.
 * YOUDAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.lang.utils;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import toolbox.lang.LanguageConsts;
import toolbox.lang.LanguageDetector;
import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 *
 * 拉丁字母相关的语种识别工具，目前支持英语，法语，德语，西班牙语的识别。无法识别对于其他欧洲
 * 语言，可能会被误判到以上某种语言中去。
 * 
 * 基于字符的NGram模型识别，建议检测的文本字符长度在20个字母以上。
 * 
 * 默认只检测英语和法语。如果要检测西班牙语和德语需要显示的注册。
 * 
 * @author qipeng
 *
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class IndoEuropLangIder implements LanguageUtils {

    private static Map<Byte, CharNGramLM> LM_MODELS 
        = new HashMap<Byte, CharNGramLM>();
    
    private Map<Byte, Double> scores 
        = new HashMap<Byte, Double>();
    
    private Set<Byte> detectLangs = new HashSet<Byte>();

    private static void loadModel(byte langId) {
        if (LM_MODELS.containsKey(langId)) {
            return;
        }
        CharNGramLM lmModel = new CharNGramLM(langId);
        if (langId == LanguageConsts.LANG_ENG) {
            try {
                lmModel.loadLM("en.plm");
            } catch (Exception ex) {
                throw new RuntimeException("Error in loading model: " + langId);
            }
        } else if (langId == LanguageConsts.LANG_FR) {
            try {
                lmModel.loadLM("fr.plm");
            } catch (Exception ex) {
                throw new RuntimeException("Error in loading model: " + langId);
            }
        } else if (langId == LanguageConsts.LANG_GE) {
            try {
                lmModel.loadLM("ge.plm");
            } catch (Exception ex) {
                throw new RuntimeException("Error in loading model: " + langId);
            }
        } else if (langId == LanguageConsts.LANG_SP) {
            try {
                lmModel.loadLM("sp.plm");
            } catch (Exception ex) {
                throw new RuntimeException("Error in loading model: " + langId);
            }
        } else {
            throw new RuntimeException("Unspport this language: " + langId);
        }
        LM_MODELS.put(langId, lmModel);
    }
    
    /**
     * 添加是否检测某种语言
     * @param langId
     */
    public void register(byte langId) {
        if (!LM_MODELS.containsKey(langId)) {
            loadModel(langId);
        }
        detectLangs.add(langId);
    }
    
    /**
     * 取消检测某种语言
     * @param langId
     */
    public void unregister(byte langId) {
        detectLangs.remove(langId);
    }
    
    public IndoEuropLangIder() {
        register(LanguageConsts.LANG_ENG);
        register(LanguageConsts.LANG_FR);
    }
    
    private byte langType = LanguageConsts.LANG_ENG;
    
    @Override
    public byte getLanguageType() {
        return langType;
    }
    
    /**
     * Clear the context
     */
    public void clear() {
        scores.clear();
    }
    
    /**
     * Update the Indo-Europe language gram score
     * @param sentence sentence the sentence of text to language identifier
     */
    public void update(CharSequence sentence) {
        for (Byte lang : detectLangs) {
            CharNGramLM lm = LM_MODELS.get(lang);
            double score = lm.getLogProb(sentence, 0, sentence.length());
            if (!scores.containsKey(lang)) {
                scores.put(lang, score);
            } else {
                scores.put(lang, score + scores.get(lang));
            }
        }
    }
    
    private StringBuffer textBuffer =  new StringBuffer();
    
    /**
     * Update the Indo-Europe language gram score
     * @param sentence the sentence of text to language identifier
     * @param offset the offset of char to update
     * @param end the length of the sentence
     * @param counts the counts
     */
    public void update(CharSequence sentence, int offset, int end, 
            int[] counts) {
        if (counts[LanguageDetector.CT_INEU_LATIN]
            + counts[LanguageDetector.CT_ASCII] == 0) {
            return;
        }
        textBuffer.setLength(0);
        CharNGramLM.preProcess(sentence, offset, end, textBuffer);
        for (Byte lang : detectLangs) {
            CharNGramLM lm = LM_MODELS.get(lang);
            double score = lm.getLogProb(textBuffer, 0, textBuffer.length());
            if (!scores.containsKey(lang)) {
                scores.put(lang, score);
            } else {
                scores.put(lang, score + scores.get(lang));
            }
        }
    }
    
    @Override
    public boolean hit(CharSequence sentence, int[] counts, double[] other) {
        if (counts[LanguageDetector.CT_NONWHITESPACE] == 0) {
            return false;
        }
        double all = other[LanguageDetector.OTHER_WESTERN_WORD] + 
            other[LanguageDetector.OTHER_EAST_ASIAN_WORD]; 
        if (all == 0) {
           return false; 
        }
        double western = other[LanguageDetector.OTHER_WESTERN_WORD] / all;
        double indoEnropu = (counts[LanguageDetector.CT_INEU_LATIN]
            + counts[LanguageDetector.CT_ASCII] +  
            + counts[LanguageDetector.CT_NUMBER])  
                / (double)counts[LanguageDetector.CT_NONWHITESPACE];
        // 判断拉丁字符占的比例
        if (western < 0.95 || indoEnropu < 0.5) {
            return false;
        }
        
        double max = -Double.MAX_VALUE;
        for (Byte langId : scores.keySet()) {
            if (scores.get(langId) > max) {
                max = scores.get(langId);
                langType = langId;
            }
        }
        return true;
    }
    
    /**
     * 西，法，德语中的拉丁字符
     */
    private static final char[][] INDO_EUROP_LATINS = {
        {0x0084, 0x0084},
        {0x009F, 0x009F},
        {0x00A1, 0x00A1},
        {0x00BF, 0x00BF},
        {0x00C0, 0x00C2},
        {0x00C4, 0x00C4},
        {0x00C7, 0x00CB},
        {0x00CD, 0x00CF},
        
        {0x00D1, 0x00D1},
        {0x00D3, 0x00D4},
        {0x00D6, 0x00D6},
        {0x00D9, 0x00D9},
        {0x00DA, 0x00DC},
        {0x00DF, 0x00DF},
        
        {0x00E0, 0x00E2},
        {0x00E4, 0x00E4},
        {0x00E7, 0x00EB},
        {0x00ED, 0x00EF},
        
        {0x00F1, 0x00F1},
        {0x00F3, 0x00F4},
        {0x00F6, 0x00F6},
        {0x00F9, 0x00F9},
        {0x00FA, 0x00FC},
        {0x00FF, 0x00FF},
        {0x0152, 0x0152},
        {0x0153, 0x0153},
        {0x0178, 0x0178},
    };
    
    /**
     * 法语中的拉丁字符
     */
    private static final char[][] FR_LATINS = {
        {0x009F, 0x009F},
        {0x00C0, 0x00C0},
        {0x00C2, 0x00C2},
        {0x00C7, 0x00CB},
        {0x00CE, 0x00CF},
        
        {0x00D4, 0x00D4},
        {0x00D9, 0x00D9},
        {0x00DB, 0x00DC},
        
        {0x00E0, 0x00E0},
        {0x00E2, 0x00E2},
        {0x00E7, 0x00EB},
        {0x00EE, 0x00EF},
        
        {0x00F4, 0x00F4},
        {0x00F9, 0x00F9},
        {0x00FB, 0x00FC},
        {0x00FF, 0x00FF},
        {0x0152, 0x0152},
        {0x0153, 0x0153},
        {0x0178, 0x0178},
    };
    
    /**
     * 西班牙语中的拉丁字符
     */
    private static final char[][] SP_LATINS = {
        {0x00A1, 0x00A1},
        {0x00BF, 0x00BF},
        {0x00C1, 0x00C1},
        {0x00C9, 0x00C9},
        {0x00CD, 0x00CD},
        {0x00D1, 0x00D1},
        {0x00D3, 0x00D3},
        {0x00DA, 0x00DA},
        {0x00DC, 0x00DC},
        {0x00E1, 0x00E1},
        {0x00E9, 0x00E9},
        {0x00ED, 0x00ED},
        {0x00F1, 0x00F1},
        {0x00F3, 0x00F3},
        {0x00FA, 0x00FA},
        {0x00FC, 0x00FC},
    };
    
    /**
     * 德语中的拉丁字符
     */
    private static final char[][] GE_LATINS = {
        {0x0084, 0x0084},
        {0x00C4, 0x00C4},
        {0x00D6, 0x00D6},
        {0x00DC, 0x00DC},
        {0x00DF, 0x00DF},
        {0x00E4, 0x00E4},
        {0x00F6, 0x00F6},
        {0x00FC, 0x00FC},
    };
    
    /**
     * 判断是不是可以检测印欧语字母，目前包括法语，英语，西班牙语，德语
     * @param c
     * @return
     */
    public static boolean isIndoEurpoLatin(char c) {
        return binarySearch(INDO_EUROP_LATINS, c);
    }
    
    /**
     * 判断是否是法语拉丁
     * @param c
     * @return
     */
    public static boolean isFrenchLatin(char c) {
        return binarySearch(FR_LATINS, c);
    }
    
    /**
     *  判断是否是西班牙语拉丁
     *  Á É Í Ñ Ó Ú Ü
     *  á é í ñ ó ú ü
     *  ¿ ¡
     */
    public static boolean isSpanishLatin(char c) {
        return binarySearch(SP_LATINS, c);
    }
    
    /**
     * 判断是否是德语拉丁
     * Ä Ö Ü ß
     * ä ö ü
     * @param c
     * @return
     */
    public static boolean isGermanLatin(char c) {
        return binarySearch(GE_LATINS, c);
    }
    
    private static boolean binarySearch(char[][] a, char key) {
        int low = 0;
        int high = a.length - 1;

        while (low <= high) {
            int mid = (low + high) >>> 1;

            if (key > a[mid][1]) {
                low = mid + 1;
            } else if (key < a[mid][0]) {
                high = mid - 1;
            } else {
                return true; // key found
            }
        }
        return false;
    }
}
