/**
 * @(#)RussianUtils.java, 2011-3-16. 
 * 
 * Copyright 2011 Youdao, Inc. All rights reserved.
 * YOUDAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.lang.utils;

import toolbox.lang.LanguageConsts;
import toolbox.lang.LanguageDetector;
import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * 俄语检测工具
 * 
 * @author qipeng
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class RussianUtils implements LanguageUtils {

    @Override
    public byte getLanguageType() {
        return LanguageConsts.LANG_RU;
    }

    @Override
    public boolean hit(CharSequence sentence, int[] counts, double[] scores) {
        if (counts[LanguageDetector.CT_WESTERN] == 0) {
            return false;
        }
        if (counts[LanguageDetector.CT_EAST_ASIAN] != 0 
                && (double)counts[LanguageDetector.CT_RUSSIAN] 
                          / counts[LanguageDetector.CT_EAST_ASIAN] < 0.7) {
            return false;
        }
        //判断是否是俄文
        double ru = ((double) counts[LanguageDetector.CT_RUSSIAN])
                / counts[LanguageDetector.CT_WESTERN];
        if (ru > 0.7) {
            return true;
        }
        return false;
    }

}
