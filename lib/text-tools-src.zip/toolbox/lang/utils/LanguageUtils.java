package toolbox.lang.utils;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * 文本语言检测工具接口类.
 * 
 * @author liq
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public interface LanguageUtils {
    /**
     *得到当前实现的语言类型
     */
    public byte getLanguageType();

    /**
     *判断sentence是否是当前实现的语言类型 若是则返回true
     * 
     * @param sentence
     *            判断的句子
     * @param counts
     *            统计字符数的结果，参考LanguageDetector的counts
     * @param other
     *            其他辅助的统计，参考LanguageDetector的other
     * @return
     */
    public boolean hit(CharSequence sentence, int[] counts, double[] other);
}