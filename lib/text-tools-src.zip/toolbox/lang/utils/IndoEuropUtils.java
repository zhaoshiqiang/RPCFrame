package toolbox.lang.utils;

import toolbox.lang.LanguageConsts;
import toolbox.lang.LanguageDetector;
import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * 基于字符比例的其他欧洲语言（非法语，英语）检测工具，用于快速的判断，只检测西班牙，德语字符
 * 
 * @author qipeng
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class IndoEuropUtils implements LanguageUtils {

    @Override
    public byte getLanguageType() {
        return LanguageConsts.LANG_OTHER_EURO;
    }

    @Override
    public boolean hit(CharSequence sentence, int[] counts, double[] other) {
        //判断是否是英文
        double west = other[LanguageDetector.OTHER_WESTERN_WORD]
                / (other[LanguageDetector.OTHER_WESTERN_WORD] 
                         + other[LanguageDetector.OTHER_EAST_ASIAN_WORD]);
        if (west > 0.95) {
            double euro = ( counts[LanguageDetector.CT_INEU_LATIN] 
                                           + counts[LanguageDetector.CT_ASCII])
                / (double)counts[LanguageDetector.CT_WESTERN];
            if (euro > 0.9) {
                return true;
            }
        }
        return false;
    }

}
