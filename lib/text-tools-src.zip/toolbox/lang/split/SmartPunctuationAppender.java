/**
 * @(#)SmartPunctuationAppender.java, 2011-8-29. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.lang.split;

import java.util.HashSet;
import java.util.Set;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * @author chengang
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class SmartPunctuationAppender {
    
    private static final int EN_SHORT_LENGTH = 4;
    private static final int CN_SHORT_LENGTH = 6;
    private static Set<String> asks = new HashSet<String>();
    private static Set<String> WHAsks = new HashSet<String>();
    private static Set<String> YesOrNoAsks = new HashSet<String>();

    static {
        WHAsks.add("what");
        WHAsks.add("when");
        WHAsks.add("where");
        WHAsks.add("who");
        WHAsks.add("whose");
        WHAsks.add("why");
        WHAsks.add("which");
        YesOrNoAsks.add("would");
        YesOrNoAsks.add("should");
        YesOrNoAsks.add("will");
        YesOrNoAsks.add("could");
        YesOrNoAsks.add("can");
        YesOrNoAsks.add("may");
        YesOrNoAsks.add("must");
        YesOrNoAsks.add("how");
        YesOrNoAsks.add("is");
        YesOrNoAsks.add("am");
        YesOrNoAsks.add("are");
        YesOrNoAsks.add("was");
        YesOrNoAsks.add("were");
        YesOrNoAsks.add("does");
        YesOrNoAsks.add("do");
        YesOrNoAsks.add("did");
        YesOrNoAsks.add("hava");
        YesOrNoAsks.add("has");
        YesOrNoAsks.add("had");
        
        asks.addAll(WHAsks);
        asks.addAll(YesOrNoAsks);
    }
    
    /**
     * 
     * @param sb 句子
     * @param wordNum 句中单词个数
     * @return 是否添加成功
     */
    public static boolean appendEnglishPunctuation (StringBuilder sb, int wordNum) {
        // 与smtback对短查询的定义一致，短查询不加标点
        if (sb == null || wordNum <= EN_SHORT_LENGTH) {
            return false;
        }
        //add by wuxm
        String  str [] =  sb.toString().split("\\s+");
        String firstWord = str[0].toLowerCase();
        String secondWord = "";
        String lastWord = str[str.length - 1].toLowerCase();
        if (str.length > 1) {
            secondWord = str[1].toLowerCase();
        }
         if (asks.contains(firstWord)) {
            if (firstWord.equals("how")) {
                if (lastWord.equals("is") || lastWord.equals("are")) {
                    // 是感叹句
                    sb.append("!");
                } else if (wordNum <= 2) {
                    // 是感叹句
                    sb.append("!");
                } else {
                    // 是问句
                    sb.append("?");
                }
            } else if (firstWord.equals("what")) {
                if (YesOrNoAsks.contains(secondWord)) {
                    // 是问句
                    sb.append("?");
                } else {
                    // 是感叹句
                    sb.append("!");
                }
            } else if (firstWord.equals("when")) {
                if (YesOrNoAsks.contains(secondWord)) {
                    //是问句
                    sb.append("?");
                } else {
                    //时间状语从句
                    sb.append(".");
                }
            } else {
                // 是问句
                sb.append("?");
            }
        } else {
            // FIXME:暂时增加一个句号
            sb.append('.');
        }
        return true;
    }
    
    /**
     * 
     * @param sb 句子
     * @param characterNum 句中汉字个数
     * @return 是否添加成功
     */
    public static boolean appendChinesePunctuation (StringBuilder sb) {
        // 与smtback对短查询的定义一致，短查询不加标点
        if (sb == null || sb.length() <= CN_SHORT_LENGTH) {
            return false;
        }
        if (isChineseQuestion(sb)) {
            sb.append("？");
        } else {
            sb.append("。");
        }
        return true;
    }
    
    /**
     * 是否是中文问句
     *
     * @param sb 待测试句子
     * @return true 问句，否则返回false
     */
    protected static boolean isChineseQuestion(StringBuilder sb) {
        if (sb.indexOf("什么") >= 0 || sb.indexOf("怎么") >= 0
                || sb.indexOf("为何") >= 0 || sb.indexOf("如何") >= 0
                || sb.indexOf("怎样") >= 0 || sb.indexOf("哪儿") >= 0
                || sb.indexOf("哪里") >= 0 || sb.indexOf("哪个地方") >= 0
                || sb.indexOf("哪有") >= 0 || sb.indexOf("在哪") >= 0) {
            return true;
        }

        if (sb.charAt(sb.length() - 1) == '吗') {
            return true;
        }

        return false;
    }

}
