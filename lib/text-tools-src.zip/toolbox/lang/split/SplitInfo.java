/**
 * @(#)SplitInfo.java, 2008-6-4. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.lang.split;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/** 
 * 保存分句信息
 *
 * @author sxy, dingyelei
 *
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class SplitInfo implements Iterable<String> {
    private static final int CACHE_NUM = 10;

    /** 分句数据 */
    private List<String> sentences = new ArrayList<String>(CACHE_NUM);

    /** 是否附加标点符号数据 */
    private List<Boolean> appendPunctuations = 
        new ArrayList<Boolean>(CACHE_NUM);

    /** 段落位置 */
    private int[] paragraphFlag = new int[CACHE_NUM];

    private int curParagraph = -1;

    private int realSplitNum = -1;

    private SplitInfo() {

    }

    /** 初始化 */
    public void init() {
        sentences.clear();
        appendPunctuations.clear();
        curParagraph = -1;
        realSplitNum = -1;
    }

    /** 分段数 */
    public int getParagraphNum() {
        return curParagraph + 1;
    }

    /** 总分句数 */
    public int getSentenceNum() {
        return sentences.size();
    }

    /** 得到指定句子 */
    public String getSentence(int index) {
        return sentences.get(index);
    }

    /** 得到所有句子 */
    public List<String> getSentences() {
        return sentences;
    }

    /** 得到指定句子的原始信息 */
    public String getOriginalSentence(int index) {
        String s = getSentence(index);
        if (getAppendPunctuationFlag(index)) {
            return s.substring(0, s.length() - 1);
        }
        return s;
    }

    /**
     * 得到指定句子是否末尾包含标点
     * @param index 句子索引
     * @return
     */
    public boolean getAppendPunctuationFlag(int index) {
        return appendPunctuations.get(index);
    }

    /** 增加一个句子 */
    public void addSentence(String sentence, boolean appendPunctuation) {
        sentences.add(sentence);
        appendPunctuations.add(appendPunctuation);
    }

    /** 增加一个分段标志 */
    public void addParagraphFlag() {
        int curSentencePos = sentences.size();
        ++curParagraph;

        if (curParagraph >= paragraphFlag.length) {
            int[] temp = new int[paragraphFlag.length + CACHE_NUM];
            System.arraycopy(paragraphFlag, 0, temp, 0, paragraphFlag.length);

            paragraphFlag = temp;
        }

        paragraphFlag[curParagraph] = curSentencePos;
    }

    /** 得到指定分段位置 */
    public int getParagraphPos(int paragraph) throws IndexOutOfBoundsException {
        if (paragraph < 0 || paragraph > curParagraph) {
            throw new IndexOutOfBoundsException();
        } else {
            return paragraphFlag[paragraph];
        }
    }

    /** 重用对象池 */
    private static BlockingQueue<SplitInfo> pool = null;

    private static final int POOL_SIZE = 1024;

    static {
        pool = new LinkedBlockingQueue<SplitInfo>(POOL_SIZE);
        for (int i = 0; i < POOL_SIZE; ++i) {
            pool.add(new SplitInfo());
        }
    }

    /**
     * 从SplitInfo对象池中获取一个SplitInfo对象，
     * 若对象池为空，则重新分配一个新的SplitInfo的对象，并对其进行初始化
     * 
     * @return SplitInfo对象
     */
    public static SplitInfo take() {
        synchronized (SplitInfo.class) {
            SplitInfo info = null;

            info = pool.poll();

            if (info == null) {
                info = new SplitInfo();
            }

            info.init();

            return info;
        }
    }

    /**
     * 将SplitInfo对象放入SplitInfo对象池
     * 
     * @param info 待放入SplitInfo对象池的SplitInfo对象
     */
    public static void put(SplitInfo info) {
        synchronized (SplitInfo.class) {
            if (info != null && pool.size() < POOL_SIZE) {
                if (info.paragraphFlag.length > CACHE_NUM) {
                    //将buffer大小变回来
                    info.paragraphFlag = new int[CACHE_NUM];
                }

                pool.add(info);
            }
        }
    }

    /** (non-Javadoc)
     * @see java.lang.Iterable#iterator()
     */
    public Iterator<String> iterator() {
        return new Iterator<String>() {
            private int cur = 0;
            public boolean hasNext() {
                return cur < sentences.size();
            }

            public String next() {
                if (hasNext()) {
                    return sentences.get(cur++);
                } else {
                    throw new IndexOutOfBoundsException();
                }
            }

            public void remove() {
                throw new NoSuchMethodError();
            }
        };
    }

    /**
     * 获得句子总数
     * 
     * @return 句子总数
     */
    public int size() {
        return sentences.size();
    }

    /**
     * 获得实际分句的个数
     * 
     * @return 实际分句的个数
     */
    public int getRealSplitNum() {
        if (realSplitNum > 0) {
            return realSplitNum;
        } else {
            return sentences.size();
        }
    }

    /**
     * 记录停止分句的位置
     */
    public void stopSplitSentence() {
        if (realSplitNum < 0) {
            realSplitNum = sentences.size();
        }
    }
}
