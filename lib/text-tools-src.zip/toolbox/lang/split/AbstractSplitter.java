/**
 * @(#)AbstractSplitter.java, 2008-6-17. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.lang.split;

import java.util.HashSet;
import java.util.Set;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * 抽象分句类，包含基本分隔符信息，供具体分句类(例如英语分句类/中文分句类)继承
 * 
 * @author sxy
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class AbstractSplitter {
    /** 顿号 */
    protected static final Set<Character> SPLITS = new HashSet<Character>();

    static {
        SPLITS.add('、');
        SPLITS.add('丶');
        SPLITS.add('﹑');
    }

    /** 左括号集合 */
    protected static final Set<Character> LEFT_BRACKET_SET = 
        new HashSet<Character>();

    /** 右括号集合 */
    protected static final Set<Character> RIGHT_BRACKET_SET = 
        new HashSet<Character>();

    /** 左书名号 */
    protected static final Set<Character> LEFT_BOOK_SET = new HashSet<Character>();

    /** 右书名号 */
    protected static final Set<Character> RIGHT_BOOK_SET = 
        new HashSet<Character>();

    /** 二元标点符号的左半边 */
    protected static final Set<Character> LEFT_P = new HashSet<Character>();

    /** 二元标点符号的右半边 */
    protected static final Set<Character> RIGHT_P = new HashSet<Character>();

    static {
        //小括号
        LEFT_BRACKET_SET.add('(');
        LEFT_BRACKET_SET.add('（');

        //中括号
        LEFT_BRACKET_SET.add('[');
        LEFT_BRACKET_SET.add('【');
        LEFT_BRACKET_SET.add('［');
        LEFT_BRACKET_SET.add('〖');
        LEFT_BRACKET_SET.add('「');
        LEFT_BRACKET_SET.add('『');

        //大括号
        LEFT_BRACKET_SET.add('{');
        LEFT_BRACKET_SET.add('｛');

        LEFT_P.addAll(LEFT_BRACKET_SET);

        //双引号
        LEFT_P.add('"');
        LEFT_P.add('“');
        LEFT_P.add('＂');
        LEFT_P.add('”');
        LEFT_P.add('〃');

        //单引号
        LEFT_P.add('\'');
        LEFT_P.add('‘');
        LEFT_P.add('’');
        LEFT_P.add('｀');
        LEFT_P.add('＇');

        //单书名号
        LEFT_BOOK_SET.add('<');
        LEFT_BOOK_SET.add('＜');
        LEFT_BOOK_SET.add('〈');

        //双书名号
        LEFT_BOOK_SET.add('《');
        LEFT_P.addAll(LEFT_BOOK_SET);

        ////////////////

        //小括号
        RIGHT_BRACKET_SET.add(')');
        RIGHT_BRACKET_SET.add('）');

        //中括号
        RIGHT_BRACKET_SET.add(']');
        RIGHT_BRACKET_SET.add('】');
        RIGHT_BRACKET_SET.add('］');
        RIGHT_BRACKET_SET.add('〗');
        RIGHT_BRACKET_SET.add('」');
        RIGHT_BRACKET_SET.add('』');

        //大括号
        RIGHT_BRACKET_SET.add('}');
        RIGHT_BRACKET_SET.add('｝');

        RIGHT_P.addAll(RIGHT_BRACKET_SET);

        //双引号
        RIGHT_P.add('"');
        RIGHT_P.add('“');
        RIGHT_P.add('＂');
        RIGHT_P.add('”');
        RIGHT_P.add('〃');

        //单引号
        RIGHT_P.add('\'');
        RIGHT_P.add('‘');
        RIGHT_P.add('’');
        RIGHT_P.add('｀');
        RIGHT_P.add('＇');

        //单书名号
        RIGHT_BOOK_SET.add('>');
        RIGHT_BOOK_SET.add('＞');

        //双书名号
        RIGHT_BOOK_SET.add('》');
        RIGHT_P.addAll(RIGHT_BOOK_SET);
    }

    /** 所有的单元标点符号 */
    protected static final Set<Character> SINGLE = new HashSet<Character>();

    static {
        //句号
        SINGLE.add('。');
        SINGLE.add('．');
        SINGLE.add('.');

        //问号
        SINGLE.add('?');
        SINGLE.add('？');

        //感叹号
        SINGLE.add('!');
        SINGLE.add('！');

        //分号
        SINGLE.add(';');
        SINGLE.add('；');

        //逗号
        SINGLE.add('，');
        SINGLE.add(',');
        SINGLE.add('﹐');

        //冒号
        SINGLE.add('：');
        SINGLE.add(':');

        //顿号
        SINGLE.addAll(SPLITS);

        //省略号
        SINGLE.add('…');

        //破折号
        SINGLE.add('－');
        SINGLE.add('—');
    }

    /** 所有标点符号 */
    protected static final Set<Character> ALLS = new HashSet<Character>();

    static {
        ALLS.addAll(LEFT_P);
        ALLS.addAll(RIGHT_P);
        ALLS.addAll(SINGLE);
    }

    /**
     * Determines if the specified character is punctuation
     * 
     * @param c   the character to be tested.
     * @return <code>true</code> if the character is a punctuation
     *          character; <code>false</code> otherwise.
     */
    protected static boolean isPunctuation(char c) {
        return ALLS.contains(c);
    }

    /**
     * Returns a copy of the string, with leading and trailing whitespace
     * omitted.
     *
     * @param sentence the string with leading and trailing whitespace
     * @return A copy of this string with leading and trailing white
     *          space removed, or this string if it has no leading or
     *          trailing white space.
     */
    protected static String trim(String sentence) {
        int len = sentence.length();
        int st = 0;
        int en = len - 1;

        while ((st < len) && isWhiteSpace(sentence.charAt(st))) {
            ++st;
        }

        while ((en > st) && isWhiteSpace(sentence.charAt(en))) {
            --en;
        }

        return st > en ? "" : sentence.substring(st, en + 1);
    }
    
    //判断是否空白，供trim()调用
    public static boolean isWhiteSpace(char c) {
        if ( c == ' ' || c == '　' || c == '\t' || c == '\r' || c == '\n') {
            return true;
        } else {
            return false;
        }
    }
}
