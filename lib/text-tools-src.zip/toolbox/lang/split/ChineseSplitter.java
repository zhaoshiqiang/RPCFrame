/**
 * @(#)ChineseSplitter.java, 2008-5-29.
 *
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.lang.split;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;


/**
 * 中文分句
 *
 * @author sxy
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class ChineseSplitter extends AbstractSplitter {

    /** 重用对象池 */
    private static BlockingQueue<SymmetricSymbolInfo> pool = null;

    private static final int POOL_SIZE = 1024;

    static {
        pool = new LinkedBlockingQueue<SymmetricSymbolInfo>(POOL_SIZE);
        for (int i = 0; i < POOL_SIZE; ++i) {
            pool.add(new SymmetricSymbolInfo());
        }
    }

    private static final Character ELLIPSIS = '\u2026';

    private static final Set<Character> DELIMITORS = new HashSet<Character>();

    static {
        // DELIMITORS.add('．');
        DELIMITORS.add('。');

        DELIMITORS.add('?');
        DELIMITORS.add('？');

        DELIMITORS.add('!');
        DELIMITORS.add('！');

        DELIMITORS.add(';');
        DELIMITORS.add('；');

        // 全角省略号
        DELIMITORS.add(ELLIPSIS);
    }

    /**
     * 对中文文本分句,有长度限制
     *
     * @param article 待分段的文本
     * @param lengthLimit 长度限制
     * @param addSmartPunctuation 是否为句末无标点的句子自动添加标点
     * @return SplitInfo 对象
     */
    protected static final SplitInfo splitArticle(final String article,
            int lengthLimit, boolean addSmartPunctuation) {
        SplitInfo splitInfo = SplitInfo.take();

        int curRemainNum = lengthLimit;

        String[] paragraphs = article.split("\n");
        for (int i = 0; i < paragraphs.length; ++i) {
            String paragraph = paragraphs[i].trim();
            splitInfo.addParagraphFlag();

            // 没有份额了，只记录段信息不再分句
            if (curRemainNum <= 0) {
                splitInfo.addSentence(paragraph, false);
            } else {
                if (paragraph.length() > 0) {
                    curRemainNum = splitParagraph(paragraph, splitInfo,
                            curRemainNum, addSmartPunctuation);
                } else { // 空字符串
                    splitInfo.addSentence("", false);
                }
            }
        }

        return splitInfo;
    }

    /**
     * 对中文文本分句，无长度限制
     *
     * @param article 待分段的文本
     * @param addSmartPunctuation 是否为句末无标点的句子自动添加标点
     * @return SplitInfo 对象
     */
    protected static final SplitInfo splitArticle(final String article,
            boolean addSmartPunctuation) {
        SplitInfo splitInfo = SplitInfo.take();

        String[] paragraphs = article.split("\n");
        for (int i = 0; i < paragraphs.length; ++i) {
            String paragraph = paragraphs[i].trim();
            splitInfo.addParagraphFlag();

            if (paragraph.length() > 0) {
                splitParagraph(paragraph, splitInfo, addSmartPunctuation);
            } else { // 空字符串
                splitInfo.addSentence("", false);
            }
        }

        return splitInfo;
    }

    /**
     * 对中文段落分句，有长度限制
     *
     * @param paragraph 待分句的段落
     * @param splitInfo 保存分句信息
     * @param remainNum 分句前后剩余的还可进行分句操作的字符数
     * @param addSmartPunctuation 是否为句末无标点的句子自动添加标点
     * @return 分句完后剩余的还可进行分句操作的字符数
     */
    private static int splitParagraph(final String paragraph,
            SplitInfo splitInfo, int remainNum, boolean addSmartPunctuation) {
        if (paragraph == null || paragraph.length() == 0) {
            return remainNum;
        }

        int curRemainNum = remainNum;

        SymmetricSymbolInfo symmetricSymbolInfo = take();
        StringBuilder sb = new StringBuilder();

        symmetricSymbolInfo.init();

        boolean curDelimitor = false;
        boolean lastDelimitor = false;

        int currChIndex = 0;
        for (; currChIndex < paragraph.length(); ++currChIndex) {
            char currCh = paragraph.charAt(currChIndex);
            sb.append(currCh);

            boolean needCheck = false;
            if (isDelimitor(currCh)) {
                curDelimitor = true;
                // 对连续的相同的结束符向前归一化不再分为多个句子
                // 例如？？？但不处理诸如？！！这样的情况
                while (currChIndex < paragraph.length() - 1
                        && paragraph.charAt(currChIndex + 1) == currCh) {
                    ++currChIndex;
                    sb.append(currCh);
                }
                if (symmetricSymbolInfo.isAllMatch()) {
                    needCheck = true;
                }
            } else {
                if (currCh == '.') { // 特别处理半角的句点看看是否为误用的
                    char nextCh = currChIndex < paragraph.length() - 1
                                    ? paragraph.charAt(currChIndex + 1)
                                    : 0;
                    if (nextCh == currCh) {
                        // example: 我知道......你不懂的。
                        curDelimitor = true;
                        do {
                            ++currChIndex;
                            sb.append(currCh);
                        } while (currChIndex < paragraph.length() - 1
                                && paragraph.charAt(currChIndex + 1) == currCh);
                    } else {
                        /*
                         * 我们无法简单通过左右是否为汉字来判断是否为句号误用，
                         * goodcase: 你好. 你好.我叫李明.
                         * 这个暑假回来,发现和你的隔阂越来越大.压抑的我快要窒息.
                         * badcase:
                         * 一、缅京.永历帝.土司王朝 约翰内斯.海因博士说:
                         * TODO: 引入长度以及外国人名常用字来增加判断的准确性
                         */
                        lastDelimitor = curDelimitor;
                        curDelimitor = false;
                    }
                } else { // 其他非分隔符
                    lastDelimitor = curDelimitor;
                    curDelimitor = false;
                }

                if (curDelimitor) {
                    if (symmetricSymbolInfo.isAllMatch()) {
                        needCheck = true;
                    }
                } else {
                    if (symmetricSymbolInfo.set(currCh) && lastDelimitor
                            && symmetricSymbolInfo.isAllMatch()) {
                        // 二元符号里的一个结尾符号，是句子结尾
                        needCheck = true;
                    }
                }
            }

            if (needCheck) {
                // 计算附加该句后的长度限额
                curRemainNum -= sb.length();

                if (curRemainNum < 0) {
                    break;
                }

                splitInfo.addSentence(sb.toString(), false);
                sb.delete(0, sb.length());

                if (curRemainNum == 0) {
                    break;
                }
            }
        }

        put(symmetricSymbolInfo);

        // 处理最后一个未处理的句子
        if (curRemainNum > 0 && sb.length() > 0) {
            curRemainNum -= sb.length();
            if (curRemainNum >= 0) {
                // 只对最后一个未处理的句子猜测标点
                if (addSmartPunctuation) { //如果需要自动在句末加标点
                    if (isPunctuation(sb.charAt(sb.toString().trim().length() - 1))) {
                        // 该句子末尾确实有标点
                        splitInfo.addSentence(sb.toString(), false);
                    } else {
                        boolean r = SmartPunctuationAppender.appendChinesePunctuation(sb);
                        splitInfo.addSentence(sb.toString(), r);
                    }
                } else { //如果不需要自动在句末加标点
                    splitInfo.addSentence(sb.toString(), false);
                }
                sb.delete(0, sb.length());
            }
        }

        if (curRemainNum <= 0) {
            if (currChIndex + 1 < paragraph.length()) {
                sb.append(paragraph.substring(currChIndex + 1));
            }
            splitInfo.stopSplitSentence();
            if (sb.length() > 0) {
                splitInfo.addSentence(sb.toString(), false);
                sb.delete(0, sb.length());
            }
        }

        return curRemainNum;
    }

    /**
     * 对中文段落分句，无长度限制
     *
     * @param paragraph 待分句的段落
     * @param addSmartPunctuation 是否为句末无标点的句子自动添加标点
     * @param splitInfo 保存分句信息
     */
    private static void splitParagraph(final String paragraph,
            SplitInfo splitInfo, boolean addSmartPunctuation) {
        if (paragraph == null || paragraph.length() == 0) {
            return;
        }

        SymmetricSymbolInfo symmetricSymbolInfo = take();
        StringBuilder sb = new StringBuilder();

        symmetricSymbolInfo.init();

        boolean curDelimitor = false;
        boolean lastDelimitor = false;

        int currChIndex = 0;
        for (; currChIndex < paragraph.length(); ++currChIndex) {
            char currCh = paragraph.charAt(currChIndex);
            sb.append(currCh);

            boolean needCheck = false;
            if (isDelimitor(currCh)) {
                curDelimitor = true;
                // 对连续的相同的结束符向前归一化不再分为多个句子
                // 例如？？？但不处理诸如？！！这样的情况
                while (currChIndex < paragraph.length() - 1
                        && paragraph.charAt(currChIndex + 1) == currCh) {
                    ++currChIndex;
                    sb.append(currCh);
                }
                if (symmetricSymbolInfo.isAllMatch()) {
                    needCheck = true;
                }
            } else {
                if (currCh == '.') { // 特别处理半角的句点看看是否为误用的
                    char nextCh = currChIndex < paragraph.length() - 1
                                    ? paragraph.charAt(currChIndex + 1)
                                    : 0;
                    if (nextCh == currCh) {
                        // example: 我知道......你不懂的。
                        curDelimitor = true;
                        do {
                            ++currChIndex;
                            sb.append(currCh);
                        } while (currChIndex < paragraph.length() - 1
                                && paragraph.charAt(currChIndex + 1) == currCh);
                    } else {
                        /*
                         * 我们无法简单通过左右是否为汉字来判断是否为句号误用，
                         * goodcase: 你好. 你好.我叫李明.
                         * 这个暑假回来,发现和你的隔阂越来越大.压抑的我快要窒息.
                         * badcase:
                         * 一、缅京.永历帝.土司王朝 约翰内斯.海因博士说:
                         * TODO: 引入长度以及外国人名常用字来增加判断的准确性
                         */
                        lastDelimitor = curDelimitor;
                        curDelimitor = false;
                    }
                } else { // 其他非分隔符
                    lastDelimitor = curDelimitor;
                    curDelimitor = false;
                }

                if (curDelimitor) {
                    if (symmetricSymbolInfo.isAllMatch()) {
                        needCheck = true;
                    }
                } else {
                    if (symmetricSymbolInfo.set(currCh) && lastDelimitor
                            && symmetricSymbolInfo.isAllMatch()) {
                        // 二元符号里的一个结尾符号，是句子结尾
                        needCheck = true;
                    }
                }
            }

            if (needCheck) {
                splitInfo.addSentence(sb.toString(), false);
                sb.delete(0, sb.length());
            }
        }

        put(symmetricSymbolInfo);

        // 处理最后一个未处理的句子
        if (sb.length() > 0) {
            // 只对最后一个未处理的句子猜测标点
            if (addSmartPunctuation) { //如果需要自动在句末加标点
                if (isPunctuation(sb.charAt(sb.toString().trim().length() - 1))) {
                    // 该句子末尾确实有标点
                    splitInfo.addSentence(sb.toString(), false);
                } else {
                    boolean r = SmartPunctuationAppender.appendChinesePunctuation(sb);
                    splitInfo.addSentence(sb.toString(), r);
                }
            } else { //如果不需要自动在句末加标点
                splitInfo.addSentence(sb.toString(), false);
            }
            sb.delete(0, sb.length());
        }

        return;
    }

    static boolean isDelimitor(char c) {
        return DELIMITORS.contains(c);
    }

    private static class SymmetricSymbolInfo {
        /** 圆括号匹配标志 */
        private int parenthesesMatch;

        /** 方括号匹配标志 */
        private int squareBracketsMatch;

        /** 书名号匹配标志 */
        private int frenchQuotesMatch;

        /** 双引号匹配标志, 不区分全角半角左双右双统一对待 */
        private int doubleQuotationMarksMatch;

        /** 单引号，暂时不处理 */
        private int singleQuotationMarksMatch;

        public void init() {
            parenthesesMatch = 0;
            squareBracketsMatch = 0;
            frenchQuotesMatch = 0;
            doubleQuotationMarksMatch = 0;
            singleQuotationMarksMatch = 0;
        }

        boolean set(char c) {
            boolean isSet = true;

            switch (c) {
                case '(': // 左圆括号
                case '（':
                    ++parenthesesMatch;
                    break;
                case ')': // 右圆括号
                case '）':
                    if (parenthesesMatch > 0) {
                        --parenthesesMatch;
                    }
                    break;
                case '[': // 左方括号
                case '【':
                case '［':
                case '〖':
                case '「':
                case '『':
                    ++squareBracketsMatch;
                    break;
                case ']': // 右方括号
                case '】':
                case '］':
                case '〗':
                case '」':
                case '』':
                    if (squareBracketsMatch > 0) {
                        --squareBracketsMatch;
                    }
                    break;
                case '\u300A': // 左书名号
                    ++frenchQuotesMatch;
                    break;
                case '\u300B': // 右书名号
                    if (frenchQuotesMatch > 0) {
                        --frenchQuotesMatch;
                    }
                    break;
                case '"': // 双引号
                case '“':
                case '＂':
                case '”':
                case '〃':
                    if (doubleQuotationMarksMatch > 0) {
                        --doubleQuotationMarksMatch;
                    } else {
                        ++doubleQuotationMarksMatch;
                    }
                    break;
                default:
                    isSet = false;
                    break;
            }

            return isSet;
        }

        boolean isAllMatch() {
            return parenthesesMatch == 0 && squareBracketsMatch == 0
                    && frenchQuotesMatch == 0 && doubleQuotationMarksMatch == 0
                    && singleQuotationMarksMatch == 0;
        }
    }

    private static SymmetricSymbolInfo take() {
        SymmetricSymbolInfo info = null;

        info = pool.poll();

        if (info == null) {
            info = new SymmetricSymbolInfo();
        }

        return info;
    }

    private static void put(SymmetricSymbolInfo info) {
        if (info != null && pool.size() < POOL_SIZE) {
            pool.add(info);
        }
    }

    /**
     * 从标准输入读入文本，执行中文分句
     *
     * @param args 在此无作用
     */
    public static void main(String[] args) {
        BufferedReader br = null;
        //BufferedWriter bw = null;
        try {
            try {
                br = new BufferedReader(new InputStreamReader(System.in));
              //br = new BufferedReader(new FileReader("ChineseSplitTest.txt"));
              //bw = new BufferedWriter(new FileWriter("ChineseSplitOut.txt"));
                String line = null;
                while ((line = br.readLine()) != null) {
                    SplitInfo info = splitArticle(line,  true);
                    for (int i = 0; i < info.getSentenceNum(); i++) {
                        System.out.println(info.getSentence(i).trim());
                        //bw.write(info.getSentence(i).trim());
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (br != null) {
                    br.close();
                    //bw.close();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
