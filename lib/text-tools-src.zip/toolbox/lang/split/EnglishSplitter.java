/**
 * @(#)EnglishSplitter.java, 2011-8-14.
 *
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.lang.split;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * 英语分句
 *
 * @author sxy chengang
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public final class EnglishSplitter extends AbstractSplitter {
    
    private static final Set<String> ABBREVIATIONS= new HashSet<String>();

    /** Lock held by take, poll, etc */
    private static final byte[] INIT_LOCK = new byte[0];

    /** Flag indicating whether native library be initialized */
    private static boolean initFlag = false;

    /** String Token To Split Sententce to Words,包含中文空格、英文空格和Tab键*/
    private static final String TOKEN_STR = "　 \t";

    /**
     * 完成初始化操作
     * @param abbreviationsInputStream 缩写文件输入流，该文件在toolbox.lang.split包中
     * @throws IOException abbreviations file load error
     */
    protected static int init(final InputStream abbreviationsInputStream) 
    throws IOException{
        synchronized (INIT_LOCK) {
            if (initFlag || ABBREVIATIONS.size() > 0) {
                return 0;
            } else if (abbreviationsInputStream == null ) {
                throw (new IOException ("abbreviationFilePath is empty"));
            } else {
                BufferedReader br = null;
                try {
                    br = new BufferedReader( new InputStreamReader(
                            new BufferedInputStream(abbreviationsInputStream),
                            "utf-8"));
                    String line = br.readLine();
                    if (line != null && line.length() > 0
                            && line.charAt(0) == (char) 0xfeff) {
                        line = line.substring(1);
                    }
                    while (line != null) {
                        line = line.trim();
                        if (line.length() > 0) {
                            ABBREVIATIONS.add(line);
                        }
                        line = br.readLine();
                    }
                } finally {
                    if (br != null) {
                        br.close();
                    }
                }
            }
            initFlag = true;
            return 0;
        }
    }

    /** 判断一个词是否是一个Abbreviation */
    protected static boolean isAbbreviation(String word) {
        if( word.length() == 0) {
            return false;
        }
        //先去掉前面可能的修饰符号，example：（"Mr. Wang ...
        while(word.matches("[\"'\\(]+.*")) {
            word = word.substring(1);
        }
        if( ABBREVIATIONS.contains(word.toLowerCase())) {
                return true;
        }
        return false;
    }

    /** 判断一个词是否以大写字母开头 */
    private static boolean isStartWithCapital(final String word) {
        if (word != null && word.length() > 0) {
            char c = word.charAt(0);
            return c >= 'A' && c <= 'Z';
        } else {
            return false;
        }
    }

    /** 
     * 判断一个词是否以句末标点结尾 
     **/
    protected static boolean isEndWithEnding(final String word) {
        if (word.length() > 0) {
            char c = word.charAt(word.length() - 1);
            return c == '.' || c == '!' || c == '?';
        }
        return false;
    }

    /**
     * 判断该单词是否以引号开始
     *
     * @param word 单词
     * @return 是否以引号开始
     */
    protected static boolean isStartWithQuote(final String word) {
        if (word != null && word.length() > 0) {
            char c = word.charAt(0);
            return c == '\'' || c == '\"' || c == '`';
        } else {
            return false;
        }
    }

    private static class SurroundWordInfo {

        /** 前一词 */
        private String wm1;

        /** 当前位置前缀 */
        private String prefix;

        /** 当前位置后缀 */
        private String suffix;

        /** 后一词 */
        private String wp1;

        /** 后两词 */
        private String wp2;

        public void init() {
            wm1 = "";
            prefix = "";
            suffix = "";
            wp1 = "";
            wp2 = "";
        }
    }

    /** 重用对象池 */
    private static BlockingQueue<SurroundWordInfo> pool = null;

    private static final int POOL_SIZE = 1024;

    static {
        pool = new LinkedBlockingQueue<SurroundWordInfo>(POOL_SIZE);
        for (int i = 0; i < POOL_SIZE; ++i) {
            pool.add(new SurroundWordInfo());
        }
    }

    /** 从池中获取一个周边信息对象 */
    private static SurroundWordInfo take() {
        SurroundWordInfo info = null;

        info = pool.poll();

        if (info == null) {
            info = new SurroundWordInfo();
        }

        return info;
    }

    /** 往池中加入一个周边信息对象 */
    private static void put(SurroundWordInfo info) {
        if (info != null && pool.size() < POOL_SIZE) {
            pool.add(info);
        }
    }

    /**
     * 对英语文本分句，有长度限制
     * 
     * @param article 待分段的文本
     * @param lengthLimit 长度限制
     * @param addSmartPunctuation 是否为句末无标点的情况自动添加标点
     * @return SplitInfo对象
     */
    protected static SplitInfo splitArticle(final String article,
            int lengthLimit, boolean addSmartPunctuation) {
        SplitInfo splitInfo = SplitInfo.take();

        List<String> words = new ArrayList<String>(100);

        int curRemainNum = lengthLimit;

        String[] paragraphs = article.split("\n");
        for (int i = 0; i < paragraphs.length; ++i) {
            String paragraph = paragraphs[i].trim();
            splitInfo.addParagraphFlag();
            // 没有份额了，只记录段信息不再分句
            if (curRemainNum <= 0) {
                splitInfo.addSentence(paragraph, false);
            } else {
                if (paragraph.length() > 0) {
                    curRemainNum = splitParagraph(paragraph, words, splitInfo,
                            curRemainNum, addSmartPunctuation);
                } else { // 空字符串
                    splitInfo.addSentence("", false);
                }
            }
        }
        return splitInfo;
    }

    /**
     * 对英语文本分句，无长度限制
     * 
     * @param article 待分段的文本
     * @param addSmartPunctuation 是否为句末无标点的情况自动添加标点
     * @return SplitInfo对象
     */
    protected static SplitInfo splitArticle(final String article,
            boolean addSmartPunctuation) {
        SplitInfo splitInfo = SplitInfo.take();

        List<String> words = new ArrayList<String>(100);

        String[] paragraphs = article.split("\n");
        for (int i = 0; i < paragraphs.length; ++i) {
            String paragraph = paragraphs[i].trim();
            splitInfo.addParagraphFlag();
            
            if (paragraph.length() > 0) {
                splitParagraph(paragraph, words, splitInfo, 
                        addSmartPunctuation);
            } else { // 空字符串
                splitInfo.addSentence("", false);
            }
        }
        return splitInfo;
    }

    /** 
     * 对英语段落分句，有长度限制
     * 
     * @param paragraph 段落
     * @param words 单词信息
     * @param splitInfo 保存分句信息
     * @param remainNum 分句前后剩余的还可进行分句操作的字符数
     * @param addSmartPunctuation 是否为句末无标点的情况自动添加标点
     * @return 分句完后剩余的还可进行分句操作的字符数
     */
    private static int splitParagraph(final String paragraph,
            List<String> words, SplitInfo splitInfo, int remainNum, 
            boolean addSmartPunctuation) {
        int curRemainNum = remainNum;

        if (words == null || paragraph.length() == 0) {
            // 该段为空
            return remainNum;
        }

        words.clear();
        //首先对输入的句子去除空白字符
        String paraTrim = paragraph.trim();
        //存储句中的连续的分隔字符串或分隔字符
        List<String> spaces = new ArrayList<String>();
        StringTokenizer tokenizer =
            new StringTokenizer(paraTrim, TOKEN_STR, true);
        //存储分隔符的buffer，用于还原原文单词中的连续的分隔符
        StringBuffer spaceSb = new StringBuffer();
        while (tokenizer.hasMoreTokens()) {
            // Modify by wuxm 获取句子里的分隔字符和单词
            String word = tokenizer.nextToken();
            // 输入为空时或连续空白字符，分隔出空字符
            if (word.length() == 0) {
                     continue;
            }
            if (TOKEN_STR.contains(word)) {
                //添加分隔符
                spaceSb.append(word);
            } else {
                words.add(word);
                //遇到添加单词的操作，将之前的存储的分隔符存入spaces中
                if (spaceSb.length() > 0) {
                    spaces.add(spaceSb.toString());
                    spaceSb.delete(0, spaceSb.length());
                }
            }
        }

        // for each word
        SurroundWordInfo surroundWordinfo = take();
        StringBuilder sb = new StringBuilder();

        int currWordIndex = 0;
        int currWordCount = 0;
        int spaceIndex = 0;
        for (; currWordIndex < words.size(); ++currWordIndex) {
            String curWord = words.get(currWordIndex);
            sb.append(curWord);
           //add by wuxm
            if (spaceIndex < spaces.size()) {
                sb.append(spaces.get(spaceIndex));
                spaceIndex++;
            }
            ++currWordCount;
            // find a delimiter candidate
            int pos = findRightmostCandidate(curWord);
            if (pos == -1) { // just common word
                continue;
            }

            // there would be a candidate, do further checking
            char candidate = curWord.charAt(pos);
            surroundWordinfo.init();
            checkSurroundInfo(words, currWordIndex, pos, surroundWordinfo);

            // call the sentence boundary subroutine
            boolean isBoundary = isBoundary(candidate, surroundWordinfo);

            if (!isBoundary) { // not boundary, so continue
                if (!isNonstandardBoundary(candidate, surroundWordinfo)) {
                    continue;
                }
                // 回退，并且修改wordlist表
                // modified by wuxm
                int spaceLen = 0;
                if (spaceIndex > 0) {
                       spaceIndex--;
                       spaceLen = spaces.get(spaceIndex).length();
                }
                sb.delete(sb.length() - curWord.length()
                        - spaceLen + pos + 1, sb.length());
                words.set(currWordIndex, curWord.substring(0, pos + 1));
                words.add(currWordIndex + 1, curWord.substring(pos + 1));
                curWord = words.get(currWordIndex);
            }

            // now we find a sentence ending
            // 计算附加该句后的长度限额
            curRemainNum -= sb.length();
            if (curRemainNum < 0) { // 已经不够添加这一句
                break;
            }
            if( addSmartPunctuation) {//如果需要为句末无标点的情况自动添加标点
                if (isPunctuation(curWord.charAt(curWord.length() - 1))) {
                    // 该句子末尾确实有标点
                    splitInfo.addSentence(sb.toString(), false);
                } else {
                    boolean r = SmartPunctuationAppender
                            .appendEnglishPunctuation(sb, currWordCount);
                    splitInfo.addSentence(sb.toString(), r);
                }
            } else { //如果不需要为句末无标点的情况自动添加标点
                splitInfo.addSentence(sb.toString(), false);
            }
            sb.delete(0, sb.length());
            currWordCount = 0;

            if (curRemainNum == 0) { // 恰好用完，添加完之后也不用再分句了
                break;
            }
        } // end of for each word in paragraph

        // 最后一个合法的句子，尝试能不能添加进来
        if (curRemainNum > 0 && sb.length() > 0) {
             //modified by wuxm
             curRemainNum -= sb.length();
            if (curRemainNum > 0) { //
                  //modified by wuxm,获得字符串中最后一个非空白的字符
                if( addSmartPunctuation) {//如果需要为句末无标点的情况自动添加标点
                    if (isPunctuation(sb.charAt(sb.toString().trim().length() - 1))) {
                        // 该句子末尾确实有标点
                        splitInfo.addSentence(sb.toString(), false);
                    } else {
                        boolean r = SmartPunctuationAppender
                                .appendEnglishPunctuation(sb, currWordCount);
                        splitInfo.addSentence(sb.toString(), r);
                    }
                } else {//如果不需要为句末无标点的情况自动添加标点
                    splitInfo.addSentence(sb.toString(), false);
                }
                sb.delete(0, sb.length());
                currWordCount = 0;
            }
        }

        // 如果没份额了，直接添加
        if (curRemainNum <= 0) {
            for (currWordIndex += 1; currWordIndex < words.size(); currWordIndex++) {
                //modified by wuxm
                sb.append(words.get(currWordIndex));
                if (spaceIndex < spaces.size()) {
                    sb.append(spaces.get(spaceIndex));
                    spaceIndex++;
               }
            }

            splitInfo.stopSplitSentence();
            splitInfo.addSentence(sb.toString(), false);

            sb.delete(0, sb.length());
        }

        put(surroundWordinfo);

        return curRemainNum;
    }
    
    /** 
     * 对英语段落分句，无长度限制
     * 
     * @param paragraph 段落
     * @param words 单词信息
     * @param addSmartPunctuation 是否为句末无标点的情况自动添加标点
     * @param splitInfo 保存分句信息
     */
    private static void splitParagraph(final String paragraph,
            List<String> words, SplitInfo splitInfo,
            boolean addSmartPunctuation) {

        if (words == null || paragraph.length() == 0) {
            // 该段为空
            return ;
        }

        words.clear();
        //首先对输入的句子去除空白字符
        String paraTrim = paragraph.trim();
        //存储句中的连续的分隔字符串或分隔字符
        List<String> spaces = new ArrayList<String>();
        StringTokenizer tokenizer =
            new StringTokenizer(paraTrim, TOKEN_STR, true);
        //存储分隔符的buffer，用于还原原文单词中的连续的分隔符
        StringBuffer spaceSb = new StringBuffer();
        while (tokenizer.hasMoreTokens()) {
            // Modify by wuxm 获取句子里的分隔字符和单词
            String word = tokenizer.nextToken();
            // 输入为空时或连续空白字符，分隔出空字符
            if (word.length() == 0) {
                     continue;
            }
            if (TOKEN_STR.contains(word)) {
                //添加分隔符
                spaceSb.append(word);
            } else {
                words.add(word);
                //遇到添加单词的操作，将之前的存储的分隔符存入spaces中
                if (spaceSb.length() > 0) {
                    spaces.add(spaceSb.toString());
                    spaceSb.delete(0, spaceSb.length());
                }
            }
        }

        // for each word
        SurroundWordInfo surroundWordinfo = take();
        StringBuilder sb = new StringBuilder();

        int currWordIndex = 0;
        int currWordCount = 0;
        int spaceIndex = 0;
        for (; currWordIndex < words.size(); ++currWordIndex) {
            String curWord = words.get(currWordIndex);
            sb.append(curWord);
           //add by wuxm
            if (spaceIndex < spaces.size()) {
                sb.append(spaces.get(spaceIndex));
                spaceIndex++;
            }
            ++currWordCount;
            // find a delimiter candidate
            int pos = findRightmostCandidate(curWord);
            if (pos == -1) { // just common word
                continue;
            }

            // there would be a candidate, do further checking
            char candidate = curWord.charAt(pos);
            surroundWordinfo.init();
            checkSurroundInfo(words, currWordIndex, pos, surroundWordinfo);

            // call the sentence boundary subroutine
            boolean isBoundary = isBoundary(candidate, surroundWordinfo);

            if (!isBoundary) { // not boundary, so continue
                if (!isNonstandardBoundary(candidate, surroundWordinfo)) {
                    continue;
                }
                // 回退，并且修改wordlist表
                // modified by wuxm
                int spaceLen = 0;
                if (spaceIndex > 0) {
                       spaceIndex--;
                       spaceLen = spaces.get(spaceIndex).length();
                }
                sb.delete(sb.length() - curWord.length()
                        - spaceLen + pos + 1, sb.length());
                words.set(currWordIndex, curWord.substring(0, pos + 1));
                words.add(currWordIndex + 1, curWord.substring(pos + 1));
                curWord = words.get(currWordIndex);
            }

            // now we find a sentence ending
            
            if( addSmartPunctuation) {//如果需要为句末无标点的情况自动添加标点
                if (isPunctuation(curWord.charAt(curWord.length() - 1))) {
                    // 该句子末尾确实有标点
                    splitInfo.addSentence(sb.toString(), false);
                } else {
                    boolean r = SmartPunctuationAppender
                                .appendEnglishPunctuation(sb, currWordCount);
                    splitInfo.addSentence(sb.toString(), r);
                }
            } else { //如果不需要为句末无标点的情况自动添加标点
                splitInfo.addSentence(sb.toString(), false);
            }
            sb.delete(0, sb.length());
            currWordCount = 0;
        } // end of for each word in paragraph

        // 最后一个合法的句子，如果不为空则添加进来
        if (sb.length() > 0) {
            //modified by wuxm,获得字符串中最后一个非空白的字符
            if( addSmartPunctuation) {//如果需要为句末无标点的情况自动添加标点
                if (isPunctuation(sb.charAt(sb.toString().trim().length() - 1))) {
                    // 该句子末尾确实有标点
                    splitInfo.addSentence(sb.toString(), false);
                } else {
                    boolean r = SmartPunctuationAppender
                                .appendEnglishPunctuation(sb, currWordCount);
                    splitInfo.addSentence(sb.toString(), r);
                }
            } else {//如果不需要为句末无标点的情况自动添加标点
                splitInfo.addSentence(sb.toString(), false);
            }
            sb.delete(0, sb.length());
            currWordCount = 0;
        }

        put(surroundWordinfo);
    }

    /** 找到某词（其实是连续无空格的字符串）中可能包含分隔符的最右位置*/
    private static int findRightmostCandidate(final String word) {
        if (word == null) {
            return -1;
        }

        final char[] candidates = {'.', '?', '!', ')'};
        for (int i = word.length() - 1; i >= 0; i--) {
            char c = word.charAt(i);
            for (int j = 0; j < candidates.length; j++) {
                if (c == candidates[j]) {
                    return i;
                }
            }
        }

        return -1;
    }

    /** 保存该词周边信息 */
    private static void checkSurroundInfo(final List<String> words,
            final int curWordIndex, final int curCadIndex,
            final SurroundWordInfo info) {
        // 保存左词
        if (curWordIndex > 0) {
            info.wm1 = words.get(curWordIndex - 1);
        }

        // 保存右词
        if (curWordIndex < words.size() - 1) {
            info.wp1 = words.get(curWordIndex + 1);

            if (curWordIndex < words.size() - 2) {
                info.wp2 = words.get(curWordIndex + 2);
            }
        }

        String word = words.get(curWordIndex);

        // 保存前缀
        if (curCadIndex != 0) {
            info.prefix = word.substring(0, curCadIndex);
        }

        // 保存后缀
        if (curCadIndex < word.length() - 1) {
            info.suffix = word.substring(curCadIndex + 1);
        }
    }

    /**判断某字符是否是句子边界，空格正确的情况。
     * 空格使用不正确的情况见isNonstandardBoundary函数。*/
    private static boolean isBoundary(char candidate,
            final SurroundWordInfo info) {
        // Check for the end of the file
        if (info.wp1.equals("") && info.wp2.equals("")) {
            return true;
        }

        // Check for the begin of quote
        // example: Thank you[!?.)] "So
        if (info.suffix.length() == 0 && isStartWithQuote(info.wp1)) {
            return true;
        }

        // Check if the candidate was a question mark or an exclamation mark
        if (candidate == '!' || candidate == '?') {
            if (info.suffix.length() == 0) {
                // example: (He climbs on John's shoulders[?!] ) That is ...
                if (info.wp1.startsWith(")")) {
                    return false;
                }                
                return true;
            }
        } else if (candidate == ')') {
            if (info.suffix.length() == 0 
                && isStartWithCapital(info.wp1) 
                && ((info.prefix.length() > 0 && isEndWithEnding(info.prefix) 
                        && !isAbbreviation(info.prefix+".")))
                    || info.prefix.length() == 0 && info.wm1.length() > 0 
                        && isEndWithEnding(info.wm1) 
                        && !isAbbreviation(info.wm1+".")) {
                  //example: ...computers fed by the Internet.) From our ...
                  //example: (He climbs on John's shoulders. ) What shall I do?
                  //example: things.( books, food, etc.) What's your ...   
                        return true;
                }
        } else { // candidate is '.'
            if (info.suffix.length() == 0) {
                
                //Patch for a.m. and p.m.
                //example:  We have a flight leaving at nine a.m. Is that OK?
                //example:  a nurse at 7:35 a.m. Wednesday.
                //example:  today in a 4:05 p.m. EDT game at Yankee Stadium.
                if ((info.prefix.equals("a.m") || info.prefix.equals("p.m"))
                        && isStartWithCapital(info.wp1)
                        && !(info.wp1.matches(//星期或时区
                            "(Mo|Tu|Wed|Thu|Fr|Sa|Su).*|([A-Z]\\.?)+T.*"))){
                    return true;
                }
                //example: U.S.A  c.t.
                if (info.prefix.matches("[\"'\\(]*(-*[A-Za-z]\\.)*[a-zA-Z]")) {
                    return false;
                }
                //example: this is a Mr. Smith alsdjf.
                //保证进行到这一步后ABBREVIATION中的缩写都被跳过，
                //假如有未登录的缩写，则进行之后的判断
                if ( isAbbreviation(info.prefix+".")) {
                    return false;
                }
                //example: include: a). the plan, 2). the action  iv). books
                if( info.prefix.matches(
                        "\\(?([a-zA-Z0-9ⅠⅡⅢⅣⅤⅥⅦⅧⅨⅩⅪⅫ]|[ivxIVX]+)\\)")){
                    return false;
                }
                //example: (Chap 4 
                if (info.prefix.matches("[\"'\\(]*[A-Z][a-z]+") 
                        && info.wp1.matches("[0-9]+.*")) {
                    return false;
                } 
                // example: (He climbs on John's shoulders. )That 
                if (info.wp1.startsWith(")")) {
                    return false;
                }
                //example: I'd like to choose... ...
                if (info.wp1.startsWith(".")) {
                    return false;
                }
                //example: This is a pen. that is a book. This is a pen.
                if( !isAbbreviation(info.prefix+".")) {
                    return true;
                }
            } // end of info.suffix.length() == 0
        } // end of candidate is '.'

        return false;
    }

    /** 判断是否为非常规的边界，用于isBoundary判断之后的进一步判断
     *  “非常规”意思是指.!?)这四个候选的任意一个不出现在字符串结尾的情况。*/
    private static boolean isNonstandardBoundary(char candidate,
            SurroundWordInfo info) {
        // some missing space cases
        // example: No,mm-hmm.Hold on.Wait a minute.No,just him.
        // example: WWW.YOUDAO.COM   16.2 
        // example: Mr.Smith is here.
        
        if (info.wp1.equals("") && info.wp2.equals("")) {
            return true;
        }
        
        // Check for the begin of quote
        // example: Thank you."So
        if ( isStartWithQuote(info.suffix)) {
            return true;
        }
        if( candidate == '.') {
            if (info.prefix.length() >= 0 && info.suffix.length() > 0) {
                
                //example:  We have a flight leaving at nine a.m.Is that OK?
                //example:  a nurse at 7:35 a.m.Wednesday.
                //example:  today in a 4:05 p.m.ET game at Yankee Stadium.
                if ((info.prefix.equals("a.m") || info.prefix.equals("p.m"))
                        && isStartWithCapital(info.suffix)
                        && !(info.suffix.matches(//星期或时区
                            "(Mo|Tu|We|Th|Fr|Sa|Su).*|([A-Z]\\.?)+T.*"))){
                    return true;
                }                
                //example: (26.3%)  MATLAB6.5
                if(info.prefix.matches(".*[0-9]+")
                        && info.suffix.matches("[0-9]+.*")) {
                    return false;
                }
                //example: www.youdao.com
                if((info.prefix+"."+info.suffix).matches(
                        ".*(www\\.|\\.com|\\.net|\\.int|\\.edu|\\.mil|\\.org" +
                        "|\\.info|\\.biz|\\.name|\\.cn).*")){
                    return false;
                }
                //example: "Cap.449 
                if (info.prefix.matches("[\"'\\(]*[A-Z][a-z]+") 
                        && info.suffix.matches("[0-9]+.*")) {
                    return false;
                }
                //example: include: a).the plan, 2).the action  iv).books
                if( info.prefix.matches(
                        "\\(?([a-zA-Z0-9ⅠⅡⅢⅣⅤⅥⅦⅧⅨⅩⅪⅫ]|[ivxIVX]+)\\)")){
                    return false;
                }
                //example: ...i have met.what are you...
                if(!isAbbreviation(info.prefix + ".")){
                    return true;
                }
            }
        }
        //example: You know?So I ...
        //example: You know?so I ...
        //example: You know?--"so I ...
        if( candidate == '!' || candidate == '?' ) {
            if (info.prefix.length() >= 0 && info.suffix.length() > 0) {
                return true;
            }
        }
        //example: realize that.)These things
        if( candidate == ')') {
            if (info.prefix.length() >= 0
                    && info.suffix.length() > 0
                    && isStartWithCapital(info.suffix)
                    && ((isEndWithEnding(info.prefix) 
                            && !isAbbreviation(info.prefix)))) {
                return true;
            }
        }
        return false;
    }

    /**
     * 从标准输入读入文本，执行英语分句
     *
     * @param args 在此无作用
     */
    public static void main(String[] args) {
        BufferedReader br = null;
        BufferedWriter bw = null;////
        try {
            try {
                EnglishSplitter.init(
                    EnglishSplitter.class.getResourceAsStream("ABBREVIATIONS"));
                br = new BufferedReader(new InputStreamReader(System.in));
                bw = new BufferedWriter(new FileWriter("ruleResult.txt"));
                String line = null;
                while ((line = br.readLine()) != null) {
                    SplitInfo info = EnglishSplitter.splitArticle(
                            line, 800,  false);
                    for (int i = 0; i < info.getSentenceNum(); i++) {
                        System.out.println(info.getSentence(i).trim());
                        bw.write(info.getSentence(i).trim()+"\r\n");
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (br != null) {
                    br.close();
                    bw.close();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
