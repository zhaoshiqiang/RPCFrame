/**
 * @(#)splitter.java, 2011-5-30. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.lang.split;

import java.io.IOException;
import toolbox.lang.LanguageConsts;
import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * 分句类，可选择特定语言、是否限定长度、是否自动添加句末标点
 * @author chengang
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class Splitter {

    /**
     * 初始化函数，初始化所有语言
     * @throws IOException
     * @param 没有参数，默认初始化所有语言
     */
    public static void initAll() throws IOException {
        init(LanguageConsts.LANG_ENG);
    }

    /**
     * 初始化函数，初始化特定语言
     *  @throws IOException
     *  @param languageName
     */
    public static void init(final byte languageID) throws IOException {
        if(languageID == LanguageConsts.LANG_ENG){
            EnglishSplitter.init(
                    EnglishSplitter.class.getResourceAsStream("ABBREVIATIONS"));
        } else {
            throw new IOException(
                "No init function for languageID=" + languageID);
        }
    }
    
    /**
     * 分句函数：输入文本，输入语言ID
     * @param article 待分句的文本
     * @param languageID 语言ID
     * @return SplitInfo对象
     */
    public static SplitInfo splitArticle(final String article,
            final byte languageID) {
        if ((languageID == LanguageConsts.LANG_ENG)
                || (languageID == LanguageConsts.LANG_FR)
                || (languageID == LanguageConsts.LANG_KR)
                || (languageID == LanguageConsts.LANG_RU)
                || (languageID == LanguageConsts.LANG_SP)) {
            return EnglishSplitter.splitArticle(article, false);
        } else if ((languageID == LanguageConsts.LANG_SIMPLE_CHINESE)
                || (languageID == LanguageConsts.LANG_TRADITIONAL_CHINESE)
                || (languageID == LanguageConsts.LANG_JP)) {
            return ChineseSplitter.splitArticle(article, false);
        } else {
            return null;
        }
    }

    /**
     * 判断某字符是否为标点
     * @param c
     * @return boolean
     */
    public static boolean isPunctuation(char c) {
        return AbstractSplitter.isPunctuation(c);
    }

    /**
     * 测试main函数
     * @param args
     * @throws Exception
     */
    public static void main(String args[]) throws Exception {
        initAll();
        SplitInfo info = splitArticle("I am lily. He is tom.",
                LanguageConsts.LANG_ENG);
        for (int i = 0; i < info.getSentenceNum(); i++) {
            System.out.println(info.getSentence(i));
        }
        info = splitArticle("我是张三。他是李四。",
                LanguageConsts.LANG_SIMPLE_CHINESE);
        for (int i = 0; i < info.getSentenceNum(); i++) {
            System.out.println(info.getSentence(i));
        }
    }
}
