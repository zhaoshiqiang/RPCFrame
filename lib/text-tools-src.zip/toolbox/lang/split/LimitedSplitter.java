/**
 * @(#)LimitedSplitter.java, 2011-8-31. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.lang.split;

import toolbox.lang.LanguageConsts;
import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * 限定的分句类，可以限制长度和是否自动添加标点
 * @author chengang
 *
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class LimitedSplitter extends Splitter{
    
    /**
     * 分句函数：输入文本，给定语言，限定长度，可自动添加句末标点
     * @param article 待分句的文本
     * @param lengthLimit 长度限制
     * @param languageID 语言ID
     * @param addSmartPunctuation 是否自动添加句末标点
     * @return SplitInfo对象
     */
    public static SplitInfo splitArticle(final String article,
            final byte languageID, final int lengthLimit,
            boolean addSmartPunctuation) {
        if ((languageID == LanguageConsts.LANG_ENG)
                || (languageID == LanguageConsts.LANG_FR)
                || (languageID == LanguageConsts.LANG_KR)
                || (languageID == LanguageConsts.LANG_RU)
                || (languageID == LanguageConsts.LANG_SP)) {
            return EnglishSplitter.splitArticle(article, lengthLimit,
                    addSmartPunctuation);
        } else if ((languageID == LanguageConsts.LANG_SIMPLE_CHINESE)
                || (languageID == LanguageConsts.LANG_TRADITIONAL_CHINESE)
                || (languageID == LanguageConsts.LANG_JP)) {
            return ChineseSplitter.splitArticle(article, lengthLimit, 
                    addSmartPunctuation);
        } else {
            return null;
        }
    }
    
    /**
     * 分句函数：输入文本，给定语言，限定长度
     * @param article 待分句的文本
     * @param languageID 语言ID
     * @param addSmartPunctuation 是否为句末无标点的情况自动添加标点
     * @return SplitInfo对象
     */
    public static SplitInfo splitArticle(final String article,
            final byte languageID, final int lengthLimit) {
        if ((languageID == LanguageConsts.LANG_ENG)
                || (languageID == LanguageConsts.LANG_FR)
                || (languageID == LanguageConsts.LANG_KR)
                || (languageID == LanguageConsts.LANG_RU)
                || (languageID == LanguageConsts.LANG_SP)) {
            return EnglishSplitter.splitArticle(article, lengthLimit, false);
        } else if ((languageID == LanguageConsts.LANG_SIMPLE_CHINESE)
                || (languageID == LanguageConsts.LANG_TRADITIONAL_CHINESE)
                || (languageID == LanguageConsts.LANG_JP)) {
            return ChineseSplitter.splitArticle(article, lengthLimit, false);
        } else {
            return null;
        }
    }
    
    /**
     * 分句函数：输入文本，给定语言，可自动添加句末标点
     * @param article 待分句的文本
     * @param languageID 语言ID
     * @param addSmartPunctuation 是否为句末无标点的情况自动添加标点
     * @return SplitInfo对象
     */
    public static SplitInfo splitArticle(final String article,
            final byte languageID, boolean addSmartPunctuation) {
        if ((languageID == LanguageConsts.LANG_ENG)
                || (languageID == LanguageConsts.LANG_FR)
                || (languageID == LanguageConsts.LANG_KR)
                || (languageID == LanguageConsts.LANG_RU)
                || (languageID == LanguageConsts.LANG_SP)) {
            return EnglishSplitter.splitArticle(article, addSmartPunctuation);
        } else if ((languageID == LanguageConsts.LANG_SIMPLE_CHINESE)
                || (languageID == LanguageConsts.LANG_TRADITIONAL_CHINESE)
                || (languageID == LanguageConsts.LANG_JP)) {
            return ChineseSplitter.splitArticle(article, addSmartPunctuation);
        } else {
            return null;
        }
    }
}
