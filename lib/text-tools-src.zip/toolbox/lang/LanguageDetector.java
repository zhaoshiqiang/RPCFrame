/**
 * @(#)LanguageDetector.java, 2008-8-1. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.lang;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import toolbox.lang.utils.ChineseUtils;
import toolbox.lang.utils.EnglishUtils;
import toolbox.lang.utils.FrenchUtils;
import toolbox.lang.utils.IndoEuropUtils;
import toolbox.lang.utils.IndoEuropLangIder;
import toolbox.lang.utils.JapaneseUtils;
import toolbox.lang.utils.KoreanUtils;
import toolbox.lang.utils.LanguageUtils;
import toolbox.lang.utils.RussianUtils;
import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * 文本语言检测工具类.
 * 
 * 检测语言基本的办法是统计文本中属于不同语言的字符的个数，按照比例关系确定是否属于某种语言.
 * 统计一段文本的语言的例子代码如下:
 * 
 * <code>
 *   LanguageDetector detector = new LanguageDetector();
 *   // = new LanguageDetector(true); //概率模型检测西德小语种
 *   // detector.register(LanguageConsts.LANG_SP);
 *   // detector.register(LanguageConsts.LANG_GE);
 *   ...
 *   String s1 = ...;
 *   String s2 = ...;
 *   
 *   detector.clear();
 *   detector.update(s1, 0, s1.length);
 *   detector.update(s2, offset2, s2.length-offset2);
 *   
 *   int lang = detector.detect();
 * </code>
 * 
 * 由于检测是按照比例关系预测的，所以，会有适应性的问题，目前确定的参数是按照在网页搜索的页面集合中
 * 实验获得的，可能不适用于其他的场合. 另外一个使用的办法就是通过 {@link #getCharOfLanguage(int)}
 * 接口获得实际的计数，自己实现语言检测的部分. 例如，我们认为如果中文字符中有超过20%是繁体，就会认为这个
 * 页面是繁体网页，但是实际上可能繁体网页中繁体的比例会小于20%.
 * 
 * 目前可支持识别英语，法语，西班牙语和德语四个拉丁语系的语言。由于是利用字符Gram模型进行检测，
 * 相比字符比例关系效率会有所降低，而且随着检测语言种类增多而线性下降。
 * 
 * 为了效率和兼容，概率识别算法默认只检测英语和法语，且需要在构造时候指定参数。
 * 如果需要检测西，德需要在检测之前通过显示的通过register注册。
 * 
 * @author lirh, river, liq, qipeng
 *
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class LanguageDetector {
    public static final int CT_NONWHITESPACE = 0;
    
    public static final int CT_ASCII = 1;
    
    public static final int CT_LATIN = 2;
    
    public static final int CT_KANJI = 3;

    public static final int CT_SIMPLE_CHINESE = 4;
    
    public static final int CT_TRADITIONAL_CHINESE = 5;
    
    public static final int CT_KANA = 6;
    
    public static final int CT_KOREAN = 7;

    public static final int CT_ASCII_PUNCTUATION = 8;
    
    public static final int CT_CHINESE_PUNCTUATION = 9;

    public static final int CT_UNKNOWN = 10;

    public static final int CT_NUMBER = 11;

    //法语中的拉丁字符
    public static final int CT_FRENCH_LATIN = 12;
    
    //法文字母：a-z+法文拉丁
    public static final int CT_FRENCH_LETTER = 13;
    
    //只在日文中出现的汉字
    public static final int CT_KANJI_J = 14;
    
    //中文日文中都会出现的汉字
    public static final int CT_KANJI_C = 15;
    
    public static final int CT_EAST_ASIAN = 16;
    
    public static final int CT_WESTERN = 17;
    
    public static final int CT_RUSSIAN = 18;
    
    public static final int CT_INEU_LATIN = 19;
    
    public static final int CT_COUNT = 20;
    
    public static final int OTHER_EAST_ASIAN_WORD = 0;
    
    public static final int OTHER_WESTERN_WORD = 1;
    
    //累计中日中都会出现的汉字为日文或中文的得分
    public static final int OTHER_SCORE_J = 2;
    
    public static final int OTHER_SCORE_C = 3;
    
    public static final int OTHER_COUNT = 4;
    
    private int[] counts = new int[CT_COUNT];

    private double[] other = new double[OTHER_COUNT];

    public static final int[][] UTF_CJK_PUNCTUATION = {
        {0x2012, 0x201F}, {0x2026, 0x2026}, {0x3000, 0x3003},
        {0x3007, 0x301F}
    };
    
    public static final int[][] UTF_FULLWIDTH_ASCII_PUNCTUATION = {
        {0xFF01, 0xFF0F}, {0xFF1A, 0xFF20}, {0xFF3B, 0xFF40},
        {0xFF5B, 0xFF65}, {0xFF9E, 0xFF9F}, {0xFFE0, 0xFFE6}
    };
    
    public static final int[][] UTF_ASCII_PUNCTUATION = {
        {0x0021, 0x002F}, {0x003A, 0x0040}, {0x005B, 0x0060},
        {0x007B, 0x007E}
    };

    private List<LanguageUtils> utils;
    
    private IndoEuropLangIder indoEuropLangIder;
    
    public LanguageDetector() {
        utils = new ArrayList<LanguageUtils>();
        //注册语言检测工具
        //注意：会先检测先注册的语言，顺序会影响语言检测结果
        utils.add(new FrenchUtils());
        utils.add(new EnglishUtils());
        utils.add(new RussianUtils());
        utils.add(new KoreanUtils());
        utils.add(new JapaneseUtils());
        utils.add(new ChineseUtils());
    }
    
    /**
     * 加载概率模型，识别西班牙，德语，法语，英语。效率比字符比例算法低
     * 
     * @param stat 是否用概率模型来识别语言
     */
    public LanguageDetector(boolean stat) {
        utils = new ArrayList<LanguageUtils>();
        if (stat) {
            indoEuropLangIder = new IndoEuropLangIder();
            utils.add(indoEuropLangIder);
        } else {
            utils.add(new FrenchUtils());
            utils.add(new EnglishUtils());
            utils.add(new IndoEuropUtils());
        }
        utils.add(new RussianUtils());
        utils.add(new KoreanUtils());
        utils.add(new JapaneseUtils());
        utils.add(new ChineseUtils());
    }
    
    /**
     * 判断一个字符是否是中文标点.
     * @param c
     * @return
     */
    public static boolean isChinesePunctuation(char c) {
        int i = (int) (c & 0xFFFF);
        for (int j = 0; j < UTF_CJK_PUNCTUATION.length; ++j) {
            if (i >= UTF_CJK_PUNCTUATION[j][0] && i <= UTF_CJK_PUNCTUATION[j][1]) {
                return true;
            }
        }
        for (int j = 0; j < UTF_FULLWIDTH_ASCII_PUNCTUATION.length; ++j) {
            if (i >= UTF_FULLWIDTH_ASCII_PUNCTUATION[j][0] && i <= UTF_FULLWIDTH_ASCII_PUNCTUATION[j][1]) {
                return true;
            }
        }
        return false;
    }

    /**
     * 判断一个字符是否是ASCII标点.
     * @param c
     * @return
     */
    public static boolean isAsciiPunctuation(char c) {
        int i = (int) (c & 0xFFFF);
        for (int j = 0; j < UTF_ASCII_PUNCTUATION.length; ++j) {
            if (i >= UTF_ASCII_PUNCTUATION[j][0] && i <= UTF_ASCII_PUNCTUATION[j][1]) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * 判断一个字符是否是ASCII数字.
     * @param c
     * @return
     */
    public static boolean isAsciiNumber(char c) {
        return c >= '0' && c <= '9';
    }
    
    // CharSequence wrapper for char array
    private BufCharSequence bufCharSequence = new BufCharSequence();
    //用来保存当前正在被检测的字符序列
    private CharSequence charSequence;
    
    /**
     * 清空所有的计数，在每次开始检测以前都必须调用这个方法.
     */
    public void clear() {
        Arrays.fill(counts, 0);
        Arrays.fill(other, 0);
        if (indoEuropLangIder != null) {
            indoEuropLangIder.clear();
        }
    }

    /**
     * 字母和数字全角转半角
     * @param c
     * @return
     */
    private char convertFull2Half(char c){
        if (c >= 0xFF10 && c <= 0xFF19) {
            return (char) (c - 0xFEE0);
        } else if (c >= 0xFF21 && c <= 0xFF3A) {
            return (char) (c - 0xFEE0);
        } else if (c >= 0xFF41 && c <= 0xFF5A) {
            return (char) (c - 0xFEE0);
        }
        return c;
    }
    
    /**
     * 统计输入文本中属于不同语言的字符的个数.
     * @param buf
     * @param offset
     * @param length
     */
    public void update(char [] buf, int offset, int length) {
        bufCharSequence.buf = buf;
        update(bufCharSequence, offset, length);
    }
    
    /**
     * 统计输入文本中属于不同语言的字符个数.
     * @param text
     * @param offset
     * @param length
     */
    public void update(CharSequence text, int offset, int length) {
        int len = text.length();
        if (offset < 0 || offset >= len)
            offset = 0;
        int end = offset + length;
        if (end > len || end < offset)
            end = len;
        if (offset == 0 && end == len)
            charSequence = text;
        else
            charSequence = text.subSequence(offset, end);
        for (int i = offset; i < end; i++) {
            char c = text.charAt(i);
            // 字母和数字全角转半角
            c = convertFull2Half(c);
                
            if (Character.isWhitespace(c)) {
                continue;
            }

            if (isAsciiPunctuation(c)) {
                ++counts[CT_ASCII_PUNCTUATION];
                continue;
            }

            if (isChinesePunctuation(c)) {
                ++counts[CT_CHINESE_PUNCTUATION];
                continue;
            }

            ++counts[CT_NONWHITESPACE];
            if (FrenchUtils.isFrenchLetter(c)) {
                ++counts[CT_FRENCH_LETTER];
                if (FrenchUtils.isFrenchLatin(c))
                    ++counts[CT_FRENCH_LATIN];
            }
            if (ChnConstant.isRussianChar(c)){
                ++counts[CT_RUSSIAN];
            }
            if (isAsciiNumber(c)) {
                ++counts[CT_NUMBER];
            } else if (ChnConstant.isAsciiChar(c)) {
                ++counts[CT_WESTERN];
                ++counts[CT_ASCII];
            } else if (ChnConstant.isOtherAlphabet(c)) {
                if (IndoEuropLangIder.isIndoEurpoLatin(c)) {
                    ++counts[CT_INEU_LATIN];
                }
                ++counts[CT_WESTERN];
                ++counts[CT_LATIN];
            } else if (ChnConstant.isChineseChar(c)) {
                ++counts[CT_EAST_ASIAN];
                double score = JapaneseUtils.getScore(c);
                if (score >= 0) {
                    ++counts[CT_KANJI];
                    other[OTHER_SCORE_J] += score;
                    other[OTHER_SCORE_C] += 1.0 - score;
                    if (score == 1.0)
                        ++counts[CT_KANJI_J];
                    else
                        ++counts[CT_KANJI_C];
                } else {
                    other[OTHER_SCORE_C] += 1.0;
                }
                if (TraditionToSimple.isTraditionalChinese(c)) {
                    ++counts[CT_TRADITIONAL_CHINESE];
                } else {
                    ++counts[CT_SIMPLE_CHINESE];
                }
            } else if (ChnConstant.isJapaneseChar(c)) {
                other[OTHER_SCORE_J] += 1.0;
                ++counts[CT_EAST_ASIAN];
                ++counts[CT_KANA];
            } else if (ChnConstant.isKoreanChar(c)) {
                ++counts[CT_EAST_ASIAN];
                ++counts[CT_KOREAN];
            } else {
                ++counts[CT_UNKNOWN];
            }
        }

        if (counts[CT_NONWHITESPACE] == counts[CT_UNKNOWN]) {
            // all pruncuation and unknow words
            counts[CT_ASCII] = counts[CT_ASCII_PUNCTUATION];
            counts[CT_WESTERN] += counts[CT_ASCII];
            counts[CT_SIMPLE_CHINESE] = counts[CT_CHINESE_PUNCTUATION];
            counts[CT_EAST_ASIAN] += counts[CT_SIMPLE_CHINESE];
        } else if (counts[CT_NONWHITESPACE] == counts[CT_NUMBER]) {
            // all numbers and puncs, such as 2009-01-01
            counts[CT_SIMPLE_CHINESE] = counts[CT_NUMBER];
            counts[CT_EAST_ASIAN] += counts[CT_SIMPLE_CHINESE];
        }

        other[OTHER_WESTERN_WORD] = ((double) counts[CT_WESTERN]) / 5;
        other[OTHER_EAST_ASIAN_WORD] = ((double) counts[CT_EAST_ASIAN]) / 2;
        
        if (indoEuropLangIder != null) {
            indoEuropLangIder.update(text, offset, end - offset, counts);
        }
    }
    
    /**
     * 返回参与检测的字符的个数，也就是非空的字符个数.
     * @return
     */
    public int getDetectedCharCount() {
        return counts[CT_NONWHITESPACE];
    }
    
    /**
     * 返回检测中某种语言的字符数的计数，这里给出的参数和 {@link LanguageConsts}
     * 中定义的语言不同，而是类似 {@link #CT_SIMPLE_CHINESE} 这样的运行中的定义.
     * 
     * 这个接口主要用于实验中访问统计结果，对于检测语言没有太大的作用.
     * 
     * @param language
     * @return
     */
    public int getCharOfLanguage(int language) {
        if (language < 0 || language >= CT_COUNT) {
            throw new RuntimeException("undefined language in detector : " + language);
        }
        
        return counts[language];
    }
    
    /**
     * 注册是否用语言模型检测拉丁语言，目前只支持英语，法语，西班牙语，德语，
     * 默认会检测英语和法语
     * 
     * @param langId
     */
    public void register(byte langId) {
        if (langId != LanguageConsts.LANG_ENG && 
                langId != LanguageConsts.LANG_FR && 
                langId != LanguageConsts.LANG_SP &&
                langId != LanguageConsts.LANG_GE) {
            return;
        }
        if (indoEuropLangIder != null) {
            indoEuropLangIder.register(langId);
        }
    }
    
    /**
     * 取消检测某中拉丁语言
     * @param langId
     */
    public void unregister(byte langId) {
        if (langId != LanguageConsts.LANG_ENG && 
                langId != LanguageConsts.LANG_FR && 
                langId != LanguageConsts.LANG_SP &&
                langId != LanguageConsts.LANG_GE) {
            return;
        }
        if (indoEuropLangIder != null) {
            indoEuropLangIder.unregister(langId);
        }
    }
    
    /**
     * 检测语言，返回实际得到的语言，返回值定义在 {@link LanguageConsts}中.
     * 当参与统计的字符数为0的时候，直接返回 {@link LanguageConsts#LANG_UNKNOWN}.
     * 
     * @return
     */
    @SuppressWarnings("deprecation")
    public byte detect() {
        
        // 在没有足够检测字符的情况下，直接返回UNKNOWN
        if (counts[CT_NONWHITESPACE] == 0) {
            return LanguageConsts.LANG_UNKNOWN;
        }

        for (LanguageUtils util: utils) {
            if (util.hit(charSequence, counts, other)) {
                if (util.getLanguageType() == LanguageConsts.LANG_CN) {
                    if ((double) counts[CT_TRADITIONAL_CHINESE]
                            / (counts[CT_SIMPLE_CHINESE] + counts[CT_TRADITIONAL_CHINESE]) > 0.2) {
                        return LanguageConsts.LANG_TRADITIONAL_CHINESE;
                    } else {
                        return LanguageConsts.LANG_SIMPLE_CHINESE;
                    }
                } else
                    return util.getLanguageType();
            }
        }

        return LanguageConsts.LANG_UNKNOWN;
        
    }

    /**
     * Refer to {@link #detectText(CharSequence, int, int)}.
     * @param s
     * @return
     */
    public byte detectText(CharSequence s) {
        return detectText(s, 0, s.length());
    }
    
    /**
     * 检测一个字符串的语言，效果等同于顺序执行 {@link #clear()}, {@link #update(CharSequence, int, int)}
     * 和 {@link #detect()}方法.
     * 
     * @param s
     * @param offset
     * @param length
     * @return
     */
    public byte detectText(CharSequence s, int offset, int length) {
        clear();
        update(s, offset, length);
        return detect();
    }
    
    private class BufCharSequence implements CharSequence {
        private char [] buf;
        
        public char charAt(int index) {
            return buf[index];
        }

        public int length() {
            return buf.length;
        }

        public CharSequence subSequence(int start, int end) {
            BufCharSequence sub = new BufCharSequence();
            sub.buf = new char[end - start];
            for (int i = 0; i < end - start; i++){
                sub.buf[i] = buf[start + i];
            }
            return sub;
        }
        
    }
    
}