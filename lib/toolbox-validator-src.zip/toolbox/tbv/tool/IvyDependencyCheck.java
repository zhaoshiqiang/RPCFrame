/**
 * @(#)IvyDependencyCheck.java, 2011-12-21. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.tbv.tool;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

import com.puppycrawl.tools.checkstyle.api.AbstractFileSetCheck;

/**
 * This class used to check invalid dependency organizations in ivy.xml.
 * 
 * @author zhangduo
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class IvyDependencyCheck extends AbstractFileSetCheck {

    private final Set<String> validOrgs = new HashSet<String>();

    private static final String LINE_NUMBER_ATTR_NAME = "tbv_hack_LineNo";

    /**
     * Default constructor.
     * <p>
     * Do some config works such as set FileExtensions.
     */
    public IvyDependencyCheck() {
        setFileExtensions(new String[] {
            "xml"
        });
    }

    /**
     * Set valid organizations.
     * 
     * @param validOrgs
     */
    public void setValidOrgs(String[] validOrgs) {
        this.validOrgs.clear();
        for (String validOrg: validOrgs) {
            this.validOrgs.add(validOrg);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void processFiltered(File aFile, List<String> aLines) {
        if (!aFile.getName().equals("ivy.xml")) {
            return;
        }
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(aFile);
            Document doc = readXML(fis);
            NodeList list = doc.getElementsByTagName("dependency");
            for (int i = 0; i < list.getLength(); i++) {
                Node node = list.item(i);
                String org = node.getAttributes().getNamedItem("org").getTextContent();
                if (!validOrgs.contains(org)) {
                    log(Integer.parseInt(node.getAttributes().getNamedItem(
                            LINE_NUMBER_ATTR_NAME).getTextContent()),
                            "dependency.invalid", org);
                }
            }
        } catch (ParserConfigurationException e) {
            throw new RuntimeException("parse ivy file failed", e);
        } catch (SAXException e) {
            throw new RuntimeException("parse ivy file failed", e);
        } catch (IOException e) {
            throw new RuntimeException("parse ivy file failed", e);
        } finally {
            CheckUtils.safeClose(fis);
        }
    }

    private Document readXML(InputStream in)
            throws ParserConfigurationException, SAXException, IOException {
        SAXParserFactory factory = SAXParserFactory.newInstance();
        SAXParser parser = factory.newSAXParser();
        DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
        final Document doc = docBuilder.newDocument();

        final Deque<Element> elementStack = new ArrayDeque<Element>();
        final StringBuilder textBuffer = new StringBuilder();
        DefaultHandler handler = new DefaultHandler() {

            private Locator locator;

            @Override
            public void setDocumentLocator(Locator locator) {
                // Save the locator, so that it can be used later for line 
                // tracking when traversing nodes.
                this.locator = locator;

            }

            @Override
            public void startElement(String uri, String localName,
                    String qName, Attributes attributes) throws SAXException {
                addTextIfNeeded();
                Element el = doc.createElement(qName);
                for (int i = 0; i < attributes.getLength(); i++) {
                    el.setAttribute(attributes.getQName(i),
                            attributes.getValue(i));
                }
                el.setAttribute(LINE_NUMBER_ATTR_NAME,
                        Integer.toString(locator.getLineNumber()));
                elementStack.push(el);
            }

            @Override
            public void endElement(String uri, String localName, String qName) {
                addTextIfNeeded();
                Element closedEl = elementStack.pop();
                if (elementStack.isEmpty()) { // Is this the root element?
                    doc.appendChild(closedEl);
                } else {
                    Element parentEl = elementStack.peek();
                    parentEl.appendChild(closedEl);
                }
            }

            @Override
            public void characters(char ch[], int start, int length)
                    throws SAXException {
                textBuffer.append(ch, start, length);

            }

            // Outputs text accumulated under the current node
            private void addTextIfNeeded() {
                if (textBuffer.length() > 0) {
                    Element el = elementStack.peek();
                    Node textNode = doc.createTextNode(textBuffer.toString());
                    el.appendChild(textNode);
                    textBuffer.delete(0, textBuffer.length());
                }
            }
        };

        parser.parse(in, handler);

        return doc;
    }
}
