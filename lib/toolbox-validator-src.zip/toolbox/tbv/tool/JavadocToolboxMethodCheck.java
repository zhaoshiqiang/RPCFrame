/**
 * @(#)JavadocToolboxMethodCheck.java, 2011-12-20. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.tbv.tool;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

import com.puppycrawl.tools.checkstyle.api.DetailAST;
import com.puppycrawl.tools.checkstyle.api.Scope;
import com.puppycrawl.tools.checkstyle.api.ScopeUtils;
import com.puppycrawl.tools.checkstyle.api.TokenTypes;
import com.puppycrawl.tools.checkstyle.checks.javadoc.JavadocMethodCheck;

/**
 * Checks javadoc for public and protected method declared in class with
 * <code>@InterfaceAudience.Public</code>.
 * 
 * @author zhangduo
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class JavadocToolboxMethodCheck extends JavadocMethodCheck {

    /**
     * {@inheritDoc}
     */
    @Override
    protected boolean isMissingJavadocAllowed(DetailAST aAST) {
        if (!CheckUtils.isUnderInterfaceAudiencePublicClass(aAST)) {
            return true;
        }
        Scope mod = ScopeUtils.inInterfaceOrAnnotationBlock(aAST) ? Scope.PUBLIC
                : ScopeUtils.getScopeFromMods(aAST.findFirstToken(TokenTypes.MODIFIERS));
        return mod != Scope.PUBLIC && mod != Scope.PROTECTED;
    }
}
