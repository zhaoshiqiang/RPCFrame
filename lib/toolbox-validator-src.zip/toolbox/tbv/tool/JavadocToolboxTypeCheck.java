/**
 * @(#)JavadocToolboxTypeCheck.java, 2011-12-21. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.tbv.tool;

import java.util.List;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

import com.puppycrawl.tools.checkstyle.api.DetailAST;
import com.puppycrawl.tools.checkstyle.api.FileContents;
import com.puppycrawl.tools.checkstyle.api.JavadocTagInfo;
import com.puppycrawl.tools.checkstyle.api.ScopeUtils;
import com.puppycrawl.tools.checkstyle.api.TextBlock;
import com.puppycrawl.tools.checkstyle.api.TokenTypes;
import com.puppycrawl.tools.checkstyle.checks.javadoc.JavadocTag;
import com.puppycrawl.tools.checkstyle.checks.javadoc.JavadocUtils;

/**
 * This class used check <code>class</code>, <code>interface</code>,
 * <code>enum</code> and <code>annotation</code> javadocs.
 * <p>
 * The rule is:
 * <ul>
 * <li>Only check class with <code>@InterfaceAudience.Public</code> annotation.</li>
 * <li>The outer most class should have an author tag.</li>
 * <li>If you do not have see tag, you should have some text documentation.</li>
 * </ul>
 * 
 * @author zhangduo
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class JavadocToolboxTypeCheck extends AbstractToolboxTypeCheck {

    /**
     * {@inheritDoc}
     */
    @Override
    public int[] getDefaultTokens() {
        return getAcceptableTokens();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int[] getAcceptableTokens() {
        return new int[] {
            TokenTypes.INTERFACE_DEF, TokenTypes.CLASS_DEF,
            TokenTypes.ENUM_DEF, TokenTypes.ANNOTATION_DEF,
        };
    }

    private boolean shouldCheck(DetailAST aAST) {
        return CheckUtils.isInterfaceAudiencePublicClass(aAST);
    }

    /**
     * {@inheritDoc}
     */
    protected void doCheck(DetailAST aAST) {
        if (!shouldCheck(aAST)) {
            return;
        }
        FileContents contents = getFileContents();
        int lineNo = aAST.getLineNo();
        TextBlock cmt = contents.getJavadocBefore(lineNo);
        if (cmt == null) {
            log(lineNo, "javadoc.missing");
            return;
        }
        List<JavadocTag> tags = JavadocUtils.getJavadocTags(cmt,
                JavadocUtils.JavadocTagType.BLOCK).getValidTags();
        if (ScopeUtils.isOuterMostType(aAST)) {
            // check author for out most classes
            if (!CheckUtils.hasTag(tags, JavadocTagInfo.AUTHOR.getName())) {
                log(lineNo, "type.missingTag",
                        "@" + JavadocTagInfo.AUTHOR.getName());
            }
        }
        // has see tag
        JavadocTag seeTag = CheckUtils.getTag(tags,
                JavadocTagInfo.SEE.getName());
        if (seeTag != null && !CheckUtils.isBlank(seeTag.getArg1())) {
            return;
        }
        // check text lines
        if (CheckUtils.hasValidTextComment(cmt)) {
            return;
        }
        log(lineNo, "javadoc.missing");
    }
}
