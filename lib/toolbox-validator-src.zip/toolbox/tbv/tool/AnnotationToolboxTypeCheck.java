/**
 * @(#)AnnotationToolboxTypeCheck.java, 2011-12-21. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.tbv.tool;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

import com.puppycrawl.tools.checkstyle.api.DetailAST;
import com.puppycrawl.tools.checkstyle.api.Scope;
import com.puppycrawl.tools.checkstyle.api.ScopeUtils;
import com.puppycrawl.tools.checkstyle.api.TokenTypes;

/**
 * This class used to check InterfaceAudience and InterfaceStability annotations
 * for public classes.
 * 
 * @author zhangduo
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class AnnotationToolboxTypeCheck extends AbstractToolboxTypeCheck {

    /**
     * {@inheritDoc}
     */
    @Override
    public int[] getDefaultTokens() {
        return getAcceptableTokens();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int[] getAcceptableTokens() {
        return new int[] {
            TokenTypes.INTERFACE_DEF, TokenTypes.CLASS_DEF,
            TokenTypes.ENUM_DEF, TokenTypes.ANNOTATION_DEF,
        };
    }

    private boolean shouldCheck(DetailAST aAST) {
        if (ScopeUtils.isOuterMostType(aAST)) {
            return ScopeUtils.getScopeFromMods(aAST.findFirstToken(TokenTypes.MODIFIERS)) == Scope.PUBLIC;
        }

        if (!CheckUtils.isUnderInterfaceAudiencePublicClass(aAST)) {
            return false;
        }
        Scope mod = ScopeUtils.inInterfaceOrAnnotationBlock(aAST) ? Scope.PUBLIC
                : ScopeUtils.getScopeFromMods(aAST.findFirstToken(TokenTypes.MODIFIERS));
        return mod == Scope.PUBLIC || mod == Scope.PROTECTED;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void doCheck(DetailAST aAST) {
        if (!shouldCheck(aAST)) {
            return;
        }
        int lineNo = aAST.getLineNo();
        int audienceCount = CheckUtils.getInterfaceAudienceAnnotationCount(aAST);
        if (audienceCount == 0) {
            log(lineNo, "annotation.missing", "InterfaceAudience");
        }
        if (audienceCount > 1) {
            log(lineNo, "annotation.conflict", "InterfaceAudience");
        }

        int stabilityCount = CheckUtils.getInterfaceStabilityAnnotationCount(aAST);
        if (stabilityCount == 0) {
            log(lineNo, "annotation.missing", "InterfaceStability");
        }
        if (stabilityCount > 1) {
            log(lineNo, "annotation.conflict", "InterfaceStability");
        }
    }
}
