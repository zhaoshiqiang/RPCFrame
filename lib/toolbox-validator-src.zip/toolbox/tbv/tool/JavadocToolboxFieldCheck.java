/**
 * @(#)JavadocToolboxFieldCheck.java, 2011-12-22. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.tbv.tool;

import java.util.List;

import com.puppycrawl.tools.checkstyle.api.DetailAST;
import com.puppycrawl.tools.checkstyle.api.FileContents;
import com.puppycrawl.tools.checkstyle.api.JavadocTagInfo;
import com.puppycrawl.tools.checkstyle.api.Scope;
import com.puppycrawl.tools.checkstyle.api.ScopeUtils;
import com.puppycrawl.tools.checkstyle.api.TextBlock;
import com.puppycrawl.tools.checkstyle.api.TokenTypes;
import com.puppycrawl.tools.checkstyle.checks.javadoc.JavadocTag;
import com.puppycrawl.tools.checkstyle.checks.javadoc.JavadocUtils;

/**
 * Checks javadoc for public and protected field declared in class with
 * <code>@InterfaceAudience.Public</code>.
 * 
 * @author zhangduo
 */
public class JavadocToolboxFieldCheck extends AbstractToolboxTypeCheck {

    /**
     * {@inheritDoc}
     */
    @Override
    public int[] getDefaultTokens() {
        return getAcceptableTokens();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int[] getAcceptableTokens() {
        return new int[] {
            TokenTypes.VARIABLE_DEF
        };
    }

    private boolean shouldCheck(DetailAST aAST) {
        if (aAST.getParent().getType() != TokenTypes.OBJBLOCK) {
            return false;
        }
        if (!CheckUtils.isUnderInterfaceAudiencePublicClass(aAST)) {
            return false;
        }
        Scope mod = ScopeUtils.inInterfaceOrAnnotationBlock(aAST) ? Scope.PUBLIC
                : ScopeUtils.getScopeFromMods(aAST.findFirstToken(TokenTypes.MODIFIERS));
        return mod == Scope.PUBLIC || mod == Scope.PROTECTED;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void doCheck(DetailAST aAST) {
        if (!shouldCheck(aAST)) {
            return;
        }
        try {
            FileContents contents = getFileContents();
            int lineNo = aAST.getLineNo();
            TextBlock cmt = contents.getJavadocBefore(lineNo);
            if (cmt == null) {
                log(lineNo, "javadoc.missing");
                return;
            }
            List<JavadocTag> tags = JavadocUtils.getJavadocTags(cmt,
                    JavadocUtils.JavadocTagType.BLOCK).getValidTags();
            // has see tag
            JavadocTag seeTag = CheckUtils.getTag(tags,
                    JavadocTagInfo.SEE.getName());
            if (seeTag != null && !CheckUtils.isBlank(seeTag.getArg1())) {
                return;
            }
            // check text lines
            if (CheckUtils.hasValidTextComment(cmt)) {
                return;
            }
            log(lineNo, "javadoc.missing");
        } catch (NullPointerException e) {
            e.printStackTrace();
        }

    }
}
