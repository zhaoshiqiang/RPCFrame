/**
 * @(#)ASTUtils.java, 2011-12-20. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.tbv.tool;

import java.io.Closeable;
import java.io.IOException;
import java.util.List;

import com.puppycrawl.tools.checkstyle.api.AnnotationUtility;
import com.puppycrawl.tools.checkstyle.api.DetailAST;
import com.puppycrawl.tools.checkstyle.api.TextBlock;
import com.puppycrawl.tools.checkstyle.api.TokenTypes;
import com.puppycrawl.tools.checkstyle.checks.javadoc.JavadocTag;

/**
 * @author zhangduo
 */
class CheckUtils {

    public static final String PUBLIC_AUDICENCE = "InterfaceAudience.Public";

    public static final String FQ_PUBLIC_AUDICENCE = "toolbox.tbv.common.InterfaceAudience.Public";

    public static final String LIMITED_PRIVATE_AUDICENCE = "InterfaceAudience.LimitedPrivate";

    public static final String FQ_LIMITED_PRIVATE_AUDICENCE = "toolbox.tbv.common.InterfaceAudience.LimitedPrivate";

    public static final String PRIVATE_AUDICENCE = "InterfaceAudience.Private";

    public static final String FQ_PRIVATE_AUDICENCE = "toolbox.tbv.common.InterfaceAudience.Private";

    public static final String STABLE_STABILITY = "InterfaceStability.Stable";

    public static final String FQ_STABLE_STABILITY = "toolbox.tbv.common.InterfaceStability.Stable";

    public static final String EVOLVING_STABILITY = "InterfaceStability.Evolving";

    public static final String FQ_EVOLVING_STABILITY = "toolbox.tbv.common.InterfaceStability.Evolving";

    public static final String UNSTABLE_STABILITY = "InterfaceStability.Unstable";

    public static final String FQ_UNSTABLE_STABILITY = "toolbox.tbv.common.InterfaceStability.Unstable";

    public static boolean isUnderInterfaceAudiencePublicClass(DetailAST aAST) {
        aAST = aAST.getParent();
        while (aAST != null) {
            int type = aAST.getType();
            if (type == TokenTypes.CLASS_DEF
                    || type == TokenTypes.INTERFACE_DEF
                    || type == TokenTypes.ENUM_DEF
                    || type == TokenTypes.ANNOTATION_DEF) {
                return isInterfaceAudiencePublicClass(aAST);
            }
            aAST = aAST.getParent();
        }
        return false;
    }

    public static boolean isInterfaceAudiencePublicClass(DetailAST aAST) {
        return AnnotationUtility.containsAnnotation(aAST, PUBLIC_AUDICENCE)
                || AnnotationUtility.containsAnnotation(aAST,
                        FQ_PUBLIC_AUDICENCE);
    }

    public static int getInterfaceAudienceAnnotationCount(DetailAST aAST) {
        int count = 0;
        if (AnnotationUtility.containsAnnotation(aAST, PUBLIC_AUDICENCE)
                || AnnotationUtility.containsAnnotation(aAST,
                        FQ_PUBLIC_AUDICENCE)) {
            count++;
        }
        if (AnnotationUtility.containsAnnotation(aAST,
                LIMITED_PRIVATE_AUDICENCE)
                || AnnotationUtility.containsAnnotation(aAST,
                        FQ_LIMITED_PRIVATE_AUDICENCE)) {
            count++;
        }
        if (AnnotationUtility.containsAnnotation(aAST, PRIVATE_AUDICENCE)
                || AnnotationUtility.containsAnnotation(aAST,
                        FQ_PRIVATE_AUDICENCE)) {
            count++;
        }
        return count;
    }

    public static int getInterfaceStabilityAnnotationCount(DetailAST aAST) {
        int count = 0;
        if (AnnotationUtility.containsAnnotation(aAST, STABLE_STABILITY)
                || AnnotationUtility.containsAnnotation(aAST,
                        FQ_STABLE_STABILITY)) {
            count++;
        }
        if (AnnotationUtility.containsAnnotation(aAST, EVOLVING_STABILITY)
                || AnnotationUtility.containsAnnotation(aAST,
                        FQ_EVOLVING_STABILITY)) {
            count++;
        }
        if (AnnotationUtility.containsAnnotation(aAST, UNSTABLE_STABILITY)
                || AnnotationUtility.containsAnnotation(aAST,
                        FQ_UNSTABLE_STABILITY)) {
            count++;
        }
        return count;
    }

    public static boolean isBlank(String s) {
        return s == null || s.trim().length() == 0;
    }

    public static void safeClose(Closeable c) {
        if (c != null) {
            try {
                c.close();
            } catch (IOException e) {}
        }
    }
    
    public static boolean hasValidTextComment(TextBlock cmt) {
        for (String line: cmt.getText()) {
            line = line.trim();
            if (line.startsWith("/**")) {
                line = line.substring(3);
            }
            if (line.endsWith("*/")) {
                line = line.substring(0, line.length() - 2);
            }
            if (line.startsWith("*")) {
                line = line.substring(1);
            }
            line = line.trim();
            if (line.length() > 0 && !line.startsWith("@")) {
                // has a valid doc line.
                return true;
            }
        }
        return false;
    }
    
    public static boolean hasTag(List<JavadocTag> tags, String tagName) {
        return getTag(tags, tagName) != null;
    }

    public static JavadocTag getTag(List<JavadocTag> tags, String tagName) {
        for (JavadocTag tag: tags) {
            if (tag.getTagName().equals(tagName)) {
                return tag;
            }
        }
        return null;
    }
}
