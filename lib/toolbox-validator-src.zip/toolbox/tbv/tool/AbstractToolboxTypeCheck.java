/**
 * @(#)AbstractToolboxTypeCheck.java, 2011-12-21. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.tbv.tool;

import com.puppycrawl.tools.checkstyle.api.Check;
import com.puppycrawl.tools.checkstyle.api.DetailAST;
import com.puppycrawl.tools.checkstyle.api.TokenTypes;

/**
 * The base class for toolbox class annotation and javadoc check.
 * 
 * @author zhangduo
 */
abstract class AbstractToolboxTypeCheck extends Check {
    private String currentClassName = null;

    /**
     * Get class name for the current context.
     * 
     * @return
     */
    protected String getCurrentClassName() {
        return currentClassName;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int[] getRequiredTokens() {
        return new int[] {
            TokenTypes.INTERFACE_DEF, TokenTypes.CLASS_DEF,
            TokenTypes.ENUM_DEF, TokenTypes.ANNOTATION_DEF,
        };
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void visitToken(DetailAST aAST) {
        String name = aAST.findFirstToken(TokenTypes.IDENT).getText();
        if (currentClassName == null) {
            currentClassName = name;
        } else {
            currentClassName += '$' + name;
        }
        doCheck(aAST);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void leaveToken(DetailAST aAST) {
        int idx = currentClassName.lastIndexOf('$');
        if (idx < 0) {
            currentClassName = null;
        } else {
            currentClassName = currentClassName.substring(0, idx);
        }
    }

    /**
     * Do the actual check work.
     * 
     * @param aAST
     *            the ast node to be checked
     */
    protected abstract void doCheck(DetailAST aAST);
}
