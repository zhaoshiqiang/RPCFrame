/*
 * Copyright (c) 2005, Yitao Duan, Jimmy Su, Feng Zhou and Li Zhuang Created on
 * Sep 16, 2005
 */
package odis.io;

import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;

import odis.util.BlockingExecutor;

/**
 * A large buffer (say 100MB) for accessing files with pipelined I/O. This
 * enables in-place access to data without a lot of data copy and method calls.
 * The buffer has a work window and an I/O window, where I/O is performed in
 * separate threads. This way computation can overlap with I/O.
 * 
 * @author zf
 */
public class FileBuffer {

    /**
     * Concurrency level for I/O for all FileBuffers.
     */
    private static final int FB_IO_THREADS = 5;

    private static final int FB_IO_QLEN = 100;

    static ThreadPoolExecutor FB_IO_EXEC = BlockingExecutor.createExecutor(
            FB_IO_THREADS, new ArrayBlockingQueue<Runnable>(FB_IO_QLEN));

    InputStream in;

    boolean eof;

    // whether we have a current pending/executing I/O going on
    boolean ioQueued;

    byte[] buf;

    // end of compute window
    int end;

    // target end position of current foreground read, -1 if no foreground read
    int targetend = -1;

    // end of io window (stuff already read in)
    // 'ioend' should be equal to or ahead of 'end'.
    int ioend;

    /**
     * Unit of I/O, should be large enough to make I/O efficient.
     */
    int prefetchBlockSize = 1024 * 1024;

    private int prefetchSize;

    /**
     * Each FileBuffer has exactly one IOTask object that gets queued into the
     * IO queue whenever I/O is needed.
     */
    private class IOTask implements Runnable {
        public void run() {
            try {
                // keep prefetching until we have reached our 'prefetchSize'
                while (true) {
                    int start, len;
                    synchronized (FileBuffer.this) {
                        if (ioend == buf.length) // we're full
                            break;
                        start = ioend;
                        if (targetend != -1 && targetend > ioend) {
                            // foreground read
                            len = Math
                                    .max(prefetchBlockSize, targetend - ioend);
                        } else {
                            // prefetching
                            if (ioend - end > prefetchSize - prefetchBlockSize)
                                // we have less than a block to fetch
                                break;
                            len = prefetchBlockSize;
                        }
                        len = Math.min(len, buf.length - ioend);
                    }
                    if ((len = in.read(buf, start, len)) == -1) {
                        synchronized (FileBuffer.this) {
                            eof = true;
                        }
                        break;
                    }
                    // wake up waiters
                    synchronized (FileBuffer.this) {
                        ioend += len;
                        FileBuffer.this.notifyAll();
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            synchronized (FileBuffer.this) {
                ioQueued = false;
                FileBuffer.this.notifyAll();
            }
        }
    }

    IOTask ioTask = new IOTask();

    private synchronized void queueIo() {
        if (ioQueued)
            return;
        FB_IO_EXEC.execute(ioTask);
        ioQueued = true;
    }

    /**
     * Constructor
     * 
     * @param bufSize
     *            total work buffer size
     * @param prefetchSize
     *            the max amount of data to fetch ahead of time
     */
    public FileBuffer(InputStream in, int bufSize, int prefetchSize) {
        // TODO: make sure bufSize is large enough
        this.in = in;
        buf = new byte[bufSize];
        if (prefetchBlockSize > prefetchSize)
            prefetchBlockSize = prefetchSize;
        this.prefetchSize = prefetchSize;
        queueIo();
    }

    /**
     * Return memory buffer. This will never change.
     * 
     * @return the buffer
     */
    public byte[] getBuf() {
        return buf;
    }

    /**
     * Free a certain amount of data in the buffer and thus make the window
     * smaller. This returns buffer space to this FileBuffer after caller is
     * done with a part of data.
     * 
     * @param len
     *            free this many bytes of the current work window.
     */
    public synchronized void free(int len) {
        if (len > end)
            throw new IllegalArgumentException(
                    "newoff should be between off and end");
        // wait for any I/O to complete
        while (ioQueued)
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        if (ioend > len) {
            // copy over remaining/prefetched data
            System.arraycopy(buf, len, buf, 0, ioend - len);
        }
        end -= len;
        ioend -= len;
    }

    /**
     * Get length of compute window.
     * 
     * @return the length of compute window
     */
    public int getLen() {
        return end;
    }

    /**
     * Wait for the I/O thread to finish reading <code>size</code> more bytes.
     * 
     * @return number of bytes read, or -1 if EOF.
     */
    public int read(int size) {
        synchronized (this) {
            if (end + size > buf.length) {
                // System.out.println("Out of buffer space");
                size = buf.length - end;
                // throw new IndexOutOfBoundsException("Out of buffer space");
            }
            targetend = end + size;
            // wait until we have enough data
            while (ioend < targetend && !eof) {
                queueIo();
                try {
                    wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            targetend = -1;
            // move pointers

            // FIXME eof just means that the prefetching procedure touch the end
            // of the file
            if (ioend == end && eof) // already eof
                return -1;
            int r = Math.min(size, ioend - end);
            end += r;
            // schedule background I/O if necessary
            if (!eof && ioend - end <= prefetchSize - prefetchBlockSize
                    && buf.length - ioend > 0)
                queueIo();
            return r;
        }
    }

    /**
     * Close the InputStream
     * 
     * @throws IOException
     */
    public synchronized void close() throws IOException {
        while (ioQueued)
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        in.close();
    }

    /**
     * Check if the InputStream is eof
     * 
     * @return the boolean Value
     */
    public synchronized boolean isEof() {
        return eof;
    }
}
