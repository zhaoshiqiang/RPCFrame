/**
 * @(#)MyByteArrayInputStream.java, 2009-7-7. Copyright 2009 Yodao, Inc. All
 *                                            rights reserved. YODAO
 *                                            PROPRIETARY/CONFIDENTIAL. Use is
 *                                            subject to license terms.
 */
package odis.io;

import java.io.ByteArrayInputStream;

/**
 * 可以设置输入的 buf 的 {@link ByteArrayInputStream}
 * 
 * @author jiangfy
 */
public class MyByteArrayInputStream extends ByteArrayInputStream {

    /**
     * construct a MyByteArrayInputStream with the given buffer
     * 
     * @param buf
     */
    public MyByteArrayInputStream(byte[] buf) {
        super(buf);
    }

    /**
     * construct a MyByteArrayInputStream with the given buffer , offset and
     * length
     * 
     * @param buf
     *            the given buffer
     * @param offset
     *            the given offset
     * @param length
     *            the given length
     */
    public MyByteArrayInputStream(byte buf[], int offset, int length) {
        super(buf, offset, length);
    }

    public MyByteArrayInputStream() {
        super(new byte[0]);
    }

    /**
     * reset the buffer with the given buffer
     * 
     * @param buf
     *            the given buffer
     */
    public void setBuffer(byte[] buf) {
        this.buf = buf;
        this.pos = 0;
        this.count = buf.length;
    }

    /**
     * reset the buffer with the given buffer , offset and length
     * 
     * @param buf
     *            the given buffer
     * @param offset
     *            the given offset
     * @param length
     *            the given length
     */
    public void setBuffer(byte[] buf, int offset, int length) {
        this.buf = buf;
        this.pos = offset;
        this.count = Math.min(offset + length, buf.length);
        this.mark = offset;
    }

}
