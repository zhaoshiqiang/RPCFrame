/*
 * Copyright (c) 2006, Outfox Team.
 */
package odis.io;

import java.io.DataOutput;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UTFDataFormatException;
import java.io.UnsupportedEncodingException;

import odis.util.unsafe.UnsafeHelper;

/**
 * DataOutputStream using little-endian byte order (reverse of Java's
 * big-endian). This makes interoperating with C/C++ code easy on Intel
 * machines. <b>attention</b>: writeUTF() is not implemented. Use
 * {@link odis.serialize.lib.StringWritable#writeString(DataOutput, String)}
 * 
 * @see CDataInputStream
 * @author river
 */
public class CDataOutputStream extends FilterOutputStream implements DataOutput {

    /**
     * the Constructor
     * 
     * @param os
     *            the OutputStream
     */
    public CDataOutputStream(OutputStream os) {
        super(os);
    }

    /**
     * Write a boolean value to the given OutputStream.
     * 
     * @param v
     *            the boolean value
     * @param out
     *            the OutputStream to which write
     * @throws IOException
     *             if an I/O error occurs
     */
    public static final void writeBoolean(boolean v, OutputStream out)
            throws IOException {
        out.write(v ? 1 : 0);
    }

    @Override
    public void writeBoolean(boolean v) throws IOException {
        writeBoolean(v, out);
    }

    public static final void writeByte(int v, OutputStream out)
            throws IOException {
        out.write(v);
    }

    @Override
    public void writeByte(int v) throws IOException {
        writeByte(v, out);
    }

    /**
     * Write a short value to the given OutputStream.
     * 
     * @param v
     *            the short value
     * @param out
     *            the OutputStream to which write
     * @throws IOException
     *             if an I/O error occurs
     */
    public static final void writeShort(int v, OutputStream out)
            throws IOException {
        out.write(v & 0xff);
        out.write((v >>> 8) & 0xff);
    }

    public static final void writeShort(int v, byte[] out, int off) {
        out[off] = (byte) v;
        out[off + 1] = (byte) (v >>> 8);
    }

    @Override
    public void writeShort(int v) throws IOException {
        writeShort(v, out);
    }

    /**
     * Write a char value to the given OutputStream.
     * 
     * @param v
     *            the char value
     * @param out
     *            the OutputStream to which write
     * @throws IOException
     *             if an I/O error occurs
     */
    public static final void writeChar(int v, OutputStream out)
            throws IOException {
        out.write(v & 0xff);
        out.write((v >>> 8) & 0xff);
    }

    public static final void writeChar(int v, byte[] out, int off) {
        out[off] = (byte) v;
        out[off + 1] = (byte) (v >>> 8);
    }

    @Override
    public void writeChar(int v) throws IOException {
        writeChar(v, out);
    }

    /**
     * Write a int value to the given OutputStream.
     * 
     * @param v
     *            the int value
     * @param out
     *            the OutputStream to which write
     * @throws IOException
     *             if an I/O error occurs
     */
    public static final void writeInt(int v, OutputStream out)
            throws IOException {
        out.write((v >>> 0) & 0xff);
        out.write((v >>> 8) & 0xff);
        out.write((v >>> 16) & 0xff);
        out.write((v >>> 24) & 0xff);
    }

    /**
     * write a int value to a byte array.
     * 
     * @param bytes
     *            the buffer to be write
     * @param offset
     *            the offset position for buffer
     * @return Return the read long value.
     */
    public static final void writeInt(int v, byte[] out, int offset) {
        UnsafeHelper.unsafe.putInt(out, UnsafeHelper.BYTE_ARRAY_BASE_OFFSET
                + offset, v);
    }

    @Override
    public void writeInt(int v) throws IOException {
        writeInt(v, out);
    }

    /**
     * Write a long value to the given OutputStream.
     * 
     * @param v
     *            the long value
     * @param out
     *            the OutputStream to which write
     * @throws IOException
     *             if an I/O error occurs
     */
    public static final void writeLong(long v, OutputStream out)
            throws IOException {
        out.write((int) (v & 0xFF));
        out.write((int) (v >>> 8) & 0xFF);
        out.write((int) (v >>> 16) & 0xFF);
        out.write((int) (v >>> 24) & 0xFF);
        out.write((int) (v >>> 32) & 0xFF);
        out.write((int) (v >>> 40) & 0xFF);
        out.write((int) (v >>> 48) & 0xFF);
        out.write((int) (v >>> 56) & 0xFF);
    }

    /**
     * write a long value to a byte array.
     * 
     * @param bytes
     *            the buffer to be write
     * @param offset
     *            the offset position for buffer
     * @return Return the read long value.
     */
    public static final void writeLong(long v, byte[] out, int offset) {
        UnsafeHelper.unsafe.putLong(out, UnsafeHelper.BYTE_ARRAY_BASE_OFFSET
                + offset, v);
    }

    @Override
    public void writeLong(long v) throws IOException {
        writeLong(v, out);
    }

    /**
     * Write a Vint value to the given OutputStream.
     * 
     * @param v
     *            the int value
     * @param out
     *            the OutputStream to which write
     * @throws IOException
     *             if an I/O error occurs
     * @return The number of bytes written.
     */
    public static int writeVInt(int v, OutputStream out) throws IOException {
        int size = 0;
        while ((v & ~0x7F) != 0) {
            out.write((byte) ((v & 0x7f) | 0x80));
            v >>>= 7;
            size++;
        }
        out.write((byte) v);
        return size + 1;
    }

    /**
     * Write a vint value to the given DataOutput.
     * 
     * @param v
     *            the int value
     * @param out
     *            the OutputStream to which write
     * @throws IOException
     *             if an I/O error occurs
     * @return The number of bytes written.
     */
    public static int writeVInt(int v, DataOutput out) throws IOException {
        int size = 0;
        while ((v & ~0x7F) != 0) {
            out.write((byte) ((v & 0x7f) | 0x80));
            v >>>= 7;
            size++;
        }
        out.write((byte) v);
        return size + 1;
    }

    /**
     * 返回写入的字符数目.
     * 
     * @param v
     * @param out
     * @param offset
     * @return the number of bytes written
     */
    public static final int writeVInt(int v, byte[] out, int offset) {
        int oldOffset = offset;
        while ((v & ~0x7F) != 0) {
            out[offset++] = ((byte) ((v & 0x7f) | 0x80));
            v >>>= 7;
        }
        out[offset++] = ((byte) v);
        return offset - oldOffset;
    }

    /**
     * Write a positive integer using variable length encoding that is shorter
     * for smaller integers. For example, integers from 0 to 127 is represented
     * with a single byte. See ODIS manual chapter on serialization or code for
     * actual representation.
     * 
     * @param v
     *            assumed to be positive!
     * @throws IOException
     *             if an I/O error occurs
     * @return The number of bytes written.
     */
    public int writeVInt(int v) throws IOException {
        return writeVInt(v, out);
    }

    /**
     * Calculate the size for given <code>v</code> when using VInt encoding.
     * 
     * @param v
     * @return
     */
    public static int calcVIntSize(int v) {
        int size = 0;
        do {
            v = v >>> 7;
            size++;
        } while (v > 0);
        return size;
    }

    /**
     * Write a long using variable length encoding that is shorter for smaller
     * longs to an specified output-stream. For example, integers from 0 to 127
     * is represented with a single byte. See ODIS manual chapter on
     * serialization or code for actual representation.
     * 
     * @param v
     *            The value to be stored.
     * @param out
     *            The output-stream the data is stored to.
     * @throws IOException
     *             if an I/O error occurs
     * @return The number of bytes written.
     */
    public static int writeVLong(long v, OutputStream out) throws IOException {
        int size = 0;
        while ((v & ~(long) 0x7F) != 0) {
            out.write((byte) ((v & 0x7f) | 0x80));
            v >>>= 7;
            size++;
        } // while
        out.write((byte) v);
        return size + 1;
    }

    /**
     * Write a long using variable length encoding that is shorter for smaller
     * longs to an specified data-output. For example, integers from 0 to 127 is
     * represented with a single byte. See ODIS manual chapter on serialization
     * or code for actual representation.
     * 
     * @param v
     *            The value to be stored.
     * @param out
     *            The data-output the data is stored to.
     * @throws IOException
     *             if an I/O error occurs
     * @return The number of bytes written.
     */
    public static int writeVLong(long v, DataOutput out) throws IOException {
        int size = 0;
        while ((v & ~(long) 0x7F) != 0) {
            out.write((byte) ((v & 0x7f) | 0x80));
            v >>>= 7;
            size++;
        } // while
        out.write((byte) v);
        return size + 1;
    }

    /**
     * Write a long using variable length encoding that is shorter for smaller
     * longs to an specified byte-array buffer. For example, integers from 0 to
     * 127 is represented with a single byte. See ODIS manual chapter on
     * serialization or code for actual representation.
     * 
     * @param v
     *            The value to be stored.
     * @param out
     *            The byte-array buffer the data is stored to.
     * @param offset
     *            The offset of the start of the buffer.
     * @return The number of bytes written.
     */
    public static final int writeVLong(long v, byte[] out, int offset) {
        int oldOffset = offset;
        while ((v & ~(long) 0x7F) != 0) {
            out[offset++] = (byte) ((v & 0x7f) | 0x80);
            v >>>= 7;
        } // while
        out[offset++] = ((byte) v);
        return offset - oldOffset;
    }

    /**
     * Write a long using variable length encoding that is shorter for smaller
     * longs. For example, integers from 0 to 127 is represented with a single
     * byte. See ODIS manual chapter on serialization or code for actual
     * representation.
     * 
     * @param v
     *            The value to be stored.
     * @throws IOException
     *             if an I/O error occurs
     * @return The number of bytes written.
     */
    public int writeVLong(long v) throws IOException {
        return writeVLong(v, out);
    }

    /**
     * Calculate the size for given <code>v</code> when using VLong encoding.
     * 
     * @param v
     * @return
     */
    public static int calcVLongSize(long v) {
        int size = 0;
        do {
            v = v >>> 7;
            size++;
        } while (v > 0);
        return size;
    }

    /**
     * Write a float value to the given DataOutput.
     * 
     * @param v
     *            the float value
     * @param out
     *            the OutputStream to which write
     * @throws IOException
     *             if an I/O error occurs
     */
    public static final void writeFloat(float v, OutputStream out)
            throws IOException {
        writeInt(Float.floatToIntBits(v), out);
    }

    /**
     * write a float value to a byte array.
     * 
     * @param bytes
     *            the buffer to be write
     * @param offset
     *            the offset position for buffer
     * @return Return the read long value.
     */
    public static final void writeFloat(float v, byte[] out, int offset) {
        writeInt(Float.floatToIntBits(v), out, offset);
    }

    @Override
    public void writeFloat(float v) throws IOException {
        writeFloat(v, out);
    }

    /**
     * Write a double value to the given DataOutput.
     * 
     * @param v
     *            the double value
     * @param out
     *            the OutputStream to which write
     * @throws IOException
     *             if an I/O error occurs
     */
    public static final void writeDouble(double v, OutputStream out)
            throws IOException {
        writeLong(Double.doubleToLongBits(v), out);
    }

    /**
     * write a double value to a byte array.
     * 
     * @param bytes
     *            the buffer to be write
     * @param offset
     *            the offset position for buffer
     * @return Return the read long value.
     */
    public static final void writeDouble(double v, byte[] out, int offset) {
        writeLong(Double.doubleToLongBits(v), out, offset);
    }

    @Override
    public void writeDouble(double v) throws IOException {
        writeDouble(v, out);
    }

    @Override
    public void writeBytes(String s) throws IOException {
        int len = s.length();
        for (int i = 0; i < len; i++) {
            out.write((byte) s.charAt(i));
        }
    }

    @Override
    public void writeChars(String s) throws IOException {
        int len = s.length();
        for (int i = 0; i < len; i++) {
            int v = s.charAt(i);
            out.write(v & 0xFF);
            out.write((v >>> 8) & 0xFF);
        }
    }

    /**
     * write a String to OutputStream in UTF-8 format.
     * 
     * @param s
     *            the String to write
     * @throws IOException
     *             if an I/O error occurs
     * @throws UnsupportedEncodingException
     *             the encode format is not supported
     */
    public void writeString(String s) throws UnsupportedEncodingException,
            IOException {
        out.write(s.getBytes("utf-8"));
    }

    @Override
    public void flush() throws IOException {
        out.flush();
    }

    /**
     * zf: The default impl in FilterOutputStream is a per-byte one...
     */
    public void write(byte b[], int off, int len) throws IOException {
        out.write(b, off, len);
    }

    @Deprecated
    public void writeUTF(String str) throws IOException {
        int strlen = str.length();
        int utflen = 0;
        int c, count = 0;

        /* use charAt instead of copying String to char array */
        for (int i = 0; i < strlen; i++) {
            c = str.charAt(i);
            if ((c >= 0x0001) && (c <= 0x007F)) {
                utflen++;
            } else if (c > 0x07FF) {
                utflen += 3;
            } else {
                utflen += 2;
            }
        }

        if (utflen > 65535)
            throw new UTFDataFormatException("encoded string too long: "
                    + utflen + " bytes");

        byte[] bytearr = new byte[utflen + 2];

        bytearr[count++] = (byte) ((utflen >>> 0) & 0xFF);
        bytearr[count++] = (byte) ((utflen >>> 8) & 0xFF);

        int i = 0;
        for (i = 0; i < strlen; i++) {
            c = str.charAt(i);
            if (!((c >= 0x0001) && (c <= 0x007F)))
                break;
            bytearr[count++] = (byte) c;
        }

        for (; i < strlen; i++) {
            c = str.charAt(i);
            if ((c >= 0x0001) && (c <= 0x007F)) {
                bytearr[count++] = (byte) c;

            } else if (c > 0x07FF) {
                bytearr[count++] = (byte) (0xE0 | ((c >> 12) & 0x0F));
                bytearr[count++] = (byte) (0x80 | ((c >> 6) & 0x3F));
                bytearr[count++] = (byte) (0x80 | ((c >> 0) & 0x3F));
            } else {
                bytearr[count++] = (byte) (0xC0 | ((c >> 6) & 0x1F));
                bytearr[count++] = (byte) (0x80 | ((c >> 0) & 0x3F));
            }
        }
        out.write(bytearr, 0, utflen + 2);
    }
}
