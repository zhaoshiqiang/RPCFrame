/**
 * @(#)LzoOutputStream.java, 2007-8-18. Copyright 2007 Yodao, Inc. All rights
 *                                      reserved. YODAO
 *                                      PROPRIETARY/CONFIDENTIAL. Use is subject
 *                                      to license terms.
 */
package odis.io;

import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import toolbox.misc.UnitUtils;

/**
 * Outputstream which compress the data during output.
 * 
 * @author river
 */
public class LzoOutputStream extends FilterOutputStream {
    private static final int DEFAULT_BATCH_SIZE = (int) (64 * UnitUtils.K);

    private byte[] buffer;

    private byte[] compressedBuffer;

    private int count;

    /**
     * construct a LzoOutputStream with the given OutputStream and
     * default_batch_size
     * 
     * @param out
     *            the given OutputStream
     */
    public LzoOutputStream(OutputStream out) {
        this(out, DEFAULT_BATCH_SIZE);
    }

    /**
     * construct a LzoOutputStream with the given OutputStream and the given
     * batch_size
     * 
     * @param out
     *            the given OutputStream
     * @param batchSize
     *            the given batchsize
     */
    public LzoOutputStream(OutputStream out, int batchSize) {
        super(out);
        buffer = Limit.createBuffer(batchSize);
        int compressedBufferSize = LzoCompression
                .getCompressBufferSize(batchSize);
        compressedBuffer = Limit.createBuffer(compressedBufferSize);

        count = 0;
    }

    @Override
    public void write(byte[] b, int off, int len) throws IOException {
        while (len > 0) {
            int toCopy = buffer.length - count;
            if (toCopy > len) {
                toCopy = len;
            }
            System.arraycopy(b, off, buffer, count, toCopy);
            off += toCopy;
            len -= toCopy;
            count += toCopy;
            if (count == buffer.length) {
                flushBuffer();
            }
        }
    }

    @Override
    public void write(byte[] b) throws IOException {
        write(b, 0, b.length);
    }

    @Override
    public void write(int b) throws IOException {
        buffer[count++] = (byte) b;
        if (count == buffer.length)
            flushBuffer();
    }

    @Override
    public void close() throws IOException {
        flush();
        super.close();
    }

    @Override
    public void flush() throws IOException {
        if (count > 0) {
            flushBuffer();
        }
        super.flush();
    }

    private void flushBuffer() throws IOException {
        int compressedSize = LzoCompression.compress(buffer, 0, count,
                compressedBuffer);
        if (compressedSize < 0) {
            throw new IOException("lzo compressed failed(rvalue="
                    + compressedSize + ")");
        }

        CDataOutputStream.writeInt(count, out);
        CDataOutputStream.writeInt(compressedSize, out);
        out.write(compressedBuffer, 0, compressedSize);
        count = 0;
    }

}
