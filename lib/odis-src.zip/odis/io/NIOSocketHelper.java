package odis.io;

import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketTimeoutException;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import toolbox.misc.LogFormatter;

/**
 * Socket helper class for non-blocking input/output.
 * 
 * @author river
 */
public class NIOSocketHelper implements Closeable {
    private static Logger LOG = LogFormatter.getLogger(NIOSocketHelper.class);

    private final SocketAddress remote;

    private final SocketChannel channel;

    private final Selector connSelector;

    private TimeoutPolicy timeoutPolicy = TimeoutPolicy.RESPONSE_IN_TIME;

    private long timeout;

    private boolean closed;

    private NIOInputStream in;

    private NIOOutputStream out;

    /**
     * construct a <code> NIOSocketHelper </code> with the given hostname, port
     * and timeout
     * 
     * @param hostname
     *            the given hostname for connect
     * @param port
     *            the given port for connect
     * @param timeout
     *            the given timeput
     * @throws IOException
     *             any I/O error occur
     */
    public NIOSocketHelper(String hostname, int port, long timeout)
            throws IOException {
        this(new InetSocketAddress(hostname, port), timeout);
    }

    @Override
    public int hashCode() {
        return remote.hashCode();
    }

    /**
     * construct a <code> NIOSocketHelper </code> with the given
     * <code>InetSocketAddress</code> and timeout
     * 
     * @param addr
     *            the given InetSocketAddress
     * @param timeout
     *            the given timeout
     * @throws IOException
     *             any I/O error occur
     */
    public NIOSocketHelper(InetSocketAddress addr, long timeout)
            throws IOException {
        this.remote = addr;
        this.timeout = timeout;

        boolean connectSuccess = false;
        channel = SocketChannel.open();
        try {
            channel.configureBlocking(false);
            connSelector = Selector.open();
            try {
                channel.connect(remote);
                channel.register(connSelector, SelectionKey.OP_CONNECT);
                int selected = connSelector.select(timeout);
                if (selected == 0) {
                    throw new SocketTimeoutException("Timeout(" + timeout
                            + "ms) waiting to connect to " + remote);
                } else {
                    if (!channel.finishConnect()) {
                        throw new IOException("connection failed though "
                                + "OP_CONNECT selection key ready.");
                    } else {
                        connectSuccess = true;
                    }
                }
            } finally {
                connSelector.close();
            }
            closed = false;
        } catch (IOException e) {
            LOG.log(Level.WARNING,
                    "Failed to connect to " + remote + ": " + e.toString());
            throw e;
        } finally {
            if (!connectSuccess) {
                channel.close();
            }
        }
    }

    /**
     * construct a <code> NIOSocketHelper </code> with the given
     * <code>SocketChannel</code> and timeout
     * 
     * @param socketChannel
     *            the given socketChannel
     * @param timeout
     *            the given timeout
     * @throws IOException
     *             any I/O error occur
     */
    public NIOSocketHelper(SocketChannel socketChannel, int timeout)
            throws IOException {
        if (socketChannel == null) {
            throw new NullPointerException("socket channel is null");
        }
        connSelector = null;
        this.channel = socketChannel;
        this.timeout = timeout;
        this.remote = channel.socket().getRemoteSocketAddress();

        if (!this.channel.isConnected()) {
            throw new IOException("socket channel is not connected");
        }
        if (this.channel.isBlocking()) {
            this.channel.configureBlocking(false);
        }
        closed = false;
    }

    /**
     * get the socketAddress
     * 
     * @return the <code>SocketAddress</code>
     */
    public SocketAddress getRemoteAddress() {
        return remote;
    }

    /**
     * get the socket
     * 
     * @return the socket
     */
    public Socket getSocket() {
        return channel.socket();
    }

    /**
     * get the SocketChannel
     * 
     * @return the SocketChannel
     */
    public SocketChannel getChannel() {
        return channel;
    }

    /**
     * get the timeout
     * 
     * @return the timeout
     */
    public long getTimeout() {
        return timeout;
    }

    /**
     * set the timeout
     * 
     * @param timeout
     *            the given timeout
     */
    public void setTimeout(long timeout) {
        this.timeout = timeout;
    }

    public TimeoutPolicy getTimeoutPolicy() {
        return timeoutPolicy;
    }

    public void setTimeoutPolicy(TimeoutPolicy timeoutPolicy) {
        this.timeoutPolicy = timeoutPolicy;
    }

    /**
     * close the <code>NIOSocketHelper</code>
     */
    public void close() throws IOException {
        if (closed) {
            return;
        }

        if (in != null) {
            in.selector.close();
        }

        if (out != null) {
            out.selector.close();
        }
        if (connSelector != null) {
            connSelector.close();
        }

        channel.close();
        closed = true;
    }

    private void assertOpened() throws IOException {
        if (closed) {
            throw new IOException("socket is closed in previous operation");
        }
    }

    /**
     * get the InputStream of <code>NIOSocketHelper</code>
     * 
     * @return the InputStream
     * @throws IOException
     */
    public InputStream getInputStream() throws IOException {
        assertOpened();
        if (in == null) {
            in = new NIOInputStream();
        }
        return in;
    }

    /**
     * Get an OutputStream backed by the channel. The advantage of this stream
     * over an ordinary socket's output stream is that this stream supports
     * write timeout.
     * 
     * @return
     * @throws IOException
     */
    public OutputStream getOutputStream() throws IOException {
        assertOpened();
        if (out == null) {
            out = new NIOOutputStream();
        }
        return out;
    }

    private class NIOInputStream extends InputStream {
        private ByteBuffer buffer;

        private Selector selector;

        public NIOInputStream() throws IOException {
            buffer = ByteBuffer.allocate(Long.SIZE / 8);
            selector = Selector.open();
            channel.register(selector, SelectionKey.OP_READ);
        }

        @Override
        public void close() throws IOException {
            NIOSocketHelper.this.close();
            super.close();
        }

        private int read(ByteBuffer buffer) throws IOException {
            int read = 0;
            long startTime = System.currentTimeMillis();
            while (buffer.hasRemaining()) {
                long toWait;
                if (timeout == 0) {
                    toWait = 0;
                } else {
                    switch (timeoutPolicy) {
                        case COMPLETE_IN_TIME:
                            toWait = timeout
                                    - (System.currentTimeMillis() - startTime);
                            if (toWait <= 0) {
                                throw new SocketTimeoutException(
                                        "socket read from " + remote
                                                + " timeout(" + timeout + ")");
                            }
                            break;
                        default:
                            toWait = timeout;
                    }
                }
                if (selector.select(toWait) > 0) {
                    for (Iterator<SelectionKey> it = selector.selectedKeys().iterator(); it.hasNext();) {
                        SelectionKey key = it.next();
                        if (!key.isValid()) {
                            LOG.warning("Connection from "
                                    + remote
                                    + " is invalid, maybe the remote socket is "
                                    + "closed.");
                            if (read == 0) {
                                return -1;
                            } else {
                                return read;
                            }
                        }

                        if (key.isReadable()) {
                            it.remove();
                            int numBytesRead = channel.read(buffer);
                            if (numBytesRead == -1) {
                                if (read == 0) {
                                    return -1;
                                } else {
                                    return read;
                                }
                            }
                            read += numBytesRead;
                            break;
                        }
                    }
                } else {
                    // select will quit if the current thread is interrupted, 
                    // this usually because we want to quit, so throw an 
                    // exception instead of retry.
                    throw new SocketTimeoutException("socket read from "
                            + remote + " timeout(" + timeout + ")");
                }
            }
            if (read == 0) {
                return -1;
            } else {
                return read;
            }
        }

        @Override
        public int read(byte[] b, int off, int len) throws IOException {
            // sanity check
            if (off < 0 || off + len > b.length) {
                throw new ArrayIndexOutOfBoundsException(
                        "bad offset ( offset = " + off + ", len = " + len
                                + ", buffer_size = " + b.length);
            }

            assertOpened();

            if (len == 0) {
                return 0;
            }
            if (len <= Long.SIZE / 8) {
                buffer.clear();
                buffer.limit(len);
                int read = read(buffer);
                if (read < 0) {
                    return read;
                }
                byte[] buf = buffer.array();
                for (int i = 0; i < len; i++) {
                    b[off + i] = buf[i];
                }
                return read;
            } else {
                return read(ByteBuffer.wrap(b, off, len));
            }
        }

        @Override
        public int read(byte[] b) throws IOException {
            return read(b, 0, b.length);
        }

        @Override
        public int read() throws IOException {
            buffer.clear();
            buffer.limit(1);
            int ret = read(buffer);
            if (ret < 0) {
                return ret;
            }
            return buffer.array()[0] & 0xff;
        }
    }

    private class NIOOutputStream extends OutputStream {

        private ByteBuffer buffer;

        private Selector selector;

        public NIOOutputStream() throws IOException {
            buffer = ByteBuffer.allocate(Long.SIZE / 8);
            selector = Selector.open();
            channel.register(selector, SelectionKey.OP_WRITE);
        }

        @Override
        public void close() throws IOException {
            NIOSocketHelper.this.close();
            super.close();
        }

        private void write(ByteBuffer buffer) throws IOException {
            long startTime = System.currentTimeMillis();
            while (buffer.hasRemaining()) {
                long toWait;
                if (timeout == 0) {
                    toWait = 0;
                } else {
                    switch (timeoutPolicy) {
                        case COMPLETE_IN_TIME:
                            toWait = timeout
                                    - (System.currentTimeMillis() - startTime);
                            if (toWait <= 0) {
                                throw new SocketTimeoutException(
                                        "socket write to " + remote
                                                + " timeout(" + timeout + ")");
                            }
                            break;
                        default:
                            toWait = timeout;
                    }
                }
                if (selector.select(toWait) > 0) {
                    for (Iterator<SelectionKey> it = selector.selectedKeys().iterator(); it.hasNext();) {
                        SelectionKey key = it.next();
                        if (key.isWritable()) {
                            it.remove();
                            channel.write(buffer);
                            break;
                        }
                    }
                } else {
                    // select will quit if the current thread is interrupted, 
                    // this usually because we want to quit, so throw an 
                    // exception instead of retry.
                    throw new SocketTimeoutException("socket write to "
                            + remote + " timeout(" + timeout + ")");
                }
            }
        }

        @Override
        public void write(byte[] b, int off, int len) throws IOException {
            // sanity check
            if (off < 0 || off + len > b.length) {
                throw new ArrayIndexOutOfBoundsException(
                        "bad offset ( offset = " + off + ", len = " + len
                                + ", buffer_size = " + b.length);
            }

            assertOpened();

            if (len == 0) {
                return;
            }

            if (len <= Long.SIZE / 8) {
                buffer.clear();
                buffer.limit(len);
                byte[] buf = buffer.array();
                for (int i = 0; i < len; i++) {
                    buf[i] = b[off + i];
                }
                write(buffer);
            } else {
                write(ByteBuffer.wrap(b, off, len));
            }
        }

        @Override
        public void write(byte[] b) throws IOException {
            write(b, 0, b.length);
        }

        @Override
        public void write(int b) throws IOException {
            buffer.clear();
            buffer.array()[0] = (byte) b;
            buffer.limit(1);
            write(buffer);
        }

    }

}
