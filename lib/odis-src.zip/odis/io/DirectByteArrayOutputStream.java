/*
 * Copyright (c) 2006, Outfox Team.
 */
package odis.io;

import java.io.ByteArrayOutputStream;

/**
 * A subclass of ByteArrayOutputStream, add the function to directly get buffer
 * and buffer size
 * 
 * @author guodd
 */
public class DirectByteArrayOutputStream extends ByteArrayOutputStream {
    /**
     * Constructor with default size
     */
    public DirectByteArrayOutputStream() {
        super();
    }

    /**
     * Constructor
     * 
     * @param size
     *            the size of Array
     */
    public DirectByteArrayOutputStream(int size) {
        super(size);
    }

    /**
     * Constructor
     * 
     * @param buf
     * @param size
     */
    public DirectByteArrayOutputStream(byte[] buf) {
        this.buf = buf;
        this.count = 0;
    }

    /**
     * Get the Array buffer
     * 
     * @return the buffer
     */
    public byte[] getBuffer() {
        return buf;
    }

    /**
     * get the buffer size
     * 
     * @return the buffer size
     */
    public int getBufferSize() {
        return count;
    }

}
