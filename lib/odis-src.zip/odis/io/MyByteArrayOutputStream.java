/**
 * @(#)MyByteArrayOutputStream.java, 2009-7-7. Copyright 2009 Yodao, Inc. All
 *                                             rights reserved. YODAO
 *                                             PROPRIETARY/CONFIDENTIAL. Use is
 *                                             subject to license terms.
 */
package odis.io;

import java.io.ByteArrayOutputStream;

/**
 * 一个可以获取和设置 buf 的 {@link ByteArrayOutputStream}
 * 
 * @author jiangfy
 */
public class MyByteArrayOutputStream extends ByteArrayOutputStream {

    public MyByteArrayOutputStream() {
        super();
    }

    /**
     * construct a MyByteArrayOutputStream with the given buf
     * 
     * @param buf
     *            the given buffer
     */
    public MyByteArrayOutputStream(byte[] buf) {
        this.buf = buf;
        this.count = 0;
    }

    /**
     * construct a MyByteArrayOutputStream with the given buffer and offset
     * 
     * @param buf
     *            the given buffer
     * @param off
     *            the givem offset
     */
    public MyByteArrayOutputStream(byte[] buf, int off) {
        this.buf = buf;
        this.count = off;
    }

    /**
     * 获取缓存的 buf，注意，使用的时候要跟 {@link #size()} 一起使用，因为这里返回的是 原始的 buf，并没有根据实际的数据做剪裁
     * 
     * @return
     */
    public synchronized byte[] getData() {
        return buf;
    }

    /**
     * 设置缓存用 buf
     * 
     * @param buf
     */
    public synchronized void setBuffer(byte[] buf) {
        this.buf = buf;
        this.count = 0;
    }

    /**
     * 设置缓存用 buf
     * 
     * @param buf
     */
    public synchronized void setBuffer(byte[] buf, int off) {
        this.buf = buf;
        this.count = off;
    }
}
