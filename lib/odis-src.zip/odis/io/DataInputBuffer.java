/**
 * Copyright 2005 The Apache Software Foundation Licensed under the Apache
 * License, Version 2.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0 Unless required by applicable law
 * or agreed to in writing, software distributed under the License is
 * distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

package odis.io;

import java.io.DataInput;
import java.io.EOFException;
import java.io.IOException;

import toolbox.text.util.HexString;

/**
 * A reusable {@link DataInput} implementation that reads from an in-memory
 * buffer.
 * <p>
 * This saves memory over creating a new DataInputStream and
 * ByteArrayInputStream each time data is read.
 * <p>
 * Typical usage is something like the following:
 * 
 * <pre>
 * 
 * DataInputBuffer buffer = new DataInputBuffer();
 * while (... loop condition ...) {
 *   byte[] data = ... get data ...;
 *   int dataLength = ... get data length ...;
 *   buffer.reset(data, dataLength);
 *   ... read buffer using DataInput methods ...
 * }
 * </pre>
 * 
 * @author Doug Cutting
 */
public class DataInputBuffer implements DataInput {
    private static final byte[] EMPTY_BYTES = new byte[0];

    private byte[] buffer;

    private int limit;

    private int offset;

    /**
     * Constructs a new empty buffer.
     */
    public DataInputBuffer() {
        buffer = EMPTY_BYTES;
        limit = 0;
        offset = 0;
    }

    /**
     * Constructs with a given buffer
     * 
     * @param data
     *            the given buffer
     */
    public DataInputBuffer(byte[] data) {
        reset(data, 0, data.length);
    }

    /**
     * Constructor
     * 
     * @param data
     *            input Array byte dataBuffer
     * @param start
     *            the offset position for read
     * @param length
     *            the read length
     */
    public DataInputBuffer(byte[] data, int start, int length) {
        reset(data, start, length);
    }

    /**
     * Constructor
     * 
     * @param obuf
     *            the outputBuffer for data to read
     */
    public DataInputBuffer(DataOutputBuffer obuf) {
        reset(obuf.getData(), 0, obuf.size());
    }

    /**
     * reset the <code>DataInputBuffer</code> with an empty buffer
     */
    public void reset() {
        reset(EMPTY_BYTES, 0, 0);
    }

    /**
     * Reset the <code>DataInputBuffer</code> with a given
     * <code>DataOutputBuffer</code>
     * 
     * @param obuf
     */
    public void reset(DataOutputBuffer obuf) {
        reset(obuf.getData(), 0, obuf.size());
    }

    /**
     * Resets the data that the buffer reads.
     * 
     * @param input
     *            the given buffer
     * @param length
     *            the buffer length
     */
    public void reset(byte[] input, int length) {
        reset(input, 0, length);
    }
    /**
     * reset the data with the given DataInput and size
     * 
     * @param in  the given DataInput
     * @param size the size
     * @throws IOException any I/O error occur
     */
    public void reset(DataInput in, int size) throws IOException {
        limit = 0;
        offset = 0;
        fill(in, size);
    }

    /**
     * fill the buffer with the DataInput
     * 
     * @param in
     *            the DataInput
     * @param size
     *            the reset size
     * @throws IOException
     *             any I/O error occur
     */
    public void fill(DataInput in, int size) throws IOException {
        if (buffer.length - limit < size) {
            Limit.checkBufferSize(size);
            byte[] newBuffer = Limit.createBuffer(limit + size);
            System.arraycopy(buffer, 0, newBuffer, 0, limit);
            buffer = newBuffer;
        }
        in.readFully(buffer, limit, size);
        limit += size;
    }

    /**
     * reset the buffer with the byte Array Data
     * 
     * @param data
     *            the Array Data
     * @param start
     *            the offset size
     * @param length
     *            the DataArray length for reset
     */
    public void reset(byte[] data, int start, int length) {
        this.buffer = data;
        this.offset = start;
        this.limit = offset + length;
        if (limit > buffer.length) {
            throw new IndexOutOfBoundsException(limit + ">" + buffer.length);
        }
    }

    /**
     * get the buffer
     * 
     * @return byte[] buffer
     */
    public byte[] getBuffer() {
        return buffer;
    }

    /**
     * return the current position of read
     * 
     * @return current position
     */
    public int getPosition() {
        return offset;
    }

    /**
     * return the reside position of read
     * 
     * @return the reside size
     */
    public int getSize() {
        return limit - offset;
    }

    /**
     * return the limit of buffer
     * 
     * @return the limit
     */
    public int getLimit() {
        return limit;
    }

    private void indexOutOfBounds(int len) throws EOFException {
        StringBuilder builder = new StringBuilder();
        builder.append("buffer=[").append(
                HexString.bytesToHex(buffer, 0, limit));
        builder.append("], offset=").append(offset).append(",len=").append(len);
        throw new EOFException(builder.toString());
    }

    @Override
    public void readFully(byte[] b) throws EOFException {
        if (offset + b.length > limit) {
            indexOutOfBounds(b.length);
        }

        System.arraycopy(buffer, offset, b, 0, b.length);
        offset += b.length;
    }

    @Override
    public void readFully(byte[] b, int off, int len) throws EOFException {
        if (offset + len > limit) {
            indexOutOfBounds(len);
        }
        System.arraycopy(buffer, offset, b, off, len);
        offset += len;
    }

    /**
     * skip the given byte
     * 
     * @return the really skipped byte
     */
    public int skip(int n) {
        int newOffset = offset + n;
        if (newOffset > limit) {
            newOffset = limit;
        }
        int skiped = newOffset - offset;
        offset = newOffset;
        return skiped;
    }

    @Override
    public int skipBytes(int n) {
        int newOffset = offset + n;
        if (newOffset > limit)
            newOffset = limit;
        int skiped = newOffset - offset;
        offset = newOffset;
        return skiped;
    }

    @Override
    public boolean readBoolean() throws EOFException {
        if (offset + 1 > limit) {
            indexOutOfBounds(1);
        }
        return buffer[offset++] != 0;
    }

    @Override
    public byte readByte() throws EOFException {
        if (offset + 1 > limit) {
            indexOutOfBounds(1);
        }
        return buffer[offset++];
    }

    @Override
    public int readUnsignedByte() throws EOFException {
        if (offset + 1 > limit) {
            indexOutOfBounds(1);
        }
        int r = buffer[offset++];
        r = r & 0xff;
        return r;
    }

    @Override
    public short readShort() throws EOFException {
        int newOffset = offset + 2;
        if (newOffset > limit) {
            indexOutOfBounds(2);
        }
        short r = (short) (((buffer[offset + 1] & 0xff) << 8) | (buffer[offset] & 0xff));
        offset = newOffset;
        return r;
    }

    @Override
    public int readUnsignedShort() throws EOFException {
        int newOffset = offset + 2;
        if (newOffset > limit) {
            indexOutOfBounds(2);
        }
        int r = ((buffer[offset + 1] & 0xff) << 8) | (buffer[offset] & 0xff);
        offset = newOffset;
        return r;
    }

    @Override
    public char readChar() throws EOFException {
        int newOffset = offset + 2;
        if (newOffset > limit) {
            indexOutOfBounds(2);
        }
        int r = ((buffer[offset + 1] & 0xff) << 8) | (buffer[offset] & 0xff);
        offset = newOffset;
        return (char) r;
    }

    @Override
    public int readInt() throws EOFException {
        int newOffset = offset + 4;
        if (newOffset > limit) {
            indexOutOfBounds(4);
        }
        int r = (((buffer[offset] & 0xff)) + ((buffer[offset + 1] & 0xff) << 8)
                + ((buffer[offset + 2] & 0xff) << 16) + ((buffer[offset + 3] & 0xff) << 24));
        offset = newOffset;
        return r;
    }

    @Override
    public long readLong() throws EOFException {
        int newOffset = offset + 8;
        if (newOffset > limit) {
            indexOutOfBounds(8);
        }
        long r = (((long) buffer[offset + 7] << 56)
                + ((long) (buffer[offset + 6] & 0xff) << 48)
                + ((long) (buffer[offset + 5] & 0xff) << 40)
                + ((long) (buffer[offset + 4] & 0xff) << 32)
                + ((long) (buffer[offset + 3] & 0xff) << 24)
                + ((buffer[offset + 2] & 0xff) << 16)
                + ((buffer[offset + 1] & 0xff) << 8) + ((buffer[offset] & 0xff) << 0));
        offset = newOffset;
        return r;
    }

    @Override
    public float readFloat() throws EOFException {
        int newOffset = offset + 4;
        if (newOffset > limit) {
            indexOutOfBounds(4);
        }
        int r = (((buffer[offset] & 0xff)) + ((buffer[offset + 1] & 0xff) << 8)
                + ((buffer[offset + 2] & 0xff) << 16) + ((buffer[offset + 3] & 0xff) << 24));
        offset = newOffset;
        return Float.intBitsToFloat(r);
    }

    @Override
    public double readDouble() throws EOFException {
        int newOffset = offset + 8;
        if (newOffset > limit) {
            indexOutOfBounds(8);
        }
        long r = (((long) buffer[offset + 7] << 56)
                + ((long) (buffer[offset + 6] & 0xff) << 48)
                + ((long) (buffer[offset + 5] & 0xff) << 40)
                + ((long) (buffer[offset + 4] & 0xff) << 32)
                + ((long) (buffer[offset + 3] & 0xff) << 24)
                + ((buffer[offset + 2] & 0xff) << 16)
                + ((buffer[offset + 1] & 0xff) << 8) + ((buffer[offset] & 0xff) << 0));
        offset = newOffset;
        return Double.longBitsToDouble(r);
    }

    @Override
    public String readLine() throws EOFException {
        throw new AbstractMethodError("not implemented");
    }

    @Override
    public String readUTF() throws IOException {
        return java.io.DataInputStream.readUTF(this);
    }

    /**
     * Reads a int value as format Vint
     * 
     * @return the <code>int</code> value read.
     * @exception EOFException
     *                if this stream reaches the end before reading all the
     *                bytes.
     * @exception IOException
     *                if an I/O error occurs.
     */
    public int readVInt() throws EOFException {
        if (offset < limit) {
            byte b = buffer[offset++];
            int i = b & 0x7F;

            for (int shift = 7; (b & 0x80) != 0 && offset < limit; shift += 7, offset++) {
                b = buffer[offset];
                i |= (b & 0x7F) << shift;
            }
            return i;
        } else {
            throw new EOFException("no more data in buffer");
        }

    }

}
