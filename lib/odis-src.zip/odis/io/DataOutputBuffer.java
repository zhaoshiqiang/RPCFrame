/**
 * Copyright 2005 The Apache Software Foundation Licensed under the Apache
 * License, Version 2.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0 Unless required by applicable law
 * or agreed to in writing, software distributed under the License is
 * distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

package odis.io;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.io.UTFDataFormatException;
import java.util.logging.Logger;

import toolbox.misc.LogFormatter;
import toolbox.misc.UnitUtils;

/**
 * A reusable {@link DataOutput} implementation that writes to an in-memory
 * buffer.
 * <p>
 * This saves memory over creating a new DataOutputStream and
 * ByteArrayOutputStream each time data is written.
 * <p>
 * Typical usage is something like the following:
 * 
 * <pre>
 * 
 *  DataOutputBuffer buffer = new DataOutputBuffer();
 *  while (... loop condition ...) {
 *    buffer.reset();
 *    ... write buffer using DataOutput methods ...
 *    byte[] data = buffer.getData();
 *    int dataLength = buffer.getLength();
 *    ... write data to its ultimate destination ...
 *  }
 * </pre>
 * 
 * <code>
 * river 2006-10-21 Limits the max buffer size to 500M.
 * </code>
 * 
 * @author Doug Cutting
 */
public class DataOutputBuffer implements DataOutput {
    public static final Logger LOG = LogFormatter.getLogger(DataOutputBuffer.class);

    private static int DOUBLE_LIMIT = 16 * 1024 * 1024;

    private static int RESET_CHECK_LIMIT = 4 * 1024 * 1024;

    private byte[] buffer;

    private int offset;

    private long totalResetSize = 0;

    private int resetCount = 1; // we start counter from 1 to avoid div by zero

    /**
     * Constructor
     */
    public DataOutputBuffer() {
        this(32);
    }

    /**
     * Constructor
     * 
     * @param initialCapacity
     *            the Buffer size
     */
    public DataOutputBuffer(int initialCapacity) {
        buffer = new byte[initialCapacity];
        offset = 0;
    }

    /**
     * Returns the current contents of the buffer.
     * 
     * @return current buffer
     */
    public byte[] getData() {
        return buffer;
    }

    /**
     * Returns the current data size of the buffer.
     * 
     * @return the datasize
     */
    public int size() {
        return offset;
    }

    /**
     * Set the size of the buffer.
     * 
     * @param vl
     *            The new size of the buffer
     */
    public void setSize(int vl) {
        ensureCapacity(vl);
        offset = vl;
    }

    /**
     * Resets the buffer to empty.
     */
    public DataOutputBuffer reset() {
        // record the statistic data for reset
        totalResetSize += offset;
        resetCount++;

        offset = 0;

        return this;
    }

    /**
     * Reset the buffer to empty, limit the capacity to limitSize.
     * 
     * @param limitSize
     * @return
     */
    public DataOutputBuffer reset(int limitSize) {
        if (buffer.length > limitSize) {
            buffer = Limit.createBuffer(limitSize);
        }
        return reset();
    }

    /**
     * According to the <code>expectSize</code>, modify the buffer size and
     * reset
     * 
     * @return
     */
    public DataOutputBuffer cannyReset() {
        if (offset > RESET_CHECK_LIMIT) {
            int expectSize = (int) (totalResetSize / resetCount) * 2;
            if (expectSize < RESET_CHECK_LIMIT) {
                expectSize = RESET_CHECK_LIMIT;
            }
            if (buffer.length - expectSize > UnitUtils.M) {
                // LOG.info("threshold buffer to size " + expectSize);
                buffer = Limit.createBuffer(expectSize);
            }
        }
        return reset();
    }

    /**
     * write the given length from DataInput
     * 
     * @param in
     *            the DataInput
     * @param length
     *            write length
     * @throws IOException
     *             any I/O error occur
     */
    public void write(DataInput in, int length) throws IOException {
        int newCount = offset + length;
        ensureCapacity(newCount);
        in.readFully(buffer, offset, length);
        offset = newCount;
    }

    /**
     * Ensure the freeSpaxe of Buffer
     * 
     * @param freeSpace
     *            size of freeSpace to ensure
     */
    public void ensureFreeSpace(int freeSpace) {
        ensureCapacity(offset + freeSpace);
    }

    /**
     * Ensure the capacity of Buffer
     * 
     * @param newCapacity
     *            capacity of Buffer to ensure
     */
    private void ensureCapacity(int newCapacity) {
        Limit.checkBufferSize(newCapacity);

        if (buffer.length < newCapacity) {
            if (newCapacity > DOUBLE_LIMIT) {
                LOG.info("Enlarge DataOutputBuffer#" + this.hashCode()
                        + " from " + buffer.length + " to size " + newCapacity);
            }
            int newSize = (buffer.length < DOUBLE_LIMIT) ? buffer.length << 1
                    : (buffer.length + DOUBLE_LIMIT);
            if (newSize < newCapacity)
                newSize = newCapacity;
            byte[] newBuffer;
            try {
                newBuffer = new byte[newSize];
            } catch (Throwable t) {
                throw new BufferOverflowException("cannot allocate memory of "
                        + "size " + newSize);
            }
            System.arraycopy(buffer, 0, newBuffer, 0, offset);
            buffer = newBuffer;
        }
    }

    /**
     * Skip the given size in buffer
     * 
     * @param size
     *            the given size
     */
    public void advance(int size) {
        int newOffset = offset + size;
        if (buffer.length < newOffset)
            ensureCapacity(newOffset);
        offset = newOffset;
    }

    @Override
    public void write(int v) {
        int newOffset = offset + 1;
        if (buffer.length < newOffset)
            ensureCapacity(newOffset);

        buffer[offset] = (byte) v;
        offset = newOffset;
    }

    @Override
    public void write(byte[] b) {
        int newOffset = offset + b.length;
        if (buffer.length < newOffset)
            ensureCapacity(newOffset);

        System.arraycopy(b, 0, buffer, offset, b.length);
        offset = newOffset;
    }

    @Override
    public void write(byte[] b, int off, int len) {
        int newOffset = offset + len;
        if (buffer.length < newOffset)
            ensureCapacity(newOffset);
        System.arraycopy(b, off, buffer, offset, len);
        offset = newOffset;
    }

    @Override
    public void writeBoolean(boolean v) {
        int newOffset = offset + 1;
        if (buffer.length < newOffset)
            ensureCapacity(newOffset);
        buffer[offset] = v ? (byte) 1 : (byte) 0;
        offset = newOffset;
    }

    @Override
    public void writeByte(int v) {
        int newOffset = offset + 1;
        if (buffer.length < newOffset)
            ensureCapacity(newOffset);
        buffer[offset] = (byte) v;
        offset = newOffset;
    }

    @Override
    public void writeShort(int v) {
        int newOffset = offset + 2;
        if (buffer.length < newOffset)
            ensureCapacity(newOffset);

        buffer[offset] = (byte) (v & 0xff);
        buffer[offset + 1] = (byte) ((v >>> 8) & 0xff);
        offset = newOffset;
    }

    @Override
    public void writeChar(int v) {
        int newOffset = offset + 2;
        if (buffer.length < newOffset)
            ensureCapacity(newOffset);

        buffer[offset] = (byte) (v & 0xff);
        buffer[offset + 1] = (byte) ((v >>> 8) & 0xff);
        offset = newOffset;
    }

    @Override
    public void writeInt(int v) {
        int newOffset = offset + 4;
        if (buffer.length < newOffset)
            ensureCapacity(newOffset);

        buffer[offset] = (byte) (v >>> 0);
        buffer[offset + 1] = (byte) (v >>> 8);
        buffer[offset + 2] = (byte) (v >>> 16);
        buffer[offset + 3] = (byte) (v >>> 24);
        offset = newOffset;
    }

    @Override
    public void writeLong(long v) {
        int newOffset = offset + 8;
        if (buffer.length < newOffset) {
            ensureCapacity(newOffset);
        }

        buffer[offset] = (byte) (v >>> 0);
        buffer[offset + 1] = (byte) (v >>> 8);
        buffer[offset + 2] = (byte) (v >>> 16);
        buffer[offset + 3] = (byte) (v >>> 24);
        buffer[offset + 4] = (byte) (v >>> 32);
        buffer[offset + 5] = (byte) (v >>> 40);
        buffer[offset + 6] = (byte) (v >>> 48);
        buffer[offset + 7] = (byte) (v >>> 56);
        offset = newOffset;
    }

    @Override
    public void writeFloat(float v) {
        writeInt(Float.floatToIntBits(v));
    }

    @Override
    public void writeDouble(double v) {
        writeLong(Double.doubleToLongBits(v));
    }

    @Override
    public void writeBytes(String s) {
        int len = s.length();
        int newOffset = offset + len;
        if (buffer.length < newOffset)
            ensureCapacity(newOffset);
        for (int i = 0; i < len; i++) {
            buffer[offset + i] = (byte) s.charAt(i);
        }
        offset = newOffset;
    }

    @Override
    public void writeChars(String s) {
        int len = s.length();
        ensureCapacity(offset + len * 2);
        for (int i = 0; i < len; i++) {
            int v = s.charAt(i);
            buffer[offset++] = (byte) (v & 0xFF);
            buffer[offset++] = (byte) ((v >>> 8) & 0xFF);
        }
    }

    /**
     * Writes an <code>int</code> value to Buffer as format of VInt
     * 
     * @param v
     *            the <code>int</code> value to written
     */
    public void writeVInt(int v) {
        while ((v & ~0x7F) != 0) {
            if (buffer.length == offset) {
                ensureCapacity(offset + 1);
            }
            buffer[offset++] = (byte) ((v & 0x7f) | 0x80);
            v >>>= 7;
        }
        if (buffer.length == offset) {
            ensureCapacity(offset + 1);
        }
        buffer[offset++] = (byte) v;
    }

    /**
     * Gets the size of an <code>int</code> as format of VInt
     * 
     * @param v
     *            the <code>int</code> value
     */
    public static int getVIntSize(int v) {
        int size = 0;
        do {
            v = v >>> 7;
            size++;
        } while (v > 0);
        return size;
    }

    @Deprecated
    public void writeUTF(String str) throws UTFDataFormatException {
        int strlen = str.length();
        int utflen = 0;
        int c, count = 0;

        /* use charAt instead of copying String to char array */
        for (int i = 0; i < strlen; i++) {
            c = str.charAt(i);
            if ((c >= 0x0001) && (c <= 0x007F)) {
                utflen++;
            } else if (c > 0x07FF) {
                utflen += 3;
            } else {
                utflen += 2;
            }
        }

        if (utflen > 65535)
            throw new UTFDataFormatException("encoded string too long: "
                    + utflen + " bytes");

        byte[] bytearr = new byte[utflen + 2];

        bytearr[count++] = (byte) ((utflen >>> 0) & 0xFF);
        bytearr[count++] = (byte) ((utflen >>> 8) & 0xFF);

        int i = 0;
        for (i = 0; i < strlen; i++) {
            c = str.charAt(i);
            if (!((c >= 0x0001) && (c <= 0x007F)))
                break;
            bytearr[count++] = (byte) c;
        }

        for (; i < strlen; i++) {
            c = str.charAt(i);
            if ((c >= 0x0001) && (c <= 0x007F)) {
                bytearr[count++] = (byte) c;

            } else if (c > 0x07FF) {
                bytearr[count++] = (byte) (0xE0 | ((c >> 12) & 0x0F));
                bytearr[count++] = (byte) (0x80 | ((c >> 6) & 0x3F));
                bytearr[count++] = (byte) (0x80 | ((c >> 0) & 0x3F));
            } else {
                bytearr[count++] = (byte) (0xC0 | ((c >> 6) & 0x1F));
                bytearr[count++] = (byte) (0x80 | ((c >> 0) & 0x3F));
            }
        }

        write(bytearr, 0, utflen + 2);
    }
}
