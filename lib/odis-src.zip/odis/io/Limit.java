package odis.io;

/**
 * Set and check the size limit of data in memory. We also support safe creation
 * of buffer.
 * 
 * @author river
 */
public class Limit {
    // in memory buffer size limit
    private static int BUFFER_LIMIT = 2000 * 1024 * 1024;

    // in memory object size limit
    private static int OBJECT_LIMIT = 100 * 1024 * 1024;

    // in memory object array length limit
    private static int ARRAY_LIMIT = 1024 * 1024;

    public static void setBufferLimit(int value) {
        BUFFER_LIMIT = value;
    }

    public static int getBufferLimit() {
        return BUFFER_LIMIT;
    }

    public static void setArrayLimit(int value) {
        ARRAY_LIMIT = value;
    }

    public static int getArrayLimit() {
        return ARRAY_LIMIT;
    }

    /**
     * Check if the size is positive or zero, and if the size is smaller or
     * equal to the limit.
     * 
     * @param name
     *            the resource name
     * @param limit
     *            the limit for check
     * @param size
     *            the size to be checked
     * @throws BufferOverflowException
     *             throws BufferOverflowException if less than zero or bigger
     *             than <code>limit</code>
     */
    public static void check(String name, long limit, long size) {
        if (size > limit || size < 0) {
            throw new BufferOverflowException("invalid size for resource "
                    + name + "(limit=" + limit + "):" + size);
        }
    }

    /**
     * Check if the size is positive or zero, and if the size is smaller than
     * BUFFER_LIMIT
     * 
     * @param size
     *            the size to be checked
     * @throws BufferOverflowException
     *             throws BufferOverflowException if less than zero or bigger
     *             than BUFFER_LIMIT
     */
    public static void checkBufferSize(int size) {
        if (size > BUFFER_LIMIT || size < 0) {
            throw new BufferOverflowException("invalid buffer size(limit="
                    + BUFFER_LIMIT + "): " + size);
        }
    }

    /**
     * Check if the size is positive or zero, and if the size is smaller than
     * ARRAY_LIMIT
     * 
     * @param size
     *            the size to be checked
     * @throws BufferOverflowException
     *             throws BufferOverflowException if less than zero or bigger
     *             than ARRAY_LIMIT
     */
    public static void checkArraySize(int size) {
        if (size > ARRAY_LIMIT || size < 0) {
            throw new BufferOverflowException("invalid array size(limit="
                    + ARRAY_LIMIT + "): " + size);
        }
    }

    /**
     * Check if the size is positive or zero, and if the size is smaller than
     * OBJECT_LIMIT
     * 
     * @param size
     *            the size to be checked
     * @throws BufferOverflowException
     *             if less than zero or bigger than OBJECT_LIMIT
     */
    public static void checkObjectSize(int size) {
        if (size > OBJECT_LIMIT || size < 0) {
            throw new BufferOverflowException("invalid object size(limit="
                    + OBJECT_LIMIT + "): " + size);
        }
    }

    /**
     * Create byte array and replace the possible OOM with
     * BufferOverflowException.
     * 
     * @param length
     * @return the created byte Array
     * @throws BufferOverflowException
     *             if OutOfMemoryError occur
     */
    public static final byte[] createBuffer(int length) {
        try {
            return new byte[length];
        } catch (OutOfMemoryError e) {
            throw new BufferOverflowException("cannot create buffer with size "
                    + length);
        }
    }
}
