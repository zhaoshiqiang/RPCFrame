/**
 * @(#)CompressUtils.java, 2009-7-7. Copyright 2009 Yodao, Inc. All rights
 *                                   reserved. YODAO PROPRIETARY/CONFIDENTIAL.
 *                                   Use is subject to license terms.
 */
package odis.file;

import java.io.IOException;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import odis.io.LzoCompression;
import odis.io.MyByteArrayInputStream;
import odis.io.MyByteArrayOutputStream;
import odis.util.ByteArrayBufferPool;
import odis.util.BytesBufferPool;

/**
 * 管理压缩和解压缩的方法
 * 
 * @author jiangfy
 */
public class CompressUtils {

    /**
     * 表示压缩算法，这是个枚举类型，使用的时候用 CompressAlgo.LZO 或者 CompressAlgo.GZIP 来指定压缩算法
     * 
     * @author jiangfy
     */
    public enum CompressAlgo {
        /**
         * The values of all algorithms should be listed {@link #algs} in the
         * order of the values
         */
        LZO((byte) 0), // 表示使用 LZO 进行压缩
        GZIP((byte) 1); // 表示使用 GZIP 进行压缩

        private static CompressAlgo[] algs = new CompressAlgo[] {
            LZO, GZIP
        };

        private byte algo;

        private CompressAlgo(byte v) {
            algo = v;
        }

        /**
         * 通过 byte 的value 获得 compress 算法。 Internal use only.
         * 
         * @param v
         *            算法的代码
         * @return
         */
        public static CompressAlgo get(byte v) {
            if (v < 0 || v >= algs.length)
                return null;
            return algs[v];
        }

        /**
         * Returns the byte value of this algorithm. Internal use only.
         * 
         * @return the byte value of this algorithm
         */
        public byte byteValue() {
            return algo;
        }
    }

    public static final int GZIP_BUFFER_SIZE = 10 * 1024; // 20k

    /**
     * 解压缩输入的 byte 数组到另一个 byte 数组，需要保证输出的数组足够大
     * 
     * @param in
     *            输入
     * @param off
     *            offset
     * @param len
     *            length
     * @param out
     *            output byte array
     * @param ooff
     *            output offset
     * @param compressAlgo
     *            压缩算法
     * @param expectSize
     *            期望的解压后的大小，如果不知道或者不想检查，设置为小于 0 即可
     * @return 解压后的大小
     * @throws IOException
     */
    public static int uncompress(byte[] in, int off, int len, byte[] out,
            int ooff, CompressAlgo compressAlgo, int expectSize)
            throws IOException {
        if (compressAlgo == CompressAlgo.LZO) {
            int rv = LzoCompression.uncompress(in, off, len, out, ooff);
            if (expectSize >= 0 && rv != expectSize) {
                throw new IOException("lzo uncompression failed(expect "
                        + expectSize + " and returned " + rv);
            }
            return rv;
        } else if (compressAlgo == CompressAlgo.GZIP) {
            MyByteArrayInputStream byteStream = new MyByteArrayInputStream(in,
                    off, len);
            GZIPInputStream gi = new GZIPInputStream(byteStream,
                    GZIP_BUFFER_SIZE);
            int readLen = 0;
            int l;
            while ((l = gi.read(out, readLen, out.length - readLen)) > 0) {
                readLen += l;
            }
            gi.close();
            if (expectSize >= 0 && readLen != expectSize)
                throw new IOException("gzip uncompression failed(expect "
                        + expectSize + " and returned " + readLen);
            return readLen;
        } else {
            throw new IOException("unknown compress algo:" + compressAlgo);
        }
    }

    /**
     * 压缩输入的数据，输出到给定的byte 数组，要求该数组足够大
     * 
     * @param in
     *            the input buffer
     * @param off
     *            the offset
     * @param len
     *            the length
     * @param out
     *            the output buffer
     * @param ooff
     *            the output offset
     * @param compressAlgo
     *            压缩算法
     * @return 压缩后的大小
     * @throws IOException
     */
    public static int compress(byte[] in, int off, int len, byte[] out,
            int ooff, CompressAlgo compressAlgo) throws IOException {
        if (compressAlgo == CompressAlgo.LZO) {
            return LzoCompression.compress(in, off, len, out, ooff);
        } else if (compressAlgo == CompressAlgo.GZIP) {
            MyByteArrayOutputStream byteStream = new MyByteArrayOutputStream(
                    out, ooff);
            GZIPOutputStream go = new GZIPOutputStream(byteStream,
                    GZIP_BUFFER_SIZE);
            go.write(in, off, len);
            go.close();
            return byteStream.size() - ooff;
        } else {
            throw new IOException("unknown compress algo:" + compressAlgo);
        }
    }

    /**
     * class type for store the compressedData
     * 
     * @author jiangfy
     */
    public static class CompressedData {
        // the compressed data
        public byte[] data;

        // the compressed data len
        public int len;
    }

    /**
     * 压缩输入的数据，输出到给定的byte 数组，这里会利用 {@link BytesBufferPool}来申请输出的 buffer
     * 
     * @param in
     *            the input buffer
     * @param off
     *            the input offset
     * @param len
     *            the input length
     * @param compressAlgo
     *            the compress algorithm
     * @param pool
     *            the compression data buffer pool
     * @param output
     *            the output
     * @return the compressed data length
     * @throws IOException
     *             any I/O error occur
     * @deprecated use
     *             {@link CompressUtils#compress(byte[], int, int, CompressAlgo, ByteArrayBufferPool, CompressedData)}
     *             instead.
     */
    @Deprecated
    public static int compress(byte[] in, int off, int len,
            CompressAlgo compressAlgo, BytesBufferPool pool,
            CompressedData output) throws IOException {
        if (compressAlgo == CompressAlgo.LZO) {
            int expectCompressedSize = LzoCompression.getCompressBufferSize(len);
            output.data = pool.allocate(expectCompressedSize);
            output.len = LzoCompression.compress(in, off, len, output.data, 0);
            return output.len;
        } else if (compressAlgo == CompressAlgo.GZIP) {
            // 先假设压缩大小最大为 len，如果实际比这个大也没有关系，
            // ByteArraOutputStream 会自动扩容
            int expectCompressedSize = len;
            byte[] data = pool.allocate(expectCompressedSize);
            MyByteArrayOutputStream byteStream = new MyByteArrayOutputStream(
                    data);
            GZIPOutputStream go = new GZIPOutputStream(byteStream,
                    GZIP_BUFFER_SIZE);
            go.write(in, off, len);
            go.close();
            output.data = byteStream.getData();
            output.len = byteStream.size();
            return byteStream.size();
        } else {
            throw new IOException("unknown compress algo:" + compressAlgo);
        }
    }

    /**
     * 压缩输入的数据，输出到给定的byte 数组，这里会利用 {@link ByteArrayBufferPool}来申请输出的 buffer
     * 
     * @param in
     *            the input buffer
     * @param off
     *            the input offset
     * @param len
     *            the input length
     * @param compressAlgo
     *            the compress algorithm
     * @param pool
     *            the compression data buffer pool
     * @param output
     *            the output
     * @return the compressed data length
     * @throws IOException
     *             any I/O error occur
     */
    public static int compress(byte[] in, int off, int len,
            CompressAlgo compressAlgo, ByteArrayBufferPool pool,
            CompressedData output) throws IOException {
        if (compressAlgo == CompressAlgo.LZO) {
            int expectCompressedSize = LzoCompression.getCompressBufferSize(len);
            output.data = pool.allocate(expectCompressedSize);
            output.len = LzoCompression.compress(in, off, len, output.data, 0);
            return output.len;
        } else if (compressAlgo == CompressAlgo.GZIP) {
            // 先假设压缩大小最大为 len，如果实际比这个大也没有关系，
            // ByteArraOutputStream 会自动扩容
            int expectCompressedSize = len;
            byte[] data = pool.allocate(expectCompressedSize);
            MyByteArrayOutputStream byteStream = new MyByteArrayOutputStream(
                    data);
            GZIPOutputStream go = new GZIPOutputStream(byteStream,
                    GZIP_BUFFER_SIZE);
            go.write(in, off, len);
            go.close();
            output.data = byteStream.getData();
            output.len = byteStream.size();
            return byteStream.size();
        } else {
            throw new IOException("unknown compress algo: " + compressAlgo);
        }
    }

}
