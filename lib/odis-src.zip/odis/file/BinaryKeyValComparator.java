/*
 * Copyright (c) 2006, Outfox Team. Created on Mar 14, 2006
 */
package odis.file;

import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.comparator.BinaryComparator;
import odis.serialize.comparator.WritableComparator;

/**
 * A record comparator compares key first, then value, using WritableComparator.
 * 
 * @author Li Zhuang (zl@rd.netease.com, zl@cs.berkeley.edu).
 */
public class BinaryKeyValComparator implements IRecordComparator {

    private BinaryComparator keyComparator, valComparator;

    private Class<? extends IWritableComparable> keyClass;

    private Class<? extends IWritable> valClass;

    /**
     * The constructor with the defaultComparator, WritableComparator<>.
     * 
     * @param keyClass
     *            the compare key class
     * @param valClass
     *            the compare value class
     */
    public BinaryKeyValComparator(
            Class<? extends IWritableComparable> keyClass,
            Class<? extends IWritable> valClass) {
        assert (keyClass != null && valClass != null);
        this.keyClass = keyClass;
        this.valClass = valClass;
        this.keyComparator = new WritableComparator(this.keyClass);
        this.valComparator = null;
    }

    /**
     * The constructor.
     * 
     * @param keyClass
     *            the compare key class
     * @param keyCmp
     *            the BinaryComparator for keyClass
     * @param valClass
     *            the compare value class
     * @param valCmp
     *            the BinaryComparator for valClass
     */
    public BinaryKeyValComparator(
            Class<? extends IWritableComparable> keyClass,
            BinaryComparator keyCmp, Class<? extends IWritable> valClass,
            BinaryComparator valCmp) {
        assert (keyClass != null && valClass != null);
        this.keyComparator = keyCmp;
        this.valComparator = valCmp;
        this.keyClass = keyClass;
        this.valClass = valClass;
        if (keyComparator != null
                && keyComparator instanceof WritableComparator) {
            WritableComparator kCmp = (WritableComparator) keyComparator;
            if (!kCmp.getComparableClass().isAssignableFrom(keyClass))
                throw new RuntimeException("Key class inconsistant: "
                        + keyClass + " =!=> " + kCmp.getComparableClass());
        }
        if (valComparator != null
                && valComparator instanceof WritableComparator) {
            WritableComparator vCmp = (WritableComparator) valComparator;
            if (!vCmp.getComparableClass().isAssignableFrom(valClass))
                throw new RuntimeException("Value class inconsistant: "
                        + valClass + " =!=> " + vCmp.getComparableClass());
        }
        if (keyComparator == null && valComparator == null)
            throw new RuntimeException(
                    "Missing both key/value comparators, how to compare?");
    }

    @Override
    public int compare(IWritable key1, IWritable value1, IWritable key2,
            IWritable value2) {
        throw new RuntimeException(this.getClass().getName()
                + " does not support comparing in non-binary way.");
    }

    @Override
    public int compare(byte[] buffer1, int start1, int keyLength1,
            int valLength1, byte[] buffer2, int start2, int keyLength2,
            int valLength2) {
        int result = 0;
        if (keyComparator != null)
            result = keyComparator.compare(buffer1, start1, keyLength1,
                    buffer2, start2, keyLength2);
        if (result != 0)
            return result;
        if (valComparator != null)
            result = valComparator.compare(buffer1, start1 + keyLength1,
                    valLength1, buffer2, start2 + keyLength2, valLength2);
        return result;
    }

    @Override
    public Class<?> getKeyClass() {
        return keyClass;
    }

    @Override
    public Class<?> getValClass() {
        return valClass;
    }

}
