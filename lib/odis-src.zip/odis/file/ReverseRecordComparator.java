package odis.file;

import odis.serialize.IWritable;

/**
 * Use the given comparator and give a reverse compare result.
 * 
 * @author guodd
 */
public class ReverseRecordComparator implements IRecordComparator {

    IRecordComparator comparator;

    /**
     * Constructor.
     * 
     * @param comparator
     *            the given IRecordComparator.
     */
    public ReverseRecordComparator(IRecordComparator comparator) {
        this.comparator = comparator;
    }

    @Override
    public int compare(IWritable key1, IWritable value1, IWritable key2,
            IWritable value2) {
        return -comparator.compare(key1, value1, key2, value2);
    }

    @Override
    public int compare(byte[] buffer1, int start1, int keyLength1,
            int valLength1, byte[] buffer2, int start2, int keyLength2,
            int valLength2) {
        return -comparator.compare(buffer1, start1, keyLength1, valLength1,
                buffer2, start2, keyLength2, valLength2);
    }

    @Override
    public Class<?> getKeyClass() {
        return comparator.getKeyClass();
    }

    @Override
    public Class<?> getValClass() {
        return comparator.getValClass();
    }

}
