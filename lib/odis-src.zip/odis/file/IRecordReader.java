/*
 * Copyright (c) 2006, Outfox Team. Created on Mar 14, 2006
 */
package odis.file;

import java.io.IOException;

/**
 * The reader interface for reading a source which is organized
 * record-by-record. Each record is a pair of (key,value). The source could be a
 * file, a database or even others. Usage: IRecordReader reader = ...; K key =
 * new K(); V val = new V(); while (reader.next(key, val)) { use key/val ... }
 * // while
 * 
 * @author Li Zhuang (zl@rd.netease.com, zl@cs.berkeley.edu).
 */
public interface IRecordReader<K, V> {

    /**
     * Get the key class of the file currently opened. The method must be called
     * after <code>open()</code> of a file is called.
     * 
     * @return the key class
     */
    public Class<? extends K> getKeyClass();

    /**
     * Get the value class of the file currently opened. The method must be
     * called after <code>open()</code> of a file is called.
     * 
     * @return the value class
     */
    public Class<? extends V> getValueClass();

    /**
     * Reads the next key/value pair.
     * 
     * @param key
     *            the key to read data into
     * @param value
     *            the value to read data into
     * @return true iff a key/value was read, false if at EOF
     * @see IWritable#readFields(DataInput)
     */
    public boolean next(K key, V value) throws IOException;

    /**
     * Close our current file being reading
     * 
     * @throws IOException
     *             exception in closing the file
     */
    public void close() throws IOException;

    /**
     * Returns the current position in the input (relative to the start).
     * 
     * @return the position in the file relative to the start
     * @throws IOException
     *             exception in getting the position
     */
    public long getPos() throws IOException;

    /**
     * Returns the total size to be read in the input file
     * 
     * @return the total size to be read
     * @throws IOException
     *             exception in getting the size
     */
    public long getSize() throws IOException;

}
