package odis.file;

import java.io.IOException;

import odis.serialize.IMutable;

/**
 * A wrapper class implements IRecordWriter interface that write records
 * (key-value pairs) asynchronously. Data are written in a different thread as
 * the writer.
 * 
 * @author david
 */
public class ARecordWriter extends AsyncWork implements IRecordWriter {
    IMutable[] keys;

    IMutable[] vals;

    int qHead = 0;

    int qTail = 0;

    int qLen = 0;

    IRecordWriter writer;

    /**
     * The constructor with the bufferLen set to 1.
     * 
     * @param reader
     *            the reader of the data
     * @throws IOException
     *             if an I/O error occurs
     */
    public ARecordWriter(IRecordWriter writer) throws IOException {
        this(writer, 1);
    }

    /**
     * The constructor.
     * 
     * @param reader
     *            the reader of the data
     * @param bufferLen
     *            the number of the records in the buffer
     * @throws IOException
     *             if an I/O error occurs
     */
    public ARecordWriter(IRecordWriter writer, int bufferLen)
            throws IOException {
        super("async-writer-thread", true, writer);
        this.writer = writer;

        /*
         * Create buffers
         */
        keys = new IMutable[bufferLen];
        vals = new IMutable[bufferLen];

        this.start();
    }

    private static boolean isCopyFieldBad(IMutable o) {
        if (o.copyFields(o) != o)
            return true;

        return false;
    }

    /**
     * The constructor.
     * 
     * @param writer
     *            the writer for real writting
     * @param bufferLen
     *            the number of objects in the buffer
     * @param keyClass
     *            the class of the key
     * @param valClass
     *            the class of the value
     * @throws IOException
     *             if an I/O error occurs
     */
    public ARecordWriter(IRecordWriter writer, int bufferLen, Class keyClass,
            Class valClass) throws IOException {
        super("async-read-thread", true, writer);
        this.writer = writer;
        /*
         * Assure the key/value classes implement IMutable
         */
        if (!IMutable.class.isAssignableFrom(keyClass))
            throw new IOException("The key " + keyClass + " does not "
                    + "implement IMutable interface.");
        if (!IMutable.class.isAssignableFrom(valClass))
            throw new IOException("The value " + valClass + " does not "
                    + "implement IMutable interface.");

        /*
         * Create buffers
         */
        keys = new IMutable[bufferLen];
        vals = new IMutable[bufferLen];

        try {
            for (int i = 0; i < bufferLen; i++) {
                keys[i] = (IMutable) keyClass.newInstance();
                vals[i] = (IMutable) valClass.newInstance();
            } // for i
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        /*
         * Check the copyFields function.
         */
        if (isCopyFieldBad(keys[0]))
            throw new IOException("The copyFields of the key " + keyClass
                    + " is not propertly implemented!");
        if (isCopyFieldBad(vals[0]))
            throw new IOException("The copyFields of the value " + valClass
                    + " is not propertly implemented!");

        this.start();
    }

    @Override
    public void close() throws IOException {
        try {
            this.stopWork();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        writer.close();
    }

    @Override
    public long getSize() throws IOException {
        return writer.getSize();
    }

    @Override
    protected boolean hasJob() {
        return qLen > 0;
    }

    @Override
    protected boolean canPassJob() {
        return this.threadStatus == STATUS_WAITING && qLen < keys.length
                || this.threadStatus == STATUS_RUNNING
                && qLen < keys.length - 1;
    }

    @Override
    protected void passJob(Object... objects) {
        IMutable key = (IMutable) objects[0];
        IMutable val = (IMutable) objects[1];
        /*
         * Allocate key-value instances if null
         */
        if (keys[qTail] == null) {
            try {
                keys[qTail] = key.getClass().newInstance();
                vals[qTail] = val.getClass().newInstance();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        } // if
        /*
         * Copy fields to the buffer
         */
        keys[qTail].copyFields(key);
        vals[qTail].copyFields(val);
        /*
         * Move down the tail and increase qLen
         */
        qTail++;
        if (qTail == keys.length) {
            qTail = 0;
        }
        qLen++;
    }

    int curJob;

    @Override
    protected void pollJob() {
        curJob = qHead;
        qHead++;
        if (qHead == keys.length) {
            qHead = 0;
        }
        qLen--;
    }

    @Override
    protected boolean runJob() throws Exception {
        writer.write(keys[curJob], vals[curJob]);
        return true;
    }

    public synchronized void write(Object key, Object value) throws IOException {
        try {
            this.addJob(key, value);
        } catch (Exception e) {
            if (e instanceof IOException)
                throw (IOException) e;
            throw new RuntimeException(e);
        }
    }
}
