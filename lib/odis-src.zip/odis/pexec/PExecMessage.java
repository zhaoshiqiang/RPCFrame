/*
 * Copyright (c) 2005, Yitao Duan, Jimmy Su, Feng Zhou and Li Zhuang Created on
 * Aug 13, 2005
 */
package odis.pexec;

/**
 * A message received from another host.
 * 
 * @author zf
 */
public class PExecMessage {
    private String id;

    private Object data;

    private int orig;

    /**
     * construct a PExecMessage with the given parameters
     * 
     * @param id
     *            the given id
     * @param data
     *            the given data
     * @param orig
     *            the given orig
     */
    public PExecMessage(String id, Object data, int orig) {
        this.id = id;
        this.data = data;
        this.orig = orig;
    }

    /**
     * get id
     * 
     * @return
     */
    public String getId() {
        return id;
    }

    /**
     * get data
     * 
     * @return
     */
    public Object getData() {
        return data;
    }

    /**
     * get origin
     * 
     * @return
     */
    public int getOrigin() {
        return orig;
    }

}
