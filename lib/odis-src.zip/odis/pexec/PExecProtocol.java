/*
 * Copyright (c) 2005, Yitao Duan, Jimmy Su, Feng Zhou and Li Zhuang Created on
 * Aug 12, 2005
 */
package odis.pexec;

import odis.rpc.RpcException;
import odis.serialize.lib.ObjectWritable;

/**
 * The RPC protocol interface for PExec.
 * 
 * @author zf, david
 */
public interface PExecProtocol {
    /**
     * Pints the receiver with heartbeat.
     */
    void ping() throws RpcException;

    /**
     * Calls to the leader to add myself to the list of processes. Every process
     * should retry this call periodically until the result is non-null.
     * 
     * @param myaddress
     *            myhostname:myport
     * @return the addresses of all process (<host:port>+), or null if
     *         bootstrapping has not finished. The caller should figure out its
     *         own rank by search through this list for its own address.
     * @throws IOException
     */
    String bootstrap(String myaddress, int rank) throws RpcException;

    /**
     * Barrier submit request going from a worker to the leader.
     * 
     * @param id
     *            unique ID of the barrier, can be either static or
     *            deterministically generated.
     * @throws RpcException
     * @throws IllegalArgumentException
     *             when submitting the request to a non-leader
     */
    void barrierSubmit(String id, int myrank) throws RpcException,
            IllegalArgumentException;

    /**
     * Callback from the leader to each worker when the barrier is complete.
     * 
     * @param id
     *            unique ID of the barrier
     * @throws IOException
     */
    void barrierCallback(String id) throws RpcException;

    /**
     * A generic message passing call.
     * 
     * @param id
     *            ID identifying the purpose of the data.
     * @param data
     *            the actual data
     * @param orig
     *            index of the originating node
     * @throws IOException
     */
    void message(String id, ObjectWritable data, int orig) throws RpcException;
}
