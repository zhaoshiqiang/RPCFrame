/*
 * Copyright (c) 2005, Yitao Duan, Jimmy Su, Feng Zhou and Li Zhuang Created on
 * Aug 12, 2005
 */
package odis.pexec;

import java.io.IOException;
import java.net.BindException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.TreeSet;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.conf.OdisServerConfig;
import odis.rpc.RPC;
import odis.rpc.RpcServer;
import odis.serialize.lib.ObjectWritable;
import toolbox.misc.LogFormatter;

/**
 * Stupid parallel communication utilities. This is the external API. PExec
 * provides a couple of primitives for communication between SPMD processes.
 * <ol>
 * <li>Barriers. See {@link #barrier(String)}
 * <li>Synchronous message passing. See {@link #send(String, int, Object)} and
 * {@link #receive(String)}.
 * <li>Asynchronous (background) message passing. See
 * {@link #backgroundSend(String, int, Object)}, {@link #finishBackgrounSend()}
 * and {@link #registerReceiver(String, PExecReceiver)}.
 * </ol>
 * <p>
 * PExec uses the Nutch RPC and I/O (IWritable) infrastructure. Notice the
 * implementation is single-threaded, i.e. the application using PExec should
 * have only one working thread in any particular process.
 * 
 * @author zf
 */
public class PExec {
    static final Logger LOG = LogFormatter.getLogger(PExec.class.getName());

    public static final int WELL_KNOWN_PORT = 1739;

    /**
     * PExec 目前主要应用于 PageRank 的计算，而目前 PageRank 计算的规模较大， 所用的节点数目一般在 1024 以上，因此，当
     * RPC 的 queue size 太小的时候， bootstrap 会出错，因此这里设了一个相对较大的初始值。 by jiangfy
     */
    public static final int MIN_QUEUE_SIZE = 10000;

    /**
     * 可以通过 config 来进行设置的 rpc 的 queue size
     */
    public static final String CONFIG_QUEUE_SIZE = "cowork.pexec.rpc-queue-size";

    /**
     * 获取 PExec 所使用的 RPC 的队列长度
     * 
     * @return
     */
    public static int getRPCQueueSize() {
        return OdisServerConfig.conf()
                .getInt(CONFIG_QUEUE_SIZE, MIN_QUEUE_SIZE);
    }

    /**
     * 设置 PExec 使用的 RPC 的队列长度
     * 
     * @param size
     *            RPC 队列长度
     */
    public static void setRPCQueueSize(int size) {
        OdisServerConfig.conf().setProperty(CONFIG_QUEUE_SIZE, size);
    }

    /**
     * A barrier operation that blocks until all procs have reached this
     * barrier.
     * 
     * @param id
     *            unique ID of this barrier.
     * @param timeout
     *            how long to wait before giving up, in units of unit
     * @param unit
     *            a TimeUnit determining how to interpret the timeout parameter
     * @return If the barrier is obtained, return true. If timeout reaches,
     *         return false.
     */
    public boolean barrier(String id, long timeout, TimeUnit unit)
            throws IOException, InterruptedException {
        // FIXME: this works only for one thread
        synchronized (this) {
            currentBarrier = id;
        }
        // WorkerServer will change currentBarrier and notify upon completion
        long endTime = System.currentTimeMillis() + unit.toMillis(timeout);
        synchronized (this) {
            clients[0].barrierSubmit(id, rank);
            while (currentBarrier != null) {
                long now = System.currentTimeMillis();
                if (now > endTime)
                    return false;
                wait(endTime - now);
            } // while
        }

        return true;
    }

    /**
     * Broadcasts data to all hosts and wait for all sending to end. If any
     * exception caught during sending, one of them will be thrown nested in a
     * RuntimeException.
     * 
     * @param id
     *            the id of the message
     * @param data
     *            the data for this message
     */
    public void broadcast(String id, Object data) {
        for (int i = 0; i < nprocs; i++)
            backgroundSend(id, i, data);
        finishBackgrounSend();
    }

    boolean sendInProgress;

    Throwable bgSendException = null;

    /**
     * Starts sending a message to another node in the background and returns
     * immediately. At most one background send can be in progress at any time.
     * Later calls will block until the current operation is finished. This
     * provides a form of back-pressure controlling so that we do not end up
     * with too many concurrent sends.
     * <p>
     * TODO: allow more concurrent sends. maybe one per destination?
     * 
     * @param id
     *            the id of the message
     * @param dest
     *            the index of the destination client
     * @param data
     *            the data for this message
     */
    public void backgroundSend(final String id, final int dest,
            final Object data) {
        synchronized (this) {
            // wait for sendInProgress to be false
            while (sendInProgress)
                try {
                    wait();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    throw new RuntimeException(e);
                }
            /*
             * set sendInProgress flag to true again since we are sending a new
             * message
             */
            sendInProgress = true;
        }
        Thread t = new Thread() {
            public void run() {
                try {
                    clients[dest].message(id, new ObjectWritable(data), rank);
                } catch (Throwable t) {
                    LOG.log(Level.WARNING, "Failed to send data from "
                            + getRank() + " to " + dest, t);
                    bgSendException = t;
                } finally {
                    synchronized (PExec.this) {
                        sendInProgress = false;
                        PExec.this.notifyAll();
                    }
                }
            }
        };
        t.setDaemon(true);
        t.setName("Background sender (" + id + " to " + dest + ")");
        t.start();
    }

    /**
     * Block waiting for any ongoing background .
     */
    public synchronized void finishBackgrounSend() {
        while (sendInProgress) {
            try {
                wait();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new RuntimeException(e);
            }
        } // while
        checkBgSendException();
    }
    /**
     * check checkBgSendException if <code>bgSendException</code> not equal null,
     * send RuntimeException
     */
    public synchronized void checkBgSendException() {
        if (bgSendException != null) {
            Throwable t = bgSendException;
            bgSendException = null;
            throw new RuntimeException("Exception found on background sending",
                    t);
        } // if
    }

    // TODO: each process may have a different port #, to allow multiple
    // procs on the same machine
    int rank;

    String[] hosts;

    int[] ports;

    int nprocs;

    int bootstrapped;

    RpcServer ipcServer;

    WorkerServer workerServer;

    PExecProtocol[] clients;

    List<PExecMessage> msgBuf = new LinkedList<PExecMessage>();

    /**
     * Make sure all processes are started successfully and then return.
     */
    private void initStatic(String addresses, int rank) throws IOException {
        // parse runtime system properties
        parseHosts(addresses);
        this.rank = rank;
        if (rank < 0 || rank >= nprocs)
            throw new IOException("pexec.rank out of range");
        if (rank == 0) {
            // the first node is leader
            LOG.fine("PExec(leader) starting on " + hosts[rank] + ":"
                    + ports[rank] + ".");
            workerServer = new LeaderServer();
        } else {
            LOG.fine("PExec(worker) starting on " + hosts[rank] + ":"
                    + ports[rank] + ".");
            workerServer = new WorkerServer();
        } // else
        workerServer.start();
        ipcServer = RPC.getServer(workerServer, ports[rank], 1, 0,
                getRPCQueueSize(), false);
        ipcServer.start();
        waitForAllReady();
    }

    private void waitForAllReady() throws UnknownHostException {
        clients = new PExecProtocol[nprocs];
        for (int i = 0; i < nprocs; i++) {
            InetSocketAddress addr = new InetSocketAddress(InetAddress
                    .getByName(hosts[i]), ports[i]);
            clients[i] = (PExecProtocol) RPC
                    .getProxy(PExecProtocol.class, addr);
        }
        // ping each node to make sure everyone's up
        LOG.fine("Waiting for nodes to come up: ");
        for (int i = 0; i < nprocs; i++) {
            while (true) {
                try {
                    clients[i].ping();
                    break;
                } catch (IOException e) {
                    try {
                        Thread.sleep(200);
                    } catch (InterruptedException ee) {
                        Thread.currentThread().interrupt();
                        throw new RuntimeException(ee);
                    }
                }
            } // while
            LOG.fine("Client " + i + "(" + hosts[i] + ":" + ports[i]
                    + ") is ready");
        } // for i
        LOG.info("PExec initalization complete.");
    }

    private void parseHosts(String addrs) {
        String[] addresses = addrs.trim().split("[ \t,]+");
        nprocs = addresses.length;
        hosts = new String[nprocs];
        ports = new int[nprocs];
        for (int i = 0; i < nprocs; i++) {
            String s = addresses[i];
            int p = s.indexOf(':');
            if (p > 0) {
                hosts[i] = s.substring(0, p);
                ports[i] = Integer.parseInt(s.substring(p + 1));
            } else {
                hosts[i] = s;
                ports[i] = WELL_KNOWN_PORT;
            }
        }
    }
    
    /**
     * close  
     */
    public void close() {
        if (ipcServer != null)
            ipcServer.stop();
        if (workerServer != null)
            workerServer.interrupt();
    }

    /**
     * Create a PExec instance by reading parameters from system properties. The
     * caller needs to set either the following system properties.
     * <ol>
     * <li>pexec.addresses: &lt;host[:port]>+ <li>pexec.rank: the index of
     * current process in pexec.addresses
     * </ol>
     * or,
     * <ol>
     * <li>pexec.bootstrap: host[:port] | +nprocs[:port]
     * </ol>
     * 
     * @throws IOException
     */
    public static PExec start() throws IOException {
        if (System.getProperty("pexec.addresses") != null) {
            String all = System.getProperty("pexec.addresses");
            int rank = Integer.parseInt(System.getProperty("pexec.rank"));
            return startProcStatic(all, rank);
        } else if (System.getProperty("pexec.bootstrap") != null) {
            String s = System.getProperty("pexec.bootstrap");
            if (!s.startsWith("+")) {
                // dynamic node
                String host;
                int port;
                int p = s.indexOf(':');
                if (p > 0) {
                    host = s.substring(0, p);
                    port = Integer.parseInt(s.substring(p + 1));
                } else {
                    host = s;
                    port = WELL_KNOWN_PORT;
                } // else
                return startProcDynamic(host, port);
            } else {
                // bootstrap node
                s = s.substring(1);
                int nprocs;
                int port;
                int p = s.indexOf(':');
                if (p > 0) {
                    nprocs = Integer.parseInt(s.substring(0, p));
                    port = Integer.parseInt(s.substring(p + 1));
                } else {
                    nprocs = Integer.parseInt(s);
                    port = WELL_KNOWN_PORT;
                } // else
                return startProcBootstrapper(nprocs, port, false);
            } // else
        } else {
            throw new IOException("Missing pexec.* property! Cannot start "
                    + "pexec");
        } // else
    }

    /**
     * Create an PExec process by statically specifying my host name and the
     * whole set of hosts.
     */
    public static PExec startProcStatic(String addresses, int rank)
            throws IOException {
        PExec ex = new PExec();
        try {
            ex.initStatic(addresses, rank);
        } catch (IOException e) {
            e.printStackTrace();
            ex.close();
            throw e;
        }
        return ex;
    }

    /**
     * Start the bootstrapper process for dynamic startup. This will also be the
     * leader for synchronization operations.
     */
    public static PExec startProcBootstrapper(int nprocs, int port,
            boolean tryNewPortIfFailed) throws IOException {
        PExec ex = new PExec();
        try {
            ex.initBootstrapper(nprocs, port, tryNewPortIfFailed);
        } catch (IOException e) {
            e.printStackTrace();
            try {
                ex.close();
            } catch (Exception exc) {
                exc.printStackTrace();
            } // catch
            throw e;
        }
        return ex;
    }

    private int bootstrapPort;

    public int getBootstrapPort() {
        return bootstrapPort;
    }

    // the ipcServer is started
    private void initBootstrapper(int nprocs, int port,
            boolean tryNewPortIfFailed) throws IOException {
        this.nprocs = nprocs;
        String host = InetAddress.getLocalHost().getHostAddress();
        bootstrapped = 0;
        hosts = new String[nprocs];
        ports = new int[nprocs];
        while (true)
            try {
                LOG.fine("Starting bootstrapping leader at " + host + ":"
                        + port);
                ipcServer = RPC.getServer(new LeaderServer(), port, 1, 0,
                        getRPCQueueSize(), false);
                ipcServer.start();
                port = ipcServer.getPort();
                break;
            } catch (BindException e) {
                if (!tryNewPortIfFailed)
                    throw e;
                port++;
                LOG.info("Bind failed. Trying new bootstrapping server port "
                        + port + " ...");
            } // catch

        bootstrapPort = port;
        LOG.info("Bootstrapper server with " + nprocs + " entries started at "
                + host + ":" + port);
    }

    /**
     * Start a process by connecting to a bootstrap node.
     * 
     * @param bootstrapHost
     * @param bootstrapPort
     * @return The PExec object to be used
     */
    public static PExec startProcDynamic(String bootstrapHost, int bootstrapPort)
            throws IOException {
        return startProcDynamic(bootstrapHost, bootstrapPort, -1);
    }
    /**
     *  Start a process by connecting to a bootstrap node
     *  
     * @param bootstrapHost the bootstrap host
     * @param bootstrapPort the bootstrap port
     * @param rank the rank
     * @return the created <code>PExec</code>
     * @throws IOException any I/O error occur
     */
    public static PExec startProcDynamic(String bootstrapHost,
            int bootstrapPort, int rank) throws IOException {
        PExec ex = new PExec();
        try {
            ex.initDynamic(bootstrapHost, bootstrapPort, rank);
            LOG.info("Connected with bootstrap server " + bootstrapHost + ":"
                    + bootstrapPort + " as " + ex.getRank());
        } catch (IOException e) {
            try {
                ex.close();
            } catch (Exception exc) {
                exc.printStackTrace();
            } // catch
            LOG.warning("Fail to connect to bootstrap server " + bootstrapHost
                    + ":" + bootstrapPort);
            throw e;
        }
        return ex;
    }

    private void initDynamic(String bootstrapHost, int bootstrapPort, int rank)
            throws IOException {
        String myhostname = InetAddress.getLocalHost().getHostAddress();
        int port = 0;
        while (true)
            try {
                LOG.fine("Starting dynamic proc at " + myhostname + ":" + port);
                if (rank == 0 || rank == -1)
                    workerServer = new LeaderServer();
                else
                    workerServer = new WorkerServer();
                workerServer.start();
                ipcServer = RPC.getServer(workerServer, port, 1, 0,
                        getRPCQueueSize(), false);
                ipcServer.start();
                port = ipcServer.getPort();
                break;
            } catch (BindException e) {
                LOG
                        .fine("Port " + port
                                + " already used. Trying the next one.");
                port++;
            } // catch, while
        bootstrap(bootstrapHost, bootstrapPort, myhostname, port, rank);
        waitForAllReady();
    }

    private void bootstrap(String bootHost, int bootPort, String myHost,
            int myPort, int rank) throws IOException {
        PExecProtocol c = (PExecProtocol) RPC.getProxy(PExecProtocol.class,
                new InetSocketAddress(bootHost, bootPort));
        String myaddr = myHost + ":" + myPort;
        while (true) {
            LOG.fine("bootstraping as " + myaddr + " - rank = " + rank);
            String addrs = c.bootstrap(myaddr, rank);
            if (addrs != null) {
                LOG.finer("Got address list" + addrs);
                parseHosts(addrs);
                this.rank = Arrays.asList(addrs.split(" ")).indexOf(myaddr);
                if (this.rank == -1)
                    throw new IOException(
                            "Cannot find my own address from the proc list!");
                break;
            } // if
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {}
        } // while
    }

    private PExec() {}

    String currentBarrier;

    /**
     * A barrier operation that blocks until all procs have reached this
     * barrier.
     * 
     * @param id
     *            unique ID of this barrier.
     */
    public void barrier(String id) throws IOException {
        // FIXME: this works only for one thread
        synchronized (this) {
            currentBarrier = id;

            clients[0].barrierSubmit(id, rank);
            // WorkerServer will change currentBarrier and notify upon
            // completion
            try {
                while (currentBarrier != null) {
                    wait();
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    HashMap<String, PExecReceiver> receivers = new HashMap<String, PExecReceiver>();

    /**
     * Register a receiver callback that will be called when this type of data
     * arrives. The receiver will be called in the IPC handler thread.
     */
    public void registerReceiver(String id, PExecReceiver r) {
        receivers.put(id, r);
    }

    /**
     * Receive a data message, block waiting if none is available.
     */
    public PExecMessage receive(String id) {
        synchronized (msgBuf) {
            while (msgBuf.isEmpty())
                try {
                    msgBuf.wait();
                } catch (InterruptedException e) {}
            PExecMessage m = msgBuf.remove(0);
            if (!m.getId().equals(id))
                throw new PExecException(
                        "Got message with wrong ID. Expecting: " + id
                                + ", got: " + m.getId());
            return m;
        }
    }

    /**
     * Synchronously send data to another host.
     */
    public void send(final String id, final int dest, final Object data) {
        backgroundSend(id, dest, data);
        finishBackgrounSend();
    }

    /**
     * Implementation of a worker as an RPC service.
     * 
     * @author zf
     */
    public class WorkerServer extends Thread implements PExecProtocol {
        List<Runnable> queue = new LinkedList<Runnable>();

        public WorkerServer() {
            setName("PExec Server queue runner");
            setDaemon(true);
        }

        /**
         * This thread runs a simple infinite job queue.
         */
        public void run() {
            try {
                while (true) {
                    Runnable job;
                    synchronized (queue) {
                        while (queue.isEmpty())
                            queue.wait();
                        job = queue.remove(0);
                    }
                    LOG.fine("Executing: " + job);
                    job.run();
                } // while
            } catch (InterruptedException e) {}
        }

        /**
         * Add the job to the queue and return immediately. The job will later
         * be executed in the PExec job queue runner thread.
         * 
         * @param job
         */
        public void execLater(Runnable job) {
            synchronized (queue) {
                LOG.fine("Enqueing: " + job);
                queue.add(job);
                queue.notifyAll();
            }
        }

        // Remote methods
        public void ping() {
            // nothing
            LOG.finer("Ping called");
        }

        public void barrierSubmit(String id, int myrank) {
            throw new IllegalArgumentException("I am not a leader");
        }

        public void barrierCallback(String id) {
            synchronized (PExec.this) {
                assert id.equals(currentBarrier);
                currentBarrier = null;
                PExec.this.notifyAll();
            }
        }

        public void message(String id, ObjectWritable data, int orig) {
            LOG.fine("Got message " + id + " from node " + orig);
            PExecReceiver receiver = receivers.get(id);
            if (receiver != null) {
                // background receive, process in IPC handler thread
                receiver.process(data.getObject(), orig);
            } else {
                // synchronous receive, deliver the message to main thread
                // through the message buffer
                PExecMessage msg = new PExecMessage(id, data.getObject(), orig);
                synchronized (msgBuf) {
                    msgBuf.add(msg);
                    msgBuf.notifyAll();
                    if (msgBuf.size() % 100 == 0) {
                        LOG.warning("Message buffer is very LONG. size: "
                                + msgBuf.size() + ", last message ID: " + id);
                    }
                }
            }
        }

        public String bootstrap(String myaddress, int rank) {
            throw new IllegalArgumentException("I am not a leader");
        }
    }

    /**
     * A leader is a worker that also acts as rendezvous points for certain
     * operations, e.g. barriers.
     * 
     * @author zf
     */
    public class LeaderServer extends WorkerServer {

        String barrier;

        TreeSet<Integer> barrierDone = new TreeSet<Integer>();

        @Override
        public void barrierSubmit(final String id, int myrank) {
            synchronized (barrierDone) {
                if (barrier == null || !barrier.equals(id)) {
                    barrier = id;
                    barrierDone.clear();
                }
                barrierDone.add(myrank);
                if (barrierDone.size() == nprocs) {
                    if (id.startsWith("trace:")) {
                        LOG.info("Receive all " + nprocs
                                + " barriers, notify all "
                                + "clients to go on.");
                    } // if
                    execLater(new Runnable() {
                        public void run() {
                            LOG
                                    .fine("Notifying all workers of barrier completion: "
                                            + id);
                            for (int i = 0; i < nprocs; i++)
                                try {
                                    clients[i].barrierCallback(id);
                                } catch (IOException e) {
                                    LOG
                                            .log(Level.WARNING,
                                                    "Error doing barrier "
                                                            + "callback", e);
                                }
                        }
                    });
                } else {
                    if (id.startsWith("trace:")) {
                        LOG.info("Receive barrier from " + myrank
                                + ", expected: " + nprocs
                                + " clients, but only " + barrierDone.size()
                                + " received(they are " + barrierDone + ")");
                    } // if
                } // else
            }
        }

        @Override
        public String bootstrap(String myaddr, int rank) {
            int p = myaddr.indexOf(':');
            String host;
            int port;
            if (p > 0) {
                host = myaddr.substring(0, p);
                port = Integer.parseInt(myaddr.substring(p + 1));
            } else {
                host = myaddr;
                port = WELL_KNOWN_PORT;
            } // else
            if (rank < 0)
                // boostrap without rank
                synchronized (PExec.this) {
                    int i;
                    for (i = 0; i < bootstrapped; i++) {
                        if (hosts[i].equals(host) && ports[i] == port) {
                            // we already know about this proc
                            break;
                        }
                    }
                    if (i == bootstrapped) {
                        // a new proc
                        if (bootstrapped < nprocs) {
                            LOG.fine("New client " + myaddr
                                    + " connected as rank " + bootstrapped);
                            hosts[bootstrapped] = host;
                            ports[bootstrapped++] = port;
                        } else {
                            LOG
                                    .warning("More than "
                                            + nprocs
                                            + " processes trying to bootstrap from me. Ignoring!");
                            return "";
                        }
                    }
                    if (bootstrapped == nprocs) {
                        // enough processes bootstrapped, returning address list
                        StringBuffer sb = new StringBuffer();
                        for (i = 0; i < nprocs; i++) {
                            if (i != 0)
                                sb.append(' ');
                            sb.append(hosts[i]).append(':').append(ports[i]);
                        }
                        return sb.toString();
                    } else
                        return null;
                } // synchronized PExec.this
            else
                // boostrap with specified rank
                synchronized (PExec.this) {
                    if (rank >= nprocs)
                        throw new IndexOutOfBoundsException("rank(" + rank
                                + ") is out of range(" + nprocs + ").");
                    if (hosts[rank] == null) {
                        LOG.fine(host + ":" + port + "(rank = " + rank
                                + ") registered.");
                        // a new proc
                        hosts[rank] = host;
                        ports[rank] = port;
                        bootstrapped++;
                    } else if (!hosts[rank].equals(host) || ports[rank] != port)
                        // duplicated registering (from different addresses)
                        throw new RuntimeException(
                                "BUG? Duplicated bootstrap registering from "
                                        + host + ":" + port + ". "
                                        + hosts[rank] + ":" + ports[rank]
                                        + " has registered.");

                    if (bootstrapped == nprocs) {
                        // enough processes bootstrapped, returning address list
                        StringBuffer sb = new StringBuffer();
                        for (int i = 0; i < nprocs; i++) {
                            if (i != 0)
                                sb.append(' ');
                            sb.append(hosts[i]).append(':').append(ports[i]);
                        } // for i
                        return sb.toString();
                    } else
                        return null;
                } // synchronized PExec.this
        }
    }

    /**
     * Get local process's index in all the processes.
     */
    public int getRank() {
        return rank;
    }

    /**
     * Return number of processes.
     */
    public int getNProcs() {
        return nprocs;
    }
}
