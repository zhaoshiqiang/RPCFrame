/**
 * @(#)RpcWritableException.java, 2010-8-3. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2;

/**
 * Thrown when an RPC method fails due to serialization exceptions of
 * parameters or the return value, e.g. when <code>readFields()</code> of a
 * parameter Writable throws an exception.
 * 
 * @author zf
 */
public class RpcWritableException extends RpcException {

    private static final long serialVersionUID = -4177510115312805014L;

    public RpcWritableException(String message, Throwable cause) {
        super(message, cause);
    }

    public RpcWritableException(String message) {
        super(message);
    }

    public RpcWritableException(Throwable cause) {
        super(cause);
    }

}
