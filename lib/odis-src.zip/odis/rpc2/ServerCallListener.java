/**
 * @(#)ServerCallListener.java, 2010-8-6. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2;

import java.lang.reflect.Method;

import odis.rpc2.PermissionManager.PermitType;

/**
 * listener to record a call's life time in RpcServer
 * 
 * @author zhangduo
 */
public interface ServerCallListener {
    /**
     * createAttach
     * 
     * @return
     */
    Object createAttach(ClientInfo clientInfo);

    /**
     * startReceive
     * 
     * @param method
     * @param attach
     */
    void startReceive(Method method, Object attach);

    /**
     * endReceive
     * 
     * @param method
     * @param args
     * @param attach
     */
    void endReceive(Method method, Object[] args, Object attach);

    /**
     * getPermit
     * 
     * @param method
     * @param permit
     * @param attach
     */
    void getPermit(Method method, PermitType permit, Object attach);

    /**
     * startCall
     * 
     * @param method
     * @param attach
     */
    void startCall(Method method, Object attach);

    /**
     * endCall
     * 
     * @param method
     * @param returnValue
     * @param error
     * @param attach
     */
    void endCall(Method method, Object returnValue, Throwable error,
            Object attach);

    /**
     * callTimeout
     * 
     * @param method
     * @param attach
     */
    void callTimeout(Method method, Object returnValue, Throwable error,
            Object attach);

    /**
     * startSend
     * 
     * @param method
     * @param attach
     */
    void startSend(Method method, Object attach);

    /**
     * endSend
     * 
     * @param method
     * @param attach
     */
    void endSend(Method method, Object attach);
}
