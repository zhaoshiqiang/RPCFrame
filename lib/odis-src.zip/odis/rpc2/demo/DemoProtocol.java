/**
 * @(#)DemoProtocol.java, 2011-7-15. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2.demo;

import odis.rpc2.RpcException;

/**
 * @author zhangduo
 */
public interface DemoProtocol {
    int add(int a, int b) throws RpcException, NumberOverflowException;
}
