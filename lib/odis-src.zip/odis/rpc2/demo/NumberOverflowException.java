/**
 * @(#)NumberOverflowException.java, 2011-7-15. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2.demo;

/**
 * @author zhangduo
 */
public class NumberOverflowException extends Exception {

    private static final long serialVersionUID = 4961131517452404548L;

}
