/**
 * @(#)PermissionManager.java, 2010-11-24. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2;

import odis.rpc2.AbstractRpcServer.Call;

/**
 * A permission manager is used to decide whether a call should be handled. It
 * is necessary if we have too many calls from one or several RpcClients.
 * 
 * @author zhangduo
 */
public interface PermissionManager {
    /**
     * <ul>
     * <li>{@link #PERMIT} means handler should handle the call.</li>
     * <li>{@link #WAIT} means handler should not handle the call at this time.</li>
     * <li>{@link #TIMEOUT} means the call is already timeout.
     * </ul>
     * 
     * @author zhangduo
     */
    public static enum PermitType {
        PERMIT, WAIT, TIMEOUT
    }

    /**
     * Handler usage status.
     * 
     * @author zhangduo
     */
    public static enum Status {
        NORMAL, EMERGENCY
    }

    /**
     * Get current status.
     * 
     * @return
     */
    Status getStatus();

    /**
     * Tell the permission manager we have finished a call.
     * 
     * @param call
     */
    void finishedCall(Call call);

    /**
     * Get a call's permission.
     * 
     * @param call
     * @return
     */
    PermitType getPermission(Call call);
}
