/**
 * @(#)RpcClient.java, 2010-8-5. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ScheduledExecutorService;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.lib.StringPropertiesWritable;
import odis.util.MiscUtils;
import toolbox.misc.LogFormatter;

/**
 * A client for an RPC service use Blocking IO to communicate with RpcServer.
 * Note: this is probably not what you use. See
 * {@link odis.rpc2.RPC#getProxy(Class, InetSocketAddress, String, String, String, long)}
 * for the easy-to-use RPC client interface.
 * 
 * @author zhangduo
 */
public class RpcClient extends AbstractRpcClient implements RpcConstants {
    private static final Logger LOG = LogFormatter.getLogger(RpcClient.class);

    private class ConnectionImpl extends Connection implements Runnable {

        private static final int RECEIVE_BUFFER_SIZE = 8 * 1024;

        private static final int SEND_BUFFER_SIZE = 8 * 1024;

        private static final boolean TCP_NO_DELAY = true;

        private Socket socket;

        private OutputStream rawOut;

        private CDataInputStream in;

        private CDataOutputStream out;

        private ReservedByteArrayOutputStream byteArrayOut; // for NIO

        private ConcurrentMap<Integer, Call> pendingCalls = new ConcurrentHashMap<Integer, Call>();

        public ConnectionImpl(String name) throws IOException {
            super(name);
            socket = new Socket();
            int soTimeout = (int) timeout;
            if (soTimeout < 0) { // may be overflow
                soTimeout = 0;
            }
            socket.connect(new InetSocketAddress(remoteAddr.getAddress(),
                    remoteAddr.getPort()), soTimeout);
            socket.setTcpNoDelay(TCP_NO_DELAY);

            socket.setSoTimeout(soTimeout);
            in = new CDataInputStream(new BufferedInputStream(
                    socket.getInputStream(), RECEIVE_BUFFER_SIZE));
            rawOut = socket.getOutputStream();
        }

        private Throwable readException() throws IOException,
                ClassNotFoundException {
            int sz = in.readVInt();
            byte[] buf = new byte[sz];
            in.readFully(buf);
            ObjectInputStream ois = new ObjectInputStream(
                    new ByteArrayInputStream(buf));
            Throwable t = (Throwable) ois.readObject();
            MiscUtils.safeClose(ois);
            return t;
        }

        public void init(boolean recordResponse) throws Throwable {
            LOG.info(name + " start init");
            StringPropertiesWritable props = new StringPropertiesWritable();
            props.put(CLIENT_PROP_RPC_TIMEOUT, Long.toString(timeout));
            props.put(CLIENT_PROP_IO_MODE, CLIENT_PROP_IO_MODE_BIO);
            props.put(CLIENT_PROP_LANGUAGE, CLIENT_PROP_LANGUAGE_JAVA);
            init(socket, props, recordResponse);
            if (serverIOMode == SERVER_IO_MODE_BIO) {
                out = new CDataOutputStream(new BufferedOutputStream(rawOut,
                        SEND_BUFFER_SIZE));
            } else {
                byteArrayOut = new ReservedByteArrayOutputStream(
                        SEND_BUFFER_SIZE, 8);
                out = new CDataOutputStream(byteArrayOut);
            }
            LOG.info(name + " init end");
        }

        public void sendHeartbeat() throws IOException {
            lastActiveTime = System.currentTimeMillis();
            out.writeInt(CALL_ID_HEARTBEAT);
            if (serverIOMode == SERVER_IO_MODE_BIO) {
                out.flush();
            } else {
                rawOut.write(byteArrayOut.data(), byteArrayOut.getReserved(), 4);
                rawOut.flush();
                byteArrayOut.clear();
            }
        }

        @Override
        public void sendParam(Call call) throws RpcException {
            boolean error = true;
            try {
                pendingCalls.put(call.id, call);
                // check closed after put to pendingCalls. if we check closed first, 
                // we may: 
                // 1. we check closed, it is false.
                // 2. connection is closed, all pendingCalls are discard.
                // 3. we put our call in pendingCalls and wait.
                // 4. we wait forever if we do not have a timeout.
                if (closed) {
                    throw new RpcException("connection already closed");
                }
                lastActiveTime = System.currentTimeMillis();
                if (serverIOMode == SERVER_IO_MODE_BIO) {
                    try {
                        out.writeInt(call.id);
                        out.writeLong(call.signature);
                        RpcSerializer.writeArgs(call.method, call.args, out);
                        out.flush();
                    } catch (IOException e) {
                        throw new RpcWritableException(
                                "Write out param for call " + call + " failed",
                                e);
                    }
                } else {
                    try {
                        out.writeLong(call.signature);
                        RpcSerializer.writeArgs(call.method, call.args, out);
                        byte[] data = byteArrayOut.data();
                        int size = byteArrayOut.size();
                        CDataOutputStream.writeInt(call.id, data, 0);
                        CDataOutputStream.writeInt(size - 8, data, 4);
                        rawOut.write(data, 0, size);
                        rawOut.flush();
                    } catch (IOException e) {
                        throw new RpcWritableException(
                                "Write out param for call " + call + " failed",
                                e);
                    } finally {
                        byteArrayOut.clear();
                    }
                }
                error = false;
            } finally {
                if (error) {
                    close();
                }
            }
        }

        @Override
        public void run() {
            try {
                while (running) {
                    lastActiveTime = System.currentTimeMillis();
                    int id;
                    try {
                        id = in.readInt();
                    } catch (SocketTimeoutException e) {
                        continue;
                    }
                    Call call = pendingCalls.remove(id);
                    if (call == null) {
                        LOG.severe("Unknown call ID received: " + id
                                + ". This is usually because readFields and "
                                + "writeFields is not match, or RpcServer and "
                                + "RpcClient has different writable implements");
                        continue;
                    }
                    byte errorFlag = in.readByte();
                    try {
                        if (errorFlag == CALL_SUCCESS) {
                            if (call.returnValueBuffer != null) {
                                call.returnValue = RpcSerializer.readReturnValue(
                                        call.returnValueBuffer, in);
                            } else {
                                call.returnValue = RpcSerializer.readReturnValue(
                                        call.method, in);
                            }
                        } else {// CALL_EXCEPTION
                            call.error = readException();
                            if (call.error == null) {
                                call.error = new RpcException(
                                        "server decide call to be exception, but do not pass the exception object");
                            }
                        }
                    } catch (Throwable t) {
                        call.error = new RpcWritableException(
                                "read return value failed", t);
                    }
                    synchronized (call) {
                        call.finished = true;
                        call.notifyAll();
                    }
                    errorTracker.noErrorOccur();
                }
            } catch (EOFException e) {
                // On Windows, this is what happens when the remote side goes
                // down
                LOG.log(Level.WARNING, name + " connection to server "
                        + remoteAddr + " closed", e);
            } catch (SocketException e) {
                // On Linux, this is what happens when the remote side goes down
                LOG.log(Level.WARNING, name + " connection to server "
                        + remoteAddr + " closed", e);
            } catch (Throwable t) {
                LOG.log(Level.WARNING, name + " unexpected exception caught", t);
            } finally {
                close();
                for (Call call: pendingCalls.values()) {
                    synchronized (call) {
                        call.finished = true;
                        call.error = new RpcException("connection to server "
                                + remoteAddr + " closed");
                        call.notifyAll();
                    }
                }
                errorTracker.fatalErrorOccur();
            }
        }

        public void close() {
            closed = true;
            MiscUtils.safeClose(out);
            MiscUtils.safeClose(in);
            MiscUtils.safeClose(rawOut);
            MiscUtils.safeClose(byteArrayOut);
            MiscUtils.safeClose(socket);
        }
    }

    protected void createConnection(int index, boolean recordResponse)
            throws RpcException {
        ConnectionImpl conn;
        try {
            conn = new ConnectionImpl("Client " + clientName
                    + " connection No." + index + " to " + remoteAddr
                    + " for protocol " + protocol.getName());
        } catch (IOException e) {
            errorTracker.fatalErrorOccur();
            throw new RpcException(clientName + " create connection to "
                    + remoteAddr + " failed", e);
        }
        try {
            conn.init(recordResponse);
        } catch (Throwable t) {
            errorTracker.fatalErrorOccur();
            conn.close();
            if (t instanceof RuntimeException) {
                throw (RuntimeException) t;
            } else if (t instanceof RpcException) {
                throw (RpcException) t;
            } else {
                throw new RpcException("init connection failed", t);
            }
        }
        Thread t = new Thread(conn, conn.name);
        t.setDaemon(true);
        t.start();
        activeConnections[index] = conn;
        LOG.info("Connection " + conn + " created");
    }

    protected RpcClient(Class<?> protocol, InetSocketAddress remoteAddr,
            String authInfo, String domain, String username, long timeout,
            String clientName, ErrorTracker errorTracker,
            ScheduledExecutorService heartbeatExecutor) throws RpcException {
        super(protocol, remoteAddr, authInfo, domain, username, timeout,
                clientName, errorTracker, heartbeatExecutor);
    }

    @Override
    public String toString() {
        return "RpcClient [authInfo=" + authInfo + ", clientName=" + clientName
                + ", domain=" + domain + ", protocol=" + protocol.getName()
                + ", remoteAddr=" + remoteAddr + ", timeout=" + timeout
                + ", username=" + username + "]";
    }

}
