/**
 * @(#)UDPRpcClient.java, 2011-10-30. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2;

import java.io.IOException;
import java.lang.reflect.Method;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.util.Map;
import java.util.logging.Logger;

import odis.io.CDataOutputStream;
import odis.io.DirectByteArrayOutputStream;
import odis.util.MiscUtils;
import toolbox.misc.LogFormatter;

/**
 * A simple rpc client using udp.
 * 
 * @author zhangduo
 */
public class UDPRpcClient<P> {

    @SuppressWarnings("unused")
    private static final Logger LOG = LogFormatter.getLogger(UDPRpcClient.class);

    private final Map<Method, Long> method2signature;

    private final DatagramSocket socket;

    final InetSocketAddress remoteAddr;

    protected UDPRpcClient(Class<P> protocol, InetSocketAddress remoteAddr)
            throws SocketException {
        this.method2signature = ProtocolVerifier.clientVerify(protocol);
        this.remoteAddr = remoteAddr;
        this.socket = new DatagramSocket();
        this.socket.connect(remoteAddr);
    }

    /**
     * do a rpc call.
     * 
     * @param method
     * @param args
     * @throws IOException
     */
    public void call(Method method, Object[] args) throws IOException {
        DirectByteArrayOutputStream bos = new DirectByteArrayOutputStream();
        CDataOutputStream dos = new CDataOutputStream(bos);
        long signature = method2signature.get(method);
        dos.writeLong(signature);
        RpcSerializer.writeArgs(method, args, dos);
        int size = bos.size();
        byte[] buf = bos.getBuffer();
        DatagramPacket packet = new DatagramPacket(buf, size);
        socket.send(packet);
    }
    
    /**
     * close the udp socket.
     */
    public void close() {
        MiscUtils.safeClose(socket);
    }
}
