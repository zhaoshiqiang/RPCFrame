/**
 * @(#)RPC.java, 2010-8-13. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2;

import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Logger;

import odis.rpc2.AbstractRpcClient.CallFuture;
import odis.serialize.IWritable;
import odis.serialize.lib.ArrayWritable;
import odis.util.ProcessUtils;
import toolbox.misc.LogFormatter;
import toolbox.misc.net.InetAddressUtils;
import toolbox.text.util.HexString;

/**
 * A simple RPC mechanism. A <i>protocol</i> is simply a Java interface. All
 * parameters and return types must be one of:
 * <ul>
 * <li>a primitive type, <code>boolean</code>, <code>byte</code>,
 * <code>char</code>, <code>short</code>, <code>int</code>, <code>long</code>,
 * <code>float</code>, <code>double</code>, <code>void</code>, or its wrapper
 * type.</li>
 * <li>an <code>enum</code>;</li>
 * <li>a {@link String};</li>
 * <li>an {@link IWritable};</li>
 * <li>a {@link Collection};</li>
 * <li>a {@link Map};</li>
 * <li>an array of the above types</li>
 * </ul>
 * <p>
 * <strong>NOTE: </strong> <code>Collection</code> and <code>Map</code> should
 * be used carefully. You can put Object with any type to a Collection or Map,
 * so we can not detect writable error until we actually read or write the
 * <code>Collection</code> or <code>Map</code>. You will get an
 * {@link RpcWritableException} when you put something that can not be
 * serialized by our RPC framework and try to use it in an rpc call. And also,
 * we nearly always need to pass the type information for every element in
 * <code>Collection</code> and <code>Map</code>(because we have no other
 * information to determine an element's type in <code>Collection</code> or
 * <code>Map</code>), so if you put small object in them, the overhead may not
 * be ignored if your program is sensitive to throughput.
 * </p>
 * <p>
 * <strong>NOTE: </strong>multidimensional array is supported but not
 * recommended, because it is too complex, we may have error under some special
 * cases.
 * </p>
 * <p>
 * <strong>NOTE: </strong>the class must have a default constructor because the
 * RPC framework need to construct it when we read(an exception,
 * {@link ArrayBlockingQueue}). And for <code>IWritable</code> classes, make
 * sure the readFields can work with default constructor(an exception,
 * {@link ArrayWritable}).
 * </p>
 * <p>
 * All exception will be sent back to the client as its original type.
 * {@link RpcException} is thrown when we got error in the RPC framework, you
 * should <strong>NOT</strong> throw {@link RpcException} in your code.
 * </p>
 * <p>
 * The server-side starts an RPC service by calling <code>getServer</code> or
 * <code>getNIOServer</code> methods.
 * </p>
 * <p>
 * The client side connects to an service remotely by calling
 * <code>getProxy</code> methods.<br>
 * We will create a new connection in every <code>getProxy</code> call, so you
 * should reuse the object construct by <code>getProxy</code>.If a proxy object
 * is not needed, call {@link RPC#close(Object)} to close the connection.
 * </p>
 * 
 * @author zhangduo
 */
public final class RPC {

    private static final Logger LOG = LogFormatter.getLogger(RPC.class);

    public static final int DEFAULT_MAX_CONNECTION_PER_CLIENT = 2;

    public static final long DEFAULT_CLIENT_DISCONNECT_TIME = 0;

    public static final long DEFAULT_CLIENT_TIMEOUT = 0;

    public static final String DEFAULT_AUTH_INFO = "";

    public static final String DEFAULT_DOMAIN = "";

    public static final String DEFAULT_USERNAME = "";

    public static final long DEFAULT_MAX_READ_BUFFER_SIZE = 0;

    private static final ScheduledExecutorService heartbeatExecutor = Executors.newScheduledThreadPool(
            1, new ThreadFactory() {

                @Override
                public Thread newThread(Runnable r) {
                    Thread thread = new Thread(r, "RpcClient-Heartbeat-Thread");
                    thread.setDaemon(true);
                    return thread;
                }
            });

    static Random rand = new Random();

    private RPC() {}

    static class Invoker implements InvocationHandler, RpcClient.ErrorTracker {
        private volatile boolean closed = false;

        volatile AbstractRpcClient client;

        AtomicInteger fatalErrorCount = new AtomicInteger(0);

        static final int FATAL_ERROR_THRESHOLD = 10;

        private final Lock clientLock = new ReentrantLock();

        private final String clientName;

        private final Class<?> protocol;

        private final InetSocketAddress remoteAddr;

        private final String authInfo;

        private final String domain;

        private final String username;

        private final long timeout;

        private final byte clientIOMode;

        Invoker(Class<?> protocol, InetSocketAddress remoteAddr,
                String authInfo, String domain, String username, long timeout,
                byte clientIOMode) throws RpcException {
            this.protocol = protocol;
            this.remoteAddr = InetSocketAddress.createUnresolved(
                    remoteAddr.getHostName(), remoteAddr.getPort());
            this.authInfo = authInfo;
            this.domain = domain;
            this.username = username;
            this.timeout = timeout;
            try {
                this.clientName = InetAddressUtils.getShortHostName() + "-"
                        + ProcessUtils.getPid() + "-" + protocol.getName()
                        + "-" + HexString.intToPaddedHex(hashCode());
            } catch (IOException e) {
                throw new RpcException("generate client name failed", e);
            }
            this.clientIOMode = clientIOMode;
        }

        private AbstractRpcClient getClient() throws RpcException {
            if (closed) {
                throw new RpcException("Proxy already closed");
            }
            AbstractRpcClient client = this.client;
            if (client == null) {
                try {
                    if (timeout > 0) {
                        if (!clientLock.tryLock(timeout, TimeUnit.MILLISECONDS)) {
                            throw new RpcTimeoutException(
                                    "Timeout when acquire rpc client");
                        }
                    } else {
                        clientLock.lockInterruptibly();
                    }
                } catch (InterruptedException e) {
                    throw new RpcException(
                            "Interrupted when acquire rpc client", e);
                }
                try {
                    if (closed) {
                        throw new RpcException("Proxy already closed");
                    }
                    client = this.client;
                    if (client == null) {
                        // recreate remoteAddr will force the host be resolve again.
                        // this is useful when ip changed.
                        if (clientIOMode == AbstractRpcClient.SERVER_IO_MODE_BIO) {
                            client = new RpcClient(protocol,
                                    new InetSocketAddress(
                                            remoteAddr.getHostName(),
                                            remoteAddr.getPort()), authInfo,
                                    domain, username, timeout, clientName,
                                    this, heartbeatExecutor);
                        } else {
                            client = new NIORpcClient(protocol,
                                    new InetSocketAddress(
                                            remoteAddr.getHostName(),
                                            remoteAddr.getPort()), authInfo,
                                    domain, username, timeout, clientName,
                                    this, heartbeatExecutor);
                        }
                        this.client = client;
                    }
                } finally {
                    clientLock.unlock();
                }
            }
            return client;
        }

        @Override
        public Object invoke(Object proxy, Method method, Object[] args)
                throws Throwable {
            // delegate Object methods like toString, hashCode, etc.
            if (method.getDeclaringClass().equals(Object.class)) {
                return method.invoke(this, args);
            }
            long startTime = System.currentTimeMillis();
            return getClient().call(method, null, args, startTime).innerGet();
        }

        public IWritable invoke(Method method, IWritable returnValueBuffer,
                Object[] args) throws Throwable {
            long startTime = System.currentTimeMillis();
            return (IWritable) getClient().call(method, returnValueBuffer,
                    args, startTime).innerGet();
        }

        public <V> CallFuture<V> asyncInvoke(Method method, Object[] args)
                throws RpcException {
            long startTime = System.currentTimeMillis();
            return getClient().call(method, null, args, startTime);
        }

        public <V extends IWritable> CallFuture<V> asyncInvoke(Method method,
                V returnValueBuffer, Object[] args) throws RpcException {
            long startTime = System.currentTimeMillis();
            return getClient().call(method, returnValueBuffer, args, startTime);
        }

        @Override
        public String toString() {
            return "Invoker [protocol=" + protocol.getName() + ", remoteAddr="
                    + remoteAddr + ", authInfo=" + authInfo + ", domain="
                    + domain + ", username=" + username + ", timeout="
                    + timeout + "]";
        }

        @Override
        public void noErrorOccur() {
            fatalErrorCount.set(0);
        }

        @Override
        public void fatalErrorOccur() {
            if (fatalErrorCount.incrementAndGet() >= FATAL_ERROR_THRESHOLD) {
                clientLock.lock();
                try {
                    if (fatalErrorCount.get() < FATAL_ERROR_THRESHOLD) {
                        return;
                    }
                    AbstractRpcClient client = this.client;
                    if (client != null) {
                        LOG.info("fatal error count reach limit "
                                + FATAL_ERROR_THRESHOLD + ", close RpcClient");
                        this.client = null;
                        client.stop();
                        fatalErrorCount.set(0);
                    }
                } finally {
                    clientLock.unlock();
                }
            }
        }

        @Override
        public void needReinitialize() {
            clientLock.lock();
            try {
                AbstractRpcClient client = this.client;
                if (client != null) {
                    LOG.info("close RpcClient immediately");
                    this.client = null;
                    client.stop();
                    fatalErrorCount.set(0);
                }
            } finally {
                clientLock.unlock();
            }
        }

        public void closeConnection() throws InterruptedException {
            clientLock.lock();
            try {
                AbstractRpcClient client = this.client;
                if (client != null) {
                    client.closeConnection();
                }
            } finally {
                clientLock.unlock();
            }
        }

        public void close() {
            closed = true;
            clientLock.lock();
            try {
                AbstractRpcClient client = this.client;
                if (client != null) {
                    client.stop();
                }
            } finally {
                clientLock.unlock();
            }
        }
    }

    /**
     * call
     * {@link RPC#getProxy(Class, InetSocketAddress, String, String, String, long)}
     * with {@link RPC#DEFAULT_AUTH_INFO}, {@link RPC#DEFAULT_DOMAIN},
     * {@link RPC#DEFAULT_USERNAME},{@link RPC#DEFAULT_CLIENT_TIMEOUT}
     */
    public static <V> V getProxy(Class<V> protocol, InetSocketAddress remoteAddr)
            throws RpcException {
        return getProxy(protocol, remoteAddr, DEFAULT_AUTH_INFO,
                DEFAULT_DOMAIN, DEFAULT_USERNAME, DEFAULT_CLIENT_TIMEOUT);
    }

    /**
     * call
     * {@link RPC#getProxy(Class, InetSocketAddress, String, String, String, long)}
     * with {@link RPC#DEFAULT_AUTH_INFO}, {@link RPC#DEFAULT_DOMAIN},
     * {@link RPC#DEFAULT_USERNAME}
     */
    public static <V> V getProxy(Class<V> protocol,
            InetSocketAddress remoteAddr, long timeout) throws RpcException {
        return getProxy(protocol, remoteAddr, DEFAULT_AUTH_INFO,
                DEFAULT_DOMAIN, DEFAULT_USERNAME, timeout);
    }

    /**
     * call
     * {@link RPC#getProxy(Class, InetSocketAddress, String, String, String, long)}
     * with {@link RPC#DEFAULT_AUTH_INFO}
     */
    public static <V> V getProxy(Class<V> protocol,
            InetSocketAddress remoteAddr, String domain, String username,
            long timeout) throws RpcException {
        return getProxy(protocol, remoteAddr, DEFAULT_AUTH_INFO, domain,
                username, timeout);
    }

    /**
     * Construct a client-side proxy object that implements the named protocol,
     * talking to a server at the named address. All methods defined in the RPC
     * interface (i.e. <code>protocol</code>) must be declared to throw
     * {@link RpcException} .<br>
     * The method inherited from {@link Object} will be handled locally.<br>
     * 
     * @param protocol
     * @param remoteAddr
     * @param authInfo
     *            a string token the server used to do authentication.if your
     *            server do not use it, use {@link RPC#DEFAULT_AUTH_INFO} .
     * @param domain
     *            a domain certain group of calls belong to, with which server
     *            can avoid calls from one client filling up the thread pool.if
     *            you do not need this, use {@link RPC#DEFAULT_DOMAIN}
     * @param username
     *            a name the server used to identify an user.if your server do
     *            not use it, use {@link RPC#DEFAULT_USERNAME}
     * @param timeout
     *            timeout of calls in ms, including sending and receiving. if 0,
     *            will wait indefinitely
     * @return
     * @throws RpcException
     */
    @SuppressWarnings("unchecked")
    public static <V> V getProxy(Class<V> protocol,
            InetSocketAddress remoteAddr, String authInfo, String domain,
            String username, long timeout) throws RpcException {
        LOG.info("get proxy, protocol = " + protocol + ", remoteAddr = "
                + remoteAddr + ", authInfo = " + authInfo + ", domain = "
                + domain + ", username = " + username + ", timeout = "
                + timeout);
        return (V) Proxy.newProxyInstance(protocol.getClassLoader(),
                new Class[] {
                    protocol
                },
                new Invoker(protocol, remoteAddr, authInfo, domain, username,
                        timeout, AbstractRpcClient.SERVER_IO_MODE_BIO));
    }

    /**
     * call
     * {@link RPC#getNIOProxy(Class, InetSocketAddress, String, String, String, long)}
     * with {@link RPC#DEFAULT_AUTH_INFO}, {@link RPC#DEFAULT_DOMAIN},
     * {@link RPC#DEFAULT_USERNAME},{@link RPC#DEFAULT_CLIENT_TIMEOUT}
     */
    public static <V> V getNIOProxy(Class<V> protocol,
            InetSocketAddress remoteAddr) throws RpcException {
        return getNIOProxy(protocol, remoteAddr, DEFAULT_AUTH_INFO,
                DEFAULT_DOMAIN, DEFAULT_USERNAME, DEFAULT_CLIENT_TIMEOUT);
    }

    /**
     * call
     * {@link RPC#getNIOProxy(Class, InetSocketAddress, String, String, String, long)}
     * with {@link RPC#DEFAULT_AUTH_INFO}, {@link RPC#DEFAULT_DOMAIN},
     * {@link RPC#DEFAULT_USERNAME}
     */
    public static <V> V getNIOProxy(Class<V> protocol,
            InetSocketAddress remoteAddr, long timeout) throws RpcException {
        return getNIOProxy(protocol, remoteAddr, DEFAULT_AUTH_INFO,
                DEFAULT_DOMAIN, DEFAULT_USERNAME, timeout);
    }

    /**
     * call
     * {@link RPC#getNIOProxy(Class, InetSocketAddress, String, String, String, long)}
     * with {@link RPC#DEFAULT_AUTH_INFO}
     */
    public static <V> V getNIOProxy(Class<V> protocol,
            InetSocketAddress remoteAddr, String domain, String username,
            long timeout) throws RpcException {
        return getNIOProxy(protocol, remoteAddr, DEFAULT_AUTH_INFO, domain,
                username, timeout);
    }

    /**
     * See the comments of
     * {@link #getProxy(Class, InetSocketAddress, String, String, String, long)}
     * .<br>
     * The only different is that the proxy returned by this method will use
     * Non-Blocking IO to communicate with RpcServer.
     * 
     * @param protocol
     * @param remoteAddr
     * @param authInfo
     * @param domain
     * @param username
     * @param timeout
     * @return
     * @throws RpcException
     */
    @SuppressWarnings("unchecked")
    public static <V> V getNIOProxy(Class<V> protocol,
            InetSocketAddress remoteAddr, String authInfo, String domain,
            String username, long timeout) throws RpcException {
        LOG.info("get NIO proxy, protocol = " + protocol + ", remoteAddr = "
                + remoteAddr + ", authInfo = " + authInfo + ", domain = "
                + domain + ", username = " + username + ", timeout = "
                + timeout);
        return (V) Proxy.newProxyInstance(protocol.getClassLoader(),
                new Class[] {
                    protocol
                },
                new Invoker(protocol, remoteAddr, authInfo, domain, username,
                        timeout, AbstractRpcClient.SERVER_IO_MODE_NIO));
    }

    /**
     * Call a proxy method asynchronously.<br>
     * If you call {@link Future#get(long, java.util.concurrent.TimeUnit)}, and
     * timeout is large than the timeout you used to getProxy, then the behavor
     * is same with call {@link Future#get()}. If the timeout is smaller than
     * timeout you used to getProxy, then the call will throw a TimeoutException
     * if a timeout happen. Notice that, 0 means <strong>NO</strong> timeout
     * here.<br>
     * 
     * @param <V>
     * @param proxy
     *            the Object you construct using getProxy.
     * @param method
     * @param args
     * @return
     * @throws RpcException
     */
    public static <V> Future<V> asyncInvoke(Object proxy, Method method,
            Object... args) throws RpcException {
        Invoker invoker = (Invoker) Proxy.getInvocationHandler(proxy);
        return invoker.asyncInvoke(method, args);
    }

    /**
     * call a proxy method with a return value buffer. we will use this buffer
     * to store the return value instead of creating a new one.<br>
     * Notice that, we do not check whether the type of the return value buffer
     * and the method is consistent, if not consistent, the behaviour is
     * undefined.
     * 
     * @param proxy
     *            the Object you construct using getProxy.
     * @param method
     * @param returnValueBuffer
     *            the buffer you used to store return value.
     * @param args
     * @return if return value if <code>null</code>, return <code>null</code>.
     *         otherwise, return the returnValueBuffer passed in.
     * @throws Throwable
     */
    public static IWritable invokeWithBuffer(Object proxy, Method method,
            IWritable returnValueBuffer, Object... args) throws Throwable {
        Invoker invoker = (Invoker) Proxy.getInvocationHandler(proxy);
        return invoker.invoke(method, returnValueBuffer, args);
    }

    /**
     * call a proxy method with a return value buffer asynchronously.<br>
     * 
     * @see RPC#invokeWithBuffer(Object, Method, IWritable, Object...)
     * @see RPC#asyncInvoke(Object, Method, Object...)
     * @param <V>
     * @param proxy
     *            the Object you construct using getProxy.
     * @param method
     * @param returnValueBuffer
     *            the buffer you used to store return value.
     * @param args
     * @return
     * @throws RpcException
     */
    public static <V extends IWritable> Future<V> asyncInvokeWithBuffer(
            Object proxy, Method method, V returnValueBuffer, Object... args)
            throws RpcException {
        Invoker invoker = (Invoker) Proxy.getInvocationHandler(proxy);
        return invoker.asyncInvoke(method, returnValueBuffer, args);
    }

    /**
     * Close the connection connected to remote server in the proxy object.if
     * the object is not a proxy object, the method will return and do nothing.
     * 
     * @param proxy
     */
    public static void close(Object proxy) {
        if (!Proxy.isProxyClass(proxy.getClass())) {
            return;
        }
        Invoker invoker = (Invoker) Proxy.getInvocationHandler(proxy);
        LOG.info("close proxy " + invoker);
        invoker.close();
    }

    /**
     * used for test
     * 
     * @param proxy
     * @throws InterruptedException
     */
    public static void closeConnection(Object proxy)
            throws InterruptedException {
        if (!Proxy.isProxyClass(proxy.getClass())) {
            return;
        }
        Invoker invoker = (Invoker) Proxy.getInvocationHandler(proxy);
        LOG.info("close proxy connection " + invoker);
        invoker.closeConnection();
    }

    /**
     * Get the client name of this proxy object. If the object is not a proxy
     * object, <code>null</code> will be returned.
     * 
     * @param proxy
     * @return
     */
    public static String getClientName(Object proxy) {
        if (!Proxy.isProxyClass(proxy.getClass())) {
            return null;
        }
        Invoker invoker = (Invoker) Proxy.getInvocationHandler(proxy);
        return invoker.clientName;
    }

    /**
     * Get the server address of this proxy object. If the object is not a proxy
     * object, <code>null</code> will be returned.
     * 
     * @param proxy
     * @return
     */
    public static InetSocketAddress getRemoteAddr(Object proxy) {
        if (!Proxy.isProxyClass(proxy.getClass())) {
            return null;
        }
        Invoker invoker = (Invoker) Proxy.getInvocationHandler(proxy);
        return invoker.remoteAddr;
    }

    /**
     * call {@link RPC#getServer(Class, Object, int, int, int, int, long)} with
     * 2 * <code>handlerCount</code>,
     * {@link RPC#DEFAULT_MAX_CONNECTION_PER_CLIENT},
     * {@link RPC#DEFAULT_CLIENT_DISCONNECT_TIME}
     */
    public static RpcServer getServer(Class<?> protocol, Object instance,
            int port, int handlerCount) {
        return getServer(protocol, instance, port, handlerCount,
                2 * handlerCount, DEFAULT_MAX_CONNECTION_PER_CLIENT,
                DEFAULT_CLIENT_DISCONNECT_TIME);
    }

    /**
     * just call {RPC#getServer(List, List, int, int, int, int, long)}.
     * 
     * @see RPC#getServer(List, List, int, int, int, int, long)
     */
    public static RpcServer getServer(Class<?> protocol, Object instance,
            int port, int handlerCount, int queueSize, int maxConnPerClient,
            long clientDisconnectTime) {
        List<Class<?>> protocols = new ArrayList<Class<?>>();
        protocols.add(protocol);
        List<Object> instances = new ArrayList<Object>();
        instances.add(instance);
        return getServer(protocols, instances, port, handlerCount, queueSize,
                maxConnPerClient, clientDisconnectTime);
    }

    /**
     * call {@link RPC#getServer(List, List, int, int, int, int, long)} with 2 *
     * <code>handlerCount</code>, {@link RPC#DEFAULT_MAX_CONNECTION_PER_CLIENT},
     * {@link RPC#DEFAULT_CLIENT_DISCONNECT_TIME}
     */
    public static RpcServer getServer(List<Class<?>> protocols,
            List<Object> instances, int port, int handlerCount) {
        return getServer(protocols, instances, port, handlerCount,
                2 * handlerCount, DEFAULT_MAX_CONNECTION_PER_CLIENT,
                DEFAULT_CLIENT_DISCONNECT_TIME);
    }

    /**
     * Construct a server for several protocols and instances.<br>
     * protocols and instances must have same size.<br>
     * the returned server is not started yet, you should call
     * {@link AbstractRpcServer#start()} to start it.
     * 
     * @param protocols
     *            the protocol interfaces.
     * @param instances
     *            the instances which implement the protocol interfaces.
     * @param port
     *            the server listening on
     * @param handlerCount
     *            server hanlder count. a handler is a thread that server used
     *            to handle rpc call.
     * @param queueSize
     *            the waiting queue size. server will store a call object in the
     *            queue before it handled by a handler.
     * @param maxConnPerClient
     *            the max connection count the server allowed for one client.
     * @param clientDisconnectTime
     *            a time in ms. if a client does not active for this time, the
     *            server will consider the client is disconnect and close the
     *            connection of this client. if set to 0, server will not do
     *            this check.
     * @return
     */
    public static RpcServer getServer(List<Class<?>> protocols,
            List<Object> instances, int port, int handlerCount, int queueSize,
            int maxConnPerClient, long clientDisconnectTime) {
        LOG.info("get Rpc Server, protocols = " + protocols + ", instance = "
                + instances + ", port = " + port + " handlerCount = "
                + handlerCount + " queueSize = " + queueSize
                + " maxConnPerClient = " + maxConnPerClient
                + " clientDisconnectTime = " + clientDisconnectTime);
        if (protocols.isEmpty()) {
            throw new IllegalArgumentException("no protocol");
        }
        if (protocols.size() != instances.size()) {
            throw new IllegalArgumentException("has " + protocols.size()
                    + " protocols but has " + instances.size() + " instance");
        }
        RpcServer server = new RpcServer(port, handlerCount, queueSize,
                maxConnPerClient, clientDisconnectTime);
        for (int i = 0; i < protocols.size(); i++) {
            server.addProtocol(protocols.get(i), instances.get(i));
        }
        return server;
    }

    /**
     * call {@link RPC#getNIOServer(Class, Object, int, int, int, int, long)}
     * with 2 * <code>handlerCount</code>,
     * {@link RPC#DEFAULT_MAX_CONNECTION_PER_CLIENT},
     * {@link RPC#DEFAULT_CLIENT_DISCONNECT_TIME}
     */
    public static NIORpcServer getNIOServer(Class<?> protocol, Object instance,
            int port, int handlerCount) {
        return getNIOServer(protocol, instance, port, handlerCount,
                2 * handlerCount, DEFAULT_MAX_CONNECTION_PER_CLIENT,
                DEFAULT_CLIENT_DISCONNECT_TIME);
    }

    /**
     * call
     * {@link RPC#getNIOServer(Class, Object, int, int, int, int, long, int)}
     * with 2 * AvailableProcessors.
     */
    public static NIORpcServer getNIOServer(Class<?> protocol, Object instance,
            int port, int handlerCount, int queueSize, int maxConnPerClient,
            long clientDisconnectTime) {
        return getNIOServer(
                protocol,
                instance,
                port,
                handlerCount,
                queueSize,
                maxConnPerClient,
                clientDisconnectTime,
                2 * ManagementFactory.getOperatingSystemMXBean().getAvailableProcessors());
    }

    /**
     * call
     * {@link #getNIOServer(Class, Object, int, int, int, int, long, int, long)}
     * with {@link #DEFAULT_MAX_READ_BUFFER_SIZE}
     */
    public static NIORpcServer getNIOServer(Class<?> protocol, Object instance,
            int port, int handlerCount, int queueSize, int maxConnPerClient,
            long clientDisconnectTime, int workerCount) {
        return getNIOServer(protocol, instance, port, handlerCount, queueSize,
                maxConnPerClient, clientDisconnectTime, workerCount,
                DEFAULT_MAX_READ_BUFFER_SIZE);
    }

    /**
     * just call
     * {@link #getNIOServer(List, List, int, int, int, int, long, int, long, long)}
     * 
     * @see RPC##getNIOServer(List, List, int, int, int, int, long, int, long,
     *      long)
     */
    public static NIORpcServer getNIOServer(Class<?> protocol, Object instance,
            int port, int handlerCount, int queueSize, int maxConnPerClient,
            long clientDisconnectTime, int workerCount, long maxReadBufferSize) {
        List<Class<?>> protocols = new ArrayList<Class<?>>();
        protocols.add(protocol);
        List<Object> instances = new ArrayList<Object>();
        instances.add(instance);
        return getNIOServer(protocols, instances, port, handlerCount,
                queueSize, maxConnPerClient, clientDisconnectTime, workerCount,
                maxReadBufferSize);
    }

    /**
     * just call
     * {@link #getNIOServer(List, List, int, int, int, int, long, int, long, long)}
     * 
     * @see RPC##getNIOServer(List, List, int, int, int, int, long, int, long,
     *      long)
     * @deprecated <code>maxWaitTimeWhenReturnValueQueueFull</code> is not used.
     */
    public static NIORpcServer getNIOServer(Class<?> protocol, Object instance,
            int port, int handlerCount, int queueSize, int maxConnPerClient,
            long clientDisconnectTime, int workerCount, long maxReadBufferSize,
            long maxWaitTimeWhenReturnValueQueueFull) {
        List<Class<?>> protocols = new ArrayList<Class<?>>();
        protocols.add(protocol);
        List<Object> instances = new ArrayList<Object>();
        instances.add(instance);
        return getNIOServer(protocols, instances, port, handlerCount,
                queueSize, maxConnPerClient, clientDisconnectTime, workerCount,
                maxReadBufferSize, maxWaitTimeWhenReturnValueQueueFull);
    }

    /**
     * call {@link RPC#getNIOServer(List, List, int, int, int, int, long)} with
     * 2 * <code>handlerCount</code>,
     * {@link RPC#DEFAULT_MAX_CONNECTION_PER_CLIENT},
     * {@link RPC#DEFAULT_CLIENT_DISCONNECT_TIME}
     */
    public static NIORpcServer getNIOServer(List<Class<?>> protocols,
            List<Object> instances, int port, int handlerCount) {
        return getNIOServer(protocols, instances, port, handlerCount,
                2 * handlerCount, DEFAULT_MAX_CONNECTION_PER_CLIENT,
                DEFAULT_CLIENT_DISCONNECT_TIME);
    }

    /**
     * call {@link RPC#getNIOServer(List, List, int, int, int, int, long, int)}
     * with 2 * AvailableProcessors.
     */
    public static NIORpcServer getNIOServer(List<Class<?>> protocols,
            List<Object> instances, int port, int handlerCount, int queueSize,
            int maxConnPerClient, long clientDisconnectTime) {
        return getNIOServer(
                protocols,
                instances,
                port,
                handlerCount,
                queueSize,
                maxConnPerClient,
                clientDisconnectTime,
                2 * ManagementFactory.getOperatingSystemMXBean().getAvailableProcessors());
    }

    /**
     * call
     * {@link #getNIOServer(List, List, int, int, int, int, long, int, long)}
     * with {@link #DEFAULT_MAX_READ_BUFFER_SIZE}
     */
    public static NIORpcServer getNIOServer(List<Class<?>> protocols,
            List<Object> instances, int port, int handlerCount, int queueSize,
            int maxConnPerClient, long clientDisconnectTime, int workerCount) {
        return getNIOServer(protocols, instances, port, handlerCount,
                queueSize, maxConnPerClient, clientDisconnectTime, workerCount,
                DEFAULT_MAX_READ_BUFFER_SIZE);
    }

    /**
     * Construct a server for several protocols and instances using Non-Blocking
     * IO.<br>
     * Most parameter is same as <code>getServer</code>.
     * 
     * @see RPC#getServer(List, List, int, int, int, int, long)
     * @param protocols
     * @param instances
     * @param port
     * @param handlerCount
     * @param queueSize
     * @param maxConnPerClient
     * @param clientDisconnectTime
     * @param workerCount
     *            the worker count. a worker is a thread that server used to
     *            read and write with socket. the default value is 2 *
     *            AvailableProcessors.
     * @param maxReadBufferSize
     * @return
     */
    public static NIORpcServer getNIOServer(List<Class<?>> protocols,
            List<Object> instances, int port, int handlerCount, int queueSize,
            int maxConnPerClient, long clientDisconnectTime, int workerCount,
            long maxReadBufferSize) {
        LOG.info("get NIO Rpc Server, protocols = " + protocols
                + ", instance = " + instances + ", port = " + port
                + " handlerCount = " + handlerCount + " queueSize = "
                + queueSize + " maxConnPerClient = " + maxConnPerClient
                + " clientDisconnectTime = " + clientDisconnectTime
                + " workerCount = " + workerCount + " maxReadBufferSize = "
                + maxReadBufferSize);
        if (protocols.isEmpty()) {
            throw new IllegalArgumentException("no protocol");
        }
        if (protocols.size() != instances.size()) {
            throw new IllegalArgumentException("has " + protocols.size()
                    + " protocols but has " + instances.size() + " instance");
        }
        NIORpcServer server = new NIORpcServer(port, handlerCount, queueSize,
                maxConnPerClient, clientDisconnectTime, workerCount,
                maxReadBufferSize);
        for (int i = 0; i < protocols.size(); i++) {
            server.addProtocol(protocols.get(i), instances.get(i));
        }
        return server;
    }

    /**
     * Just keep compatible.
     * 
     * @deprecated <code>maxWaitTimeWhenReturnValueQueueFull</code> is not used.
     */
    public static NIORpcServer getNIOServer(List<Class<?>> protocols,
            List<Object> instances, int port, int handlerCount, int queueSize,
            int maxConnPerClient, long clientDisconnectTime, int workerCount,
            long maxReadBufferSize, long maxWaitTimeWhenReturnValueQueueFull) {
        return RPC.getNIOServer(protocols, instances, port, handlerCount,
                queueSize, maxConnPerClient, clientDisconnectTime, workerCount,
                maxReadBufferSize);
    }

    /**
     * Construct a server with given <code>protocol</code> and
     * <code>instance</code> using udp protocl.
     * <p>
     * This is a RAW implements, we have only one thread that do all the things.
     * So if your instance call will block or execute for a long time, use a
     * thread pool yourself.
     * 
     * @param <P>
     * @param protocol
     * @param instance
     * @param port
     * @return
     * @throws IOException
     */
    public static <P> UDPRpcServer getUDPServer(Class<P> protocol, P instance,
            int port) throws IOException {
        return new UDPRpcServer(port, protocol, instance);
    }

    static class UDPInvoker<P> implements InvocationHandler {

        private final UDPRpcClient<P> client;

        public UDPInvoker(UDPRpcClient<P> client) {
            this.client = client;
        }

        @Override
        public Object invoke(Object proxy, Method method, Object[] args)
                throws Throwable {
            if (method.getDeclaringClass().equals(Object.class)) {
                return method.invoke(this, args);
            }
            try {
                client.call(method, args != null ? args : new Object[0]);
            } catch (IOException e) {
                throw new RpcException(e);
            }
            return null;
        }

        public void close() {
            client.close();
        }

    }

    /**
     * Get a rpc client that use udp protocol.
     * <p>
     * <strong>NOTICE: </strong>we do not implement a reliable protocol over
     * udp, we just send the packet out and return. The packet will be truncated
     * if its size is too large(no packet split), and we do not guarantee that
     * the server will get this packet(no failure detect and no retransmission).
     * The return value is always null if your method has a return value.
     * 
     * @param <P>
     * @param protocol
     * @return
     * @throws SocketException
     */
    @SuppressWarnings("unchecked")
    public static <P> P getUDPProxy(Class<P> protocol,
            InetSocketAddress remoteAddr) throws SocketException {
        return (P) Proxy.newProxyInstance(protocol.getClassLoader(),
                new Class[] {
                    protocol
                }, new UDPInvoker<P>(new UDPRpcClient<P>(protocol, remoteAddr)));
    }

    /**
     * Must be called in your UDP RPC server's method, and notice that, if you
     * do not do a RPC call(e.g., a simple function call in testcase), this
     * method will return null.
     * 
     * @return the client address for the current call.
     */
    public static SocketAddress getUDPClientAddr() {
        Thread t = Thread.currentThread();
        if (t instanceof UDPRpcServer.Listener) {
            return ((UDPRpcServer.Listener) t).remoteAddr;
        } else {
            return null;
        }
    }

    /**
     * Get the udp server address of this proxy object. If the object is not a
     * proxy object, <code>null</code> will be returned.
     * 
     * @return
     */
    public static InetSocketAddress getUDPRemoteAddr(Object proxy) {
        if (!Proxy.isProxyClass(proxy.getClass())) {
            return null;
        }
        UDPInvoker<?> invoker = (UDPInvoker<?>) Proxy.getInvocationHandler(proxy);
        return invoker.client.remoteAddr;
    }

    /**
     * Close the udp socket in the proxy object.if the object is not a proxy
     * object, the method will return and do nothing.
     * 
     * @param proxy
     */
    public static void closeUDPProxy(Object proxy) {
        if (!Proxy.isProxyClass(proxy.getClass())) {
            return;
        }
        UDPInvoker<?> invoker = (UDPInvoker<?>) Proxy.getInvocationHandler(proxy);
        LOG.info("close udp proxy " + invoker);
        invoker.close();
    }

    /**
     * Must be called in your RPC server's method, and notice that, if you do
     * not do a RPC call(e.g., a simple function call in testcase), this method
     * will return null.
     * 
     * @return the client info for the current call.
     */
    public static ClientInfo getClientInfo() {
        Thread t = Thread.currentThread();
        if (t instanceof AbstractRpcServer.Handler) {
            return ((AbstractRpcServer.Handler) t).currentCall.conn.info;
        } else {
            return null;
        }
    }

    /**
     * Must be called in your RPC server's method, and notice that, if you do
     * not do a RPC call(e.g., a simple function call in testcase), this method
     * will return null.
     * 
     * @return the <tt>AsyncRpcCallEntry</tt> for the current call.
     */
    public static AsyncRpcCallEntry getAsyncRpcCallEntry() {
        Thread t = Thread.currentThread();
        if (t instanceof AbstractRpcServer.Handler) {
            AbstractRpcServer.Call call = ((AbstractRpcServer.Handler) t).currentCall;
            call.async = true;
            return call;
        } else {
            return null;
        }
    }
}
