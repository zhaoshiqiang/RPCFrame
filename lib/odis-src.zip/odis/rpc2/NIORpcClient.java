/**
 * @(#)NIORpcClient.java, 2011-3-31. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2;

import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.SelectionKey;
import java.nio.channels.SocketChannel;
import java.rmi.server.UID;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ScheduledExecutorService;
import java.util.logging.Logger;

import odis.rpc2.NIORpcClientManager.Worker;
import odis.serialize.lib.StringPropertiesWritable;
import odis.util.MiscUtils;
import toolbox.collections.ArrayQueue;
import toolbox.misc.LogFormatter;

/**
 * A client for an RPC service use Non-Blocking IO to communicate with
 * RpcServer. Note: this is probably not what you use. See
 * {@link odis.rpc2.RPC#getNIOProxy(Class, InetSocketAddress, String, String, String, long)}
 * for the easy-to-use RPC client interface.
 * 
 * @author zhangduo
 */
public class NIORpcClient extends AbstractRpcClient {

    private static final Logger LOG = LogFormatter.getLogger(NIORpcClient.class);

    private static final NIORpcClientManager MANAGER;

    static {
        try {
            // the selector.select() do not work after the selector thread is 
            // interrupted, so we create a ThreadGroup to avoid the selector 
            // thread being interrupted.
            ThreadGroup threadGroup = new ThreadGroup(
                    MiscUtils.findTopThreadGroup(), "NIORpcClientManager-"
                            + new UID().toString());
            LOG.info("Create ThreadGroup " + threadGroup + " with parent = "
                    + threadGroup.getParent() + " for Client NIO Worker");
            MANAGER = new NIORpcClientManager(
                    threadGroup,
                    2 * ManagementFactory.getOperatingSystemMXBean().getAvailableProcessors());
            MANAGER.start();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    class ConnectionImpl extends Connection {

        private static final int MAX_SEND_QUEUE_LENGTH = 10;

        private static final boolean TCP_NO_DELAY = true;

        NIORpcClient client;

        Worker worker;

        SocketChannel socket;

        Object interestOpLock = new Object();

        int interestOps = SelectionKey.OP_READ;

        Queue<Call> sendQueue = new ArrayQueue<Call>(MAX_SEND_QUEUE_LENGTH);

        ConcurrentMap<Integer, Call> pendingCalls = new ConcurrentHashMap<Integer, AbstractRpcClient.Call>();

        ByteBuffer callIdBuffer;

        // Record callId if the callIdBuffer is full. We need this because we 
        // may read callId and callReturnValueLength in different times. 
        // We do not need callReturnValueLength because we will read callReturnValue
        // immediately after the callReturnValueLengthBuffer is full. If we can not read 
        // all the return value this time, we will create callReturnValueBuffer 
        // with the a capacity of callReturnValueLength.
        int callId;

        ByteBuffer callReturnValueLengthBuffer;

        ByteBuffer callReturnValueBuffer;

        public ConnectionImpl(String name) throws IOException {
            super(name);
            client = NIORpcClient.this;
            socket = SocketChannel.open();
            socket.configureBlocking(true);
            int soTimeout = (int) timeout;
            if (soTimeout < 0) { // may be overflow
                soTimeout = 0;
            }
            socket.socket().connect(
                    new InetSocketAddress(remoteAddr.getAddress(),
                            remoteAddr.getPort()), soTimeout);
            socket.socket().setTcpNoDelay(TCP_NO_DELAY);

            // for connection init
            socket.socket().setSoTimeout(soTimeout);
            callIdBuffer = ByteBuffer.allocate(4);
            callIdBuffer.order(ByteOrder.LITTLE_ENDIAN);
            callReturnValueLengthBuffer = ByteBuffer.allocate(4);
            callReturnValueLengthBuffer.order(ByteOrder.LITTLE_ENDIAN);
        }

        public void init(boolean recordResponse) throws Throwable {
            LOG.info(name + " start init");
            socket.configureBlocking(true);
            StringPropertiesWritable props = new StringPropertiesWritable();
            props.put(CLIENT_PROP_RPC_TIMEOUT, Long.toString(timeout));
            props.put(CLIENT_PROP_IO_MODE, CLIENT_PROP_IO_MODE_NIO);
            props.put(CLIENT_PROP_LANGUAGE, CLIENT_PROP_LANGUAGE_JAVA);
            init(socket.socket(), props, recordResponse);
            socket.configureBlocking(false);
            LOG.info(name + " init end");
        }

        @Override
        protected void sendParam(Call call) throws RpcException {
            long startTime = System.currentTimeMillis();
            if (closed) {
                throw new RpcException("connection already closed");
            }
            synchronized (sendQueue) {
                // double check to confirm closed is not change.
                if (closed) {
                    throw new RpcException("connection already closed");
                }
                pendingCalls.put(call.id, call);
                while (worker != null && !sendQueue.offer(call)) {
                    if (timeout > 0) {
                        long waitTime = timeout
                                - (System.currentTimeMillis() - startTime);
                        if (waitTime <= 0) {
                            pendingCalls.remove(call.id);
                            throw new RpcTimeoutException(
                                    "send param for call " + call + " timeout");
                        }
                        try {
                            sendQueue.wait(waitTime);
                        } catch (InterruptedException e) {}
                    } else {
                        try {
                            sendQueue.wait();
                        } catch (InterruptedException e) {}
                    }
                }
            }
            synchronized (interestOpLock) {
                if ((interestOps & SelectionKey.OP_WRITE) == 0) {
                    interestOps = SelectionKey.OP_READ | SelectionKey.OP_WRITE;
                    worker.register(this);
                }
            }
        }

        @Override
        protected void sendHeartbeat() throws IOException {
            Call call = new Call();
            call.id = CALL_ID_HEARTBEAT;
            call.remaining = ByteBuffer.wrap(new byte[] {
                0, 0, 0, 0
            });
            sendParam(call);
        }

        @Override
        protected void close() {
            closed = true;
            if (worker != null) {
                synchronized (interestOpLock) {
                    // use 0 means cancel the key and close SocketChannel
                    interestOps = 0;
                    worker.register(this);
                }
                worker = null;
            }
        }
    }

    protected NIORpcClient(Class<?> protocol, InetSocketAddress remoteAddr,
            String authInfo, String domain, String username, long timeout,
            String clientName, ErrorTracker errorTracker,
            ScheduledExecutorService heartbeatExecutor) throws RpcException {
        super(protocol, remoteAddr, authInfo, domain, username, timeout,
                clientName, errorTracker, heartbeatExecutor);
    }

    @Override
    protected void createConnection(int index, boolean recordResponse)
            throws RpcException {
        ConnectionImpl conn;
        try {
            conn = new ConnectionImpl("Client " + clientName
                    + " connection No." + index + " to " + remoteAddr
                    + " for protocol " + protocol.getName());
        } catch (IOException e) {
            errorTracker.fatalErrorOccur();
            throw new RpcException(clientName + " create connection to "
                    + remoteAddr + " failed", e);
        }
        try {
            conn.init(recordResponse);
        } catch (Throwable t) {
            errorTracker.fatalErrorOccur();
            conn.close();
            if (t instanceof RuntimeException) {
                throw (RuntimeException) t;
            } else if (t instanceof RpcException) {
                throw (RpcException) t;
            } else {
                throw new RpcException("init connection failed", t);
            }
        }
        MANAGER.register(conn);
        activeConnections[index] = conn;
        LOG.info("Connection " + conn + " created");
    }

    @Override
    public String toString() {
        return "NIORpcClient [authInfo=" + authInfo + ", clientName="
                + clientName + ", domain=" + domain + ", protocol="
                + protocol.getName() + ", remoteAddr=" + remoteAddr
                + ", timeout=" + timeout + ", username=" + username + "]";
    }
}
