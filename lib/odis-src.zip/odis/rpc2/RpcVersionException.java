/**
 * @(#)RpcVersionException.java, 2010-10-22. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2;

/**
 * Exception indicating that the rpc version of RpcServer and RpcClient are not
 * compatible.
 * 
 * @author zhangduo
 */
public class RpcVersionException extends RpcException {

    private static final long serialVersionUID = 8111478057861581432L;

    public RpcVersionException() {}

    public RpcVersionException(String message, Throwable cause) {
        super(message, cause);
    }

    public RpcVersionException(String message) {
        super(message);
    }

    public RpcVersionException(Throwable cause) {
        super(cause);
    }

}
