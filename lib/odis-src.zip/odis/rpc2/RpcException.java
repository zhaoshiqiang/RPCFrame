/**
 * @(#)RpcException.java, 2010-8-3. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2;

import java.io.IOException;

/**
 * An <code>RpcException</code> represents any communication-related exception
 * during the process of an RPC call. Every method in an RPC interface should be
 * declared as <code>throws RpcException</code>. This is checked when the client
 * proxy is created.
 * 
 * @author zf
 */
public class RpcException extends IOException {

    private static final long serialVersionUID = -5542794599280927590L;

    public RpcException() {
        super();
    }

    public RpcException(String message, Throwable cause) {
        super(message, cause);
    }

    public RpcException(String message) {
        super(message);
    }

    public RpcException(Throwable cause) {
        super(cause);
    }

}
