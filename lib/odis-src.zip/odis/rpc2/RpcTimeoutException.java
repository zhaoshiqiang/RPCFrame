/**
 * @(#)RpcTimeoutException.java, 2010-8-3. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2;

/**
 * Exception indicating that an RPC call has timed out.
 * @author zf
 */
public class RpcTimeoutException extends RpcException {

    private static final long serialVersionUID = 4143623282114649099L;

    public RpcTimeoutException(String message, Throwable cause) {
        super(message, cause);
    }

    public RpcTimeoutException(String message) {
        super(message);
    }

    public RpcTimeoutException(Throwable cause) {
        super(cause);
    }

}
