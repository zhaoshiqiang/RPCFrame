/**
 * @(#)AuthListener.java, 2010-8-6. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2;

import odis.rpc2.AbstractRpcServer.Connection;

/**
 * listener for authentication
 * 
 * @author zhangduo
 */
public interface AuthListener {
    /**
     * return false will reject the client request.
     * 
     * @param authInfo
     * @return
     */
    boolean auth(String authInfo, Connection conn);
}
