/**
 * @(#)AbstractRpcServer.java, 2010-8-3. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.rpc2.PermissionManager.PermitType;
import odis.rpc2.PermissionManager.Status;
import odis.serialize.lib.StringPropertiesWritable;
import toolbox.collections.ArrayQueue;
import toolbox.misc.LogFormatter;

/**
 * Base class of all RpcServers.
 * 
 * @author zhangduo
 */
public abstract class AbstractRpcServer implements RpcConstants {
    private static final Logger LOG = LogFormatter.getLogger(AbstractRpcServer.class);

    protected String serverIOMode;

    protected int port;

    protected final int maxConnPerClient;

    protected final int handlerCount;

    protected final int queueSize;

    protected final long clientDisconnectTime;

    protected static final byte CLIENT_IO_MODE_BIO = 0;

    protected static final byte CLIENT_IO_MODE_NIO = 1;

    protected final Map<String, Instance> protocolMap = new HashMap<String, Instance>();

    protected final Map<String, RpcClientInfo> clientMap = new HashMap<String, RpcClientInfo>();

    protected static class Instance {
        public final Object instance;

        public final Map<Long, Method> signature2method;

        public Instance(Object instance, Map<Long, Method> signature2method) {
            this.instance = instance;
            this.signature2method = signature2method;
        }
    }

    protected static class RpcClientInfo {
        public List<Connection> activeConnections = new ArrayList<Connection>();

        public long lastCallTime;

        public boolean isNewClient;
    }

    private boolean started = false;

    /**
     * @param port
     *            if 0, will use a random port.use getPort to get the actual
     *            port used.
     * @param handlerCount
     * @param queueSize
     * @param clientDisconnectTime
     */
    protected AbstractRpcServer(int port, int handlerCount, int queueSize,
            int maxConnPerClient, long clientDisconnectTime) {
        this.port = port;
        this.handlerCount = handlerCount;
        this.queueSize = queueSize;
        this.maxConnPerClient = maxConnPerClient;
        this.clientDisconnectTime = clientDisconnectTime;
    }

    private void addProtocolInternal(Class<?> protocol, Object instance) {
        if (!protocol.isInstance(instance)) {
            throw new IllegalArgumentException(instance
                    + " is not instanceof protocol " + protocol);
        }
        Instance inst = protocolMap.get(protocol.getName());
        if (inst != null) {
            if (inst.instance != instance) {
                throw new RuntimeException("protocl " + protocol
                        + " is already hold by instance "
                        + inst.instance.getClass());
            } else {
                return;
            }
        }
        Map<Long, Method> signature2method = ProtocolVerifier.serverVerify(protocol);
        protocolMap.put(protocol.getName(), new Instance(instance,
                signature2method));
        // add super interface recursive.
        for (Class<?> superProtocol: protocol.getInterfaces()) {
            addProtocolInternal(superProtocol, instance);
        }
    }

    /**
     * Add a protocol and its handler.<br>
     * <strong>NOTE:</strong> you can only do this before start.
     * 
     * @param protocol
     * @param instance
     */
    public void addProtocol(Class<?> protocol, Object instance) {
        if (started) {
            throw new IllegalStateException("server is already started");
        }
        addProtocolInternal(protocol, instance);
    }

    protected abstract class Connection {

        protected boolean authPassed = false;

        protected int rpcVersion;

        protected String clientName;

        protected String protocolName;

        protected String domain;

        protected String username;

        protected long clientTimeout = -1L;

        protected byte clientIOMode;

        protected InetSocketAddress clientAddr;

        protected ClientInfo info;

        public void initClientInfo(StringPropertiesWritable clientProps) {
            try {
                info = new ClientInfo(clientName, clientAddr, rpcVersion,
                        Class.forName(protocolName), domain, username,
                        Collections.unmodifiableMap(clientProps));
            } catch (ClassNotFoundException e) {
                // should not happen
                LOG.log(Level.WARNING, "init client info failed", e);
            }
        }

        /**
         * should not throw any exception
         * 
         * @param call
         */
        public abstract boolean finishCall(Call call);

        /**
         * shutdown this connection.<br>
         * notice that, who shutdown the connection, then who need to remove it
         * from activeConnections.
         */
        public abstract void shutdown();

        @Override
        public String toString() {
            return "Connection [clientName=" + clientName + "]";
        }
    }

    protected class Call implements AsyncRpcCallEntry {

        protected Connection conn;

        protected long startTime;

        protected int id;

        protected long signature;

        protected Object instance;

        protected Method method;

        protected Object[] args;

        protected Object returnValue;

        protected Throwable error;

        protected Object attach;

        protected boolean async;

        public void finish() {
            if (conn.clientTimeout > 0
                    && System.currentTimeMillis() - startTime > conn.clientTimeout) {
                if (serverCallListener != null) {
                    try {
                        serverCallListener.callTimeout(method, returnValue,
                                error, attach);
                    } catch (Throwable t) {}
                }
                LOG.warning("Call " + this + " timeout, ignore it");
            } else {
                conn.finishCall(this);
            }
        }

        @Override
        public String toString() {
            return "Call [conn=" + conn + ", method=" + method + "]";
        }

        @Override
        public void setReturnValue(Object returnValue) {
            this.returnValue = returnValue;
        }

        @Override
        public Object getReturnValue() {
            return returnValue;
        }

        @Override
        public void setError(Throwable error) {
            this.error = error;
        }

        @Override
        public Throwable getError() {
            return error;
        }

        @Override
        public void finishCall() {
            if (serverCallListener != null) {
                try {
                    serverCallListener.endCall(method, returnValue, error,
                            attach);
                } catch (Throwable t) {}
            }
            finish();
        }
    }

    protected Object queueLock = new Object();

    protected Queue<Call> callQueue;

    protected Queue<Call> waitingQueue;

    protected PermissionManager permissionManager;

    protected Handler[] handlers;

    protected List<ClientConnectListener> clientConnectListeners = new ArrayList<ClientConnectListener>();

    protected AuthListener authListener;

    protected ServerCallListener serverCallListener;

    protected void receiveCall(String clientName, long time) {
        synchronized (clientMap) {
            RpcClientInfo info = clientMap.get(clientName);
            if (info == null) {
                LOG.warning("no client named " + clientName
                        + " when receive call");
                return;
            }
            info.lastCallTime = time;
        }
    }

    protected void receiveRpcVersion(Call call) {
        int rpcVersion = (Integer) call.args[0];
        LOG.fine("receive rpc version " + rpcVersion);
        call.conn.rpcVersion = rpcVersion;
    }

    protected void receiveClientName(Call call) {
        String clientName = (String) call.args[0];
        LOG.fine("receive client name " + clientName);
        boolean isNewClient;
        synchronized (clientMap) {
            RpcClientInfo info = clientMap.get(clientName);
            if (info == null) {
                info = new RpcClientInfo();
                clientMap.put(clientName, info);
                isNewClient = true;
            } else {
                isNewClient = false;
            }
            info.isNewClient = isNewClient;
            if (info.activeConnections.size() == maxConnPerClient) {
                LOG.warning("Too many connections from client " + clientName
                        + ", max allowed is " + maxConnPerClient);
                call.error = new RpcConnectionException(
                        "Too many connections, max allowed is "
                                + maxConnPerClient);
                return;
            }
            info.activeConnections.add(call.conn);
            info.lastCallTime = call.startTime;
        }
        call.conn.clientName = clientName;
        if (isNewClient) {
            LOG.info("client " + clientName + " connected");
        }
    }

    protected void doAuth(Call call) {
        LOG.fine("receive auth info " + call.args[0]);
        if (authListener != null) {
            try {
                if (!authListener.auth((String) call.args[0], call.conn)) {
                    call.error = new RpcAuthException(
                            "connection reject by auth listener");
                } else {
                    call.conn.authPassed = true;
                }
            } catch (Throwable t) {
                call.error = new RpcAuthException("auth failed", t);
            }
        } else {
            call.conn.authPassed = true;
        }
    }

    protected void verifyProtocol(Call call) {
        ProtocolVerifyEntry entry = (ProtocolVerifyEntry) call.args[0];
        LOG.fine("receive protocol verify entry " + entry);
        Instance instance = protocolMap.get(entry.getProtocolName());
        if (instance == null) {
            call.error = new RpcProtocolException(
                    "RPC server not implements protocol "
                            + entry.getProtocolName());
            return;
        }
        for (ProtocolVerifyEntry.MethodEntry methodEntry: entry.getMethods()) {
            long signature = methodEntry.getSignature();
            Method serverMethod = instance.signature2method.get(signature);
            if (serverMethod == null) {
                call.error = new RpcProtocolException(
                        "RPC server has no method " + methodEntry);
                return;
            }
            String[] parameterTypes = methodEntry.getParameterTypes();
            Class<?>[] serverParameterTypes = serverMethod.getParameterTypes();
            if (serverParameterTypes.length != parameterTypes.length) {
                call.error = new RpcProtocolException("RPC server method "
                        + serverMethod + " and client method " + methodEntry
                        + " has different parameter count");
                return;
            }
            for (int i = 0; i < parameterTypes.length; i++) {
                if (!parameterTypes[i].equals(serverParameterTypes[i].getName())) {
                    call.error = new RpcProtocolException("RPC server method "
                            + serverMethod + " and client method "
                            + methodEntry
                            + " has different parameter type at parameter " + i
                            + ", server is "
                            + serverParameterTypes[i].getName()
                            + ", client is " + parameterTypes[i]);
                    return;
                }
            }
            Set<String> exceptionTypes = methodEntry.getExpectionTypes();
            // if the exception type mismatched, the client may get an 
            // UndeclaredThrowableException when calling. But this is not a
            // big question because server and client can both finish the call
            // (although client may not get what it want), so we just warn it
            // and let it pass the verification.
            for (Class<?> serverExceptionType: serverMethod.getExceptionTypes()) {
                if (!exceptionTypes.contains(serverExceptionType.getName())) {
                    LOG.warning("RPC server method " + serverMethod
                            + " is declared to throw "
                            + serverExceptionType.getName()
                            + " but client method " + methodEntry + " is not");
                }
            }
            if (!methodEntry.getReturnType().equals(
                    serverMethod.getReturnType().getName())) {
                call.error = new RpcProtocolException("RPC server method "
                        + serverMethod + " and client method " + methodEntry
                        + " has different return type, server is "
                        + serverMethod.getReturnType().getName()
                        + ", client is " + methodEntry.getReturnType());
                return;
            }
        }
        LOG.fine("protocol " + entry.getProtocolName() + " verify success");
        call.conn.protocolName = entry.getProtocolName();
    }

    protected void receiveDomain(Call call) {
        String domain = (String) call.args[0];
        LOG.fine("receive domain " + domain);
        // auth listener may already set it
        if (call.conn.domain == null) {
            call.conn.domain = domain;
        }
    }

    protected void receiveUsername(Call call) {
        String username = (String) call.args[0];
        LOG.fine("receive username " + username);
        // auth listener may already set it
        if (call.conn.username == null) {
            call.conn.username = username;
        }
    }

    protected void receiveAndSendProps(Call call) {
        StringPropertiesWritable clientProperties = (StringPropertiesWritable) call.args[0];
        LOG.fine("receive client props " + clientProperties);
        long clientTimeout = Long.parseLong(clientProperties.getProperty(CLIENT_PROP_RPC_TIMEOUT));
        call.conn.clientTimeout = clientTimeout;
        String clientIOMode = clientProperties.getProperty(CLIENT_PROP_IO_MODE,
                CLIENT_PROP_IO_MODE_BIO);
        call.conn.clientIOMode = clientIOMode.equals(CLIENT_PROP_IO_MODE_BIO) ? CLIENT_IO_MODE_BIO
                : CLIENT_IO_MODE_NIO;
        StringPropertiesWritable serverProperties = new StringPropertiesWritable();
        serverProperties.put(SERVER_PROP_CONNECTION_PER_CLIENT,
                Integer.toString(maxConnPerClient));
        serverProperties.put(SERVER_PROP_HEARTBEAT_INTERVAL,
                Long.toString(clientDisconnectTime / 2));
        serverProperties.put(SERVER_PROP_IO_MODE, serverIOMode);
        call.returnValue = serverProperties;

        // init client info
        call.conn.initClientInfo(clientProperties);
        synchronized (clientMap) {
            RpcClientInfo info = clientMap.get(call.conn.clientName);
            if (info != null && info.isNewClient) {
                for (ClientConnectListener listener: clientConnectListeners) {
                    try {
                        listener.clientConnect(call.conn.info);
                    } catch (Throwable t) {}
                }
                info.isNewClient = false;
            }
        }
    }

    protected void closeConnection(Connection conn) {
        conn.shutdown();
        String clientName = conn.clientName;
        synchronized (clientMap) {
            RpcClientInfo info = clientMap.get(clientName);
            if (info == null) {
                LOG.warning("no client named " + clientName
                        + " when close connection protocol = "
                        + conn.protocolName + " username = " + conn.username
                        + " domain = " + conn.domain);
            } else {
                Iterator<Connection> iter = info.activeConnections.iterator();
                while (iter.hasNext()) {
                    if (conn == iter.next()) {
                        iter.remove();
                        break;
                    }
                }
                if (info.activeConnections.isEmpty()) {
                    LOG.info("all connections for client " + clientName
                            + " disconnect");
                    for (ClientConnectListener listener: clientConnectListeners) {
                        try {
                            listener.clientDisconnect(conn.info);
                        } catch (Throwable t) {}
                    }
                    clientMap.remove(clientName);
                }
            }
        }
    }

    protected class Handler extends Thread {

        protected Call currentCall;

        @Override
        public void run() {
            LOG.info(getName() + " started");
            while (running) {
                try {
                    Call call;
                    Status status = permissionManager.getStatus();
                    synchronized (queueLock) {
                        if (status == Status.NORMAL) {
                            if (!waitingQueue.isEmpty()) {
                                call = waitingQueue.poll();
                            } else if (!callQueue.isEmpty()) {
                                call = callQueue.poll();
                            } else {
                                try {
                                    queueLock.wait();
                                } catch (InterruptedException e) {
                                    // nothing
                                }
                                continue;
                            }
                        } else { // Status.EMERGENCY
                            if (!callQueue.isEmpty()) {
                                call = callQueue.poll();
                            } else if (!waitingQueue.isEmpty()) {
                                call = waitingQueue.poll();
                            } else { // this will happen when no more calls arrived, but many arrived calls won't end
                                try {
                                    queueLock.wait();
                                } catch (InterruptedException e) {
                                    // nothing
                                }
                                continue;
                            }
                        }
                    }
                    if (!call.conn.authPassed) {
                        call.error = new RpcAuthException(
                                "connection has not passed auth, call is not permitted");
                    } else {
                        PermitType permit = permissionManager.getPermission(call);
                        if (serverCallListener != null) {
                            try {
                                serverCallListener.getPermit(call.method,
                                        permit, call.attach);
                            } catch (Throwable t) {}
                        }
                        if (permit == PermitType.TIMEOUT) {
                            LOG.warning("Call " + call + " timeout, ignore it");
                            continue;
                        } else if (permit == PermitType.WAIT) {
                            LOG.warning("Call " + call + " waiting");
                            synchronized (queueLock) {
                                if (waitingQueue.offer(call)) {
                                    queueLock.notify();
                                    continue;
                                }
                            }
                            // waiting queue is full
                            call.error = new RpcQueueFullExeption(
                                    "RpcServer's waitingQueue is full");
                            call.finish();
                            continue;
                        } // PermitType.PERMIT
                        currentCall = call;
                        if (serverCallListener != null) {
                            try {
                                serverCallListener.startCall(call.method,
                                        call.attach);
                            } catch (Throwable t) {}
                        }

                        try {
                            Object ret = call.method.invoke(call.instance,
                                    call.args);
                            if (!call.async) {
                                call.returnValue = ret;
                            }
                        } catch (Throwable t) {
                            if (t instanceof InvocationTargetException) {
                                call.error = ((InvocationTargetException) t).getCause();
                            } else {
                                call.error = t;
                            }
                        }
                        if (!call.async || call.error != null) {
                            if (serverCallListener != null) {
                                try {
                                    serverCallListener.endCall(call.method,
                                            call.returnValue, call.error,
                                            call.attach);
                                } catch (Throwable t) {}
                            }
                        }
                    }
                    if (!call.async || call.error != null) {
                        call.finish();
                    }
                    // call this even if the call is async and not finished.
                    // because permission manager is used to control handler
                    // usage, async call does not use handler.
                    permissionManager.finishedCall(call);
                } catch (Exception e) {
                    LOG.log(Level.WARNING, "unexpected exception caught in "
                            + getName(), e);
                }
            }
            LOG.info(getName() + " ended");
        }
    }

    protected volatile boolean running = false;

    protected ScheduledExecutorService backgroundTaskExecutor = Executors.newScheduledThreadPool(
            5, new ThreadFactory() {

                @Override
                public Thread newThread(Runnable r) {
                    Thread t = new Thread(r, "Background task thread");
                    return t;
                }
            });

    /**
     * start server.
     * 
     * @throws IOException
     */
    public void start() throws IOException {
        LOG.info("starting RPC server on " + port);
        if (protocolMap.isEmpty()) {
            throw new IllegalStateException("No handler added");
        }
        if (handlerCount > 2) {
            permissionManager = new DomainPermissionManager(handlerCount);
        } else {
            permissionManager = new AllPermitPermissionManager();
        }
        handlers = new Handler[handlerCount];
        for (int i = 0; i < handlerCount; i++) {
            handlers[i] = new Handler();
            handlers[i].setName("Server handler on " + port + " No." + i);
            handlers[i].setDaemon(true);
        }
        if (clientDisconnectTime > 0) {
            backgroundTaskExecutor.scheduleAtFixedRate(
                    new Runnable() {

                        @Override
                        public void run() {
                            long currentTime = System.currentTimeMillis();
                            synchronized (clientMap) {
                                Iterator<Map.Entry<String, RpcClientInfo>> iter = clientMap.entrySet().iterator();
                                while (iter.hasNext()) {
                                    Map.Entry<String, RpcClientInfo> entry = iter.next();
                                    String clientName = entry.getKey();
                                    RpcClientInfo info = entry.getValue();
                                    if (currentTime - info.lastCallTime > clientDisconnectTime) {
                                        LOG.warning("Client " + clientName
                                                + " last call at "
                                                + new Date(info.lastCallTime)
                                                + ", close it");
                                        for (Connection conn: info.activeConnections) {
                                            conn.shutdown();
                                        }
                                        iter.remove();
                                    }
                                }
                            }
                        }
                    }, clientDisconnectTime / 2, clientDisconnectTime / 2,
                    TimeUnit.MILLISECONDS);
        }
        callQueue = new ArrayQueue<Call>(queueSize);
        waitingQueue = new ArrayQueue<Call>(queueSize);
        running = true;
        for (Handler handler: handlers) {
            handler.start();
        }
        startServer();
        LOG.info("RPC server on " + port + " started");
    }

    /**
     * stop server.
     */
    public void stop() {
        LOG.info("stopping RPC server on " + port);
        running = false;
        try {
            stopServer();
        } catch (Throwable t) {
            LOG.log(Level.WARNING, "stop server failed", t);
        }
        backgroundTaskExecutor.shutdownNow();
        synchronized (clientMap) {
            for (Map.Entry<String, RpcClientInfo> entry: clientMap.entrySet()) {
                RpcClientInfo info = entry.getValue();
                ClientInfo clientInfo = null;
                for (Connection conn: info.activeConnections) {
                    clientInfo = conn.info;
                    conn.shutdown();
                }
                info.activeConnections.clear();
                if (clientInfo != null) {
                    for (ClientConnectListener listener: clientConnectListeners) {
                        try {
                            listener.clientDisconnect(clientInfo);
                        } catch (Throwable t) {}
                    }
                }
            }
            clientMap.clear();
        }

        for (Handler handler: handlers) {
            handler.interrupt();
        }
        synchronized (queueLock) {
            callQueue.clear();
            waitingQueue.clear();
        }
        LOG.info("RPC server on " + port + " stopped");
        synchronized (this) {
            notifyAll();
        }

    }

    /**
     * Wait until server is stopped.<br>
     * You should call this after server started.
     * 
     * @throws InterruptedException
     */
    public synchronized void join() throws InterruptedException {
        while (running) {
            wait();
        }
    }

    public int getPort() {
        return port;
    }

    public int getHandlerCount() {
        return handlerCount;
    }

    public int getQueueSize() {
        return queueSize;
    }

    public boolean isRunning() {
        return running;
    }

    public long getPendingCalls() {
        synchronized (callQueue) {
            return callQueue.size() + waitingQueue.size();
        }
    }

    /**
     * Add a ClientConnetctListener.
     * 
     * @param listener
     */
    public void addClientConnectListener(ClientConnectListener listener) {
        clientConnectListeners.add(listener);
    }

    public void setServerCallListener(ServerCallListener listener) {
        serverCallListener = listener;
    }

    protected abstract void startServer() throws IOException;

    protected abstract void stopServer() throws IOException;
}
