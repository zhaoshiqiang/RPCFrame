/**
 * @(#)RpcSerializer.java, 2010-8-5. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Collection;
import java.util.Map;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;
import toolbox.misc.EmptyInstance;

/**
 * Seriallizer for RpcServer and RpcClient to pass call arguments and return
 * value.
 * 
 * @author zhangduo
 */
public class RpcSerializer {

    private static Object readPrimitive(Class<?> type, DataInput in)
            throws IOException {
        if (type == void.class) {
            return null;
        }
        if (type == boolean.class) {
            return in.readBoolean();
        }
        if (type == byte.class) {
            return in.readByte();
        }
        if (type == char.class) {
            return in.readChar();
        }
        if (type == short.class) {
            return in.readShort();
        }
        if (type == int.class) {
            return in.readInt();
        }
        if (type == long.class) {
            return in.readLong();
        }
        if (type == float.class) {
            return in.readFloat();
        }
        if (type == double.class) {
            return in.readDouble();
        }
        throw new IllegalArgumentException(type + " is not a primitive type");

    }

    private static Object readPrimitiveArray(Class<?> componentType,
            DataInput in, int length) throws IOException {
        if (componentType == boolean.class) {
            boolean[] a = new boolean[length];
            for (int i = 0; i < length; i++) {
                a[i] = in.readBoolean();
            }
            return a;
        }
        if (componentType == byte.class) {
            byte[] a = new byte[length];
            in.readFully(a);
            return a;
        }
        if (componentType == char.class) {
            char[] a = new char[length];
            for (int i = 0; i < length; i++) {
                a[i] = in.readChar();
            }
            return a;
        }
        if (componentType == short.class) {
            short[] a = new short[length];
            for (int i = 0; i < length; i++) {
                a[i] = in.readShort();
            }
            return a;
        }
        if (componentType == int.class) {
            int[] a = new int[length];
            for (int i = 0; i < length; i++) {
                a[i] = in.readInt();
            }
            return a;
        }
        if (componentType == long.class) {
            long[] a = new long[length];
            for (int i = 0; i < length; i++) {
                a[i] = in.readLong();
            }
            return a;
        }
        if (componentType == float.class) {
            float[] a = new float[length];
            for (int i = 0; i < length; i++) {
                a[i] = in.readFloat();
            }
            return a;
        }
        if (componentType == double.class) {
            double[] a = new double[length];
            for (int i = 0; i < length; i++) {
                a[i] = in.readDouble();
            }
            return a;
        }
        throw new IllegalArgumentException(componentType
                + " is not a primitive type");
    }

    private static Object readArray(Class<?> componentType, DataInput in)
            throws IOException, ClassNotFoundException, InstantiationException,
            IllegalAccessException {
        int length = CDataInputStream.readVInt(in);
        if (componentType.isPrimitive()) {
            return readPrimitiveArray(componentType, in, length);
        }
        if (componentType == Boolean.class) {
            Boolean[] a = new Boolean[length];
            for (int i = 0; i < length; i++) {
                if (in.readBoolean()) {
                    a[i] = in.readBoolean();
                }
            }
            return a;
        }
        if (componentType == Byte.class) {
            Byte[] a = new Byte[length];
            for (int i = 0; i < length; i++) {
                if (in.readBoolean()) {
                    a[i] = in.readByte();
                }
            }
            return a;
        }
        if (componentType == Character.class) {
            Character[] a = new Character[length];
            for (int i = 0; i < length; i++) {
                if (in.readBoolean()) {
                    a[i] = in.readChar();
                }
            }
            return a;
        } else if (componentType == Short.class) {
            Short[] a = new Short[length];
            for (int i = 0; i < length; i++) {
                if (in.readBoolean()) {
                    a[i] = in.readShort();
                }
            }
            return a;
        }
        if (componentType == Integer.class) {
            Integer[] a = new Integer[length];
            for (int i = 0; i < length; i++) {
                if (in.readBoolean()) {
                    a[i] = in.readInt();
                }
            }
            return a;
        }
        if (componentType == Long.class) {
            Long[] a = new Long[length];
            for (int i = 0; i < length; i++) {
                if (in.readBoolean()) {
                    a[i] = in.readLong();
                }
            }
            return a;
        }
        if (componentType == Float.class) {
            Float[] a = new Float[length];
            for (int i = 0; i < length; i++) {
                if (in.readBoolean()) {
                    a[i] = in.readFloat();
                }
            }
            return a;
        }
        if (componentType == Double.class) {
            Double[] a = new Double[length];
            for (int i = 0; i < length; i++) {
                if (in.readBoolean()) {
                    a[i] = in.readDouble();
                }
            }
            return a;
        }

        if (componentType == String.class) {
            String[] a = new String[length];
            for (int i = 0; i < length; i++) {
                if (in.readBoolean()) {
                    a[i] = StringWritable.readString(in);
                }
            }
            return a;
        }

        String componentTypeName = StringWritable.readString(in);
        Object array;
        Class<?> actualComponentType = componentTypeName.length() == 0 ? componentType
                : Class.forName(componentTypeName);
        array = Array.newInstance(actualComponentType, length);
        for (int i = 0; i < length; i++) {
            Array.set(array, i, readNonPrimitive(actualComponentType, in));
        }
        return array;
    }

    private static <T> Collection<T> readCollection(
            Class<? extends Collection<T>> type, DataInput in)
            throws IOException, ClassNotFoundException, InstantiationException,
            IllegalAccessException {
        Class<? extends Collection<T>> clazz;
        if (Modifier.isFinal(type.getModifiers())) {
            clazz = type;
        } else {
            String className = StringWritable.readString(in);
            clazz = (Class<? extends Collection<T>>) (className.length() == 0 ? type
                    : Class.forName(className));
        }

        Collection<T> collection = clazz.newInstance();
        int size = CDataInputStream.readVInt(in);
        for (int i = 0; i < size; i++) {
            collection.add((T) readNonPrimitive(null, in));
        }
        return collection;
    }

    private static <K, V> Map<K, V> readMap(Class<? extends Map<K, V>> type,
            DataInput in) throws IOException, ClassNotFoundException,
            InstantiationException, IllegalAccessException {
        Class<? extends Map<K, V>> clazz;
        if (Modifier.isFinal(type.getModifiers())) {
            clazz = type;
        } else {
            String className = StringWritable.readString(in);
            clazz = (Class<? extends Map<K, V>>) (className.length() == 0 ? type
                    : Class.forName(className));
        }
        Map<K, V> map = clazz.newInstance();
        int size = CDataInputStream.readVInt(in);
        for (int i = 0; i < size; i++) {
            Object key = readNonPrimitive(null, in);
            Object value = readNonPrimitive(null, in);
            map.put((K) key, (V) value);
        }
        return map;
    }

    private static Object readNonPrimitive(Class<?> declType, DataInput in)
            throws IOException, ClassNotFoundException, InstantiationException,
            IllegalAccessException {
        if (!in.readBoolean()) {
            return null;
        }
        Class<?> type;
        if (declType == null) {
            String className = StringWritable.readString(in);
            type = Class.forName(className);
        } else {
            type = declType;
        }
        if (type.isArray()) {
            return readArray(type.getComponentType(), in);
        }
        if (type == Boolean.class) {
            return in.readBoolean();
        }
        if (type == Byte.class) {
            return in.readByte();
        }
        if (type == Character.class) {
            return in.readChar();
        }
        if (type == Short.class) {
            return in.readShort();
        }
        if (type == Integer.class) {
            return in.readInt();
        }
        if (type == Long.class) {
            return in.readLong();
        }
        if (type == Float.class) {
            return in.readFloat();
        }
        if (type == Double.class) {
            return in.readDouble();
        }
        if (type == String.class) {
            return StringWritable.readString(in);
        }
        if (IWritable.class.isAssignableFrom(type)) {
            Class<?> clazz;
            if (declType == null || Modifier.isFinal(type.getModifiers())) {
                clazz = type;
            } else {
                String className = StringWritable.readString(in);
                clazz = className.length() == 0 ? type
                        : Class.forName(className);
            }
            Object obj = clazz.newInstance();
            ((IWritable) obj).readFields(in);
            return obj;
        }
        if (Collection.class.isAssignableFrom(type)) {
            return readCollection((Class) type, in);
        }
        if (Map.class.isAssignableFrom(type)) {
            return readMap((Class) type, in);
        }
        if (type.isEnum()) {
            String name = StringWritable.readString(in);
            return Enum.valueOf((Class) type, name);
        }
        throw new IllegalArgumentException(type + " is not writable");

    }

    private static Object readObject(Class<?> type, DataInput in)
            throws IOException, ClassNotFoundException, InstantiationException,
            IllegalAccessException {
        if (type.isPrimitive()) {
            return readPrimitive(type, in);
        } else {
            return readNonPrimitive(type, in);
        }
    }

    /**
     * Read call arguments.
     * 
     * @param method
     * @param in
     * @return
     * @throws IOException
     * @throws ClassNotFoundException
     * @throws InstantiationException
     * @throws IllegalAccessException
     */
    public static Object[] readArgs(Method method, DataInput in)
            throws IOException, ClassNotFoundException, InstantiationException,
            IllegalAccessException {
        Class<?>[] parameterTypes = method.getParameterTypes();
        Object[] args = new Object[parameterTypes.length];
        for (int i = 0; i < parameterTypes.length; i++) {
            args[i] = readObject(parameterTypes[i], in);
        }
        return args;
    }

    private static void writePrimitive(Class<?> type, Object arg, DataOutput out)
            throws IOException {
        if (type == void.class) {
            // do nothing
        } else if (type == boolean.class) {
            out.writeBoolean(((Boolean) arg).booleanValue());
        } else if (type == byte.class) {
            out.writeByte(((Byte) arg).byteValue());
        } else if (type == char.class) {
            out.writeChar(((Character) arg).charValue());
        } else if (type == short.class) {
            out.writeShort(((Short) arg).shortValue());
        } else if (type == int.class) {
            out.writeInt(((Integer) arg).intValue());
        } else if (type == long.class) {
            out.writeLong(((Long) arg).longValue());
        } else if (type == float.class) {
            out.writeFloat(((Float) arg).floatValue());
        } else if (type == double.class) {
            out.writeDouble(((Double) arg).doubleValue());
        } else {
            throw new IllegalArgumentException(type
                    + " is not a primitive type");
        }
    }

    private static void writePrimitiveArray(Class<?> componentType, Object arg,
            DataOutput out) throws IOException {
        if (componentType == boolean.class) {
            boolean[] a = (boolean[]) arg;
            for (boolean v: a) {
                out.writeBoolean(v);
            }
        } else if (componentType == byte.class) {
            byte[] a = (byte[]) arg;
            out.write(a);
        } else if (componentType == char.class) {
            char[] a = (char[]) arg;
            for (char v: a) {
                out.writeChar(v);
            }
        } else if (componentType == short.class) {
            short[] a = (short[]) arg;
            for (short v: a) {
                out.writeShort(v);
            }
        } else if (componentType == int.class) {
            int[] a = (int[]) arg;
            for (int v: a) {
                out.writeInt(v);
            }
        } else if (componentType == long.class) {
            long[] a = (long[]) arg;
            for (long v: a) {
                out.writeLong(v);
            }
        } else if (componentType == float.class) {
            float[] a = (float[]) arg;
            for (float v: a) {
                out.writeFloat(v);
            }
        } else if (componentType == double.class) {
            double[] a = (double[]) arg;
            for (double v: a) {
                out.writeDouble(v);
            }
        } else {
            throw new IllegalArgumentException(componentType
                    + " is not a primitive type");
        }
    }

    private static void writeArray(Class<?> componentType, Object arg,
            DataOutput out) throws IOException {
        int length = Array.getLength(arg);
        CDataOutputStream.writeVInt(length, out);
        if (componentType.isPrimitive()) {
            writePrimitiveArray(componentType, arg, out);
        } else if (componentType == Boolean.class) {
            Boolean[] a = (Boolean[]) arg;
            for (Boolean v: a) {
                if (v != null) {
                    out.writeBoolean(true);
                    out.writeBoolean(v);
                } else {
                    out.writeBoolean(false);
                }
            }
        } else if (componentType == Byte.class) {
            Byte[] a = (Byte[]) arg;
            for (Byte v: a) {
                if (v != null) {
                    out.writeBoolean(true);
                    out.writeByte(v);
                } else {
                    out.writeBoolean(false);
                }
            }
        } else if (componentType == Character.class) {
            Character[] a = (Character[]) arg;
            for (Character v: a) {
                if (v != null) {
                    out.writeBoolean(true);
                    out.writeChar(v);
                } else {
                    out.writeBoolean(false);
                }
            }
        } else if (componentType == Short.class) {
            Short[] a = (Short[]) arg;
            for (Short v: a) {
                if (v != null) {
                    out.writeBoolean(true);
                    out.writeShort(v);
                } else {
                    out.writeBoolean(false);
                }
            }
        } else if (componentType == Integer.class) {
            Integer[] a = (Integer[]) arg;
            for (Integer v: a) {
                if (v != null) {
                    out.writeBoolean(true);
                    out.writeInt(v);
                } else {
                    out.writeBoolean(false);
                }
            }
        } else if (componentType == Long.class) {
            Long[] a = (Long[]) arg;
            for (Long v: a) {
                if (v != null) {
                    out.writeBoolean(true);
                    out.writeLong(v);
                } else {
                    out.writeBoolean(false);
                }
            }
        } else if (componentType == Float.class) {
            Float[] a = (Float[]) arg;
            for (Float v: a) {
                if (v != null) {
                    out.writeBoolean(true);
                    out.writeFloat(v);
                } else {
                    out.writeBoolean(false);
                }
            }
        } else if (componentType == Double.class) {
            Double[] a = (Double[]) arg;
            for (Double v: a) {
                if (v != null) {
                    out.writeBoolean(true);
                    out.writeDouble(v);
                } else {
                    out.writeBoolean(false);
                }
            }
        } else if (componentType == String.class) {
            String[] a = (String[]) arg;
            for (String v: a) {
                if (v != null) {
                    out.writeBoolean(true);
                    StringWritable.writeString(out, v);
                } else {
                    out.writeBoolean(false);
                }
            }
        } else {
            //TODO: for a int[][], enum[] and final class[], we need not to write any type information.
            Class<?> actualComponentType = arg.getClass().getComponentType();
            if (actualComponentType == componentType) {
                StringWritable.writeString(out, EmptyInstance.STRING);
            } else {
                StringWritable.writeString(out, actualComponentType.getName());
            }
            for (int i = 0; i < length; i++) {
                Object element = Array.get(arg, i);
                writeNonPrimitive(actualComponentType, element, out);
            }
        }
    }

    private static <T> void writeCollection(
            Class<? extends Collection<T>> type, Collection<T> arg,
            DataOutput out) throws IOException {
        if (!Modifier.isFinal(type.getModifiers())) {
            if (arg.getClass() == type) {
                StringWritable.writeString(out, EmptyInstance.STRING);
            } else {
                StringWritable.writeString(out, arg.getClass().getName());
            }
        }
        CDataOutputStream.writeVInt(arg.size(), out);
        for (Object obj: arg) {
            // The generic type information is lost at runtime, so we must write
            // the type information for every element.
            writeNonPrimitive(null, obj, out);
        }
    }

    private static <K, V> void writeMap(Class<? extends Map<K, V>> type,
            Map<K, V> arg, DataOutput out) throws IOException {
        if (!Modifier.isFinal(type.getModifiers())) {
            if (arg.getClass() == type) {
                StringWritable.writeString(out, EmptyInstance.STRING);
            } else {
                StringWritable.writeString(out, arg.getClass().getName());
            }
        }
        CDataOutputStream.writeVInt(arg.size(), out);
        for (Map.Entry<?, ?> entry: arg.entrySet()) {
            // The generic type information is lost at runtime, so we must write
            // the type information for every key and value.
            writeNonPrimitive(null, entry.getKey(), out);
            writeNonPrimitive(null, entry.getValue(), out);
        }
    }

    private static void writeNonPrimitive(Class<?> declType, Object arg,
            DataOutput out) throws IOException {
        if (arg == null) {
            out.writeBoolean(false);
            return;
        }
        out.writeBoolean(true);
        Class<?> type;
        if (declType == null) {
            StringWritable.writeString(out, arg.getClass().getName());
            type = arg.getClass();
        } else {
            type = declType;
        }
        if (type.isArray()) {
            writeArray(type.getComponentType(), arg, out);
        } else if (type == Boolean.class) {
            out.writeBoolean(((Boolean) arg).booleanValue());
        } else if (type == Byte.class) {
            out.writeByte(((Byte) arg).byteValue());
        } else if (type == Character.class) {
            out.writeChar(((Character) arg).charValue());
        } else if (type == Short.class) {
            out.writeShort(((Short) arg).shortValue());
        } else if (type == Integer.class) {
            out.writeInt(((Integer) arg).intValue());
        } else if (type == Long.class) {
            out.writeLong(((Long) arg).longValue());
        } else if (type == Float.class) {
            out.writeFloat(((Float) arg).floatValue());
        } else if (type == Double.class) {
            out.writeDouble(((Double) arg).doubleValue());
        } else if (type == String.class) {
            StringWritable.writeString(out, (String) arg);
        } else if (IWritable.class.isAssignableFrom(type)) {
            if (declType != null && !Modifier.isFinal(type.getModifiers())) {
                if (arg.getClass() == type) {
                    StringWritable.writeString(out, EmptyInstance.STRING);
                } else {
                    StringWritable.writeString(out, arg.getClass().getName());
                }
            }
            ((IWritable) arg).writeFields(out);
        } else if (type.isEnum()) {
            StringWritable.writeString(out, ((Enum<?>) arg).name());
        } else if (Collection.class.isAssignableFrom(type)) {
            writeCollection((Class) type, (Collection) arg, out);
        } else if (Map.class.isAssignableFrom(type)) {
            writeMap((Class) type, (Map) arg, out);
        } else {
            throw new RpcWritableException(arg + " is not writable");
        }
    }

    private static void writeObject(Class<?> type, Object arg, DataOutput out)
            throws IOException {
        if (type.isPrimitive()) {
            writePrimitive(type, arg, out);
        } else {
            writeNonPrimitive(type, arg, out);
        }
    }

    /**
     * Write call arguments.
     * 
     * @param method
     * @param args
     * @param out
     * @throws IOException
     */
    public static void writeArgs(Method method, Object[] args, DataOutput out)
            throws IOException {
        Class<?>[] parameterTypes = method.getParameterTypes();
        if (parameterTypes.length != args.length) {
            throw new IllegalArgumentException(method + " has "
                    + parameterTypes.length + " parameters, but passed in "
                    + args.length + " parameters");
        }
        for (int i = 0; i < parameterTypes.length; i++) {
            writeObject(parameterTypes[i], args[i], out);
        }
    }

    /**
     * Read call return value.
     * 
     * @param method
     * @param in
     * @return
     * @throws IOException
     * @throws ClassNotFoundException
     * @throws InstantiationException
     * @throws IllegalAccessException
     */
    public static Object readReturnValue(Method method, DataInput in)
            throws IOException, ClassNotFoundException, InstantiationException,
            IllegalAccessException {
        return readObject(method.getReturnType(), in);
    }

    /**
     * Read call return value with given buffer.If the return value is null,
     * return null.Otherwise, return the given buffer.<br>
     * <strong>NOTE:</strong> we do not check type consistency, you should
     * ensure it yourself.
     * 
     * @param buffer
     * @param in
     * @return
     * @throws IOException
     */
    public static IWritable readReturnValue(IWritable buffer, DataInput in)
            throws IOException {
        if (!in.readBoolean()) {
            return null;
        }
        // class name
        StringWritable.readString(in);
        buffer.readFields(in);
        return buffer;
    }

    /**
     * Write call return value.
     * 
     * @param method
     * @param returnValue
     * @param out
     * @throws IOException
     */
    public static void writeReturnValue(Method method, Object returnValue,
            DataOutput out) throws IOException {
        writeObject(method.getReturnType(), returnValue, out);
    }
}
