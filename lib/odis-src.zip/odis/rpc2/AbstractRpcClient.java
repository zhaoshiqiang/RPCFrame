/**
 * @(#)AbstractRpcClient.java, 2011-3-29. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc2;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicIntegerArray;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.IWritable;
import odis.serialize.lib.StringPropertiesWritable;
import odis.serialize.lib.StringWritable;
import odis.util.MiscUtils;
import toolbox.misc.LogFormatter;

/**
 * Base class of all RpcClient classes.
 * 
 * @author zhangduo
 */
public abstract class AbstractRpcClient implements RpcConstants {
    private static final Logger LOG = LogFormatter.getLogger(AbstractRpcClient.class);

    /**
     * Used for error recovery.<br>
     * Should not throw any exception or runtime exception.
     * 
     * @author zhangduo
     */
    public static interface ErrorTracker {
        /**
         * if a connection run a success loop, will call this method, this means
         * previous fatal error should be ignored.
         */
        void noErrorOccur();

        /**
         * this means a connection has been closed. if this error happens too
         * many times, the RpcClient should be discard and reinitialized.
         */
        void fatalErrorOccur();

        /**
         * reinitialize RpcClient immediately, this usually because the server
         * properties are changed.
         */
        void needReinitialize();
    }

    protected final Class<?> protocol;

    protected final Map<Method, Long> method2signature;

    protected final InetSocketAddress remoteAddr;

    public InetSocketAddress getRemoteAddr() {
        return remoteAddr;
    }

    // generated using host, pid, etc.
    protected final String clientName;

    protected final String authInfo;

    protected final String username;

    protected final String domain;

    protected final long timeout;

    protected long heartbeatInterval;

    protected byte serverIOMode;

    protected static final byte SERVER_IO_MODE_BIO = 0;

    protected static final byte SERVER_IO_MODE_NIO = 1;

    protected StringPropertiesWritable serverProperties;

    protected AtomicIntegerArray connFlag;

    protected Connection[] activeConnections;

    protected Semaphore connLock;

    protected final AtomicLong lastCallTime = new AtomicLong();

    protected final ScheduledFuture<?> heartbeatTask;

    protected AtomicInteger counter = new AtomicInteger(1);

    protected volatile boolean running = true;

    protected final ErrorTracker errorTracker;

    // threshold in ms of reporting calls taking too long
    public static final int RPC_TOO_LONG = 1000;

    private static final Map<Integer, String> INIT_CALL_ID_TO_NAME;

    static {
        Map<Integer, String> map = new HashMap<Integer, String>();
        map.put(CALL_ID_SEND_RPC_VERSION, "send rpc version");
        map.put(CALL_ID_SEND_CLIENT_NAME, "send client name");
        map.put(CALL_ID_SEND_AUTH_INFO, "send auth info");
        map.put(CALL_ID_VERIFY_PROTOCOL, "verify protocol");
        map.put(CALL_ID_SEND_DOMAIN, "send domain");
        map.put(CALL_ID_SEND_USERNAME, "send username");
        map.put(CALL_ID_SEND_AND_GET_PROPS, "send and get props");
        INIT_CALL_ID_TO_NAME = Collections.unmodifiableMap(map);
    }

    /**
     * Base class of connection to RpcServer.
     * 
     * @author zhangduo
     */
    protected abstract class Connection {
        protected volatile long lastActiveTime;

        protected volatile boolean closed;

        protected final String name;

        protected Connection(String name) {
            this.name = name;
        }

        protected abstract void close();

        protected abstract void sendParam(Call call) throws RpcException;

        protected abstract void sendHeartbeat() throws IOException;

        private Throwable readException(CDataInputStream in)
                throws IOException, ClassNotFoundException {
            int sz = in.readVInt();
            byte[] buf = new byte[sz];
            in.readFully(buf);
            ObjectInputStream ois = new ObjectInputStream(
                    new ByteArrayInputStream(buf));
            Throwable t = (Throwable) ois.readObject();
            MiscUtils.safeClose(ois);
            return t;
        }

        private void sendInitCall(OutputStream out,
                ReservedByteArrayOutputStream bos, CDataOutputStream dos,
                int callId, CDataInputStream in) throws Throwable {
            byte[] data = bos.data();
            int size = bos.size();
            CDataOutputStream.writeInt(callId, data, 0);
            CDataOutputStream.writeInt(size - 8, data, 4);
            out.write(data, 0, size);
            out.flush();
            lastCallTime.set(System.currentTimeMillis());
            bos.clear();
            int id = in.readInt();
            if (id != callId) {
                throw new RpcException("unexpected return call id " + id
                        + " for " + INIT_CALL_ID_TO_NAME.get(callId) + " call");
            }
            if (in.readByte() == CALL_EXCEPTION) {
                throw readException(in);
            }
        }

        protected void init(Socket socket, StringPropertiesWritable props,
                boolean recordResponse) throws Throwable {
            CDataInputStream in = new CDataInputStream(new BufferedInputStream(
                    socket.getInputStream(), 1024));
            OutputStream out = socket.getOutputStream();
            ReservedByteArrayOutputStream bos = new ReservedByteArrayOutputStream(
                    1024, 8);
            CDataOutputStream dos = new CDataOutputStream(bos);

            // send rpc version
            LOG.fine(name + " send rpc version");
            dos.writeInt(RPC_VERSION);
            sendInitCall(out, bos, dos, CALL_ID_SEND_RPC_VERSION, in);

            // send client name
            LOG.fine(name + " send client name");
            StringWritable.writeString(dos, clientName);
            sendInitCall(out, bos, dos, CALL_ID_SEND_CLIENT_NAME, in);

            // send auth info
            LOG.fine(name + " send auth info");
            StringWritable.writeString(dos, authInfo);
            sendInitCall(out, bos, dos, CALL_ID_SEND_AUTH_INFO, in);

            // verify protocol
            LOG.fine(name + " verify protocol");
            ProtocolVerifyEntry verifyEntry = new ProtocolVerifyEntry(
                    protocol.getName(), method2signature);
            verifyEntry.writeFields(dos);
            sendInitCall(out, bos, dos, CALL_ID_VERIFY_PROTOCOL, in);

            // send domain
            LOG.fine(name + " send domain");
            StringWritable.writeString(dos, domain);
            sendInitCall(out, bos, dos, CALL_ID_SEND_DOMAIN, in);

            // send username
            LOG.fine(name + " send username");
            StringWritable.writeString(dos, username);
            sendInitCall(out, bos, dos, CALL_ID_SEND_USERNAME, in);

            // send and get props
            LOG.fine(name + " send and get props");
            props.writeFields(dos);
            sendInitCall(out, bos, dos, CALL_ID_SEND_AND_GET_PROPS, in);
            props.readFields(in);
            if (recordResponse) {
                receiveServerProperties(props);
            } else {
                checkServerPropertiesConsistency(props);
            }
        }
    }

    protected static class Call {
        protected int id;

        protected long signature;

        protected Method method;

        protected Object[] args;

        protected Object returnValue;

        protected IWritable returnValueBuffer;

        protected Throwable error;

        // for NIO
        protected ByteBuffer remaining;

        protected boolean finished = false;

        @Override
        public String toString() {
            return "Call [id=" + id + ", signature=" + signature + ", method="
                    + method + ", args=" + Arrays.toString(args)
                    + ", returnValue=" + returnValue + ", error=" + error
                    + ", finished=" + finished + "]";
        }

    }

    protected class CallFuture<V> implements Future<V> {

        private Call call;

        private long start;

        private long sendTime;

        public CallFuture(Call call, long startTime) throws RpcException {
            this.call = call;
            this.start = startTime;
            try {
                if (timeout > 0) {
                    long toWait = timeout
                            - (System.currentTimeMillis() - startTime);
                    if (toWait <= 0) {
                        throw new RpcTimeoutException(
                                "Timed out getting connection: timeout = "
                                        + timeout + ", remoteAddr = "
                                        + remoteAddr + ", method = "
                                        + call.method);
                    }
                    if (!connLock.tryAcquire(timeout, TimeUnit.MILLISECONDS)) {
                        throw new RpcTimeoutException(
                                "Timed out getting connection: timeout = "
                                        + timeout + ", remoteAddr = "
                                        + remoteAddr + ", method = "
                                        + call.method);
                    }
                } else {
                    connLock.acquire();
                }
            } catch (InterruptedException e) {
                throw new RpcException("get connection failed", e);
            }
            int index = -1;
            try {
                for (int i = 0; i < connFlag.length(); i++) {
                    if (connFlag.compareAndSet(i, 0, 1)) {
                        index = i;
                        break;
                    }
                }
                if (activeConnections[index] == null
                        || activeConnections[index].closed) {
                    createConnection(index, false);
                }
                activeConnections[index].sendParam(call);
                lastCallTime.set(start);
                sendTime = System.currentTimeMillis() - start;
                if (sendTime > RPC_TOO_LONG) {
                    LOG.warning("Network problem or overloaded server? "
                            + "Sending out RPC to " + remoteAddr + " took: "
                            + sendTime + "ms");
                }
            } finally {
                if (index >= 0) {
                    connFlag.set(index, 0);
                }
                connLock.release();
            }
        }

        @Override
        public boolean cancel(boolean mayInterruptIfRunning) {
            return false;
        }

        Object innerGet(long timeout, boolean throwRpcException)
                throws Throwable {
            synchronized (call) {
                while (!call.finished) {
                    if (timeout > 0) {
                        long toWait = timeout
                                - (System.currentTimeMillis() - start);
                        if (toWait <= 0) {
                            LOG.warning("Call " + call + " timeout");
                            if (throwRpcException) {
                                throw new RpcTimeoutException(
                                        "timed out waiting for response: timeout = "
                                                + timeout + ", remoteAddr = "
                                                + remoteAddr + ", method = "
                                                + call.method);
                            } else {
                                throw new TimeoutException(
                                        "timed out waiting for response: timeout = "
                                                + timeout + ", remoteAddr = "
                                                + remoteAddr + ", method = "
                                                + call.method);
                            }
                        }
                        try {
                            call.wait(toWait);
                        } catch (InterruptedException e) {}
                    } else {
                        try {
                            call.wait();
                        } catch (InterruptedException e) {}
                    }
                }
            }
            if (call.error != null) {
                Exception tmp = new Exception();
                StackTraceElement[] clientStackTrace = tmp.getStackTrace();
                StackTraceElement[] remoteStackTrace = call.error.getStackTrace();
                StackTraceElement[] stackTrace = new StackTraceElement[clientStackTrace.length
                        + remoteStackTrace.length + 1];
                System.arraycopy(remoteStackTrace, 0, stackTrace, 0,
                        remoteStackTrace.length);
                stackTrace[remoteStackTrace.length] = new StackTraceElement(
                        "---rpc call ---", "...", "...", -1);
                System.arraycopy(clientStackTrace, 0, stackTrace,
                        remoteStackTrace.length + 1, clientStackTrace.length);
                call.error.setStackTrace(stackTrace);
                throw call.error;
            } else {
                long totalTime = System.currentTimeMillis() - start;
                if (totalTime > RPC_TOO_LONG) {
                    LOG.info("Long RPC call, totalTime=" + totalTime
                            + ", sendTime=" + sendTime + ", remoteAddr = "
                            + remoteAddr + ", method = " + call.method);
                }
                return call.returnValue;
            }
        }

        Object innerGet() throws Throwable {
            return innerGet(timeout, true);
        }

        @SuppressWarnings("unchecked")
        @Override
        public V get() throws InterruptedException, ExecutionException {
            try {
                return (V) innerGet();
            } catch (Throwable t) {
                throw new ExecutionException(t);
            }
        }

        @SuppressWarnings("unchecked")
        @Override
        public V get(long timeout, TimeUnit unit) throws InterruptedException,
                ExecutionException, TimeoutException {
            try {
                return (V) innerGet(unit.toMillis(timeout), false);
            } catch (TimeoutException e) {
                throw e;
            } catch (Throwable t) {
                throw new ExecutionException(t);
            }
        }

        @Override
        public boolean isCancelled() {
            return false;
        }

        @Override
        public boolean isDone() {
            synchronized (call) {
                return call.finished;
            }
        }
    }

    protected void receiveServerProperties(StringPropertiesWritable props)
            throws RpcException {
        LOG.fine("receice server properties " + props);
        this.serverProperties = props;
        int maxConnections = Integer.parseInt(props.getProperty(SERVER_PROP_CONNECTION_PER_CLIENT));
        activeConnections = new Connection[maxConnections];
        connLock = new Semaphore(maxConnections);
        connFlag = new AtomicIntegerArray(maxConnections);
        heartbeatInterval = Long.parseLong(props.getProperty(SERVER_PROP_HEARTBEAT_INTERVAL));
        String serverIOMode = props.getProperty(SERVER_PROP_IO_MODE);
        if (serverIOMode.equals(SERVER_PROP_IO_MODE_BIO)) {
            this.serverIOMode = SERVER_IO_MODE_BIO;
        } else if (serverIOMode.equals(SERVER_PROP_IO_MODE_NIO)) {
            this.serverIOMode = SERVER_IO_MODE_NIO;
        } else {
            throw new RpcException("unknown server mode");
        }
    }

    protected void checkServerPropertiesConsistency(
            StringPropertiesWritable props) throws RpcException {
        if (!props.equals(serverProperties)) {
            errorTracker.needReinitialize();
            throw new RpcException(
                    "Server Properties changed, need reinitialize");
        }
    }

    protected abstract void createConnection(int index, boolean recordResponse)
            throws RpcException;

    private void sendHeartbeat() throws InterruptedException, IOException {
        LOG.fine("send heartbeat to " + remoteAddr + " for client "
                + clientName);
        int index = -1;
        connLock.acquire();
        try {
            for (int i = 0; i < connFlag.length(); i++) {
                if (connFlag.compareAndSet(i, 0, 1)) {
                    index = i;
                    break;
                }
            }
            if (activeConnections[index] == null
                    || activeConnections[index].closed) {
                createConnection(index, false);
            } else {
                activeConnections[index].sendHeartbeat();
            }

        } finally {
            if (index >= 0) {
                connFlag.set(index, 0);
            }
            connLock.release();
        }
    }

    protected AbstractRpcClient(Class<?> protocol,
            InetSocketAddress remoteAddr, String authInfo, String domain,
            String username, long timeout, String clientName,
            ErrorTracker errorTracker,
            ScheduledExecutorService heartbeatExecutor) throws RpcException {
        if (timeout < 0) {
            throw new IllegalArgumentException(
                    "timeout must >= 0 (passed in is " + timeout + ")");
        }
        this.protocol = protocol;
        this.method2signature = ProtocolVerifier.clientVerify(protocol);
        this.remoteAddr = remoteAddr;
        this.authInfo = authInfo;
        this.domain = domain;
        this.username = username;
        this.timeout = timeout;
        this.clientName = clientName;
        this.errorTracker = errorTracker;
        createConnection(0, true);
        if (heartbeatInterval > 0) {
            heartbeatTask = heartbeatExecutor.scheduleAtFixedRate(
                    new Runnable() {

                        @Override
                        public void run() {
                            if (running) {
                                for (int i = 0; i < connFlag.length(); i++) {
                                    if (connFlag.get(i) > 0
                                            && System.currentTimeMillis()
                                                    - activeConnections[i].lastActiveTime > heartbeatInterval) {
                                        activeConnections[i].close();
                                    }
                                }
                                long last = lastCallTime.get();
                                long current = System.currentTimeMillis();
                                if (current - last >= heartbeatInterval) {
                                    try {
                                        sendHeartbeat();
                                        lastCallTime.set(current);
                                    } catch (Throwable t) {
                                        LOG.log(Level.WARNING,
                                                "send heartbeat failed", t);
                                    }
                                }
                            }

                        }
                    },
                    heartbeatInterval
                            + RPC.rand.nextInt((int) (heartbeatInterval / 2)),
                    heartbeatInterval * 2 / 3, TimeUnit.MILLISECONDS);
        } else {
            heartbeatTask = null;
        }
    }

    private int getCallId() {
        int id;
        int nextId;
        do {
            id = counter.get();
            nextId = id == Integer.MAX_VALUE ? 1 : id + 1;
        } while (!counter.compareAndSet(id, nextId));
        return id;
    }

    /**
     * Do an rpc call.<br>
     * 
     * @param <V>
     * @param method
     * @param returnValueBuffer
     * @param args
     * @return
     * @throws RpcException
     */
    public <V> CallFuture<V> call(Method method, IWritable returnValueBuffer,
            Object[] args, long startTime) throws RpcException {
        if (!running) {
            throw new RpcException("RpcClient is stopped");
        }
        Call call = new Call();
        call.id = getCallId();
        call.signature = method2signature.get(method);
        call.method = method;
        call.args = args != null ? args : new Object[0];
        call.returnValueBuffer = returnValueBuffer;
        return new CallFuture<V>(call, startTime);
    }

    /**
     * Return whether this RpcClient is still running
     * 
     * @return
     */
    public boolean isRunning() {
        return running;
    }

    /**
     * Close all connections to remote server.<br>
     * This do not means to shutdown this RpcClient, the connection will be
     * recreated when you do a call next time.
     * 
     * @throws InterruptedException
     */
    public void closeConnection() throws InterruptedException {
        connLock.acquire(activeConnections.length);
        try {
            for (int i = 0; i < activeConnections.length; i++) {
                if (activeConnections[i] != null) {
                    activeConnections[i].close();
                    activeConnections[i] = null;
                }
                connFlag.set(i, 0);
            }
        } finally {
            connLock.release(activeConnections.length);
        }
    }

    /**
     * Stop this RpcClient. If an RpcClient is stopped, you can not use it any
     * more.
     */
    public void stop() {
        running = false;
        if (heartbeatTask != null) {
            heartbeatTask.cancel(true);
        }
        for (int i = 0; i < activeConnections.length; i++) {
            if (activeConnections[i] != null) {
                activeConnections[i].close();
                activeConnections[i] = null;
            }
            connFlag.set(i, 0);
        }
    }
}
