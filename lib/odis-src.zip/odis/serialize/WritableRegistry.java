package odis.serialize;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.serialize.comparator.BinaryComparator;
import toolbox.misc.ClassUtils;
import toolbox.misc.LogFormatter;

/**
 * Register related information about a Writable - alias - size - binary
 * comparator
 * 
 * @author Li Zhuang (zl@cs.berkeley.edu, zl@rd.netease.com), David
 *         (david@rd.netease.com) Created on Apr 21, 2006 Copyright (c) 2006
 *         Outfox Team
 */
public class WritableRegistry {

    public static final int NON_FIXED_SIZE = -1;

    public static final Logger LOG = LogFormatter.getLogger(WritableRegistry.class.getName());

    private static Map<Class<? extends IWritable>, String> CLASS_TO_ALIAS = new HashMap<Class<? extends IWritable>, String>();

    private static Map<String, Class<? extends IWritable>> ALIAS_TO_CLASS = new HashMap<String, Class<? extends IWritable>>();

    private static Map<String, Class<? extends IWritable>> LEGACY_ALIAS_TO_CLASS = new HashMap<String, Class<? extends IWritable>>();

    private static Map<Class<? extends IWritable>, Integer> CLASS_TO_SIZE = new HashMap<Class<? extends IWritable>, Integer>();

    private static Map<Class<? extends IWritable>, Class<? extends BinaryComparator>> CLASS_TO_COMPARATOR = new HashMap<Class<? extends IWritable>, Class<? extends BinaryComparator>>();

    private static Set<Class<? extends IWritable>> INITIALIZED_CLASS = new HashSet<Class<? extends IWritable>>();

    public static final String PROP_NAME = "writable_registry.list";

    private static boolean isLoaded = false;

    private static boolean allowDynamicReload = false;

    /**
     * Set <code>allowDynamicReload</code> to true. This means we will use
     * {@link DynamicWritableRegistry} when register.
     * 
     * @see DynamicWritableRegistry
     */
    public static void enableDynamicReload() {
        allowDynamicReload = true;
    }

    /**
     * Set <code>allowDynamicReload</code> to false.
     */
    public static void disableDynamicReload() {
        allowDynamicReload = false;
    }

    /**
     * load all writable classes in {@link #PROP_NAME} files.
     */
    public static void load() {
        if (isLoaded) {
            return;
        }
        // find all list files
        List<URL> resources = new ArrayList<URL>();
        try {
            Enumeration<URL> enume = WritableRegistry.class.getClassLoader().getResources(
                    PROP_NAME);
            for (; enume.hasMoreElements();) {
                resources.add(enume.nextElement());
            }
            enume = WritableRegistry.class.getClassLoader().getResources(
                    "META-INF/" + PROP_NAME);
            for (; enume.hasMoreElements();) {
                resources.add(enume.nextElement());
            }
        } catch (IOException e) {
            LOG.severe("cannot find " + PROP_NAME + " in classpath");
            throw new RuntimeException("cannot find " + PROP_NAME
                    + " in classpath ");
        }
        // find all package names
        HashSet<String> pack = new HashSet<String>();
        for (URL url: resources) {
            BufferedReader reader = null;
            try {
                try {
                    reader = new BufferedReader(new InputStreamReader(
                            url.openStream()));
                    String s = reader.readLine();
                    while (s != null) {
                        if (!s.trim().equals(""))
                            pack.add(s);
                        s = reader.readLine();
                    }
                } finally {
                    if (reader != null)
                        reader.close();
                }
            } catch (IOException e) {
                LOG.log(Level.SEVERE, "load writable id configuration from "
                        + url + " failed.", e);
                throw new RuntimeException(e);
            }
        }
        // load writables
        WritableRegistry.loadWritables(pack.toArray(new String[pack.size()]));
        isLoaded = true;
    }

    /**
     * print all loaded Writable classes.
     */
    public static void printLoaded() {
        System.out.println("Loaded " + INITIALIZED_CLASS.size()
                + " writables in registry");
        Iterator<Class<? extends IWritable>> it = INITIALIZED_CLASS.iterator();
        while (it.hasNext()) {
            System.out.println(it.next().toString());
        }
    }

    /**
     * Register Class <-> alias.
     * 
     * @param cls
     * @param alias
     */
    public static void registerAlias(Class<? extends IWritable> cls,
            String alias) {
        register(cls, alias, NON_FIXED_SIZE, null);
    }

    /**
     * Register Class -> size.
     * 
     * @param cls
     * @param size
     */
    public static void registerSize(Class<? extends IWritable> cls, int size) {
        register(cls, null, size, null);
    }

    /**
     * Register Class -> comparator.
     * 
     * @param cls
     * @param comparator
     */
    public static void registerComparator(Class<? extends IWritable> cls,
            Class<? extends BinaryComparator> comparator) {
        register(cls, null, NON_FIXED_SIZE, comparator);
    }

    /**
     * Register alias and comparator.
     * 
     * @param cls
     * @param alias
     * @param comparator
     */
    public static void register(Class<? extends IWritable> cls, String alias,
            Class<? extends BinaryComparator> comparator) {
        register(cls, alias, NON_FIXED_SIZE, comparator);
    }

    /**
     * Register size and comparator.
     * 
     * @param cls
     * @param size
     * @param comparator
     */
    public static void register(Class<? extends IWritable> cls, int size,
            Class<? extends BinaryComparator> comparator) {
        register(cls, null, size, comparator);
    }

    /**
     * Register alias and size.
     * 
     * @param cls
     * @param alias
     * @param size
     */
    public static void register(Class<? extends IWritable> cls, String alias,
            int size) {
        register(cls, alias, size, null);
    }

    /**
     * Register the alias/size/comparator for a class.
     * 
     * @param cls
     *            the class to be registered
     * @param alias
     *            the alais of this class
     * @param size
     *            the size of the IWritable in bytes. -1 means non-fixed size
     * @param comparator
     *            the binary-comparator for this class. Could be null
     */
    public static void register(Class<? extends IWritable> cls, String alias,
            int size, Class<? extends BinaryComparator> comparator) {
        if (allowDynamicReload
                && !cls.getClassLoader().equals(
                        WritableRegistry.class.getClassLoader())) {
            LOG.info("Use DynamicRegistry to register " + cls.getName()
                    + " as " + alias);
            DynamicWritableRegistry dyRegistry = DynamicWritableRegistry.get(cls.getClassLoader());
            dyRegistry.register(cls, alias, size, comparator);
            return;
        }
        if (alias != null && !"".equals(alias)) {
            if (CLASS_TO_ALIAS.containsKey(cls)) {
                throw new RuntimeException("Class " + cls
                        + " has been given an " + "aliase "
                        + CLASS_TO_ALIAS.get(cls) + " when trying to "
                        + "register it with an alias " + alias);
            }
            if (ALIAS_TO_CLASS.containsKey(alias)) {
                throw new RuntimeException(alias + " has been "
                        + "registered as the alias of "
                        + ALIAS_TO_CLASS.get(alias)
                        + " when trying to register it as the alias of " + cls);
            }
            CLASS_TO_ALIAS.put(cls, alias);
            ALIAS_TO_CLASS.put(alias, cls);
        } // if
        if (size > 0)
            CLASS_TO_SIZE.put(cls, size);
        if (comparator != null)
            CLASS_TO_COMPARATOR.put(cls, comparator);
    }

    /**
     * register legacy alias.
     * 
     * @param cls
     * @param legacyAlias
     */
    public static void registerLegacyAlias(Class<? extends IWritable> cls,
            String legacyAlias) {
        if (legacyAlias != null && !"".equals(legacyAlias))
            LEGACY_ALIAS_TO_CLASS.put(legacyAlias, cls);
    }

    private static boolean initClass(Class<? extends IWritable> clazz) {
        if (INITIALIZED_CLASS.contains(clazz))
            return true;
        synchronized (INITIALIZED_CLASS) {
            if (!INITIALIZED_CLASS.contains(clazz)) {
                INITIALIZED_CLASS.add(clazz);
                try {
                    Class.forName(clazz.getName());
                } catch (Exception e) {
                    LOG.severe("Initialize class " + clazz + " error:" + e);
                    return false;
                }
            }
            return true;
        }
    }

    /**
     * Get writable name. If no alias found, return its class name.
     * 
     * @param clazz
     * @return
     */
    public static String getWritableName(Class<? extends IWritable> clazz) {
        // initialize class?
        assert clazz != null;
        if (!initClass(clazz))
            return clazz.getName();
        // get alias name?
        String value = CLASS_TO_ALIAS.get(clazz);
        if (value == null) {
            return clazz.getName();
        } else {
            return value;
        }
    }

    /**
     * Get Writable class. If no class found, return null.
     * 
     * @param alias
     * @return
     */
    @SuppressWarnings("unchecked")
    public static Class<? extends IWritable> getWritableClass(String alias) {
        assert alias != null;
        Class<? extends IWritable> cls = ALIAS_TO_CLASS.get(alias);
        if (cls == null)
            cls = LEGACY_ALIAS_TO_CLASS.get(alias);
        if (cls == null)
            try {
                cls = (Class<? extends IWritable>) ClassUtils.getClass(alias,
                        IWritable.class);
            } catch (RuntimeException e) {
                if (e.getCause() instanceof ClassNotFoundException)
                    LOG.warning("Cannot find class with alias: "
                            + alias
                            + ", maybe forgot to add your packge/class in META-INF/writable_registry.list?");
                throw e;
            }
        return cls;
    }

    /**
     * Get Writable class. If no class found, return null.<br>
     * This method will use {@link DynamicWritableRegistry}.
     * 
     * @see DynamicWritableRegistry
     * @param alias
     * @param cl
     * @return
     */
    public static Class<? extends IWritable> getWritableClass(String alias,
            ClassLoader cl) {
        assert alias != null;
        assert cl != null;
        DynamicWritableRegistry dyRegistry = DynamicWritableRegistry.get(cl);
        return dyRegistry.getWritableClass(alias);
    }

    /**
     * Get writable size. If no size found, return {@link #NON_FIXED_SIZE}
     * 
     * @param clazz
     * @return
     */
    public static int getWritableSize(Class<? extends IWritable> clazz) {
        // initialize class?
        assert clazz != null;
        if (!initClass(clazz))
            return NON_FIXED_SIZE;
        // get size?
        Integer value = CLASS_TO_SIZE.get(clazz);
        if (value == null)
            return NON_FIXED_SIZE;
        else
            return value.intValue();
    }

    /**
     * Get writable comparator class. If no comparator class found, return null.
     * 
     * @param clazz
     * @return
     */
    public static Class<? extends BinaryComparator> getBinaryComparatorClass(
            Class<? extends IWritable> clazz) {
        // initialize class?
        if (!initClass(clazz))
            return null;
        // get comparator?
        return CLASS_TO_COMPARATOR.get(clazz);
    }

    /**
     * Get writable comparator instance. If no comparator class found, return
     * null, else return a comparator instance with its comparator class.
     * 
     * @param clazz
     * @return
     */
    public static BinaryComparator getBinaryComparator(
            Class<? extends IWritable> clazz) {
        assert clazz != null;
        // initialize class?
        if (!initClass(clazz))
            return null;
        // get comparator?
        Class<? extends BinaryComparator> value = CLASS_TO_COMPARATOR.get(clazz);
        if (value == null)
            return null;
        else
            return (BinaryComparator) ClassUtils.newInstance(value);
    }

    @SuppressWarnings("unchecked")
    private static void loadWritables(String[] packages) {
        String[] cls;
        for (int i = 0; i < packages.length; i++) {
            // find classes
            try {
                cls = ClassUtils.findClassesInPackage(packages[i],
                        new ArrayList<String>(), new ArrayList<String>());
            } catch (IOException e) {
                LOG.log(Level.SEVERE, "load writables error: " + packages[i], e);
                continue;
            }
            // load classes
            for (int j = 0; j < cls.length; j++) {
                try {
                    Class<?> clazz = Class.forName(cls[j]);
                    if (IWritable.class.isAssignableFrom(clazz)
                            && !clazz.isInterface())
                        initClass((Class<? extends IWritable>) clazz);
                } catch (Throwable e) {
                    LOG.log(Level.WARNING, "Error loading " + cls[j]
                            + ", ignoring ...", e);
                }
            }
        }
    }
}
