package odis.serialize;

import java.util.Properties;

/**
 * Those writables implement this interface should be configed with the
 * properties in sequence file header.
 * 
 * @author river
 * @deprecated on 7/23/2007 since I think no one is using it
 */
@Deprecated
public interface IConfigurable {

    public void config(Properties properties);

}
