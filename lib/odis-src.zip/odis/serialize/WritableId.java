package odis.serialize;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import toolbox.misc.LogFormatter;

/**
 * 对于有限的Writable类型，我们可以给他们用一个数字id(byte)进行编号，这样对于
 * 需要标识对象类型但是又不希望引入过大的其他负载的情况，例如多类型输入到MapReduce， Map输出的时候希望统一到一种类型.
 * 
 * 对于id，我们有如下的定义:
 * <ul>
 * <li>0: Null，这个是一个表示空的值，不能被使用</li>
 * <li>1 -- 127: 静态设置的id，通过配置文件或者其他方式设置，对于同样一份代码， 一直有效</li>
 * <li>-128 -- -1 : 动态设置的id，在代码中设置，但是这个信息必须手动在多虚拟机之间传递
 * </ul>
 * 
 * Writable id list is load from classpath, all the resources with path "writable_ids.properties"
 * and "META-INF/writable_ids.properties".
 * 
 * @see DynamicWritable
 * @author river
 * @deprecated Don't use id for writable, use the abstract containers instead.
 */
public class WritableId {
    public static final Logger LOG = LogFormatter.getLogger(WritableId.class);

    public static final byte NULL_ID = 0;

    private static Class<?>[] CLASSES = new Class[256];

    private static Map<Class<?>, Byte> ID_MAP = new HashMap<Class<?>, Byte>();

    public static final String PROP_NAME = "writable_ids.properties";
    static {
        List<URL> resources = new ArrayList<URL>();
        
        try {
            Enumeration<URL> enume = WritableId.class.getClassLoader().getResources(PROP_NAME);
            for (; enume.hasMoreElements(); ) { resources.add(enume.nextElement()); }
            enume = WritableId.class.getClassLoader().getResources("META-INF/" + PROP_NAME);
            for (; enume.hasMoreElements(); ) { resources.add(enume.nextElement()); }
        } catch (IOException e) {
            LOG.severe("cannot find " + PROP_NAME + " in classpath");
            throw new RuntimeException("cannot find " + PROP_NAME
                    + " in classpath ");
        }

        for (URL url : resources) {
            InputStream is;
            try {
                is = url.openStream();
                try {
                    load(is);
                } finally {
                    is.close();
                }
            } catch (IOException e) {
                LOG.log(Level.SEVERE, "load writable id configuration from "
                        + url + " failed.", e);
                throw new RuntimeException(e);
            }
        }
    }

    private static void load(InputStream is) throws IOException {
        Properties prop = new Properties();
        prop.load(is);

        for (Iterator<Object> it = prop.keySet().iterator(); it.hasNext();) {
            String key = (String) it.next();
            String value = prop.getProperty(key);
            try {
                int k = Integer.parseInt(key, 16);
                Class<?> clazz = Class.forName(value);
                register((byte) k, clazz);
            } catch (ClassNotFoundException e) {
                LOG.log(Level.SEVERE, "cannot find class " + value, e);
                throw new RuntimeException(e);
            }
        }
    }

    /**
     * 注册一个类对应的id.
     * 
     * @param id
     * @param clazz
     */
    public static void register(byte id, Class<?> clazz) {
        int normalizedId = ((int) id & 0xFF);
        if (CLASSES[normalizedId] == null) {
            CLASSES[normalizedId] = clazz;
            ID_MAP.put(clazz, id);
            LOG.fine("class " + clazz + " registered with id " + id);
        } else if (CLASSES[normalizedId] != clazz) {
            throw new RuntimeException("class " + CLASSES[normalizedId]
                    + " and " + clazz + " registered with the same id " + id);
        }

    }

    /**
     * 返回和id相关的类型，如果不存在，返回null.
     * 
     * @param id
     * @return the class corresponding to the id
     */
    public static Class<?> getClass(byte id) {
        if (id == 0)
            return null;

        return CLASSES[(int) id & 0xFF];
    }

    /**
     * 活动某个类对应的id，如果没有注册这个类，返回0.
     * 
     * @param clazz
     * @return the id corresponding to the class
     */
    public static byte getId(Class<?> clazz) {
        Byte o = ID_MAP.get(clazz);
        return (o == null) ? NULL_ID : o.byteValue();
    }
}
