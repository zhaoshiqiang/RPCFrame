package odis.serialize;

/**
 * An interface representing the ability to parse from a string.
 * 
 * @author david
 */
public interface IParsable {
    /**
     * Parses the given string and change the content
     * 
     * @param str
     *            the string to be parsed
     * @throws ParseException
     *             if an error occurs during parsing
     */
    public void parse(String str) throws ParseException;
}
