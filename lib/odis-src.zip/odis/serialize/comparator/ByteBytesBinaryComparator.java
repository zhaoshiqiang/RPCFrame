/*
 * Copyright (c) 2006, Outfox Team.
 */
package odis.serialize.comparator;

/**
 * Comparing two "byte-bytes" (ie length prefixed byte array: <code>length in 
 * a byte followed by the actual bytes).
 * 
 * @author zhangduo
 */
public class ByteBytesBinaryComparator extends BinaryComparator {

    /**
     * @param l1
     *            ignored as length is contained in data
     * @param l2
     *            ignored as length is contained in data
     * @see BinaryComparator#compare(byte[], int, int, byte[], int, int)
     */
    @Override
    public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2) {
        return compareBytes(b1, s1 + 1, b1[s1] & 0xFF, b2, s2 + 1,
                b2[s2] & 0xFF);
    }

}
