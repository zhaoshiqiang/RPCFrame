/**
 * @(#)VLongBinarycomparator.java, 2011-3-9. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.serialize.comparator;

import odis.io.CDataInputStream;

/**
 * A comparator comparing two variant longs.
 * 
 * @author zhangduo
 */
public class VLongBinaryComparator extends BinaryComparator {

    /**
     * @param l1
     *            ignored as decided by {@link CDataInputStream#readVLong()}
     * @param l2
     *            ignored as decided by {@link CDataInputStream#readVLong()}
     * @see BinaryComparator#compare(byte[], int, int, byte[], int, int)
     */
    @Override
    public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2) {
        long v1 = CDataInputStream.readVLong(b1, s1);
        long v2 = CDataInputStream.readVLong(b2, s2);
        return v1 > v2 ? 1 : v1 == v2 ? 0 : -1;
    }

}
