/*
 * Copyright (c) 2006, Outfox Team.
 */
package odis.serialize.comparator;

import odis.io.CDataInputStream;

/**
 * Comparing two doubles.
 * 
 * @author zhangduo
 */
public class DoubleBinaryComparator extends BinaryComparator {

    /**
     * @param l1
     *            ignored as length is always 8
     * @param l2
     *            ignored as length is always 8
     * 
     * @see BinaryComparator#compare(byte[], int, int, byte[], int, int)
     */
    @Override
    public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2) {
        double thisValue = CDataInputStream.readDouble(b1, s1);
        double thatValue = CDataInputStream.readDouble(b2, s2);
        return (thisValue < thatValue ? -1 : (thisValue == thatValue ? 0 : 1));
    }

}
