/*
 * Copyright (c) 2006, Outfox Team.
 */
package odis.serialize.comparator;

import odis.serialize.lib.MD5Writable;

/**
 * Comparing two MD5 checksums.
 * 
 * @author zhangduo
 */
public class MD5BinaryComparator extends BinaryComparator {

    /**
     * @param l1
     *            ignored as length is always 16
     * @param l2
     *            ignored as length is always 16
     * @see BinaryComparator#compare(byte[], int, int, byte[], int, int)
     */
    @Override
    public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2) {
        return compareBytes(b1, s1, MD5Writable.MD5_LENGTH, b2, s2,
                MD5Writable.MD5_LENGTH);
    }

}
