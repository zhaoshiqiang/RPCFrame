/*
 * Copyright (c) 2006, Outfox Team.
 */
package odis.serialize.comparator;

import java.io.IOException;
import java.util.Comparator;

import odis.file.BinaryKeyValComparator;
import odis.io.DataInputBuffer;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.WritableRegistry;
import toolbox.misc.ClassUtils;

/**
 * A generic comparator that parses the {@link IWritableComparable} and calls
 * {@link Comparable#compareTo(Object)} to do comparison. This is the default
 * BinaryComparator used in {@link BinaryKeyValComparator} and works for any
 * {@link IWritableComparable}. However, for fast comparison in sorting, you
 * need to implement a separate {@link BinaryComparator} for your IWritable.
 * 
 * @author Li Zhuang
 */
public class WritableComparator extends BinaryComparator implements
        Comparator<Object> {

    private Class<? extends IWritable> cls;

    private BinaryComparator bCmp;

    private DataInputBuffer buffer;

    private IWritable wc1;

    private IWritable wc2;

    /**
     * constructor with no <code>BinaryComparator</code>
     * 
     * @param cmpClass
     */
    public WritableComparator(Class<? extends IWritable> cmpClass) {
        this(cmpClass, null);
    }

    /**
     * construct a WritableComparator with given class and BinaryComparator.<br>
     * if <code>bCmp</code> is null, we will create two IWriable instance of
     * <code>cmpClass</code> to compare. Otherwise, use bCmp directly.
     * 
     * @param cmpClass
     * @param bCmp
     */
    public WritableComparator(Class<? extends IWritable> cmpClass,
            BinaryComparator bCmp) {
        this.cls = cmpClass;
        if (bCmp != null) {
            this.bCmp = bCmp;
        } else {
            this.buffer = new DataInputBuffer();
            this.wc1 = (IWritable) ClassUtils.newInstance(cmpClass);
            this.wc2 = (IWritable) ClassUtils.newInstance(cmpClass);
        }
    }

    /** Returns the WritableComparable implementation class. */
    public Class<? extends IWritable> getComparableClass() {
        return cls;
    }

    /** Default binary comparison implementation, bad performance */
    public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2) {
        // with binary comparator
        if (bCmp != null) {
            return bCmp.compare(b1, s1, l1, b2, s2, l2);
        }
        // no binary comparator
        try {
            buffer.reset(b1, s1, l1); // parse key1
            wc1.readFields(buffer);
            buffer.reset(b2, s2, l2); // parse key2
            wc2.readFields(buffer);
        } catch (IOException e) {
            throw new RuntimeException("Error reading fields", e);
        }
        return compare(wc1, wc2); // compare them
    }

    /** Default compare implementation for IWritableComparable */
    public int compare(Object o1, Object o2) {
        if (o1 instanceof IWritableComparable) {
            if (o2 instanceof IWritableComparable) {
                return ((IWritableComparable) o1).compareTo((IWritable) o2);
            } else if (o2 == null) {
                return 1;
            } else {
                throw new RuntimeException(o1.getClass().getName() + " and "
                        + o2.getClass().getName() + " are not comparable");
            }
        } else if (o1 == null) {
            if (o2 instanceof IWritableComparable) {
                return -1;
            } else if (o2 == null) {
                return 0;
            } else {
                throw new RuntimeException("null and "
                        + o2.getClass().getName() + " are not comparable");
            }
        } else {
            throw new RuntimeException(o1.getClass().getName() + " and " + o2
                    + " are not comparable");
        }
    }

    /**
     * Get WritableComparator for the given class.We will use
     * <code>WritableRegistry</code> to get comparator.
     * 
     * @see WritableRegistry
     * @param cls
     * @return
     */
    public static WritableComparator get(
            Class<? extends IWritableComparable> cls) {
        BinaryComparator cmp = WritableRegistry.getBinaryComparator(cls);
        if (cmp == null) {
            return new WritableComparator(cls);
        }
        return new WritableComparator(cls, cmp);
    }

}
