/*
 * Copyright (c) 2006, Outfox Team.
 */
package odis.serialize.comparator;

import odis.io.CDataInputStream;

/**
 * Comparing two shorts.
 * 
 * @author zhangduo
 */
public class ShortBinaryComparator extends BinaryComparator {

    /**
     * @param l1
     *            ignored as length is always 2
     * @param l2
     *            ignored as length is always 2
     * @see BinaryComparator#compare(byte[], int, int, byte[], int, int)
     */
    @Override
    public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2) {
        int thisValue = CDataInputStream.readShort(b1, s1);
        int thatValue = CDataInputStream.readShort(b2, s2);
        return thisValue - thatValue;
    }

}
