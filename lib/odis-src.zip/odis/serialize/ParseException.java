package odis.serialize;

/**
 * Used at {@link IParsable#parse(String)} to indicate that an error occurs
 * during parsing.
 * 
 * @author zhangduo
 */
public class ParseException extends Exception {

    private static final long serialVersionUID = 8060842699365116010L;

    public ParseException() {}

    public ParseException(Class<?> clazz, String string) {
        super("Parse " + string + " as class " + clazz + " error");
    }
}
