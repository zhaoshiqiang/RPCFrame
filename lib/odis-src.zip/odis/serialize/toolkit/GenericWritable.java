package odis.serialize.toolkit;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.IWritable;
import odis.serialize.WritableRegistry;

/**
 * A polymorphic Writable that can hold several types of objects. This is
 * similar to ObjectWritable but much faster because only one extra byte per
 * object is needed. There are in general two ways to use this class:
 * <ul>
 * <li>Inheritance. You make a subclass of GenericWritable and override
 * {@link #getTypes()}, which should return all the Writable classes the class
 * could use.</li>
 * <li>Dynamically setting types. You directly instantiate GenericWritable and
 * pass the classes to the constructor. After that, use {@link #getTypeString()}
 * to get a string with type info encoded inside it. This string can then be
 * passed to the receiving side, which should in turn calls
 * {@link #setTypeString(String)} to set types into a newly constructed
 * GenericWritable. It is currently cumbersome to use this in MapReduce because
 * the need to manually pass the type string somehow. So use of the inheritance
 * method is recommended. In the future, if we need, we can modify the task
 * runners to specially support GenericWritable.</li>
 * </ul>
 * <!-- This needs special support from the receiving side to pass the "types
 * string" in through {@link #setTypeString(String)}. For mapreduce use, this is
 * implemented by the task runner if
 * <code>JobConf.setGenericWritableInput()</code> is used on the sending side.
 * -->
 * 
 * @author zf
 */
// Modified: by David, 2005-12-31: No creation of all object instances supported.
// Modified: by zl, 2006-3-4: No creation of object at all, must call set(i)
//           before calling get()

public class GenericWritable implements IWritable {
    static {
        WritableRegistry.registerAlias(GenericWritable.class,
                "GenericWritable_v3");
    }

    private final static int NON_EXIST_TAG = -1;

    private int tag;

    private IWritable obj_cur;

    private Class[] types;

    /**
     * Construct a GenericWritable and assign types.
     */
    public GenericWritable(Class[] types) {
        this.types = types;
        tag = NON_EXIST_TAG;
        obj_cur = null;
    }

    /**
     * Construct a GenericWritable. It first tries to call #getType() to obtain
     * the types. If getTypes() is not implemented, the caller will have to call
     * #setTypeString() to assign types to it before it can be used.
     */
    public GenericWritable() {
        this.types = getTypes();
        tag = NON_EXIST_TAG;
        obj_cur = null;
    }

    /**
     * A subclass can override this and return the types it needs to enable
     * static initialization of the GenericWritable.
     */
    protected Class[] getTypes() {
        return new Class[0];
    }

    /**
     * Set type of this GenericWritable with a string got from #getTypeString().
     * The current type after calling this is always the first type.
     */
    public void setTypeString(String typeString) throws ClassNotFoundException {
        String[] classes = typeString.split(":");
        if (classes.length == 0)
            throw new IllegalArgumentException("types cannot be empty");
        if (classes.length > 255)
            throw new IllegalArgumentException(
                    "GenericWritable supports at most 255 types");
        int n = classes.length;
        types = new Class[n];
        for (int i = 0; i < n; i++) {
            types[i] = Class.forName(classes[i]);
            if (!IWritable.class.isAssignableFrom(types[i]))
                throw new IllegalArgumentException("Class " + types[i]
                        + " is not a IWritable.");
            obj_cur = null;
        } // for i
    }

    /**
     * Get a string representation of the types in this GenericWritable, which
     * can be used to set a new GenericWritable's type using setTypeString()..
     */
    public String getTypeString() {
        StringBuffer sb = new StringBuffer(types[0].getName());
        for (int i = 1; i < types.length; i++) {
            sb.append(':');
            sb.append(types[i].getName());
        } // for i
        return sb.toString();
    }

    /**
     * @see IWritable#writeFields(DataOutput)
     */
    @Override
    public void writeFields(DataOutput out) throws IOException {
        if (types == null || (tag < 0 || tag >= types.length)
                || obj_cur == null)
            throw new IOException("Uninitialized GenericWritable object used.");
        out.writeByte(tag);
        obj_cur.writeFields(out);
    }

    /**
     * @see IWritable#readFields(DataInput)
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        if (types == null)
            throw new IOException("Uninitialized GenericWritable object used.");
        set(in.readByte() & 0xff);
        obj_cur.readFields(in);
    }

    /**
     * @see IWritable#copyFields(IWritable)
     */
    @Override
    public IWritable copyFields(IWritable value) {
        GenericWritable that = (GenericWritable) value;
        this.types = new Class[that.types.length];
        System.arraycopy(that.types, 0, this.types, 0, types.length);
        this.tag = that.tag;
        if (that.obj_cur == null)
            this.obj_cur = null;
        else
            this.obj_cur.copyFields(that.obj_cur);
        return this;
    }

    /**
     * Set the current type to index and replace the internal object with a new
     * one.
     * 
     * @param index
     *            the index of this type of Writable in the original types array
     *            passed in when creating the GenericWritable.
     */
    public void set(IWritable obj, int index) {
        if (index < 0 || index > types.length)
            throw new IndexOutOfBoundsException("Bad index: " + index);
        if (obj.getClass().equals(types[index]))
            obj_cur = obj;
        else
            throw new ClassCastException("Expecting " + types[index].getClass()
                    + ", got " + obj.getClass());
        tag = index;
    }

    /**
     * Set the current type, but keep the internal object of the corresponding
     * type. This object can be obtained by calling #get() after this.
     * 
     * @param index
     *            the index of this type of Writable in the original types array
     *            passed in when creating the GenericWritable.
     * @throws IOException
     */
    public void set(int index) throws IOException {
        if (index != tag) {
            if (index < 0 || index > types.length)
                throw new IndexOutOfBoundsException("Bad type tag index: "
                        + index);
            tag = index;
            try {
                obj_cur = (IWritable) types[index].newInstance();
            } catch (Exception e) {
                throw new IOException("Unsupported type: " + e);
            }
        } // if
    }

    /**
     * Get IWritable instance.
     * 
     * @return
     */
    public IWritable get() {
        return obj_cur;
    }

    /**
     * Get the type tag.
     * 
     * @return
     */
    public int getType() {
        return tag;
    }

}
