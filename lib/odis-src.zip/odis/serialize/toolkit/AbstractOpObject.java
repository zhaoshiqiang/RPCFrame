/**
 * @(#)AbstractOpObject.java, 2008-1-28. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.serialize.toolkit;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.IWritable;

/**
 * OpObject implementation based on AbstractDynamicWritable.
 * 
 * @author river
 */
public abstract class AbstractOpObject extends AbstractDynamicWritable {
    /**
     * Default operation.
     */
    public static final byte OP_UNKNOWN = 0;

    /**
     * Modify operation.
     */
    public static final byte OP_MODIFIED = 1;

    /**
     * Delete operation.
     */
    public static final byte OP_DELETED = 2;

    private long timestamp = 0;

    private byte op = OP_UNKNOWN;

    /**
     * Operation names.
     */
    public static final String[] OP_NAMES = new String[] {
        "OP_UNKONWN", "OP_MODIFIED", "OP_DELETED",
    };

    /**
     * Return the name for operator.
     * 
     * @param op
     * @return
     */
    public static String getOpName(byte op) {
        if (op < 0 || op >= OP_NAMES.length) {
            return OP_NAMES[OP_UNKNOWN];
        } else {
            return OP_NAMES[op];
        }
    }

    /**
     * Get the operator.
     * 
     * @return the operator in byte.
     */
    public byte getOperator() {
        return op;
    }

    /**
     * Set the operator.
     * 
     * @param value
     *            the operator in byte.
     */
    public void setOperator(byte value) {
        this.op = value;
    }

    /**
     * Return the object only when operator is {@link #OP_MODIFIED}.
     */
    @Override
    public IWritable get() {
        if (this.op == OP_MODIFIED)
            return super.get();
        else
            return null;
    }

    /**
     * Return the timestamp.
     * 
     * @return the timestamp in millisecond
     */
    public long getTimestamp() {
        return timestamp;
    }

    /**
     * Set the timestamp.
     * 
     * @param value
     *            the timestamp in millisecond
     */
    public void setTimestamp(long value) {
        this.timestamp = value;
    }

    /**
     * @see IWritable#copyFields(IWritable)
     */
    @Override
    public IWritable copyFields(IWritable value) {
        if (value == null || (value.getClass() != this.getClass())) {
            throw new RuntimeException("bad value to copy : " + value);
        }
        if (value == this)
            return this;

        AbstractOpObject that = (AbstractOpObject) value;
        this.op = that.op;
        this.timestamp = that.timestamp;
        if (this.op == OP_MODIFIED) {
            super.copyFields(that);
        }
        return this;
    }

    /**
     * @see IWritable#readFields(DataInput)
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        this.timestamp = in.readLong();
        this.op = in.readByte();
        if (this.op == OP_MODIFIED) {
            super.readFields(in);
        }
    }

    /**
     * @see IWritable#writeFields(DataOutput)
     */
    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeLong(this.timestamp);
        out.writeByte(this.op);
        if (this.op == OP_MODIFIED) {
            super.writeFields(out);
        }
    }

    /**
     * Print op, timestamp and the Object(if exists).
     */
    @Override
    public String toString() {
        StringBuilder buf = new StringBuilder();
        buf.append("[").append(timestamp).append("] ").append(getOpName(op));
        if (this.op == OP_MODIFIED) {
            buf.append(' ').append(super.toString());
        }
        return buf.toString();
    }

}
