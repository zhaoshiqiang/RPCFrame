package odis.serialize.toolkit;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.IWritable;

/**
 * The abstract class for an IWritable hash-map.
 * 
 * Usage:
 *   Two alternative ways to use this class:
 *     1) Inherite this class, implements newKey()/newValue() then use the
 *        the sub-class as other IWritable class. 
 *        E.g.
 *          public class StringIntMap extends WritableMap<StringWritable, 
 *                      IntWritable> {
 *              @Override
 *              protected StringWritable newKey() {
 *                  return new StringWritable();
 *              }
 *              @Override
 *              protected IntWritable newValue() {
 *                  return new IntWritable();
 *              }
 *          }
 *          
 *     2) Use the WritableMap.get(...) to directly generate instance. This is
 *        sometimes useful, since a writable instance whithin another IWritable
 *        class is often modified by private and final, i.e. it was created at 
 *        creation of the parent class and never change again. 
 *        E.g.
 *          class ParentWritable {
 *              private final WritableMap<StringWritable, IntWritable> map =
 *                  WritableMap.get(StringWritable.class, IntWritable.class);
 *                  
 *              public WritableMap<StringWritable, IntWritable> getMap() {
 *                  return map;
 *              }
 *          } 
 *  
 * @author david
 *
 * @param <K>  the type of the key
 * @param <V>  the type of the value
 */
public abstract class WritableMap<K extends IWritable, V extends IWritable>
        extends HashMap<K, V> implements IWritable {
    private static final long serialVersionUID = 3092410508934836539L;

    /**
     * Returns a new instance of the key class
     * 
     * @return a new instance of the key class
     */
    protected abstract K newKey();

    /**
     * Returns a new instance of the value class
     * 
     * @return a new instance of the value class
     */
    protected abstract V newValue();

    /**
     * @see IWritable#readFields(DataInput)
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        this.clear();
        int len = CDataInputStream.readVInt(in);
        for (int i = 0; i < len; i++) {
            K key = newKey();
            key.readFields(in);
            V val = null;
            if (in.readBoolean()) {
                val = newValue();
                val.readFields(in);
            } // else
            this.put(key, val);
        } // for i
    }

    /**
     * @see IWritable#writeFields(DataOutput)
     */
    @Override
    public void writeFields(DataOutput out) throws IOException {
        CDataOutputStream.writeVInt(this.size(), out);
        for (Map.Entry<K, V> entry : entrySet()) {
            entry.getKey().writeFields(out);
            V val = entry.getValue();
            if (val == null) {
                out.writeBoolean(false);
            } else {
                out.writeBoolean(true);
                val.writeFields(out);
            } // else
        } // for entry
    }

    /**
     * @see IWritable#copyFields(IWritable)
     */
    @SuppressWarnings("unchecked")
    @Override
    public IWritable copyFields(IWritable value) {
        this.clear();
        WritableMap<K, V> that = (WritableMap<K, V>) value;
        for (Map.Entry<K, V> entry : that.entrySet()) {
            K thisKey = (K)newKey().copyFields(entry.getKey());
            V thatVal = entry.getValue();
            if (thatVal == null) {
                this.put(thisKey, null);
            } else {
                this.put(thisKey, (V)newValue().copyFields(thatVal));
            }
        }

        return this;
    }

    /**
     * Constructs an instance of WritableMap with specified key/value types.
     * 
     * @param <K>
     *            the type of the key
     * @param <V>
     *            the type of the value
     * @param keyCls
     *            the class of the key
     * @param valCls
     *            the class of the value
     * @return the generated instance.
     */
    public static <K extends IWritable, V extends IWritable> WritableMap<K, V> get(
            final Class<K> keyCls, final Class<V> valCls) {
        return new WritableMap<K, V>() {
            private static final long serialVersionUID = 1L;

            @Override
            protected K newKey() {
                try {
                    return keyCls.newInstance();
                } catch (InstantiationException e) {
                    throw new RuntimeException(e);
                } catch (IllegalAccessException e) {
                    throw new RuntimeException(e);
                }
            }

            @Override
            protected V newValue() {
                try {
                    return valCls.newInstance();
                } catch (InstantiationException e) {
                    throw new RuntimeException(e);
                } catch (IllegalAccessException e) {
                    throw new RuntimeException(e);
                }
            }
        };
    }
}
