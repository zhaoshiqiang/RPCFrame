/**
 * Copyright 2005 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package odis.serialize.toolkit;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.io.OutputStream;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import java.util.zip.InflaterInputStream;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.io.DataOutputBuffer;
import odis.io.LzoCompression;

/**
 * <p>
 * A base-class for Writables which store themselves compressed and lazily
 * inflate on field access. This is useful for large objects whose fields are
 * not be altered during a map or reduce operation: leaving the field data
 * compressed makes copying the instance from one file to another much faster.
 * </p>
 * <p>
 * zf: this is based on <code>org.apache.nutch.io.CompressedWritable</code>. We
 * added compression algorithm selection.
 * </p>
 * <p>
 * river: add compression algorithm field to indicate the algorithm used when
 * read out.
 * </p>
 * <p>
 * <strong>压缩算法的选择办法:</strong>
 * <ul>
 * <li>对于新创建的对象，在不调用{@link #setCompressionAlgorithm(byte)} 或者
 * {@link #setUseDefaultCompression(boolean)}的情况下，采用LZO压缩算法</li>
 * <li>对于一个已有的对象，在不调用上述指定方法的情况下，维持原有的压缩算法，尤其需要注意的
 * 是，如果原来采用不压缩的方式，那么对象在再次输出的时候，依旧是不压缩的。</li>
 * </ul>
 * </p>
 * <p>
 * NOTE: this object is not thread-safe.
 * </p>
 * <p>
 * Known bugs:
 * <ul>
 * <li>重新设置压缩算法的时候，实际上首先解压到未压缩的状态。这里引入了对象反序列化的开销. 对于如下应用情况会导致引入不必要的额外操作：
 * 原来对象以原文形式存储，需要转成压缩形式，并不修改对象内容，</li>
 * </ul>
 * </p>
 * 
 * @author zf, river
 */
public abstract class CompressedWritable extends LazyWritable {

    private static final byte UNSPECIFIED = (byte) 0xFF;

    public static final byte DEFLATE_SPEED = (byte) 0xF1;

    public static final byte GZIP = (byte) 0xF2;

    public static final byte LZO = (byte) 0xF3;

    public static final byte RAW = (byte) 0xF4;

    public static final byte DEFAULT_ALGORITHM = LZO;

    private int uncompressedLen;

    private byte compressionAlgorithm = UNSPECIFIED;

    private DataOutputBuffer directBuffer = new DataOutputBuffer();

    /**
     * 创建一个新的压缩对象，默认情况下采用系统默认的压缩算法.
     */
    public CompressedWritable() {}

    /**
     * 判断两个没有Lazy Write的数据是否相等. FIXME：两个结构用到的压缩算法不一致，即使数据一致，也判定为不相等
     * 解决的方法应该是区分没有进行Lazy Writable的数据是否会影响进行LazyWrite的数据的格式
     */
    @Override
    protected boolean equalHeader(Object other) {
        assert (other != null && other instanceof CompressedWritable);
        CompressedWritable that = (CompressedWritable) other;
        return this.compressionAlgorithm == that.compressionAlgorithm
                && this.uncompressedLen == that.uncompressedLen;
    }

    /**
     * 复制没有参与Lazy Write的数据
     * 
     * @param other
     */
    @Override
    protected void copyHeader(Object other) {
        assert other != null;
        if (!(other instanceof CompressedWritable))
            throw new RuntimeException("non CompressedWritable object found");
        CompressedWritable that = (CompressedWritable) other;
        this.compressionAlgorithm = that.compressionAlgorithm;
        this.uncompressedLen = that.uncompressedLen;
    }

    /**
     * 设置输出时候使用的压缩算法.
     * 
     * @param newAlgo
     *            the new algorithm. Possible values: DEFLATE_SPEED fast zip
     *            GZIP normal zip LZO lzo RAW no compresssion
     */
    public void setCompressionAlgorithm(byte newAlgo) {
        if (compressionAlgorithm != newAlgo && hasBufferData()) {
            decode();
            changed();
        }
        compressionAlgorithm = newAlgo;
    }

    /**
     * 输出时是否使用系统默认的压缩算法，如果value是true，会使用系统默认的压缩算法
     * 压缩当前的数据，如果value是false，会避免压缩当前数据.
     * 
     * @param value
     */
    public void setUseDefaultCompression(boolean value) {
        setCompressionAlgorithm(value ? DEFAULT_ALGORITHM : RAW);
    }

    @Override
    protected final void readHeader(DataInput in) throws IOException {
        compressionAlgorithm = in.readByte();
        uncompressedLen = in.readInt();
        assert uncompressedLen >= 0;
    }

    @Override
    protected final void writeHeader(DataOutput out) throws IOException {
        out.writeByte(compressionAlgorithm);
        out.writeInt(uncompressedLen);
    }

    /**
     * Compress.
     */
    @Override
    public void encode() throws IOException {
        if (compressionAlgorithm == UNSPECIFIED) {
            compressionAlgorithm = DEFAULT_ALGORITHM;
        }

        directBuffer.cannyReset();
        writeBuffer(directBuffer);

        uncompressedLen = directBuffer.size();
        byte[] directBuf = directBuffer.getData();

        switch (compressionAlgorithm) {
            case DEFLATE_SPEED:
                ByteArrayOutputStream deflated = new ByteArrayOutputStream();
                Deflater deflater = new Deflater(Deflater.BEST_SPEED);
                CDataOutputStream dout = new CDataOutputStream(
                        new DeflaterOutputStream(deflated, deflater));
                try {
                    dout.write(directBuf, 0, uncompressedLen);
                    obuf.reset();
                    obuf.write(deflated.toByteArray());
                } finally {
                    dout.close();
                }
                break;

            case GZIP:
                ByteArrayOutputStream o = new ByteArrayOutputStream();
                OutputStream go = new GZIPOutputStream(o);
                go.write(directBuf, 0, uncompressedLen);
                go.close();
                obuf.reset();
                obuf.write(o.toByteArray());
                break;

            case LZO:
                // no "new" operation for lzo to improve the performance 
                int expectCompressedLength = LzoCompression.getCompressBufferSize(uncompressedLen);
                obuf.reset();
                obuf.ensureFreeSpace(expectCompressedLength);
                int compressedSize = LzoCompression.compress(directBuf, 0,
                        uncompressedLen, obuf.getData());
                if (compressedSize < 0) {
                    throw new RuntimeException("lzo compression failed(rvalue="
                            + compressedSize + ")");
                }
                obuf.advance(compressedSize);
                break;

            case RAW:
                // TODO why not use it directly??
                obuf.write(directBuf, 0, uncompressedLen);
                break;

            default:
                throw new RuntimeException("bad algorithm setting");
        }
        dataInBuffer = true;
    }

    /**
     * Uncompress.
     */
    @Override
    public void decode() {
        if (!decoded && hasBufferData()) {
            try {
                switch (compressionAlgorithm) {
                    case DEFLATE_SPEED:
                        // Closing a ByteArrayInputStream has no effect
                        ByteArrayInputStream deflated = new ByteArrayInputStream(
                                obuf.getData(), 0, obuf.size());
                        DataInput inflater = new CDataInputStream(
                                new InflaterInputStream(deflated));
                        readBuffer(inflater);
                        break;

                    case GZIP:
                        ByteArrayInputStream b = new ByteArrayInputStream(
                                obuf.getData(), 0, obuf.size());
                        DataInput in = new CDataInputStream(
                                new GZIPInputStream(b));
                        readBuffer(in);
                        break;

                    case LZO:
                        directBuffer.cannyReset();
                        directBuffer.ensureFreeSpace(uncompressedLen);
                        int tmp = LzoCompression.uncompress(obuf.getData(), 0,
                                obuf.size(), directBuffer.getData());
                        if (tmp != uncompressedLen) {
                            throw new RuntimeException(
                                    "LZO error, could cause jvm "
                                            + "failure(uncomp_return = " + tmp
                                            + ", expect " + uncompressedLen);
                        }
                        ibuf.reset(directBuffer.getData(), 0, tmp);
                        readBuffer(ibuf);
                        break;

                    case RAW:
                        ibuf.reset(obuf.getData(), 0, obuf.size());
                        readBuffer(ibuf);
                        break;
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        decoded = true;
    }

}
