package odis.serialize.toolkit;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.IWritable;
import odis.serialize.WritableRegistry;

/**
 * DynamicWritable with version info.
 * 
 * @author river
 * @deprecated Use {@link AbstractOpObject } instead.
 */
@Deprecated
public class VersionedDynamicWritable extends DynamicWritable {
    static {
        WritableRegistry.registerAlias(VersionedDynamicWritable.class,
                "VersionedDynamicWritable_v3");
    }

    private int version;

    public VersionedDynamicWritable() {}

    public VersionedDynamicWritable(int version, IWritable value) {
        super(value);
        this.version = version;
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        version = CDataInputStream.readVInt(in);
        super.readFields(in);
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        CDataOutputStream.writeVInt(version, out);
        super.writeFields(out);
    }

    public void setVersion(int value) {
        this.version = value;
    }

    public int getVersion() {
        return version;
    }

    @Override
    public String toString() {
        return "[" + version + "]" + super.toString();
    }

}
