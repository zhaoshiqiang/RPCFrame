package odis.serialize.toolkit;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import odis.serialize.IWritable;
import odis.serialize.WritableId;
import odis.serialize.WritableRegistry;
import odis.serialize.lib.BlobWritable;
import odis.serialize.lib.UTF8Writable;

/**
 * 可以同时容纳多个对象的DynamicWritable. 由于存储上标识对象个数用的是2 bytes，所以，这里最多可以容纳32767个对象.
 * 
 * @author river
 * @deprecated Use odis.serialize.toolkit.AbstractMultiDynamicWritable instead.
 */
@Deprecated
public class MultiDynamicWritable implements IWritable {
    static {
        WritableRegistry.registerAlias(MultiDynamicWritable.class,
                "MultiDynamicWritable_v3");
    }

    private static class TriEntry {
        private IWritable instance;

        private byte id = WritableId.NULL_ID;

        private Class<? extends IWritable> clazz = null;

        public TriEntry() {}

        public void set(IWritable obj) {
            instance = obj;
            clazz = obj.getClass();
            id = WritableId.getId(clazz);
        }

    }

    private List<TriEntry> entries = new ArrayList<TriEntry>();

    private int size = 0;

    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeShort(size);
        for (int i = 0; i < size; i++) {
            TriEntry entry = entries.get(i);

            out.writeByte(entry.id);
            if (entry.id == WritableId.NULL_ID) {
                UTF8Writable.writeString(out,
                        WritableRegistry.getWritableName(entry.clazz));
            }
            entry.instance.writeFields(out);
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public void readFields(DataInput in) throws IOException {
        size = in.readShort();
        for (int i = 0; i < size; i++) {
            byte clazzId = in.readByte();
            TriEntry entry;
            if (i < entries.size()) {
                entry = entries.get(i);
            } else {
                entry = new TriEntry();
                entries.add(entry);
            }

            if (clazzId == WritableId.NULL_ID) {
                entry.id = clazzId;
                String className = UTF8Writable.readString(in);
                Class<? extends IWritable> clazz = null;
                try {
                    clazz = WritableRegistry.getWritableClass(className);
                    if (clazz != entry.clazz) {
                        entry.clazz = clazz;
                        entry.instance = (IWritable) clazz.newInstance();
                    }
                } catch (Exception e) {
                    throw new RuntimeException("Cannot initialize class : "
                            + className, e);
                }
            } else {
                if (entry.id != clazzId) {
                    entry.id = clazzId;
                    entry.clazz = (Class) WritableId.getClass(clazzId);
                    try {
                        entry.instance = (IWritable) entry.clazz.newInstance();
                    } catch (Exception e) {
                        throw new RuntimeException(
                                "Cannot initialize instance of class : "
                                        + entry.clazz, e);
                    }
                }
            }

            entry.instance.readFields(in);
        }
    }

    @Override
    public IWritable copyFields(IWritable value) {
        BlobWritable blob = new BlobWritable();

        blob.setData(value);
        blob.getData(this);

        return this;
    }

    public void clear() {
        size = 0;
    }

    public void add(IWritable obj) {
        if (size >= entries.size()) {
            TriEntry entry = new TriEntry();
            entry.set(obj);
            entries.add(entry);
        } else {
            entries.get(size).set(obj);
        }
        size++;
    }

    public int size() {
        return size;
    }

    public IWritable get(int size) {
        return entries.get(size).instance;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append('[').append(size).append(']');
        for (int i = 0; i < size; i++) {
            builder.append('<').append(i).append('>').append(
                    entries.get(i).instance);
        }
        return builder.toString();
    }

}
