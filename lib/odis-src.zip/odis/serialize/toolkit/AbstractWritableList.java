/**
 * @(#)AbstractWritableList.java, 2007-5-24. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.serialize.toolkit;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.IClearable;
import odis.serialize.IWritable;

/**
 * 一个简单的顺序表的实现，支持列表的顺序填充和顺序访问，但不支持remove，仅仅支持全部清空.
 * 
 * @author river
 */
public abstract class AbstractWritableList<E extends IWritable> implements
        Iterable<E>, IWritable, IClearable {
    protected final ArrayList<E> list = new ArrayList<E>();

    protected int size = 0;

    private int maxBufferSize = Integer.MAX_VALUE;

    /**
     * 返回列表中元素的类型，子类必须重载这个方法.
     * 
     * @return
     */
    public abstract Class<E> getElementClass();

    /**
     * Set the max count of objects buffered when {@link #clear()} called.
     * 
     * @param value
     */
    public void setMaxBufferSize(int value) {
        this.maxBufferSize = value;
    }

    /**
     * 创建一个新的对象，返回的对象是 {@link #getElementClass()} 的实例.
     * 
     * @return
     */
    protected E newElement() {
        try {
            return getElementClass().newInstance();
        } catch (Exception e) {
            throw new RuntimeException("class " + getElementClass()
                    + " cannot be instantiated");
        }
    }

    /**
     * 添加一个对象的拷贝，如果列表中存在没有使用的对象(在size范围以外的对象)， 就会 直接使用这个对象进行拷贝，否则会创建新的对象.
     * 这个方法一般会和 {@link #clear()} 一起使用.
     * 
     * @param element
     */
    public void add(E element) {
        if (size < list.size()) {
            list.get(size).copyFields(element);
        } else {
            E newElement = newElement();
            newElement.copyFields(element);
            list.add(newElement);
        }
        size++;
    }

    /**
     * 添加一个引用到列表中. 这个方法一般和 {@link #reset()} 一起使用.
     * 
     * @param element
     */
    public void addReference(E element) {
        if (size < list.size()) {
            list.set(size, element);
        } else {
            list.add(element);
        }
        size++;
    }

    /**
     * 返回列表的大小.
     * 
     * @return
     */
    public int size() {
        return size;
    }

    /**
     * 返回第index个对象.
     * 
     * @param index
     * @return
     */
    public E get(int index) {
        if (index < 0 || index >= size) {
            throw new ArrayIndexOutOfBoundsException("index " + index
                    + " should be smaller than " + size);
        }
        return list.get(index);
    }

    /**
     * 返回一个包含列表中所有元素的数组，数组的类型由运行时传入的数组<code>a</code> 的类型来决定。如果<code>a</code>
     * 的长度大于列表的长度，直接将元素放到<code>a</code> 中并返回，否则，创建一个新的长度等于列表长度的数组来存储元素并返回。
     * 
     * @param a
     * @return
     */
    @SuppressWarnings("unchecked")
    public E[] toArray(E[] a) {
        if (a.length < size)
            a = (E[]) java.lang.reflect.Array.newInstance(
                    a.getClass().getComponentType(), size);

        for (int i = 0; i < size; i++) {
            a[i] = list.get(i);
        }

        for (int i = size; i < a.length; i++) {
            a[i] = null;
        }

        return a;
    }

    /**
     * 列表计数清零，但是所有的对象保留，成为没有被使用的对象，便于在 {@link #add(IWritable)} 中使用.
     */
    public void clear() {
        size = 0;
        if (list.size() > maxBufferSize) {
            list.clear();
        }
    }

    /**
     * 清空列表，包括清空所有的引用. 如果希望保留引用便于在后面的 {@link #add(IWritable)} 过程中重用，请使用
     * {@link #clear()} 方法.
     */
    public void reset() {
        list.clear();
        size = 0;
    }

    /**
     * @see IWritable#readFields(DataInput)
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        size = CDataInputStream.readVInt(in);
        for (int i = 0; i < size; i++) {
            if (i < list.size()) {
                list.get(i).readFields(in);
            } else {
                E newElement = newElement();
                newElement.readFields(in);
                list.add(newElement);
            }
        }
    }

    /**
     * @see IWritable#writeFields(DataOutput)
     */
    @Override
    public void writeFields(DataOutput out) throws IOException {
        CDataOutputStream.writeVInt(size, out);
        for (int i = 0; i < size; i++) {
            list.get(i).writeFields(out);
        }
    }

    /**
     * @see IWritable#copyFields(IWritable)
     */
    @SuppressWarnings("unchecked")
    @Override
    public IWritable copyFields(IWritable value) {
        if (value == null || !(value instanceof AbstractWritableList)) {
            throw new RuntimeException("bad value : " + value);
        }
        AbstractWritableList<E> that = (AbstractWritableList<E>) value;
        if (this.getElementClass() != that.getElementClass()) {
            throw new RuntimeException("element class mismatch");
        }
        if (this == that)
            return this;

        this.size = that.size;
        for (int i = 0; i < this.size; i++) {
            if (i < list.size()) {
                list.get(i).copyFields(that.list.get(i));
            } else {
                E newElement = newElement();
                newElement.copyFields(that.list.get(i));
                list.add(newElement);
            }
        }

        return this;
    }

    @Override
    public int hashCode() {
        int result = 1;
        for (int i = 0; i < size; i++) {
            E element = list.get(i);
            int elementHash = element == null ? 0 : element.hashCode();
            result = 31 * result + elementHash;
        }
        return result;
    }

    /**
     * 比较两个列表是否相等，这里逐个比较列表中的元素.
     */
    @SuppressWarnings("unchecked")
    @Override
    public boolean equals(Object other) {
        if (other == null || !(other instanceof AbstractWritableList)) {
            return false;
        }
        AbstractWritableList<E> that = (AbstractWritableList<E>) other;
        if (that.getElementClass() != this.getElementClass()) {
            return false;
        }
        if (that.size != this.size) {
            return false;
        }

        for (int i = 0; i < size; i++) {
            E thisElement = this.list.get(i);
            E thatElement = that.list.get(i);
            if (thisElement == null) {
                if (thatElement != null) {
                    return false;
                }
            } else {
                if (!thisElement.equals(thatElement)) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * 返回string描述.
     */
    @Override
    public String toString() {
        StringBuilder buffer = new StringBuilder();
        buffer.append("[").append(size).append("]");
        for (int i = 0; i < size; i++) {
            buffer.append("(").append(i).append(")").append(list.get(i));
        }
        return buffer.toString();
    }

    /**
     * 返回一个顺序访问的iterator，其remove()方法没有实现.
     */
    @Override
    public Iterator<E> iterator() {
        return new IteratorImpl();
    }

    private class IteratorImpl implements Iterator<E> {

        private int cursor = 0;

        @Override
        public boolean hasNext() {
            return cursor != size;
        }

        @Override
        public E next() {
            E nextElement = get(cursor);
            cursor++;
            return nextElement;
        }

        @Override
        public void remove() {
            throw new AbstractMethodError("not implemented");
        }

    }

}
