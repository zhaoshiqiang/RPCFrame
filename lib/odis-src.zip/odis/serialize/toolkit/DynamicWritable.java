package odis.serialize.toolkit;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.IWritable;
import odis.serialize.WritableId;
import odis.serialize.WritableRegistry;
import odis.serialize.lib.NullWritable;
import odis.serialize.lib.UTF8Writable;

/**
 * 依赖于WritableId，实现类似ObjectWritable功能. 代码中针对一段时间内连续读取同一实际类型数据进行了优化，带来的 NOTE：
 * <strong>通过get()接口返回的对象可能在下次read()过程中被复用.</strong>
 * 
 * @author river
 * @deprecated Use {@link odis.serialize.toolkit.AbstractDynamicWritable} instead.
 */
@Deprecated
public class DynamicWritable implements IWritable {
    static {
        WritableRegistry.registerAlias(DynamicWritable.class, "DynamicWritable_v3");
    }

    private IWritable instance = NullWritable.get();

    private Class<?> declaredClass = NullWritable.class;

    private byte classId;

    /**
     * Write out this DynamicWritable, if the classId is not set, write out the
     * declared class name instead.
     */
    @SuppressWarnings("unchecked")
    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeByte(classId);
        if (classId == WritableId.NULL_ID) {
            UTF8Writable.writeString(out, 
                    WritableRegistry.getWritableName((Class)declaredClass));
        } // if
        instance.writeFields(out);
    }

    /**
     * Read in this DynamicWritable. If the classId is not set or unknown, read
     * in the declared class name instead. Check
     * 
     * @link WritableId given the classId. If the classId is the same as last
     *       classId, reuse current instance object.
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        byte oldClassId = classId;
        classId = in.readByte();
        try {
            if (classId == WritableId.NULL_ID) {
                // class without id, read class-name first
                String className = UTF8Writable.readString(in);
                declaredClass = WritableRegistry.getWritableClass(className);
                instance = (IWritable) declaredClass.newInstance();
            } else {
                // class with classId, create new object if differnt from
                // current one.
                if (classId != oldClassId) {
                    declaredClass = WritableId.getClass(classId);
                    if (declaredClass == null)
                        throw new RuntimeException(
                                "Unknown classId("
                                        + classId
                                        + "). writable_ids.properties maybe missing or incomplete.");
                    instance = (IWritable) declaredClass.newInstance();
                }
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        instance.readFields(in);
    }

    public DynamicWritable set(IWritable w) {
        instance = w;
        Class<?> oldDeclaredClass = declaredClass;
        declaredClass = w.getClass();
        if (classId == WritableId.NULL_ID || !declaredClass.equals(oldDeclaredClass)) {
            classId = WritableId.getId(declaredClass);
        }
        return this;
    }

    public IWritable get() {
        return instance;
    }

    public Class<?> getDeclaredClass() {
        return declaredClass;
    }

    public DynamicWritable() {
    }

    public DynamicWritable(IWritable w) {
        set(w);
    }

    @Override
    public IWritable copyFields(IWritable value) {
        DynamicWritable that = (DynamicWritable) value;
        if (declaredClass != null && declaredClass.equals(that.declaredClass))
            this.instance.copyFields(that.instance);
        else {
            if (that.declaredClass == null) {
                this.declaredClass = null;
            } else {
                try {
                    // make a copy of that.instance and set into this
                    this.set(((IWritable) that.declaredClass.newInstance())
                            .copyFields(that.instance));
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            } // else
        } // else
        return this;
    }
    
    @Override
    public String toString() {
        if (instance == null) {
            return "<null>";
        } else {
            return instance.toString();
        }
    }
    
}
