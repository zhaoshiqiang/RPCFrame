package odis.serialize.toolkit;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.io.CDataInputStream;
import odis.io.DataInputBuffer;
import odis.io.DataOutputBuffer;
import odis.io.Limit;
import odis.serialize.ISkippable;
import odis.serialize.IWritable;

/**
 * Will read IWritable object to a buffer without decode it into variables
 * unless the variables will be really used in process.  That is, if the process
 * of this writable is to read it in and directly write out (partial or whole)
 * of writable, extends your IWritable from LazyWritable to increase the process
 * speed.
 * <p>
 * IWritable extends from this should read/write from the buffer.
 * <p>
 * This classes do not define <code>hashCode</code>, so do not use it as a hash key.
 * <p>
 * Status change:
 *   Status:
 *   
 *   hasBufferData decoded  status
 *       false      false     FF
 *       false       true     FT
 *        true      false     TF
 *        true       true     TT
 *        
 *   Actions:
 *       method      abbr
 *     changed()     chg
 *     encode()      enc
 *     decode()      dec
 *     readFields()  read
 *
 *   <init>  
 *    .--.             .--.
 *    |FT| -、         |FF|
 *    `--’   \         `--’          
 *     ^|     r         |^         
 *     ||      e        ||
 * chg || enc   a   enc || chg
 *     ||        d      ||
 *     |V         \     V|
 *    .--.         `--> .--.
 *    |TT| <---dec----- |TF|
 *    `--’ `---read---7 `--’
 *    
 *    
 *                
 * @author zf & river
 */
public abstract class LazyWritable implements IWritable, ISkippable {
    protected DataOutputBuffer obuf = new DataOutputBuffer();

    protected DataInputBuffer ibuf = new DataInputBuffer();

    protected boolean dataInBuffer = false;

    protected boolean decoded;

    public LazyWritable() {
        dataInBuffer = false;
        decoded = true;
    }

    protected boolean hasBufferData() {
        return dataInBuffer;
    }

    /**
     * 按域比较两个对象是否相等. 注意这里比较的对象是所有field this和other中的Lazy Write已经恢复，可以直接使用
     * 
     * @return whether the two objects are equal
     */
    protected boolean equalsByField(Object other) {
        throw new RuntimeException("equalsByField(Object other) is not "
                + "implemented in " + this.getClass());
    }

    /**
     * 比较没有Lazy Write的数据
     */
    protected boolean equalHeader(Object other) {
        return true;
    }

    /**
     * 判断两个对象是否相等.
     */
    @Override
    public final boolean equals(Object other) {
        if (other == null || !other.getClass().equals(this.getClass())) {
            return false;
        }

        LazyWritable that = (LazyWritable) other;
        if (this.hasBufferData() && that.hasBufferData()) {
            if (!equalHeader(that)) {
                return false;
            }
            if (obuf.size() != that.obuf.size()) {
                return false;
            }
            int dataSize = obuf.size();
            byte[] buf1 = obuf.getData();
            byte[] buf2 = that.obuf.getData();
            for (int i = 0; i < dataSize; i++) {
                if (buf1[i] != buf2[i]) {
                    return false;
                }
            }
            return true;
        } else {
            this.decode();
            that.decode();
            return equalsByField(that);
        }
    }

    /**
     * 按域拷贝对象. 注意这里复制的数据为所有field
     * 
     * @param other
     */
    protected abstract void copyByField(Object other);

    /**
     * 复制没有进行Lazy Write的数据
     * 
     * @param other
     */
    protected void copyHeader(Object other) {}

    /**
     * 从另外一个对象拷贝数据到当前对象.
     * 
     * @param other
     */
    public final void copy(Object other) {
        if (other == null) {
            throw new NullPointerException("cannot copy from null object");
        }

        if (!(other instanceof LazyWritable)) {
            throw new RuntimeException("non LazyWritable object found");
        }

        LazyWritable that = (LazyWritable) other;
        if (that.hasBufferData()) {
            copyHeader(that);
            this.decoded = false;
            this.obuf.reset();
            this.obuf.write(that.obuf.getData(), 0, that.obuf.size());
            this.dataInBuffer = true;
        } else {
            copyByField(other);
            changed();
        }
    }

    /**
     * This method should not be override.
     */
    @Override
    public IWritable copyFields(IWritable value) {
        copy(value);
        return this;
    }

    protected void readHeader(DataInput in) throws IOException {
        // used to read fast data
    }

    /** Subclasses implement this instead of {@link #readFields(DataInput)}. */
    protected abstract void readBuffer(DataInput in) throws IOException;

    /**
     * @see IWritable#readFields(DataInput)
     */
    @Override
    public final void readFields(DataInput in) throws IOException {
        readHeader(in);
        int dataSize = in.readInt();
        Limit.checkBufferSize(dataSize);
        obuf.cannyReset();
        obuf.write(in, dataSize);
        dataInBuffer = true;
        decoded = false;
    }

    /**
     * @see ISkippable#skipFields(DataInput)
     */
    @Override
    public final void skipFields(DataInput in) throws IOException {
        readHeader(in);
        int dataSize = in.readInt();
        CDataInputStream.skipBytes(in, dataSize);
    }

    protected void writeHeader(DataOutput out) throws IOException {
        // used to write fast data
    }

    /**
     * Subclasses implement this instead of {@link #writeFields(DataOutput)}.
     */
    protected abstract void writeBuffer(DataOutput out) throws IOException;

    /**
     * @see IWritable#writeFields(DataOutput)
     */
    @Override
    public final void writeFields(DataOutput out) throws IOException {
        if (!hasBufferData()) {
            encode();
        }

        writeHeader(out);
        out.writeInt(obuf.size());
        out.write(obuf.getData(), 0, obuf.size());
    }

    /**
     * Encodes the data in obuf into data-buffer.
     * 
     * @throws IOException
     *             if an I/O error occurs
     */
    public void encode() throws IOException {
        obuf.reset();
        writeBuffer(obuf);
        dataInBuffer = true;
    }

    /**
     * Decodes the (encoded) data in data-buffer to fields. Should be called
     * before accessing any fields.
     */
    public void decode() {
        if (!decoded && hasBufferData()) {
            try {
                ibuf.reset(obuf.getData(), 0, obuf.size());
                readBuffer(ibuf);
                decoded = true;
            } catch (IOException e) {
                throw new RuntimeException("reading from buffer failed", e);
            }
        }
    }

    /**
     * Informs that the data-buffer is not valid since some value of the fields
     * or encoding method changed. Should be called whenever the value of any
     * field changed.
     */
    protected void changed() {
        dataInBuffer = false;
    }

    /**
     * Return buffer size.
     * 
     * @return
     */
    public int bufferSize() {
        return dataInBuffer ? obuf.size() : -1;
    }
}
