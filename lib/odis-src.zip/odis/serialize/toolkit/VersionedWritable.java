/**
 * Copyright 2005 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package odis.serialize.toolkit;

import java.io.DataOutput;
import java.io.DataInput;
import java.io.IOException;

import odis.serialize.IWritable;

/**
 * A base class for Writables that provides version checking.
 * <p>
 * This is useful when a class may evolve, so that instances written by the old
 * version of the class may still be processed by the new version.
 * <p>
 * <p>
 * Classes extend this VersionedWritable should implements
 * 
 * @link #readContent(DataInput, byte) and @link #writeContent(DataOutput, byte)
 *       in order to read or write data.
 *       </p>
 * @author zl (modified from previous version by Doug Cutting)
 */
public abstract class VersionedWritable implements IWritable {

    /**
     * Return the version number of the current implementation.
     */
    public abstract byte getVersion();

    /**
     * Read content from <code>in</code> with given version.
     * 
     * @param in
     * @param version
     */
    public abstract void readContent(DataInput in, byte version);

    /**
     * Write content to <code>out</code> with given version.
     * 
     * @param out
     * @param version
     */
    public abstract void writeContent(DataOutput out, byte version);

    /**
     * @see IWritable#writeFields(DataOutput)
     */
    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeByte(getVersion()); // store version
        writeContent(out, getVersion());
    }

    /**
     * @see IWritable#readFields(DataInput)
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        byte version = in.readByte(); // read version
        if (version != getVersion()) {
            throw new VersionMismatchException(getVersion(), version);
        }
        readContent(in, getVersion());
    }

    /**
     * Thrown by {@link VersionedWritable#readFields(DataInput)} when the
     * version of an object being read does not match the current implementation
     * version as returned by {@link VersionedWritable#getVersion()}.
     */
    @SuppressWarnings("serial")
    public static class VersionMismatchException extends IOException {

        private byte expectedVersion;

        private byte foundVersion;

        public VersionMismatchException(byte expectedVersionIn,
                byte foundVersionIn) {
            expectedVersion = expectedVersionIn;
            foundVersion = foundVersionIn;
        }

        /**
         * Returns a string representation of this object.
         */
        @Override
        public String toString() {
            return "A record version mismatch occured. Expecting v"
                    + expectedVersion + ", found v" + foundVersion;
        }
    }

}
