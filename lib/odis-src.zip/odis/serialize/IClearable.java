/**
 * @(#)IClearable.java, 2008-4-14. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.serialize;

import odis.serialize.lib.BooleanWritable;
import odis.serialize.lib.IntWritable;
import odis.serialize.lib.LongWritable;

/**
 * Interface indicates that this class has implemented clear() method and is
 * clearable.<br>
 * Usually, for an array based class, clear means to remove all entries(e.g.
 * set size to 0), and for other class, clear means set its value to default or
 * reset all fields(e.g. {@link BooleanWritable#clear()} will set its value to
 * <code>false</code>, {@link IntWritable#clear()} or
 * {@link LongWritable#clear()} will set its value to 0).
 * 
 * @author river
 */
public interface IClearable {

    /**
     * Reset all the fields, or remove all entries in container.
     */
    public void clear();

}
