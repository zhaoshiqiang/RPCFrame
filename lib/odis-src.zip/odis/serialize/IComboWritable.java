package odis.serialize;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

/**
 * @author david
 * @deprecated on 7/23/2007 since I think no one is using it
 */
@Deprecated
public interface IComboWritable {
    public String[] getFieldNames();

    public Class<?> getBaseClass();

    void writeFields(DataOutput[] out) throws IOException;

    void readFields(DataInput[] in) throws IOException;
}
