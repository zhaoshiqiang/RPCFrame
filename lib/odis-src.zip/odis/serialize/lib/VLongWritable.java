/**
 * @(#)VLongWritable.java, 2011-3-9. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.serialize.lib;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.WritableRegistry;
import odis.serialize.comparator.VLongBinaryComparator;

/**
 * Variable length positive long representation that is shorter for storing
 * small longs.
 * 
 * @see CDataOutputStream#writeVLong(int)
 * @author zhangduo
 */
public class VLongWritable extends LongWritable {
    static {
        WritableRegistry.register(VLongWritable.class, "vlong",
                WritableRegistry.NON_FIXED_SIZE, VLongBinaryComparator.class);
    }

    /**
     * Constructor with initial value 0.
     */
    public VLongWritable() {}

    /**
     * Constructor with an initial value.
     * 
     * @param value
     */
    public VLongWritable(long value) {
        super(value);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeFields(DataOutput out) throws IOException {
        CDataOutputStream.writeVLong(value, out);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        value = CDataInputStream.readVLong(in);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void skipFields(DataInput in) throws IOException {
        CDataInputStream.skipVLong(in);
    }

}
