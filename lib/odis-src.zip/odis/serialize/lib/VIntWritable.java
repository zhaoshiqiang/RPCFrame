package odis.serialize.lib;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.WritableRegistry;
import odis.serialize.comparator.VIntBinaryComparator;

/**
 * Variable length positive integer representation that is shorter for storing
 * small integers.
 * 
 * @see CDataOutputStream#writeVInt(int)
 * @author zhangduo
 */
public class VIntWritable extends IntWritable {
    static {
        WritableRegistry.register(VIntWritable.class, "vint",
                WritableRegistry.NON_FIXED_SIZE, VIntBinaryComparator.class);
    }

    /**
     * Constructor with initial value 0.
     */
    public VIntWritable() {}

    /**
     * Constructor with an initial value.
     * 
     * @param i
     */
    public VIntWritable(int i) {
        super(i);
    }

    /**
     * Sets the value.
     * 
     * @param i
     *            the new value
     * @return this instance
     */
    public VIntWritable set(int i) {
        this.value = i;
        return this;
    }

    /**
     * {@inheritDoc}
     */
    public void writeFields(DataOutput out) throws IOException {
        CDataOutputStream.writeVInt(value, out);
    }

    /**
     *{@inheritDoc}
     */
    public void readFields(DataInput in) throws IOException {
        value = CDataInputStream.readVInt(in);
    }

    /**
     * {@inheritDoc}
     */
    public void skipFields(DataInput in) throws IOException {
        CDataInputStream.skipVInt(in);
    }
}
