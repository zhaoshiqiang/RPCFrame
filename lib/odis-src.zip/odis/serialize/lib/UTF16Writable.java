package odis.serialize.lib;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.io.CDataInputStream;
import odis.io.Limit;
import odis.serialize.IClearable;
import odis.serialize.IParsable;
import odis.serialize.ISkippable;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.WritableRegistry;
import odis.serialize.comparator.BinaryComparator;
import odis.serialize.comparator.IntBytesBinaryComparator;
import toolbox.misc.EmptyInstance;
import toolbox.misc.UnitUtils;

/**
 * utf16 implementation.
 * 
 * @author river
 */
public class UTF16Writable implements IWritableComparable, IParsable,
        BytesAccessable, IClearable, ISkippable {

    static {
        WritableRegistry.register(UTF16Writable.class, "UTF16",
                IntBytesBinaryComparator.class);
    }

    private static final int MAX_BUFFER_SIZE = (int) (16 * UnitUtils.K);

    public static final int CHAR_WIDTH = 2;

    private byte[] buf = EmptyInstance.BYTES;

    private int length;

    private String cachedString = EmptyInstance.STRING;

    /**
     * Default constructor.
     */
    public UTF16Writable() {}

    /**
     * Constructor with an initial value.
     * 
     * @param s
     */
    public UTF16Writable(String s) {
        set(s);
    }

    /**
     * Constructor using {@link #copyFields(IWritable)}
     * 
     * @param other
     */
    public UTF16Writable(UTF16Writable other) {
        copyFields(other);
    }

    /**
     * This method is equal to call {@link #set(String)} with "".
     */
    @Override
    public void clear() {
        length = 0;
        cachedString = EmptyInstance.STRING;
    }

    /**
     * @param other
     * @deprecated use UTF16Writable.copyFields instead
     */
    @Deprecated
    public void set(UTF16Writable other) {
        if (buf.length < other.length
                || (buf.length > MAX_BUFFER_SIZE && other.length < MAX_BUFFER_SIZE)) {
            buf = new byte[other.length];
        }
        length = other.length;
        System.arraycopy(other.buf, 0, buf, 0, length);
        this.cachedString = other.cachedString;
    }

    /**
     * Set value using raw bytes.
     * 
     * @param data
     * @param offset
     * @param len
     */
    public void set(int length, byte[] bytes) {
        this.length = length;
        if (buf.length < length
                || (buf.length > MAX_BUFFER_SIZE && length < MAX_BUFFER_SIZE)) {
            buf = new byte[length];
        }
        System.arraycopy(bytes, 0, buf, 0, length);
        this.cachedString = null;
    }

    /**
     * Convert <code>s</code> to a UTF16 sequence and store it in
     * <code>buf</code>
     * 
     * @param s
     * @param buf
     * @param offset
     */
    public static void encode(String s, byte[] buf, int offset) {
        int len = s.length();
        if (buf.length - offset < len * 2)
            throw new IndexOutOfBoundsException("buf (" + offset + ":"
                    + buf.length + ") to small to store string \"" + s + "\"");

        if (len > 256) {
            char[] charArr = s.toCharArray();
            for (int i = 0; i < len; i++) {
                char c = charArr[i];
                buf[i * 2 + offset] = (byte) (c & 0xff);
                buf[i * 2 + 1 + offset] = (byte) (c >> 8);
            }
        } else {
            for (int i = 0; i < len; i++) {
                char c = s.charAt(i);
                buf[i * 2 + offset] = (byte) (c & 0xff);
                buf[i * 2 + 1 + offset] = (byte) (c >> 8);
            }
        }
    }

    /**
     * decode a UTF16 sequence to string.
     * 
     * @param buf
     * @param offset
     * @param len
     * @return
     */
    public static String decode(byte[] buf, int offset, int len) {
        if (len == 0)
            return "";

        if ((len % 2) != 0) {
            throw new IndexOutOfBoundsException("utf16 buf length error : "
                    + len);
        }
        if (buf.length - offset < len) {
            throw new IndexOutOfBoundsException("buf size error : "
                    + buf.length + "-" + offset + "<" + len);
        }

        int count = len / 2;
        StringBuilder builder = new StringBuilder(count);
        int pos = offset;
        for (int i = 0; i < count; i++) {
            char c = (char) ((buf[pos + 1] & 0xff) << 8 | (buf[pos] & 0xff));
            builder.append(c);
            pos += 2;
        }
        return builder.toString();
    }

    /**
     * Set value.
     * 
     * @param string
     */
    public void set(String s) {
        if (s == null || s.length() == 0) {
            length = 0;
            this.cachedString = EmptyInstance.STRING;
        } else {
            int len = s.length();
            if (buf.length < len * 2
                    || (buf.length > MAX_BUFFER_SIZE && (len * 2) < MAX_BUFFER_SIZE)) {
                buf = new byte[len * 2];
            }
            encode(s, buf, 0);
            length = len * 2;
            this.cachedString = s;
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeInt(length);
        if (length > 0) {
            out.write(buf, 0, length);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        length = in.readInt();
        Limit.checkBufferSize(length);

        if (length > 0) {
            if (length > buf.length
                    || (buf.length > MAX_BUFFER_SIZE && length < MAX_BUFFER_SIZE)) {
                buf = new byte[length];
            }
            in.readFully(buf, 0, length);
        }
        this.cachedString = null;
    }

    /**
     * {@inheritDoc}
     */
    public IWritable copyFields(IWritable value) {
        UTF16Writable other = (UTF16Writable) value;
        if (buf.length < other.length
                || (buf.length > MAX_BUFFER_SIZE && other.length < MAX_BUFFER_SIZE)) {
            buf = new byte[other.length];
        } // if
        length = other.length;
        System.arraycopy(other.buf, 0, buf, 0, length);
        this.cachedString = other.cachedString;
        return this;
    }

    /**
     * read length bytes from <code>in</code> as raw bytes.
     * 
     * @param in
     * @param length
     * @throws IOException
     */
    public void readBytes(DataInput in, int length) throws IOException {
        this.length = length;
        Limit.checkBufferSize(length);

        if (length > 0) {
            if (length > buf.length
                    || (buf.length > MAX_BUFFER_SIZE && length < MAX_BUFFER_SIZE))
                buf = new byte[length];
            in.readFully(buf, 0, length);
        }
        this.cachedString = null;
    }

    /**
     * compare raw bytes.
     * 
     * @see BinaryComparator#compareBytes(byte[], int, int, byte[], int, int)
     */
    public int compareTo(IWritable o) {
        UTF16Writable other = (UTF16Writable) o;
        return BinaryComparator.compareBytes(buf, 0, length, other.buf, 0,
                other.length);
    }

    /**
     * equal to {@link #set(String)}
     */
    public void parse(String s) {
        set(s);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int hashCode() {
        int hash = 1;
        for (int i = 0; i < length; i++) {
            hash = (31 * hash) + (int) buf[i];
        }
        return hash;
    }

    /**
     * return true if and only if <code>o</code> is an instance of
     * <code>UTF16Writable</code>, and raw bytes are equal.
     */
    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        UTF16Writable that = (UTF16Writable) o;
        if (this.length != that.length) {
            return false;
        }
        for (int i = 0; i < length; i++) {
            if (buf[i] != that.buf[i]) {
                return false;
            }
        }
        return true;
    }

    /**
     * @deprecated Use {@link #getByteLength()} instead.
     * @return
     */
    public int getLength() {
        return length;
    }

    /**
     * Return raw bytes of string. Implement {@link BytesAccessable#getBytes()}.
     */
    @Override
    public byte[] getBytes() {
        return buf;
    }

    /**
     * Return length of bytes. Implement {@link BytesAccessable#getByteLength()}
     * .
     */
    @Override
    public int getByteLength() {
        return length;
    }

    /**
     * Read a UTF16 encoded string.
     * 
     * @param in
     * @return
     * @throws IOException
     */
    public static String readString(DataInput in) throws IOException {
        int len = in.readInt();
        if (len == 0) {
            return "";
        }
        Limit.checkBufferSize(len);

        byte[] buf = new byte[len];
        in.readFully(buf);
        return decode(buf, 0, len);
    }

    /**
     * Write a string to out using UTF16 encoding.
     * 
     * @param out
     * @param s
     * @return the number of bytes written by DataOutput.
     * @throws IOException
     */
    public static int writeString(DataOutput out, String s) throws IOException {
        byte buf[] = new byte[s.length() * 2];
        encode(s, buf, 0);
        out.writeInt(buf.length);
        out.write(buf);
        return buf.length + 4;
    }

    /**
     * Get the number of bytes when we write <code>s</code> out using
     * {@link UTF16Writable#writeString(DataOutput, String)}.
     * 
     * @param s
     * @return
     */
    public static int getWriteLength(String s) {
        return s.length() * 2 + 4;
    }

    /**
     * Get string value.
     * 
     * @return
     */
    public String get() {
        if (cachedString == null) {
            cachedString = decode(buf, 0, length);
        }
        return cachedString;
    }

    /**
     * equal to {@link #get()}
     */
    @Override
    public String toString() {
        return get();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void skipFields(DataInput in) throws IOException {
        int sz = in.readInt();
        CDataInputStream.skipBytes(in, sz);
    }

    /**
     * Skip a UTF16 encoded string.
     * 
     * @param out
     * @return the number of bytes skipped.
     * @throws IOException
     */
    public static int skipString(DataInput in) throws IOException {
        int sz = in.readInt();
        CDataInputStream.skipBytes(in, sz);
        return sz + 4;
    }
}
