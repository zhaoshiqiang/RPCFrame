package odis.serialize.lib;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.IClearable;
import odis.serialize.ISkippable;
import odis.serialize.IWritable;
import odis.serialize.WritableRegistry;
import toolbox.misc.EmptyInstance;

/**
 * Writable to store int array.
 * 
 * @author river, David
 */
public class IntsWritable implements IWritable, ISkippable, IClearable {
    static {
        WritableRegistry.registerAlias(IntsWritable.class, "Ints");
    }

    private int[] arr = EmptyInstance.INTS;

    private int size;

    /**
     * Constructor.
     */
    public IntsWritable() {
        arr = EmptyInstance.INTS;
        size = 0;
    }

    /**
     * Constructor.
     * 
     * @param initialCapacity
     *            the intial number of elements in the buffer. size is set to 0.
     */
    public IntsWritable(int initialCapacity) {
        arr = new int[initialCapacity];
        size = 0;
    }

    /**
     * Set buffer to empty, set size to 0.
     */
    @Override
    public void clear() {
        arr = EmptyInstance.INTS;
        size = 0;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int hashCode() {
        int hash = 0;
        for (int i = 0; i < size; i++) {
            hash = hash * 31 + arr[i];
        }
        return hash;
    }

    /**
     * return <code>true</code> if and only if size are same and every int are
     * same.
     */
    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        IntsWritable that = (IntsWritable) o;
        if (this.size != that.size) {
            return false;
        }

        for (int i = 0; i < this.size; i++) {
            if (this.arr[i] != that.arr[i]) {
                return false;
            }
        }
        return true;
    }

    /**
     * @deprecated the name of Data confuses a lot of person. Use
     *             {@link #getBuffer()} instead. Return the raw data, you must
     *             use {@link #size()} to acquire the actual number of elements.
     * @return
     */
    @Deprecated
    public int[] getData() {
        return arr;
    }

    /**
     * Returns the internal int array buffer. Call #{@link #size()} to get the
     * the number of available elements in the buffer.
     * 
     * @return the internal int array buffer
     */
    public int[] getBuffer() {
        return arr;
    }

    /**
     * Access the data by index.
     * 
     * @param index
     * @return
     */
    public int get(int index) {
        if (index >= size) {
            throw new ArrayIndexOutOfBoundsException(
                    "Array index out of range: " + index + ", length: " + size);
        }
        return arr[index];
    }

    /**
     * Return data as int array.
     * 
     * @return
     */
    public int[] toIntArray() {
        return Arrays.copyOf(arr, size);
    }

    /**
     * Return size of data.
     * 
     * @return
     */
    public int size() {
        return size;
    }

    /**
     * Append one int data to the tail with step 1.
     * 
     * @param v
     */
    public void addInt(int v) {
        addInt(v, 1);
    }

    /**
     * Append one int data to the tail.
     * 
     * @param v
     * @param stepWhenExceed
     *            enlarge step when size exceed capacity
     */
    public void addInt(int v, int stepWhenExceed) {
        if (size == arr.length) {
            arr = Arrays.copyOf(arr, size + stepWhenExceed);
        }
        arr[size++] = v;
    }

    /**
     * Append several int datas to the tail.
     * 
     * @param v
     */
    public void addInt(int[] v) {
        if (size + v.length > arr.length) {
            int[] newdata = new int[size + v.length];
            System.arraycopy(arr, 0, newdata, 0, size);
            arr = newdata;
        }
        System.arraycopy(v, 0, arr, size, v.length);
        size += v.length;
    }

    /**
     * Remove the first n element in array.
     */
    public void shift(int n) {
        if (size >= n) {
            System.arraycopy(arr, n, arr, 0, size - n);
            size -= n;
        }
    }

    /**
     * Remove the first element.
     */
    public void shift() {
        shift(1);
    }

    /**
     * Set the data.
     * 
     * @param v
     */
    public void set(int[] v) {
        size = 0;
        addInt(v);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        size = CDataInputStream.readVInt(in);
        if (size > arr.length) {
            arr = new int[size];
        }

        for (int i = 0; i < size; i++) {
            arr[i] = in.readInt();
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void skipFields(DataInput in) throws IOException {
        int size = CDataInputStream.readVInt(in);
        CDataInputStream.skipBytes(in, size * (Integer.SIZE / Byte.SIZE));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeFields(DataOutput out) throws IOException {
        CDataOutputStream.writeVInt(size, out);
        for (int i = 0; i < size; i++) {
            out.writeInt(arr[i]);
        }
    }

    /**
     * @deprecated Use IntsWritable.copyFileds instead.
     * @param that
     */
    @Deprecated
    public void set(IntsWritable that) {
        this.size = that.size;
        if (this.size > this.arr.length) {
            this.arr = new int[this.size];
        }
        System.arraycopy(that.arr, 0, this.arr, 0, this.size);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public IWritable copyFields(IWritable value) {
        if (value == this) {
            return this;
        }
        IntsWritable that = (IntsWritable) value;
        this.size = that.size;
        if (this.size > this.arr.length) {
            this.arr = new int[this.size];
        }
        System.arraycopy(that.arr, 0, this.arr, 0, this.size);
        return this;
    }

    /**
     * like {@link Arrays#toString(int[])}.
     * 
     * @see Arrays#toString(int[])
     */
    @Override
    public String toString() {
        if (size == 0) {
            return "[]";
        }
        StringBuilder b = new StringBuilder();
        b.append('[');
        for (int i = 0;; i++) {
            b.append(arr[i]);
            if (i == size - 1) {
                return b.append(']').toString();
            }
            b.append(", ");
        }
    }
}
