package odis.serialize.lib;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.lang.reflect.Array;

import odis.io.Limit;
import odis.serialize.IWritable;
import odis.serialize.WritableRegistry;

/**
 * A generic writable containing an array of objects of the same class. The
 * class is specified when constructing the ArrayWritable. <br>
 * XXX David: this is not a legal IWritable definition. We do not serialize the
 * valueClass, so you need to set valueClass before calling readFields.
 * 
 * @author David
 */
public class ArrayWritable implements IWritable {
    static {
        WritableRegistry.registerAlias(ArrayWritable.class, "Array_v3");
    }

    private static final IWritable[] EMPTY_VALUES = new IWritable[0];

    private Class<? extends IWritable> valueClass;

    private IWritable[] values = EMPTY_VALUES;

    /**
     * Construct an ArrayWritable with null valueClass and empty values.
     */
    public ArrayWritable() {
        this.valueClass = null;
    }

    /**
     * Construct an ArrayWritable with given valueClass.
     * 
     * @param valueClass
     */
    public ArrayWritable(Class<? extends IWritable> valueClass) {
        this.valueClass = valueClass;
    }

    /**
     * Construct an ArrayWritable with given valueClass and values.
     * 
     * @param valueClass
     * @param values
     */
    public ArrayWritable(Class<? extends IWritable> valueClass,
            IWritable[] values) {
        this(valueClass);
        this.values = values;
    }

    /**
     * Set valueClass to null and values to empty array.
     */
    public void clear() {
        valueClass = null;
        values = EMPTY_VALUES;
    }

    /**
     * Set valueClass. If valueClass change, clear values.
     * 
     * @param valueClass
     */
    public void setValueClass(Class<? extends IWritable> valueClass) {
        if (valueClass != this.valueClass) {
            this.valueClass = valueClass;
            this.values = null;
        }
    }

    /**
     * Get valueClass.
     * 
     * @return
     */
    public Class<? extends IWritable> getValueClass() {
        return valueClass;
    }

    /**
     * Set values.
     * 
     * @param values
     */
    public void set(IWritable[] values) {
        this.values = values;
    }

    /**
     * Get values. Change this array's element will effect ArrayWritable.
     * 
     * @return
     */
    public IWritable[] get() {
        return values;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeInt(values.length); // write values
        for (int i = 0; i < values.length; i++) {
            values[i].writeFields(out);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        int arraySize = in.readInt();
        Limit.checkArraySize(arraySize);
        values = (IWritable[]) Array.newInstance(valueClass, arraySize);// construct values
        for (int i = 0; i < values.length; i++) {
            IWritable value; // construct value
            try {
                value = valueClass.newInstance();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            value.readFields(in); // read a value
            values[i] = value; // store it in values
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public IWritable copyFields(IWritable value) {
        if (value == this) {
            return this;
        }

        ArrayWritable that = (ArrayWritable) value;

        if (that.valueClass == null) {
            this.valueClass = null;
            this.values = EMPTY_VALUES;
            return this;
        } // if
        values = (IWritable[]) Array.newInstance(valueClass, that.values.length);
        for (int i = 0; i < values.length; i++) {
            try {
                values[i] = (IWritable) valueClass.newInstance();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            values[i].copyFields(that.values[i]); // copy a value
        }
        return this;
    }
}
