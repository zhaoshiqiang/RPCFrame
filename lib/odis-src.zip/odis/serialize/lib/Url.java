package odis.serialize.lib;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.io.Limit;
import odis.serialize.IClearable;
import odis.serialize.IParsable;
import odis.serialize.ISkippable;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.ParseException;
import odis.serialize.WritableRegistry;
import odis.serialize.comparator.BinaryComparator;
import odis.serialize.comparator.UrlBinaryComparator;
import toolbox.misc.EmptyInstance;

/**
 * Url stores one normalized url string in utf-8 encoding. <b>This class does
 * NOT normalize the url, so normalize it before passing data in.</b> The bytes
 * acturally stored are:
 * <p>
 * (protocol: 1 byte) (host_length: vint) (size : vint) (reversed_hostname:
 * bytes) (port_path : bytes) [proto_string : bytes]
 * </p>
 * Each field is explained below. <strong>protocol</strong> This field stores
 * the id of standard protocol in higher 3 bits, and the length of non-standard
 * protocol in lower 5 bits. Standard protocols include http, https and ftp, and
 * ids for them are 1, 2, 3, respectively. So for protocol "http", this field is
 * 00100000B; and for protocol "file", this field is 00000100B. Bytes of
 * non-standard protocol, named with "proto_string", is stored as the last bytes
 * field.
 * <p>
 * <strong>host_length</strong> This field stores the length of the hostname in
 * bytes. For example, host_length field equals 11 for URL
 * "http://www.163.com:8080/a.html", whose hostname is "www.163.com". This field
 * is serialzed as a VINT.
 * <p>
 * <strong>size</strong> Size field stores the sum of the size of the bytes
 * fields after it, include "reversed_hostname", "port_path" and "proto_string"
 * (if this protocol is non-standard).
 * <p>
 * <strong>reversed_hostname</strong> This field stores the reversed hostname,
 * "moc.361.www" for "http://www.163.com:8080/a.html". We store hostname in
 * reverse order so that sites of same domain could be placed near to each
 * other. For example, "news.sohu.com" will be near to "www.sohu.com", not be
 * near to "news.163.com".
 * <p>
 * <strong>port_path</strong> This field stores the data after hostname of url,
 * for example, ":8080/a.html" for "http://www.163.com:8080/a.html", or "/b" for
 * "http://www.163.com/b".
 * <p>
 * <strong>proto_string</strong> If the protocol of url is non-standard, in
 * other words, it is not included in "http", "https" and "ftp", the actural
 * protocol string should be stored in bytes.
 * <p>
 * How the url stored is for the convenient of comparison. Refer to
 * {@link odis.serialize.comparator.UrlBinaryComparator} for the comparing
 * policy. This class contains some methods to transform url into
 * {@link odis.serialize.lib.StringWritable}. Use these methods instead of using
 * java.lang.String as temp form to improve the performance. <b>Most of the
 * methods of this class is non-thread-safe, because it uses an internal buffer
 * during transforming.</b>
 * 
 * @author river
 */
public class Url implements IWritableComparable, IParsable, BytesAccessable,
        IClearable, ISkippable {
    static {
        WritableRegistry.register(Url.class, "Url", UrlBinaryComparator.class);
    }

    /**
     * A url with all fields empty.
     */
    public static final Url EMPTY_URL = new Url();

    /**
     * Max number of protocol char.
     */
    public static final int MAX_PROTO_LENGTH = 8;

    /**
     * Unknown protocol.
     */
    public static final String UNKNOWN = "unknown";

    private static final byte[] UNKNOWN_BYTES = UNKNOWN.getBytes();

    /**
     * Http protocol.
     */
    public static final int PROTO_HTTP = 1;

    /**
     * Http protocol string form.
     */
    public static final String HTTP = "http";

    private static final byte[] HTTP_BYTES = HTTP.getBytes();

    private static final int PORT_HTTP = 80;

    /**
     * Https protocol.
     */
    public static final int PROTO_HTTPS = 2;

    /**
     * Https protocol string form.
     */
    public static final String HTTPS = "https";

    private static final byte[] HTTPS_BYTES = HTTPS.getBytes();

    private static final int PORT_HTTPS = 443;

    /**
     * Ftp protocol.
     */
    public static final int PROTO_FTP = 3;

    /**
     * Ftp protocol string form.
     */
    public static final String FTP = "ftp";

    private static final byte[] FTP_BYTES = FTP.getBytes();

    private static final int PORT_FTP = 21;

    private static final byte BYTE_SEMI = (byte) ':';

    private byte[] data = EmptyInstance.BYTES;

    private int size = 0;

    private int hostLength = 0;

    private byte protocol = 0;

    private byte[] internalBuf = EmptyInstance.BYTES;

    private int internalSize = 0;

    private String cachedString = EmptyInstance.STRING; // cache of string format of url

    /**
     * Constructor.
     */
    public Url() {}

    /**
     * Constructor with an initial value.
     * 
     * @param s
     */
    public Url(String s) {
        set(s);
    }

    /**
     * @deprecated
     */
    @Deprecated
    public Url(UTF8Writable s) {
        set(s);
    }

    /**
     * Constructor with an initial value.
     * 
     * @param s
     */
    public Url(StringWritable s) {
        set(s);
    }

    /**
     * Contrsuctor using {@link #copyFields(IWritable)}
     * 
     * @param url
     */
    public Url(Url url) {
        copyFields(url);
    }

    /**
     * Set normalized url in string into this object.
     * 
     * @param url
     */
    public void set(String url) {
        if (internalBuf.length < url.length() * 3) {
            internalBuf = new byte[url.length() * 3];
        }
        internalSize = StringWritable.encode(url, internalBuf, 0);
        set(internalBuf, internalSize);
        this.cachedString = url;
    }

    /**
     * Set normalized url in UTF8Writable into this object.
     * 
     * @param url
     * @deprecated
     */
    @Deprecated
    public void set(UTF8Writable url) {
        set(url.getBytes(), url.getByteLength());
        this.cachedString = url.cachedString;
    }

    /**
     * Set normalized url in StringWritable into this object.
     * 
     * @param url
     */
    public void set(StringWritable url) {
        set(url.getBytes(), url.getByteLength());
        this.cachedString = url.cachedString;
    }

    /**
     * Copy another url.
     * 
     * @param that
     * @deprecated Use Url.copyFileds instead.
     */
    @Deprecated
    public void set(Url that) {
        this.copyFields(that);
    }

    /**
     * Splits the url into different parts, and stores bytes in the buffer in
     * the order described before.
     * 
     * @param bytes
     * @param len
     */
    private void set(byte[] bytes, int len) {
        int pos = 0;
        int protocolDataLength = 0;

        int protoCheckEnd = MAX_PROTO_LENGTH;
        if (protoCheckEnd > len)
            protoCheckEnd = len;
        while (pos < protoCheckEnd && bytes[pos] != BYTE_SEMI) {
            pos++;
        }

        if (pos == protoCheckEnd) {
            protocol = 0;
            pos = 0;
        } else {
            if (pos == 4 && bytes[0] == 'h' && bytes[1] == 't'
                    && bytes[2] == 't' && bytes[3] == 'p') {
                protocol = PROTO_HTTP << 5;
            } else if (pos == 5 && bytes[0] == 'h' && bytes[1] == 't'
                    && bytes[2] == 't' && bytes[3] == 'p' && bytes[4] == 's') {
                protocol = PROTO_HTTPS << 5;
            } else if (pos == 3 && bytes[0] == 'f' && bytes[1] == 't'
                    && bytes[2] == 'p') {
                protocol = PROTO_FTP << 5;
            } else {
                protocol = (byte) pos;
                protocolDataLength = pos;
            }
            pos++;
        }

        while (pos < len && bytes[pos] == '/')
            pos++;
        int hostStart = pos;
        while (pos < len && bytes[pos] != '/' && bytes[pos] != ':')
            pos++;
        hostLength = pos - hostStart;

        size = protocolDataLength + hostLength + (len - pos);
        if (data.length < size) {
            data = new byte[size];
        }

        int off = 0;
        // first store reversed-host
        for (int i = pos - 1; i >= hostStart; i--) {
            data[off++] = bytes[i];
        }
        // store path
        for (int i = pos; i < len; i++) {
            data[off++] = bytes[i];
        }
        // store protocol if not standard protocol
        for (int i = 0; i < protocolDataLength; i++) {
            data[off++] = bytes[i];
        }

        this.cachedString = null;
    }

    /**
     * Clear host, protocol and url information.
     */
    @Override
    public void clear() {
        size = 0;
        hostLength = 0;
        protocol = 0;
        cachedString = EmptyInstance.STRING;
    }

    /**
     * Transform stored bytes into normal ordered url.
     */
    private void expand() {
        int maxExpendedLength = size + 3 + MAX_PROTO_LENGTH;
        if (internalBuf.length < maxExpendedLength) {
            internalBuf = new byte[maxExpendedLength];
        }

        int off = 0;
        if (protocol != 0) {
            int pid = (protocol >> 5) & 0x7;
            if (pid != 0) {
                if (pid == PROTO_HTTP) {
                    System.arraycopy(HTTP_BYTES, 0, internalBuf, 0,
                            HTTP_BYTES.length);
                    off = HTTP_BYTES.length;
                } else if (pid == PROTO_HTTPS) {
                    System.arraycopy(HTTPS_BYTES, 0, internalBuf, 0,
                            HTTPS_BYTES.length);
                    off = HTTPS_BYTES.length;
                } else if (pid == PROTO_FTP) {
                    System.arraycopy(FTP_BYTES, 0, internalBuf, 0,
                            FTP_BYTES.length);
                    off = FTP_BYTES.length;
                } else {
                    System.arraycopy(UNKNOWN_BYTES, 0, internalBuf, 0,
                            UNKNOWN_BYTES.length);
                    off = UNKNOWN_BYTES.length;
                }
            } else {
                for (int i = size - protocol; i < size; i++) {
                    internalBuf[off++] = data[i];
                }
            }
            internalBuf[off++] = ':';
            internalBuf[off++] = '/';
            internalBuf[off++] = '/';
        }

        for (int i = hostLength - 1; i >= 0; i--) {
            internalBuf[off++] = data[i];
        }

        for (int i = hostLength; i < size - (protocol & 0x1f); i++) {
            internalBuf[off++] = data[i];
        }

        internalSize = off;
    }

    /**
     * Get the url in string.
     * 
     * @return
     */
    public String get() {
        if (cachedString == null) {
            expand();
            cachedString = StringWritable.decode(internalBuf, 0, internalSize);
        }
        return cachedString;
    }

    /**
     * Get the url in string, the return value is same as {@link #get()}.
     */
    @Override
    public String toString() {
        return get();
    }

    /**
     * Transform url into utf-8, and a new created UTF8Writable object is
     * returned. Use {@link #toUTF8Writable(UTF8Writable)} instead if called
     * frequently.
     * 
     * @return
     * @deprecated
     */
    @Deprecated
    public UTF8Writable toUTF8Writable() {
        expand();
        return new UTF8Writable(internalBuf, 0, internalSize);
    }

    /**
     * Transform url into utf-8, the tranformed data is stored into passed-in
     * parameter "utf8". No temporary object is created during this call.
     * 
     * @param utf8
     * @deprecated
     */
    @Deprecated
    public void toUTF8Writable(UTF8Writable utf8) {
        utf8.set(internalBuf, 0, internalSize);
    }

    /**
     * Transform url into StringWritable, and a new created StringWritable
     * object is returned. Use {@link #toStringWritable(StringWritable)} instead
     * if called frequently.
     * 
     * @return
     */
    public StringWritable toStringWritable() {
        expand();
        return new StringWritable(internalBuf, 0, internalSize);
    }

    /**
     * Transform url into StringWritable, the tranformed data is stored into
     * passed-in parameter "s". No temporary object is created during this call.
     * 
     * @param utf8
     */
    public void toStringWritable(StringWritable s) {
        expand();
        s.set(internalBuf, 0, internalSize);
    }

    /**
     * Return the protocol string, such as "http". No new string object created
     * if the protocol is standard protocol.
     * 
     * @return
     */
    public String getProtocol() {
        int pid = (protocol >> 5) & 0x7;
        if (pid == PROTO_HTTP)
            return HTTP;
        else if (pid == PROTO_HTTPS)
            return HTTPS;
        else if (pid == PROTO_FTP)
            return FTP;
        else if (pid != 0)
            return UNKNOWN;
        else {
            return StringWritable.decode(data, size - protocol, protocol);
        }
    }

    /**
     * Return the hostname of this url in string. Use
     * {@link #getSite(StringWritable)} instead if you want to store the result.
     * 
     * @return
     */
    public String getHostname() {
        if (internalBuf.length < hostLength) {
            internalBuf = new byte[hostLength];
        }
        int off = 0;
        for (int i = hostLength - 1; i >= 0; i--) {
            internalBuf[off++] = data[i];
        }
        internalSize = off;
        return StringWritable.decode(internalBuf, 0, internalSize);
    }

    /**
     * Return the path of this url in string. Use
     * {@link #getPath(StringWritable)} instead if called frequently.
     * 
     * @return
     */
    public String getPath() {
        int start = hostLength;
        while (start < size && data[start] != '/') {
            start++;
        }
        internalSize = size - start - (protocol & 0x1f);
        if (internalBuf.length < internalSize) {
            internalBuf = new byte[internalSize];
        }
        System.arraycopy(data, start, internalBuf, 0, internalSize);
        return StringWritable.decode(internalBuf, 0, internalSize);
    }

    /**
     * Store the path of this url into StringWritable.
     * 
     * @param v
     */
    public void getPath(StringWritable v) {
        int start = hostLength;
        while (start < size && data[start] != '/') {
            start++;
        }
        v.set(data, start, size - start - (protocol & 0x1f));
    }

    /**
     * Return the hostname as site object. A new created Url object is returned.
     * Use {@link #getSite(StringWritable)} instead if called frequently.
     * 
     * @return
     */
    public Url getSite() {
        byte[] newData = new byte[hostLength];
        System.arraycopy(data, 0, newData, 0, hostLength);
        Url newUrl = new Url();
        newUrl.cachedString = null;
        newUrl.data = newData;
        newUrl.size = hostLength;
        newUrl.hostLength = hostLength;
        newUrl.protocol = 0;
        return newUrl;
    }

    /**
     * Store the hostname into another url object.
     * 
     * @param url
     */
    public void getSite(Url url) {
        if (url.data.length < hostLength) {
            url.data = new byte[hostLength];
        }
        System.arraycopy(data, 0, url.data, 0, hostLength);
        url.size = hostLength;
        url.hostLength = hostLength;
        url.protocol = 0;
        url.cachedString = null;
    }

    /**
     * Store the hostname into one StringWritable.
     * 
     * @param v
     */
    public void getSite(StringWritable v) {
        if (internalBuf.length < hostLength) {
            internalBuf = new byte[hostLength];
        }
        int off = 0;
        for (int i = hostLength - 1; i >= 0; i--) {
            internalBuf[off++] = data[i];
        }
        internalSize = off;
        v.set(internalBuf, 0, internalSize);
    }

    /**
     * Return port of this url, and default port of standard protocol is
     * returned also.
     * 
     * @return
     */
    public int getPort() {
        int start = hostLength;
        if (start < size && data[start] == ':') {
            int port = 0;
            start++;
            while (start < size && data[start] != '/') {
                if (data[start] >= '0' && data[start] <= '9') {
                    port = port * 10 + (data[start] - '0');
                } else {
                    return -1;
                }
                start++;
            }
            return port;
        } else {
            int pid = (protocol >> 5) & 0x7;
            switch (pid) {
                case PROTO_HTTP:
                    return PORT_HTTP;
                case PROTO_HTTPS:
                    return PORT_HTTPS;
                case PROTO_FTP:
                    return PORT_FTP;
                default:
                    return -1;
            }
        }
    }

    /**
     * Returns the bytes. <strong> For performance concern, we return the
     * internal buffer directly, so the buffer could be changed even when some
     * non-modification method called, such as {@link #getHostname()}. Copy the
     * buffer if you want to save it and use it later. </strong> Implement
     * {@link BytesAccessable#getBytes()}.
     */
    @Override
    public byte[] getBytes() {
        expand();
        return internalBuf;
    }

    /**
     * Return whole url length in bytes. The return value is not the actural
     * count of stored bytes, because length of standard protocol is also
     * included. Implement {@link BytesAccessable#getByteLength()}.
     * 
     * @return
     */
    @Override
    public int getByteLength() {
        int pid = (protocol >> 5) & 0x7;
        int psize = 0;

        if (pid != 0) {
            switch (pid) {
                case PROTO_HTTP:
                    psize = 4;
                    break;
                case PROTO_HTTPS:
                    psize = 5;
                    break;
                case PROTO_FTP:
                    psize = 3;
                    break;
                default:
                    psize = 7;
                    break;
            }
        } else {
            psize = protocol & 0x1f;
        }

        return psize > 0 ? size + 3 + psize : size;
    }

    /**
     * Return length of hostname.
     * 
     * @return
     */
    public int getHostByteLength() {
        return hostLength;
    }

    /**
     * Return length of path.
     * 
     * @return
     */
    public int getPathByteLength() {
        int start = hostLength;
        while (start < size && data[start] != '/') {
            start++;
        }
        return size - start - (protocol & 0x1f);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        protocol = in.readByte();
        hostLength = CDataInputStream.readVInt(in);
        size = CDataInputStream.readVInt(in);
        Limit.checkBufferSize(size);
        if (size > data.length) {
            data = Limit.createBuffer(size);
        }
        in.readFully(data, 0, size);
        this.cachedString = null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeByte(protocol);
        CDataOutputStream.writeVInt(hostLength, out);
        CDataOutputStream.writeVInt(size, out);
        out.write(data, 0, size);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public IWritable copyFields(IWritable value) {
        if (value == null || !(value instanceof Url))
            throw new RuntimeException("bad value : " + value);
        if (value == this)
            return this;

        Url that = (Url) value;

        this.protocol = that.protocol;
        this.hostLength = that.hostLength;
        this.size = that.size;
        if (size > data.length) {
            data = Limit.createBuffer(size);
        }
        System.arraycopy(that.data, 0, this.data, 0, size);
        this.cachedString = that.cachedString;
        return this;
    }

    /**
     * This method should be consistent with
     * {@link UrlBinaryComparator#compare(byte[], int, int, byte[], int, int)}.
     */
    @Override
    public int compareTo(IWritable o) {
        if (o == null || !(o instanceof Url))
            throw new RuntimeException("bad value : " + o);
        if (o == this)
            return 0;

        Url that = (Url) o;
        int plen1 = this.protocol & 0x1f;
        int plen2 = that.protocol & 0x1f;

        // compare the reversed host first
        int comp = BinaryComparator.compareBytes(this.data, 0, this.hostLength,
                that.data, 0, that.hostLength);
        if (comp != 0)
            return comp;
        comp = BinaryComparator.compareBytes(this.data, this.hostLength,
                this.size - plen1 - this.hostLength, that.data,
                that.hostLength, that.size - plen2 - that.hostLength);
        if (comp != 0)
            return comp;

        // compare by protocol
        if (this.protocol == 0 && that.protocol != 0) {
            return -1;
        } else if (this.protocol != 0 && that.protocol == 0) {
            return 1;
        } else {
            // compare protocol
            int pid1 = (this.protocol >> 5) & 0x7;
            int pid2 = (that.protocol >> 5) & 0x7;
            if (pid1 != 0 && pid2 != 0) {
                return pid1 - pid2;
            } else if (pid1 != 0 && pid2 == 0) {
                return -1;
            } else if (pid1 == 0 && pid2 != 0) {
                return 1;
            } else {
                return BinaryComparator.compareBytes(this.data, this.size
                        - plen1, plen1, that.data, that.size - plen2, plen2);
            }
        }
    }

    /**
     * Pass given normalized url, this method is same as {@link #set(String)}.
     */
    @Override
    public void parse(String str) throws ParseException {
        set(str);
    }

    /**
     * First check protocol and host length, then check bytes.
     */
    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Url that = (Url) o;
        if (this.protocol != that.protocol
                || this.hostLength != that.hostLength || this.size != that.size) {
            return false;
        }
        for (int i = 0; i < size; i++) {
            if (data[i] != that.data[i]) {
                return false;
            }
        }
        return true;
    }

    /**
     * Return the hash code of url object. The return value is
     * <strong>not</strong> equals to <code>this.toString().hashCode()</code>.
     */
    @Override
    public int hashCode() {
        int hash = protocol & 0xff;
        for (int i = 0; i < size; i++)
            hash = (31 * hash) + (int) data[i];
        return hash;
    }

    /**
     * Return the long_md5_hash of this url. The return value is equals to
     * MD5Writable.halfDigest(this.toString()), but this method is more
     * efficient.
     * 
     * @return
     */
    public long md5HashCode() {
        expand();
        return MD5Writable.halfDigest(internalBuf, 0, internalSize);
    }

    /**
     * Return the lower 8 bytes of md5sum of the url string as a long. The
     * return value is the same as "new DocID(this.get()).get()".
     * 
     * @return
     */
    public long getDocID() {
        expand();
        return MD5Writable.halfDigest(internalBuf, 0, internalSize);
    }

    /**
     * Return the low 8-bits of md5sum of hostname. The return value is the same
     * as "new SiteID(this.getHostname()).get()".
     * 
     * @return
     */
    public long getSiteID() {
        if (internalBuf.length < hostLength) {
            internalBuf = new byte[hostLength];
        }
        int off = 0;
        for (int i = hostLength - 1; i >= 0; i--) {
            internalBuf[off++] = data[i];
        }
        internalSize = off;
        return MD5Writable.halfDigest(internalBuf, 0, internalSize);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void skipFields(DataInput in) throws IOException {
        CDataInputStream.skipBytes(in, 1); // protocol
        CDataInputStream.skipVInt(in); // hostLength
        int sz = CDataInputStream.readVInt(in);
        CDataInputStream.skipBytes(in, sz);
    }

}
