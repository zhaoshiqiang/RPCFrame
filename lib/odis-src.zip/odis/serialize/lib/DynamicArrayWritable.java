package odis.serialize.lib;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.io.Limit;
import odis.serialize.IWritable;
import odis.serialize.WritableId;
import odis.serialize.WritableRegistry;
import toolbox.misc.ClassUtils;

/**
 * An array of writables of the same class with their class stored along with 
 * them. This way the reader does not need to know the class beforehand when
 * reading the data. Useful as a generic container in mapreduce.
 * 
 * @author zhangduo
 * @deprecated Use {@link odis.serialize.toolkit.AbstractMultiWritable}.
 */
@Deprecated
public class DynamicArrayWritable implements IWritable {
    static {
        WritableRegistry.registerAlias(DynamicArrayWritable.class, "DynamicArrayWritable_v3");
    }
    private Class valueClass = null;
    private byte id = WritableId.NULL_ID;
    private ArrayList<IWritable> objects = null;
    private int size = 0;
    
    public void clear() {
        size = 0;
        if (objects != null) {
            objects.clear();
        }
    }
    
    /**
     * Add an IWritable object. All objects added has to be of the same class. 
     */
    public void add(Object o) {
        IWritable obj = (IWritable) o;
        if (size > 0) {
            if (obj.getClass() != valueClass) {
                throw new RuntimeException("value class " + obj.getClass() + " mismatch with previous " + valueClass);
            }
        } else {
            valueClass = obj.getClass();
            if (objects == null) {
                objects = new ArrayList<IWritable>();
            }
        }
        objects.add(obj);
        size ++;
    }
    
    public int size() {
        return size;
    }
    
    public IWritable get(int index) {
        if (index >= size || index < 0) {
            throw new IndexOutOfBoundsException("index " + index + " out of bounds of " + size);
        }
        return objects.get(index);
    }
    
    public IWritable [] toArray() {
        if (size == 0) {
            return new IWritable[0];
        } else {
            IWritable [] array = (IWritable[])Array.newInstance(valueClass, size);
            for (int i=0; i<size; i++) {
                array[i] = objects.get(i);
            }
            return array;
        }
    }
    
    @Override
    public int hashCode() {
        int hashCode = 1;
        for (int i = 0; i < size; i++) {
            IWritable obj = objects.get(i);
            hashCode = 31 * hashCode + (obj == null ? 0 : obj.hashCode());
        }
        return hashCode ^ valueClass.hashCode();
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        DynamicArrayWritable other = (DynamicArrayWritable) o;
        if (this.size != other.size) {
            return false;
        }
        if (this.size == 0) {
            return true;
        }

        if (this.valueClass != other.valueClass) {
            return false;
        }

        for (int i = 0; i < size; i++) {
            if (!objects.get(i).equals(other.objects.get(i))) {
                return false;
            }
        }
        return true;
    }
    
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("[").append(size).append("]");
        for (int i=0; i<size; i++) {
            builder.append("{").append(objects.get(i)).append("}");
        }
        return builder.toString();
    }
    
    @Override
    public IWritable copyFields(IWritable value) {
        this.valueClass = ((DynamicArrayWritable)value).valueClass;
        this.id = ((DynamicArrayWritable)value).id;
        if(((DynamicArrayWritable)value).objects == null) {
            this.objects = null;
        } else {
            if(this.objects == null) {
                this.objects = new ArrayList<IWritable>();
            } else {
                this.objects.clear();
            }
            this.objects.addAll(((DynamicArrayWritable)value).objects);
        }
        this.size = ((DynamicArrayWritable)value).size;
        return this;
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        size = CDataInputStream.readVInt(in);
        if (size == 0) {
            return;
        }
        Limit.checkArraySize(size);
        
        Class oldClass = valueClass;
        
        id = in.readByte();
        if (id == WritableId.NULL_ID) {
            String classname = UTF8Writable.readString(in);
            try {
                valueClass = Class.forName(classname);
            } catch(Exception e) {
                throw new RuntimeException("cannot initialize class " + classname);
            }
        } else {
            valueClass = WritableId.getClass(id);
            assert valueClass != null;
        }
        
        if (objects == null) {
            objects = new ArrayList<IWritable>(size);
        } else {
            if (valueClass != oldClass) {
                objects.clear();
            }
        }
        
        for (int i=0; i<size; i++) {
            if (objects.size() > i) {
                objects.get(i).readFields(in);
            } else {
                IWritable o = (IWritable) ClassUtils.newInstance(valueClass);
                o.readFields(in);
                objects.add(o);
            }
        }
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        CDataOutputStream.writeVInt(size, out);
        if (size == 0) {
            return;
        }
        
        out.writeByte(id);
        if (id == WritableId.NULL_ID) {
            UTF8Writable.writeString(out, valueClass.getName());
        }
        

        if (size > 0) {
            assert objects != null;
            for (int i=0; i<size; i++) {
                objects.get(i).writeFields(out);
            }
        }
    }

}
