package odis.serialize.lib;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.io.CDataInputStream;
import odis.serialize.IClearable;
import odis.serialize.IParsable;
import odis.serialize.ISkippable;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.ParseException;
import odis.serialize.WritableRegistry;
import odis.serialize.comparator.LongBinaryComparator;

/**
 * The IWritable class storing a long value.
 * 
 * @author zhangduo
 */
public class LongWritable implements IWritableComparable, IParsable,
        ISkippable, IClearable {
    static {
        WritableRegistry.register(LongWritable.class, "long", Long.SIZE
                / Byte.SIZE, LongBinaryComparator.class);
    }

    protected long value;

    /**
     * Constructor with value 0.
     */
    public LongWritable() {}

    /**
     * Constructor.
     * 
     * @param value
     *            the initial value
     */
    public LongWritable(long value) {
        set(value);
    }

    /**
     * Sets the value to zero.
     */
    @Override
    public void clear() {
        value = 0;
    }

    /**
     * Sets the value.
     * 
     * @param value
     *            the new value
     * @return this instance
     */
    public void set(long value) {
        this.value = value;
    }

    /**
     * Return the value of this LongWritable.
     */
    public long get() {
        return value;
    }

    /**
     * Increase the value and returns the new value. new-value = old-value +
     * change <br>
     * NOTE: this method is not synchronized.
     * 
     * @param change
     *            the delta value
     * @return the new value
     */
    public long incAndGet(long change) {
        value += change;
        return value;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeLong(value);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        value = in.readLong();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public IWritable copyFields(IWritable value) {
        this.value = ((LongWritable) value).value;
        return this;
    }

    /**
     * same rule with {@link Long#compareTo(Long)}
     */
    @Override
    public int compareTo(IWritable o) {
        long thisValue = this.value;
        long thatValue = ((LongWritable) o).value;
        return (thisValue < thatValue ? -1 : (thisValue == thatValue ? 0 : 1));
    }

    /**
     * use {@link Long#parseLong(String)} to parse.
     */
    @Override
    public void parse(String s) throws ParseException {
        set(Long.parseLong(s));
    }

    /**
     * Returns true iff <code>o</code> is a LongWritable with the same value.
     */
    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        LongWritable other = (LongWritable) o;
        return this.value == other.value;
    }

    /**
     * same with {@link Long#hashCode()}
     */
    @Override
    public int hashCode() {
        return (int) (value ^ (value >>> 32));
    }

    /**
     * just call {@link Long#toString(long)}
     */
    @Override
    public String toString() {
        return Long.toString(value);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void skipFields(DataInput in) throws IOException {
        CDataInputStream.skipBytes(in, Long.SIZE / Byte.SIZE);
    }
}
