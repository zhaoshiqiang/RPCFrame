/**
 * @(#)StringPropertiesWritable.java, 2010-8-9. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.serialize.lib;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.IClearable;
import odis.serialize.ISkippable;
import odis.serialize.IWritable;
import odis.serialize.WritableRegistry;
import odis.serialize.comparator.BinaryComparator;

/**
 * A properties object with string properties and IWritable interface.<br>
 * <strong>Note</strong>: properties can not be null.
 * 
 * @author zhangduo
 */
public class StringPropertiesWritable extends HashMap<String, String> implements
        IWritable, ISkippable, IClearable {

    private static final long serialVersionUID = 2133201351374962371L;

    static {
        WritableRegistry.register(StringPropertiesWritable.class,
                "StringPropertiesWritable", BinaryComparator.class);
    }

    /**
     * Put property <code>key=value</code>.
     * 
     * @param key
     * @param value
     */
    public void setProperty(String key, String value) {
        put(key, value);
    }

    /**
     * Get property for this key. If no property exists for this key, return
     * <code>null</code>.
     * 
     * @param key
     * @return
     */
    public String getProperty(String key) {
        return get(key);
    }

    /**
     * Get property for this key with default value.If no property exists for
     * this key, return <code>defaultValue</code>.
     * 
     * @param key
     * @param defaultValue
     * @return
     */
    public String getProperty(String key, String defaultValue) {
        String value = get(key);
        return value == null ? defaultValue : value;
    }

    /**
     * Get all properties's name in this properties object.
     * 
     * @return
     */
    public Set<String> propertyNames() {
        return Collections.unmodifiableSet(keySet());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        int sz = CDataInputStream.readVInt(in);
        clear();
        for (int i = 0; i < sz; i++) {
            String key = StringWritable.readString(in);
            String value = StringWritable.readString(in);
            put(key, value);
        }

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeFields(DataOutput out) throws IOException {
        CDataOutputStream.writeVInt(size(), out);
        for (Map.Entry<String, String> entry: entrySet()) {
            StringWritable.writeString(out, entry.getKey());
            StringWritable.writeString(out, entry.getValue());
        }

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public IWritable copyFields(IWritable value) {
        StringPropertiesWritable v = (StringPropertiesWritable) value;
        clear();
        putAll(v);
        return this;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void skipFields(DataInput in) throws IOException {
        int sz = CDataInputStream.readVInt(in);
        for (int i = 0; i < sz; i++) {
            StringWritable.skipString(in);
            StringWritable.skipString(in);
        }
    }
    
    /**
     * return a hashcode base on all key value pairs.
     */
    @Override
    public int hashCode() {
        int h = 0;
        for (Map.Entry<String, String> entry : entrySet()) {
            h += entry.hashCode();
        }
        return h;
    }

    /**
     * return true if and only if <code>o</code> is an instance of
     * <code>StringPropertiesWritable</code> with same key value pairs.
     */
    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        if (this == o) {
            return true;
        }
        StringPropertiesWritable that = (StringPropertiesWritable) o;
        if (size() != that.size()) {
            return false;
        }
        for (Map.Entry<String, String> e: entrySet()) {
            if (!e.getValue().equals(that.get(e.getKey()))) {
                return false;
            }
        }
        return true;
    }

}
