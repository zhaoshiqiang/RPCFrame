/**
 * @(#)BitsWritable.java, 2007-6-27. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.serialize.lib;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.io.Limit;
import odis.serialize.IClearable;
import odis.serialize.ISkippable;
import odis.serialize.IWritable;
import odis.serialize.WritableRegistry;
import toolbox.misc.EmptyInstance;

/**
 * Writable to store BitSet. Sample code:
 * <p>
 * <code>
 *   BitsWritable bits = new BitsWritable();
 *   bits.set(1, true);
 *   bits.set(3, true);
 *   bits.set(4, true);
 *   
 *   int [] set = bits.toIntArray(); // set should be [1, 3, 4]
 *   
 *   bits.set(3, false);
 *   set = bits.toIntArray(); // set should be [1, 4]
 *   
 * </code>
 * 
 * @see java.util.BitSet
 * @author river
 */
public class BitsWritable implements IWritable, IClearable, ISkippable {
    static {
        WritableRegistry.registerAlias(BitsWritable.class, "BitSet_v1");
    }

    private static final int UNIT_BITS_LENGTH = 8;

    private byte[] bits = EmptyInstance.BYTES;

    private int size = 0;

    /**
     * Clear the bit set.
     */
    @Override
    public void clear() {
        Arrays.fill(bits, (byte) 0);
        size = 0;
    }

    /**
     * Mark bits at idx as value(true/false).
     * 
     * @see java.util.BitSet#set(int, boolean)
     * @param idx
     * @param value
     */
    public void set(int idx, boolean value) {
        int i = idx / UNIT_BITS_LENGTH;
        int j = idx % UNIT_BITS_LENGTH;
        if (i >= bits.length) {
            byte[] tmp = new byte[i + 1];
            Arrays.fill(tmp, (byte) 0);
            System.arraycopy(bits, 0, tmp, 0, bits.length);
            bits = tmp;
        }
        if (value) {
            bits[i] = (byte) (bits[i] | (1 << j));
        } else {
            bits[i] = (byte) (bits[i] & ~(1 << j));
        }
        if (i >= size)
            size = i + 1;
    }

    /**
     * Get bit set at idx.
     * 
     * @see java.util.BitSet#get(int)
     * @param idx
     * @return
     */
    public boolean get(int idx) {
        int i = idx / UNIT_BITS_LENGTH;
        int j = idx % UNIT_BITS_LENGTH;
        return (i < size) && ((bits[i] & (1 << j)) != 0);
    }

    /**
     * Return the max bit which is set. Return -1 if no bit found.
     * 
     * @return
     */
    public int getLastBit() {
        for (int i = size - 1; i >= 0; i--) {
            if (bits[i] != 0) {
                int j = 0;
                int b = bits[i];
                while ((b & 0x01) == 0) {
                    b = (b >> 1);
                    j++;
                }
                return i * UNIT_BITS_LENGTH + j;
            }
        }
        return -1;
    }

    /**
     * Return if there's no bit found.
     * 
     * @return
     */
    public boolean isEmpty() {
        for (int i = 0; i < size; i++) {
            if (bits[i] != 0)
                return false;
        }
        return true;
    }

    /**
     * Return the bits in int array.
     * 
     * @return
     */
    public int[] toIntArray() {
        int[] tmp = new int[size * UNIT_BITS_LENGTH];
        int idx = 0;
        int bit = 0;
        for (int i = 0; i < size; i++) {
            int b = bits[i];
            for (int j = 0; j < UNIT_BITS_LENGTH; j++) {
                if ((b & 0x01) != 0) {
                    tmp[idx++] = bit;
                }
                b = b >> 1;
                bit++;
            }
        }

        if (idx == 0) {
            return EmptyInstance.INTS;
        } else {
            if (idx < tmp.length) {
                return Arrays.copyOf(tmp, idx);
            } else {
                return tmp;
            }
        }
    }

    /**
     * Two BitsWritable equals if and only if they contains the same bits.
     */
    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        BitsWritable that = (BitsWritable) o;
        int minSize = Math.min(this.size, that.size);
        for (int i = 0; i < minSize; i++) {
            if (this.bits[i] != that.bits[i]) {
                return false;
            }
        }
        if (this.size > minSize) {
            for (int i = minSize; i < this.size; i++) {
                if (this.bits[i] != 0) {
                    return false;
                }
            }
        } else if (that.size > minSize) {
            for (int i = minSize; i < that.size; i++) {
                if (that.bits[i] != 0) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * Return the same hashCode when {@link #equals(Object)} return true.
     */
    @Override
    public int hashCode() {
        long h = 1234;
        for (int i = size; --i >= 0;) {
            h ^= bits[i] * (i + 1);
        }

        return (int) ((h >> 32) ^ h);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        size = CDataInputStream.readVInt(in);
        if (size > bits.length) {
            bits = Limit.createBuffer(size);
        }
        in.readFully(bits, 0, size);
        for (int i = size; i < bits.length; i++) {
            bits[i] = 0;
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeFields(DataOutput out) throws IOException {
        CDataOutputStream.writeVInt(size, out);
        out.write(bits, 0, size);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public IWritable copyFields(IWritable value) {
        if (value == null || !(value instanceof BitsWritable)) {
            throw new RuntimeException("bad value :" + value);
        }
        if (value == this) {
            return this;
        }

        BitsWritable that = (BitsWritable) value;
        this.size = that.size;
        if (bits.length < this.size) {
            bits = Limit.createBuffer(this.size);
        }
        System.arraycopy(that.bits, 0, this.bits, 0, this.size);
        for (int i = this.size; i < bits.length; i++) {
            bits[i] = 0;
        }
        return this;
    }

    /**
     * Return the "[e1,e2]" format string.
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("[");
        for (int i = 0; i < size * UNIT_BITS_LENGTH; i++) {
            if (get(i)) {
                builder.append(i).append(',');
            }
        }
        if (builder.length() > 1) {
            builder.setLength(builder.length() - 1);
        }
        builder.append("]");
        return builder.toString();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void skipFields(DataInput in) throws IOException {
        int size = CDataInputStream.readVInt(in);
        CDataInputStream.skipBytes(in, size);
    }
}
