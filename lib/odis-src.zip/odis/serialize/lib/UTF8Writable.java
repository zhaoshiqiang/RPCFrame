package odis.serialize.lib;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.logging.Logger;

import odis.io.CDataInputStream;
import odis.serialize.IClearable;
import odis.serialize.IParsable;
import odis.serialize.ISkippable;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.WritableRegistry;
import odis.serialize.comparator.BinaryComparator;
import odis.serialize.comparator.ShortBytesBinaryComparator;
import toolbox.misc.EmptyInstance;
import toolbox.misc.LogFormatter;

/**
 * This version of UTF8Writable is ported from Nutch's
 * <code>outfox.commons.serialize.UTF8</code>. Kept only the working part of
 * code and removed unused code of very old nutch version.
 * 
 * @Deprecated UTF8Writable can only handle strings shorter than 64K/3, use
 *             {@link StringWritable} instead.
 * @author zl
 */
@Deprecated
public class UTF8Writable implements IWritableComparable, IParsable,
        ISkippable, BytesAccessable, IClearable {

    private static final Logger LOG = LogFormatter.getLogger(UTF8Writable.class);

    static {
        WritableRegistry.register(UTF8Writable.class, "UTF8",
                ShortBytesBinaryComparator.class);
        // FIXME: due to a previous bug in LongUTF8Writable (currently
        // StringWritable)
        WritableRegistry.registerLegacyAlias(UTF8Writable.class, "L_UTF8");
    }

    // the length of unsigned short
    private static final int LENGTH_LIMIT = 0xffff;

    private static final int BYTES_PER_UNICODE_CHAR = 3;

    private static final int TRUNCATE_LENGTH = LENGTH_LIMIT
            / BYTES_PER_UNICODE_CHAR;

    private byte[] bytes = EmptyInstance.BYTES;

    private int length; // used as an unsigned short

    String cachedString = EmptyInstance.STRING; // string object cached

    public UTF8Writable() {}

    public UTF8Writable(String s) {
        set(s);
    }

    public UTF8Writable(UTF8Writable utf8) {
        set(utf8);
    }

    UTF8Writable(byte[] data, int offset, int len) {
        set(data, offset, len);
    }

    /**
     * The raw bytes. Implement {@link BytesAccessable#getBytes()}.
     */
    public byte[] getBytes() {
        return bytes;
    }

    /**
     * @deprecated Use {@link #getByteLength()} instead. The number of bytes in
     *             the encoded string.
     */
    public int getLength() {
        return length;
    }

    /**
     * Implement {@link BytesAccessable#getByteLength()}.
     */
    public int getByteLength() {
        return length;
    }

    /** Set to contain the contents of a string. */
    public void set(String string) {
        if (string == null || string.length() == 0) {
            length = 0;
            cachedString = EmptyInstance.STRING;
            return;
        }
        cachedString = string;
        if (string.length() > TRUNCATE_LENGTH) { // maybe too long
            LOG.warning("Truncating long string: " + string.length()
                    + " chars, starting with " + string.substring(0, 20));
            string = string.substring(0, TRUNCATE_LENGTH);
        }
        int targetLength = string.length() * 3;
        if (bytes.length < targetLength)
            bytes = new byte[targetLength];
        length = StringWritable.encode(string, bytes, 0);
        if (length > 65535)
            throw new RuntimeException("BUG: UTF8Writable internal error. "
                    + "String has bytes longer than 65535.");
    }

    void set(byte[] data, int offset, int len) {
        cachedString = null;
        if (bytes.length < len) {
            bytes = new byte[len];
        }
        System.arraycopy(data, offset, bytes, 0, len);
        length = len;
    }

    /**
     * Set to contain the contents of a string.
     * 
     * @deprecated use UTF8Writable.copyFields instead.
     */
    @Deprecated
    public void set(UTF8Writable other) {
        length = other.length;
        if (bytes == null || length > bytes.length) { // grow buffer
            bytes = new byte[length];
        }
        System.arraycopy(other.bytes, 0, bytes, 0, length);
        cachedString = other.cachedString;
    }

    public String get() {
        if (cachedString == null) {
            cachedString = StringWritable.decode(bytes, 0, length);
        }
        return cachedString;
    }

    @Override
    public void clear() {
        length = 0;
        this.cachedString = EmptyInstance.STRING;
    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeShort(length);
        out.write(bytes, 0, length);
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        cachedString = null;
        length = in.readUnsignedShort();
        if (bytes == null || bytes.length < length)
            bytes = new byte[length];
        in.readFully(bytes, 0, length);
    }

    @Override
    public IWritable copyFields(IWritable value) {
        if (value == this)
            return this;
        if (value == null || !(value instanceof UTF8Writable)) {
            throw new RuntimeException("bad value : " + value);
        }

        UTF8Writable other = (UTF8Writable) value;
        set(other);
        return this;
    }

    @Override
    public int compareTo(IWritable o) {
        UTF8Writable that = (UTF8Writable) o;
        return BinaryComparator.compareBytes(bytes, 0, length, that.bytes, 0,
                that.length);
    }

    @Override
    public void parse(String s) {
        set(s);
    }

    /** Returns true iff <code>o</code> is a UTF8 with the same contents. */
    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        UTF8Writable that = (UTF8Writable) o;
        if (length != that.length) {
            return false;
        }
        for (int i = 0; i < length; i++) {
            if (bytes[i] != that.bytes[i]) {
                return false;
            }
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 1;
        for (int i = 0; i < length; i++) {
            hash = (31 * hash) + (int) bytes[i];
        }
        return hash;
    }

    /** Convert to a String. */
    @Override
    public String toString() {
        return get();
    }

    /** Skips over one UTF8 in the input. */
    public static int skip(DataInput in) throws IOException {
        return skipString(in);
    }

    /**
     * Read a UTF-8 encoded string.
     * 
     * @see DataInput#readUTF()
     */
    public static String readString(DataInput in) throws IOException {
        int bytes = in.readUnsignedShort();
        // use JDK's own, for Nutch's version refer to
        // <code>outfox.commons.serialize.UTF8</code>
        byte[] buf = new byte[bytes];
        in.readFully(buf);
        return StringWritable.decode(buf, 0, bytes);
    }

    public static int skipString(DataInput in) throws IOException {
        int len = in.readUnsignedShort();
        CDataInputStream.skipBytes(in, len);
        return len + 2;
    }

    /**
     * Write a UTF-8 encoded string.
     * 
     * @see DataOutput#writeUTF(String)
     */
    public static int writeString(DataOutput out, String s) throws IOException {
        UTF8Writable w = new UTF8Writable(s);
        w.writeFields(out);
        return w.length + 2;
    }

    public static String readStringNull(DataInput in) throws IOException {
        if (in.readBoolean())
            return readString(in);
        else
            return null;
    }

    public static int skipStringNull(DataInput in) throws IOException {
        if (in.readBoolean()) {
            return skipString(in) + 1;
        } else {
            return 1;
        }
    }

    public static int writeStringNull(DataOutput out, String s)
            throws IOException {
        if (s == null) {
            out.writeBoolean(false);
            return 1;
        } else {
            out.writeBoolean(true);
            return writeString(out, s) + 1;
        }
    }

    @Override
    public void skipFields(DataInput in) throws IOException {
        skipString(in);
    }
}
