package odis.serialize.lib;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.io.CDataInputStream;
import odis.serialize.IClearable;
import odis.serialize.IParsable;
import odis.serialize.ISkippable;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.ParseException;
import odis.serialize.WritableRegistry;
import odis.serialize.comparator.ByteBinaryComparator;

/**
 * Writable to store one byte.
 * 
 * @author river
 */
public class ByteWritable implements IWritableComparable, IParsable,
        ISkippable, IClearable {
    static {
        WritableRegistry.register(ByteWritable.class, "byte", 1,
                ByteBinaryComparator.class);
    }

    private byte value;

    /**
     * The constructor with initial value 0.
     */
    public ByteWritable() {}

    /**
     * The constructor with an initial value.
     * 
     * @param value
     */
    public ByteWritable(byte value) {
        this.value = value;
    }

    /**
     * Set value to 0.
     */
    @Override
    public void clear() {
        value = 0;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.write(value);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        value = in.readByte();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public IWritable copyFields(IWritable value) {
        this.value = ((ByteWritable) value).value;
        return this;
    }

    /**
     * same rule with {@link Byte#compareTo(Byte)}.
     */
    @Override
    public int compareTo(IWritable o) {
        int thisValue = this.value;
        int thatValue = ((ByteWritable) o).value;
        return thisValue - thatValue;
    }

    /**
     * Returns true iff <code>o</code> is a ByteWritable with the same value.
     */
    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        ByteWritable other = (ByteWritable) o;
        return this.value == other.value;
    }

    /**
     * same with {@link Byte#hashCode()}
     */
    @Override
    public int hashCode() {
        return (int) value;
    }

    /**
     * Set the value.
     * 
     * @param value
     */
    public void set(byte value) {
        this.value = value;
    }

    /**
     * Get the value.
     * 
     * @return
     */
    public byte get() {
        return value;
    }

    /**
     * increment value by adding change, then return the value after increment.
     * 
     * @param change
     * @return
     */
    public byte incAndGet(int change) {
        value = (byte) (value + change);
        return value;
    }

    /**
     * use {@link Byte#parseByte(String)} to parse.
     */
    @Override
    public void parse(String str) throws ParseException {
        set(Byte.parseByte(str));
    }

    /**
     * just call {@link Byte#toString(byte)}
     */
    @Override
    public String toString() {
        return Byte.toString(value);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void skipFields(DataInput in) throws IOException {
        CDataInputStream.skipBytes(in, 1);
    }

}
