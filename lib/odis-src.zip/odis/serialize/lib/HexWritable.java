package odis.serialize.lib;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.io.CDataInputStream;
import odis.io.Limit;
import odis.serialize.IClearable;
import odis.serialize.ISkippable;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.WritableRegistry;
import odis.serialize.comparator.BinaryComparator;
import odis.serialize.comparator.ByteBytesBinaryComparator;
import toolbox.misc.EmptyInstance;
import toolbox.text.util.HexString;

/**
 * A writable holding a byte array less than 128 bytes long, so that the length
 * can be represented by one byte.
 * 
 * @author zhangduo
 */
public class HexWritable implements IWritableComparable, ISkippable, IClearable {

    static {
        WritableRegistry.register(HexWritable.class, "HexWritable_v3",
                ByteBytesBinaryComparator.class);
    }

    private byte[] bytes = EmptyInstance.BYTES;

    private byte size = 0;

    /**
     * Constructor with empty buffer and zero size.
     */
    public HexWritable() {}

    /**
     * The constructor with an initial value
     * 
     * @param bytes
     *            the initial value for the bytes field
     */
    public HexWritable(byte[] bytes) {
        set(bytes);
    }

    /**
     * Set buffer to empty, set size to 0.
     */
    @Override
    public void clear() {
        bytes = EmptyInstance.BYTES;
        size = 0;
    }

    /**
     * Set the data, this method copy the bytes into this object.
     * 
     * @param bytes
     */
    public void set(byte[] bytes) {
        if (bytes.length > 127) {
            throw new RuntimeException("bytes overflow for HexWritable("
                    + bytes.length + ")");
        }

        this.bytes = bytes;
        size = (byte) bytes.length;
    }

    /**
     * Get the buffer for the bytes of given data/object.<br>
     * NOTE: this buffer could be larger than the actual data, so call
     * {@link #size()} to get the actual size.
     * 
     * @return the buffer bytes array
     */
    public byte[] data() {
        return bytes;
    }

    /**
     * Returns the number of bytes in the object
     * 
     * @return
     */
    public int size() {
        return size;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.write(size);
        out.write(bytes, 0, size);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        size = in.readByte();
        Limit.checkBufferSize(size);
        if (size > bytes.length) {
            bytes = new byte[size];
        }
        in.readFully(bytes, 0, size);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public IWritable copyFields(IWritable value) {
        HexWritable that = (HexWritable) value;
        size = that.size;
        if (size > bytes.length) {
            bytes = new byte[size];
        }

        System.arraycopy(that.bytes, 0, this.bytes, 0, size);
        return this;
    }

    /**
     * just call {@link HexString#bytesToHex(byte[], int, int)}.
     * 
     * @see HexString#bytesToHex(byte[], int, int)
     */
    @Override
    public String toString() {
        return HexString.bytesToHex(bytes, 0, size);
    }

    /**
     * just call
     * {@link BinaryComparator#compareBytes(byte[], int, int, byte[], int, int)}
     */
    @Override
    public int compareTo(IWritable o) {
        HexWritable that = (HexWritable) o;
        return BinaryComparator.compareBytes(bytes, 0, size, that.bytes, 0,
                that.size);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void skipFields(DataInput in) throws IOException {
        int sz = in.readByte();
        CDataInputStream.skipBytes(in, sz);
    }

    /**
     * @see Object#hashCode()
     */
    @Override
    public int hashCode() {
        int hash = 0;
        for (int i = 0; i < size; i++) {
            hash = (hash << 31) ^ bytes[i];
        }
        return hash;
    }

    /**
     * return true if and only if size are same and every byte are same.
     */
    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        if (this == o) {
            return true;
        }
        HexWritable that = (HexWritable) o;
        if (size != that.size) {
            return false;
        }
        byte[] thatData = that.bytes;
        for (int i = 0; i < size; i++) {
            if (bytes[i] != thatData[i]) {
                return false;
            }
        }
        return true;
    }
}
