package odis.serialize.lib;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.IWritable;
import odis.serialize.WritableRegistry;

/**
 * A blob writable with its type.
 * 
 * @author david
 */
public class TypedBlobWritable extends BlobWritable {
    static {
        WritableRegistry.registerAlias(TypedBlobWritable.class,
                "TypedBlobWritable_v3");
    }

    private int type = 0;

    /**
     * Set type to 0, and call {@link BlobWritable#clear()}.
     */
    @Override
    public void clear() {
        type = 0;
        super.clear();
    }

    /**
     * Return this blob's type.
     * 
     * @return
     */
    public int getType() {
        return type;
    }

    /**
     * Set this blob's type.
     * 
     * @param type
     */
    public void setType(int type) {
        this.type = type;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int hashCode() {
        return type ^ super.hashCode();
    }

    /**
     * Return <code>true</code> iff type and data are all equal.
     */
    @Override
    public boolean equals(Object obj) {
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        TypedBlobWritable other = (TypedBlobWritable) obj;
        return type == other.type && super.equals(other);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public IWritable copyFields(IWritable value) {
        this.type = ((TypedBlobWritable) value).type;
        return super.copyFields(value);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        type = CDataInputStream.readVInt(in);
        super.readFields(in);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void skipFields(DataInput in) throws IOException {
        CDataInputStream.skipVInt(in);
        super.skipFields(in);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeFields(DataOutput out) throws IOException {
        CDataOutputStream.writeVInt(type, out);
        super.writeFields(out);
    }

    /**
     * Print type and blob buffer size.
     */
    @Override
    public String toString() {
        return "BLOB(type: " + type + ", size: " + buffer.size() + ")";
    }
}
