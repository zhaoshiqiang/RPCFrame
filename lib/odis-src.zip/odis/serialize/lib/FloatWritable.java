package odis.serialize.lib;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.io.CDataInputStream;
import odis.serialize.IClearable;
import odis.serialize.IParsable;
import odis.serialize.ISkippable;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.ParseException;
import odis.serialize.WritableRegistry;
import odis.serialize.comparator.FloatBinaryComparator;

/**
 * Writable to store one float.
 * 
 * @author river
 */
public class FloatWritable implements IWritableComparable, ISkippable,
        IParsable, IClearable {
    static {
        WritableRegistry.register(FloatWritable.class, "float", Float.SIZE
                / Byte.SIZE, FloatBinaryComparator.class);
    }

    private float value;

    /**
     * The constructor with initial value 0.0f.
     */
    public FloatWritable() {}

    /**
     * The constructor with an initial value.
     * 
     * @param value
     */
    public FloatWritable(float value) {
        this.value = value;
    }

    /**
     * Set the value of this DoubleWritable.
     * 
     * @param value
     * @return itself
     */
    public FloatWritable set(float value) {
        this.value = value;
        return this;
    }

    /**
     * Set value to 0.0f.
     */
    @Override
    public void clear() {
        value = 0.0f;
    }

    /**
     * Return the value of this FloatWritable.
     */
    public float get() {
        return value;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeFloat(value);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        value = in.readFloat();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public IWritable copyFields(IWritable value) {
        this.value = ((FloatWritable) value).value;
        return this;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void skipFields(DataInput in) throws IOException {
        CDataInputStream.skipBytes(in, Float.SIZE / Byte.SIZE);
    }

    /**
     * just call {@link Float#compare(float, float)}.<br>
     * <strong>Note</strong>: this class has a natural ordering that is
     * inconsistent with equals.
     * 
     * @see Float#compare(float, float)
     */
    @Override
    public int compareTo(IWritable o) {
        float thisValue = this.value;
        float thatValue = ((FloatWritable) o).value;
        return Float.compare(thisValue, thatValue);
    }

    /**
     * Same rule with {@link Float#equals(Object)}. <br>
     * <strong>Notice:</strong> Call <code>f1.equals(f2)</code> is not
     * encouraged, you should use <code>abs(f1 - f2) < delta</code> instead.
     * 
     * @see Float#equals(Object)
     */
    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        FloatWritable other = (FloatWritable) o;
        return Float.floatToIntBits(value) == Float.floatToIntBits(other.value);
    }

    /**
     * same with {@link Float#hashCode()}
     */
    @Override
    public int hashCode() {
        return Float.floatToIntBits(value);
    }

    /**
     * just call {@link Float#toString(float)}
     */
    @Override
    public String toString() {
        return Float.toString(value);
    }

    /**
     * use {@link Float#parseFloat(String)} to parse.
     */
    @Override
    public void parse(String str) throws ParseException {
        set(Float.parseFloat(str));
    }
}
