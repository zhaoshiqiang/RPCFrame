package odis.serialize.lib;

import java.io.ByteArrayOutputStream;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Arrays;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.io.Limit;
import odis.serialize.IClearable;
import odis.serialize.ISkippable;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.WritableRegistry;
import odis.serialize.comparator.BinaryComparator;
import odis.serialize.comparator.VIntBytesBinaryComparator;
import toolbox.misc.EmptyInstance;
import toolbox.text.util.HexString;

/**
 * Writable that stores a byte array. Unlike BytesWritable, ByteArrayWritable
 * uses a VINT instead of a 4-byte Int to represent the length during
 * serialization.
 * 
 * @author zhangkun
 */
public class ByteArrayWritable implements IWritableComparable, ISkippable,
        BytesAccessable, IClearable {

    static {
        WritableRegistry.register(ByteArrayWritable.class, "ByteArray",
                VIntBytesBinaryComparator.class);
    }

    private byte[] bytes = EmptyInstance.BYTES;

    private int size = 0;

    private int maxBufferSize = Integer.MAX_VALUE;

    public ByteArrayWritable() {}

    /**
     * The consturctor with an initial value
     * 
     * @param bytes
     *            the initial value for the bytes field
     */
    public ByteArrayWritable(byte[] bytes) {
        this.bytes = bytes;
        size = bytes.length;
    }

    /**
     * <code>maxBufferSize</code> do <strong>NOT</strong> means the buffer size
     * limit. You can set a buffer larger than <code>maxBufferSize</code> or
     * create a buffer larger than maxBufferSize by <code>readFields</code>.<br>
     * <code>maxBufferSize</code> works as follow: <br>
     * when you call <code>set</code> or
     * <code>readFields<code>, we find that you have a buffer larger
     * than maxBufferSize, and you only need a buffer smaller than maxBufferSize
     * actually, then we will recreate the buffer, so its size will be smaller than
     * maxBufferSize.
     * 
     * @param size
     */
    public void setMaxBufferSize(int size) {
        this.maxBufferSize = size;
    }

    /**
     * Set the data, this method copy the bytes into this object.
     * 
     * @param bytes
     */
    public void set(byte[] bytes) {
        set(bytes, 0, bytes.length);
    }

    /**
     * Set the contents.
     * 
     * @param bytes
     *            the content buffer
     * @param off
     *            the start of the content in the buffer
     * @param len
     *            the number of bytes of the content in the buffer
     */
    public void set(byte[] bytes, int off, int len) {
        if (len > this.bytes.length
                || (this.bytes.length > maxBufferSize && len < maxBufferSize)) {
            this.bytes = Limit.createBuffer(len);
        }
        System.arraycopy(bytes, off, this.bytes, 0, len);
        this.size = len;
    }

    /**
     * Set the byte at index.
     * 
     * @param index
     * @param b
     */
    public void setByte(int index, byte b) {
        if (index >= bytes.length) {
            byte[] temp = Limit.createBuffer((index / 16 + 1) * 16);
            Arrays.fill(temp, (byte) 0);
            System.arraycopy(bytes, 0, temp, 0, bytes.length);
            bytes = temp;
        }
        bytes[index] = b;
        if (index >= size) {
            size = index + 1;
        }
    }

    /**
     * Return the byte at index.
     * 
     * @param index
     * @return
     */
    public byte getByte(int index) {
        return bytes[index];
    }

    /**
     * Set buffer to empty, set size to 0.
     */
    @Override
    public void clear() {
        bytes = EmptyInstance.BYTES;
        size = 0;
    }

    /**
     * Set the buffer, this method use the given bytes directly as buffer.
     * 
     * @param bytes
     */
    public void setBuffer(byte[] bytes) {
        setBuffer(bytes, bytes.length);
    }

    /**
     * Set the buffer, this method use the given bytes directly as buffer.
     * 
     * @param bytes
     * @param size
     */
    public void setBuffer(byte[] bytes, int size) {
        this.bytes = bytes;
        this.size = size;
    }

    /**
     * Get the buffer for the bytes of given data/object. NOTE: this buffer
     * could be larger than the actual data, so call {@link #getByteLength()} to
     * get the actual size.
     * 
     * @return the buffer bytes array
     */
    public byte[] data() {
        return bytes;
    }

    /**
     * Returns the size of the contents in bytes
     * 
     * @return the size of the contents in bytes
     */
    public int size() {
        return size;
    }

    /**
     * @see Object#hashCode()
     */
    @Override
    public int hashCode() {
        int step = size / 128;
        if (step == 0) {
            step = 1;
        }
        int index = 0;
        int hash = 0;
        while (index < size) {
            hash = (hash << 31) ^ bytes[index];
            index += step;
        }
        return hash;
    }

    /**
     * return true if and only if size are same and every byte are same.
     */
    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        if (o == this) {
            return true;
        }
        ByteArrayWritable that = (ByteArrayWritable) o;
        if (this.size != that.size) {
            return false;
        }
        byte[] thatData = that.bytes;
        for (int i = 0; i < size; i++) {
            if (bytes[i] != thatData[i]) {
                return false;
            }
        }
        return true;
    }

    /**
     * just call
     * {@link BinaryComparator#compareBytes(byte[], int, int, byte[], int, int)}
     * .
     */
    @Override
    public int compareTo(IWritable o) {
        ByteArrayWritable that = (ByteArrayWritable) o;
        return BinaryComparator.compareBytes(this.data(), 0, this.size,
                that.data(), 0, that.size);
    }

    /**
     * Writes the contents to a DataOutput
     * 
     * @param out
     *            the DataOutput instance
     * @throws IOException
     *             if an I/O error occurs
     */
    public void writeBytes(DataOutput out) throws IOException {
        out.write(bytes, 0, size);
    }

    /**
     * Reads the contents from a DataInput
     * 
     * @param in
     *            the DataInput instance
     * @param length
     *            the number of bytes to be read
     * @throws IOException
     *             if an I/O error occurs
     */
    public void readBytes(DataInput in, int length) throws IOException {
        size = length;
        if (size > bytes.length
                || (this.bytes.length > maxBufferSize && size < maxBufferSize)) {
            bytes = Limit.createBuffer(size);
        }
        in.readFully(bytes, 0, size);
    }

    /**
     * Read VInt byte array from given input.
     * 
     * @param in
     * @return
     * @throws IOException
     */
    public static byte[] readByteArray(DataInput in) throws IOException {
        int sz = CDataInputStream.readVInt(in);
        byte[] bytes = new byte[sz];
        in.readFully(bytes);
        return bytes;
    }

    /**
     * Write bytes out with vint length.
     * 
     * @param out
     * @param bytes
     * @throws IOException
     */
    public static void writeByteArray(DataOutput out, byte[] bytes)
            throws IOException {
        CDataOutputStream.writeVInt(bytes.length, out);
        out.write(bytes);
    }

    /**
     * Write bytes contained in <code>bos</code> to <code>out</code> with vint
     * length.
     * 
     * @param out
     * @param bos
     * @throws IOException
     */
    public static void writeByteArray(OutputStream out,
            ByteArrayOutputStream bos) throws IOException {
        CDataOutputStream.writeVInt(bos.size(), out);
        bos.writeTo(out);
    }

    /**
     * Write range bytes to <code>out</code> with vint length.
     * 
     * @param out
     * @param bytes
     * @param off
     * @param len
     */
    public static void writeByteArray(DataOutput out, byte[] bytes, int off,
            int len) throws IOException {
        CDataOutputStream.writeVInt(len, out);
        out.write(bytes, off, len);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        size = CDataInputStream.readVInt(in);
        if (size > bytes.length
                || (this.bytes.length > maxBufferSize && size < maxBufferSize)) {
            bytes = Limit.createBuffer(size);
        }
        in.readFully(bytes, 0, size);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeFields(DataOutput out) throws IOException {
        CDataOutputStream.writeVInt(size, out);
        out.write(bytes, 0, size);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public IWritable copyFields(IWritable value) {
        if (value == this) {
            return this;
        }
        ByteArrayWritable that = (ByteArrayWritable) value;
        set(that.bytes, 0, that.size);
        return this;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void skipFields(DataInput in) throws IOException {
        int len = CDataInputStream.readVInt(in);
        CDataInputStream.skipBytes(in, len);
    }

    /**
     * Convert to a hex string with ' ' between bytes.
     * 
     * @see HexString#bytesToHex(byte[], int, int)
     */
    @Override
    public String toString() {
        return HexString.bytesToHex(bytes, 0, size);
    }

    /**
     * equal to {@link #size()}.
     * 
     * @see BytesAccessable#getByteLength()
     */
    @Override
    public int getByteLength() {
        return size;
    }

    /**
     * equal to {@link #data()}
     * 
     * @see BytesAccessable#getBytes()
     */
    @Override
    public byte[] getBytes() {
        return bytes;
    }

}
