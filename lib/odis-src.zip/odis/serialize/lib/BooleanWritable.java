package odis.serialize.lib;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.io.CDataInputStream;
import odis.serialize.IClearable;
import odis.serialize.IParsable;
import odis.serialize.ISkippable;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.ParseException;
import odis.serialize.WritableRegistry;
import odis.serialize.comparator.BooleanBinaryComparator;

/**
 * Save boolean value as one byte.
 * 
 * @author river
 */
public class BooleanWritable implements IWritableComparable, IParsable,
        ISkippable, IClearable {
    static {
        WritableRegistry.register(BooleanWritable.class, "boolean", 1,
                BooleanBinaryComparator.class);
    }

    private boolean value;

    /**
     * With value set to <code>false<code>.
     */
    public BooleanWritable() {}

    /**
     * With value set to the given <code>boolean</code>.
     * 
     * @param value
     */
    public BooleanWritable(boolean value) {
        this.value = value;
    }

    /**
     * Set value to <code>false</code>.
     */
    @Override
    public void clear() {
        value = false;
    }

    /**
     * Set value to the given <code>boolean</code>.
     * 
     * @param b
     */
    public void set(boolean b) {
        this.value = b;
    }

    /**
     * Get value.
     * 
     * @return
     */
    public boolean get() {
        return value;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeBoolean(value);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        value = in.readBoolean();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public IWritable copyFields(IWritable value) {
        this.value = ((BooleanWritable) value).value;
        return this;
    }

    /**
     * Compare to a BooleanWritable.<br>
     * The Rule is:
     * <ul>
     * <li>true > false</li>
     * <li>true == true, false == false.</li>
     * </ul>
     */
    @Override
    public int compareTo(IWritable o) {
        boolean a = this.value;
        boolean b = ((BooleanWritable) o).value;
        return ((a == b) ? 0 : (a == false) ? -1 : 1);
    }

    /**
     * return true if and only if value are equal.
     */
    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        BooleanWritable other = (BooleanWritable) o;
        return this.value == other.value;
    }

    /**
     * same with {@link Boolean#hashCode()}
     */
    @Override
    public int hashCode() {
        return value ? 1231 : 1237;
    }

    /**
     * just call {@link Boolean#toString(boolean)}
     */
    @Override
    public String toString() {
        return Boolean.toString(value);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void skipFields(DataInput in) throws IOException {
        CDataInputStream.skipBytes(in, 1);
    }

    /**
     * use {@link Boolean#parseBoolean(String)} to parse.
     */
    @Override
    public void parse(String str) throws ParseException {
        set(Boolean.parseBoolean(str));
    }
}
