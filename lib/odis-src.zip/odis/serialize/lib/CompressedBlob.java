/**
 * 
 */
package odis.serialize.lib;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.io.DataInputBuffer;
import odis.io.DataOutputBuffer;
import odis.serialize.IWritable;
import odis.serialize.WritableRegistry;
import odis.serialize.toolkit.CompressedWritable;

/**
 * A compressed writable class for storing data blob. A raw data blob is stored
 * when calling <code>setData/addData</code>, and retrieved to a writable object
 * when calling <code>getData/extractData</code>. NOTE: this object is not
 * thread-safe.
 * 
 * @author david
 */
public class CompressedBlob extends CompressedWritable {
    static {
        WritableRegistry.registerAlias(CompressedBlob.class, "CBlob_v3");
    }

    protected DataOutputBuffer buffer = new DataOutputBuffer();

    private DataInputBuffer reader;

    @Override
    protected void copyByField(Object value) {
        CompressedBlob that = (CompressedBlob) value;

        this.buffer.reset();
        this.buffer.write(that.buffer.getData(), 0, that.buffer.size());
    }

    @Override
    protected void readBuffer(DataInput in) throws IOException {
        buffer.reset(); // reset before setting size for avoiding data copy.
        buffer.setSize(CDataInputStream.readVInt(in));
        if (buffer.size() > 0) {
            in.readFully(buffer.getData(), 0, buffer.size());
        }
    }

    @Override
    protected void writeBuffer(DataOutput out) throws IOException {
        CDataOutputStream.writeVInt(buffer.size(), out);
        if (buffer.size() > 0) {
            out.write(buffer.getData(), 0, buffer.size());
        }
    }

    /**
     * Set the blob data into a writable object's data. data.writeFields will be
     * called.
     * 
     * @param data
     *            The writable object containing data.
     * @return this.
     */
    public CompressedBlob setData(IWritable... data) {
        this.changed();
        try {
            buffer.reset();
            for (int i = 0; i < data.length; i++) {
                data[i].writeFields(buffer);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return this;
    }

    /**
     * Append data into the end of the buffer.
     * 
     * @param data
     * @return this.
     */
    public CompressedBlob addData(IWritable... data) {
        this.changed();
        try {
            for (int i = 0; i < data.length; i++) {
                data[i].writeFields(buffer);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return this;
    }

    /**
     * Fetch data from this BlobWritable. buf.readFields will be called
     * 
     * @param buf
     *            The buffer writable object to get from BlobWritable
     */
    public CompressedBlob getData(IWritable... buf) {
        this.decode();

        if (reader == null) {
            reader = new DataInputBuffer();
        }
        reader.reset(buffer.getData(), 0, buffer.size());
        try {
            for (int i = 0; i < buf.length; i++) {
                buf[i].readFields(reader);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return this;
    }

    /**
     * Extracting data from last get/extraction point.
     * 
     * @param buf
     * @return this.
     */
    public CompressedBlob extractData(IWritable... buf) {
        this.decode();
        try {
            for (int i = 0; i < buf.length; i++) {
                buf[i].readFields(reader);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return this;
    }

    /**
     * @see Object#hashCode()
     */
    @Override
    public int hashCode() {
        this.decode();

        int hash = buffer.size();
        byte[] data = buffer.getData();
        for (int i = 0; i < buffer.size(); i++) {
            hash = hash * 31 + (int) data[i];
        } // for i
        return hash;
    }

    @Override
    protected boolean equalsByField(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final CompressedBlob other = (CompressedBlob) obj;
        byte[] data_this = buffer.getData();
        byte[] data_that = other.buffer.getData();

        if (buffer.size() != other.buffer.size()) {
            return false;
        }

        for (int i = 0; i < buffer.size(); i++) {
            if (data_this[i] != data_that[i]) {
                return false;
            }
        }
        return true;
    }

    /**
     * only print the size.
     */
    @Override
    public String toString() {
        this.decode();
        return "CBLOB(" + buffer.size() + ")";
    }
}
