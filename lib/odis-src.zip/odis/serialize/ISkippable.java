package odis.serialize;

import java.io.DataInput;
import java.io.IOException;

/**
 * The interface representing that an object can be skipped in a DataInput. When
 * a data-structure implements this interface, the data can be fast skipped.
 * 
 * @author David
 */
public interface ISkippable {
    /**
     * Skips the fields in the DataInput. For the DataInput, this function is
     * like IWritable.readFields, but the data in this object is UNDEFINED (NOT
     * unchanged). <br>
     * <strong>NOTE</strong>: The implementation must assure the actually skipped
     * bytes are as specified, or an IOException is thrown.
     * 
     * @param in
     *            the DataInput instance
     * @throws IOException
     *             if an I/O error occurs
     */
    public void skipFields(DataInput in) throws IOException;
}
