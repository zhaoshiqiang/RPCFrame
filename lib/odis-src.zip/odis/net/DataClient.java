package odis.net;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.io.LzoInputStream;
import odis.io.NIOSocketHelper;
import odis.serialize.lib.UTF8Writable;
import toolbox.misc.LogFormatter;

/**
 * Retrieve file from dataserver with one thread and serve the data.
 * 
 * @author river
 */
public class DataClient {
    private static final Logger LOG = LogFormatter.getLogger(DataClient.class);

    private static final int DEFAULT_IO_TIMEOUT = 60000;

    private String host;

    private int port;

    private String path;

    private long size = -1;

    private int timeout;

    private boolean compressed;

    /**
     * construct a DataClient with the given host, port and path
     * 
     * @param host
     *            the DataServer host address
     * @param port
     *            the DataServer port address
     * @param path
     *            the DataServer file path
     */
    public DataClient(String host, int port, String path) {
        this(host, port, path, DEFAULT_IO_TIMEOUT);
    }

    /**
     * get the host address
     * 
     * @return the host name
     */
    public String getHost() {
        return host;
    }

    /**
     * get the host port
     * 
     * @return the port
     */
    public int getPort() {
        return port;
    }

    /**
     * get the file path
     * 
     * @return the given path
     */
    public String getPath() {
        return path;
    }
    /**
     * construct the DataClient with the given host,port,path and timeout
     * 
     * @param host the DataServer host address
     * @param port the DataServer port address
     * @param path  the DataServer file path
     * @param timeout the socket connect timeout
     */
    public DataClient(String host, int port, String path, int timeout) {
        this(host, port, path, false, timeout);
    }

    /**
     * 创建一个访问远程文件的客户端，这里没有打开连接，只有在具体的调用 的时候才会打开连接.
     * 
     * @param host
     *            the given host name
     * @param port
     *            the given port number
     * @param path
     *            the given file path
     * @param compressed
     *            the compressed flag
     * @param timeout
     *            the socket connect timeout
     */
    public DataClient(String host, int port, String path, boolean compressed,
            int timeout) {
        this.host = host;
        this.port = port;
        this.compressed = compressed;
        if (compressed) {
            this.path = DataServer.COMPRESS_TAG + path;
        } else {
            if (path.startsWith(DataServer.COMPRESS_TAG)) {
                this.compressed = true;
            }
            this.path = path;
        }
        this.timeout = timeout;
    }

    /**
     * 发送一个命令到DataServer，如果offset小于0，不输出offset，否则输出offset
     * 到DataServer，这个主要是考虑到SEEKTRANSFER的需要. 返回对应文件的大小.
     * 
     * @param cmd
     * @param offset
     * @return
     * @throws ConcurrentLimitException
     *             if concurrent limit reaches on dest server
     * @throws IOException
     */
    private long command(OutputStream os, InputStream is, byte cmd, long offset)
            throws IOException {
        if (LOG.isLoggable(Level.FINE)) {
            LOG.fine("Sending command " + cmd + " to remote dataserver " + host
                    + ":" + port + ", path=" + path);
        }

        CDataOutputStream out = new CDataOutputStream(os);
        out.writeByte(cmd);
        UTF8Writable filename = new UTF8Writable(path);
        filename.writeFields(out);
        if (offset >= 0) {
            out.writeLong(offset);
        } // if
        out.flush();

        CDataInputStream in = new CDataInputStream(is);
        long returnValue = in.readLong();
        if (returnValue == DataServer.ERR_NO_SUCH_FILE) {
            throw new IOException("cannot find file " + path);
        } else if (returnValue == DataServer.ERR_NO_SUCH_COMMAND) {
            throw new IOException("cannot find such command " + cmd);
        } else if (returnValue == DataServer.ERR_BAD_OFFSET) {
            throw new IOException("bad offset " + offset + " for file "
                    + filename);
        } else if (returnValue == DataServer.ERR_CONCURRENT_LIMIT) {
            throw new ConcurrentLimitException("concurrent limit for file "
                    + filename);
        } else if (returnValue < 0) {
            throw new IOException("unknown error found(" + returnValue + ")");
        } else {
            return returnValue;
        } // else
    }

    /**
     * 返回远程文件的大小.
     * 
     * @return
     * @throws IOException
     */
    public long size() throws IOException {
        if (size < 0) {
            NIOSocketHelper socketHelper = new NIOSocketHelper(host, port,
                    timeout);
            try {
                size = command(socketHelper.getOutputStream(), socketHelper
                        .getInputStream(), DataServer.CMD_LENGTH, -1);
            } finally {
                socketHelper.close();
            }
        } // if
        return size;
    }

    /**
     * 打开远程的文件并且从文件开头开始读取，相当于以参数0调用 {@link #open(long)}.
     * 
     * @return
     * @throws IOException
     */
    public InputStream open() throws IOException {
        return open(0);
    }

    /**
     * 打开远程文件的输入，offset 是起始的位置. 这里直接返回一个 InputStream，当这个 InputStream 关闭的时候，对应的
     * socket 也会被关闭. 这个方法每次调用的时候都打开新的连接.
     * 
     * @param offset
     * @return
     * @throws IOException
     */
    public InputStream open(long offset) throws IOException {
        NIOSocketHelper socketHelper = new NIOSocketHelper(host, port, timeout);
        boolean noClose = false;
        try {
            size = command(socketHelper.getOutputStream(), socketHelper
                    .getInputStream(), DataServer.CMD_SEEKTRANSFER, offset);
            noClose = true;
            if (compressed) {
                return new LzoInputStream(socketHelper.getInputStream());
            } else {
                return socketHelper.getInputStream();
            }
        } finally {
            if (!noClose)
                socketHelper.close();
        }
    }

    /**
     * Concurrent connect limit Exception
     */
    public static class ConcurrentLimitException extends IOException {
        private static final long serialVersionUID = -462628928580489733L;

        /**
         * construct a <code>ConcurrentLimitException</code> with message
         * 
         * @param message
         *            the Exception message
         */
        public ConcurrentLimitException(String message) {
            super(message);
        }
    }
}
