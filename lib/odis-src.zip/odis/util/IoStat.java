/**
 * @(#)IoStat.java, Jul 23, 2010. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.util;

import java.io.BufferedReader;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Get disk load information from 'iostat' program which is provided by
 * 'sysstat' package available on most linux distributions.
 * 
 * @author zhangkun
 */
public class IoStat {
    /**
     * A ValueSet is the load values printed by "iostat" at one time. It
     * includes a CPU-load map (avgCpuValues) and several disk device-load maps
     * (deviceValues).
     * 
     * @author zhangkun
     */
    public static class ValueSet {
        private final Map<String, Double> avgCpuValues;

        private final Map<String, Map<String, Double>> deviceValues;

        private ValueSet(Map<String, Double> avgCpuValues,
                Map<String, Map<String, Double>> deviceValues) {
            this.avgCpuValues = avgCpuValues;
            this.deviceValues = deviceValues;
        }

        /**
         * Get the key-value map for CPU loads
         * 
         * @return
         */
        public Map<String, Double> getAvgCpuValues() {
            return avgCpuValues;
        }

        /**
         * Get the key-value map for one disk device.
         * 
         * @param device
         * @return
         */
        public Map<String, Double> getDeviceValues(String device) {
            if (deviceValues.get(device) != null) {
                return deviceValues.get(device);
            }
            for (String dev: deviceValues.keySet()) {
                if (device.contains(dev))
                    return deviceValues.get(dev);
            }
            return null;
        }

        /**
         * Get all available disk device names
         * 
         * @return
         */
        public Set<String> getDevices() {
            return deviceValues.keySet();
        }

        @Override
        public String toString() {
            return "avg-cpu: " + avgCpuValues + ", device: " + deviceValues;
        }
    }

    private final ValueSet avgValue;

    private final ValueSet intervalValue;

    /**
     * Get the average load values since system boot till now.
     * 
     * @return
     */
    public ValueSet getAvgValue() {
        return avgValue;
    }

    /**
     * Get the load values collected during the interval.
     * 
     * @return
     */
    public ValueSet getIntervalValue() {
        return intervalValue;
    }

    /**
     * Get load values by invoking <code>iostat</code> command. This method will
     * at least take <b>interval</b> seconds to collect values.
     * 
     * @param interval
     *            The interval (in seconds) within which the load values are
     *            collected.
     */
    public IoStat(long interval) throws IOException {
        Process process = Runtime.getRuntime().exec(new String[] {
            "iostat", Long.toString(interval), "2", "-x", "-k"
        });
        BufferedReader reader = new BufferedReader(new InputStreamReader(
                process.getInputStream()));
        // the first value set is the average value since boot
        avgValue = parseOneValueSet(reader);
        // the second value set is collected after the given interval
        intervalValue = parseOneValueSet(reader);
        reader.close();
        try {
            process.waitFor();
        } catch (InterruptedException e) {}
    }

    /**
     * "iostat" outputs one value set every interval. This method parse one
     * value set from the command's output.
     * 
     * @param reader
     * @return
     * @throws IOException
     */
    private ValueSet parseOneValueSet(BufferedReader reader) throws IOException {
        Map<String, Double> avgCpuValues = null;
        Map<String, Map<String, Double>> deviceValues = null;
        String line;
        while ((line = reader.readLine()) != null) {
            if (line.startsWith("avg-cpu:")) {
                avgCpuValues = parseAvgCpuValues(reader, line);
                break;
            }
        }
        while ((line = reader.readLine()) != null) {
            if (line.startsWith("Device:")) {
                deviceValues = parseDeviceValues(reader, line);
                break;
            }
        }
        if (avgCpuValues == null) {
            throw new IOException("cannot find avg-cpu values");
        }
        if (deviceValues == null) {
            throw new IOException("cannot find Device values");
        }
        return new ValueSet(avgCpuValues, deviceValues);
    }

    private Map<String, Double> parseAvgCpuValues(BufferedReader reader,
            String headLine) throws IOException {
        String[] headers = headLine.split(" +");
        String valueLine = reader.readLine();
        if (valueLine == null) {
            throw new EOFException("Unexpected end of command output");
        }
        String[] values = valueLine.split(" +");
        if (values.length != headers.length) {
            throw new IOException("header '" + headLine + "' and values '"
                    + valueLine + "' doesn't match");
        }
        Map<String, Double> result = new HashMap<String, Double>();
        for (int i = 1; i < values.length; i++) {
            result.put(headers[i], Double.parseDouble(values[i]));
        }
        return result;
    }

    private Map<String, Map<String, Double>> parseDeviceValues(
            BufferedReader reader, String headLine) throws IOException {
        String[] headers = headLine.split(" +");
        Map<String, Map<String, Double>> result = new HashMap<String, Map<String, Double>>();
        while (true) {
            String line = reader.readLine();
            if (line == null || line.length() == 0) {
                break;
            }
            String[] values = line.split(" +");
            if (values.length != headers.length) {
                throw new IOException("header '" + headLine + "' and values '"
                        + Arrays.toString(values) + "' doesn't match");
            }
            Map<String, Double> devValue = new HashMap<String, Double>();
            for (int i = 1; i < values.length; i++) {
                devValue.put(headers[i], Double.parseDouble(values[i]));
            }
            result.put(values[0], devValue);
        }
        return result;
    }
}
