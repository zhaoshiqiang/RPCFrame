/**
 * @(#)DiskUsage.java, 2011-1-17. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.util;

import java.io.File;
import java.io.FileNotFoundException;

/**
 * Get disk space usage.
 * 
 * @author zhangduo
 */
public class DiskUsage {

    private long total;

    private long free;

    private long used;

    private double percentUsed;

    /**
     * The constructor.
     * 
     * @param path
     *            the path you want to get its space usage.
     * @throws FileNotFoundException
     */
    public DiskUsage(String path) throws FileNotFoundException {
        File f = new File(path);
        if (!f.exists()) {
            throw new FileNotFoundException("\"" + path + "\" not exists");
        }
        while (f != null && (total = f.getTotalSpace()) <= 0) {
            f = f.getParentFile();
        }
        if (f != null) {
            free = f.getFreeSpace();
            used = total - free;
            percentUsed = (double) used / total * 100;
        }

    }

    public long getTotal() {
        return total;
    }

    public long getFree() {
        return free;
    }

    public long getUsed() {
        return used;
    }

    public double getPercentUsed() {
        return percentUsed;
    }

}
