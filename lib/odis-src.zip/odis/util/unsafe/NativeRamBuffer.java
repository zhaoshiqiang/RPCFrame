/**
 * @(#)NativeRamBuffer.java, 2011-7-7. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.util.unsafe;

import odis.io.BufferOverflowException;
import toolbox.text.util.HexString;

/**
 * A buffer using native memory instead of heap.
 * <p>
 * You should use it as follow: <blockquote>
 * 
 * <pre>
 * long ptr = UnsafeHelper.unsafe.allocateMemory(capacity);
 * NativeRamBuffer buffer = new NativeRamBuffer(ptr, capacity);
 * ...
 * UnsafeHelper.unsafe.freeMemory(ptr);
 * </pre>
 * 
 * </blockquote>
 * <p>
 * Also, you can do things like: <blockquote>
 * 
 * <pre>
 * long ptr = UnsafeHelper.unsafe.allocateMemory(10 * capacity);
 * List&lt;NativeRamBuffer&gt; buffers = new ArrayList&lt;NativeRamBuffer&gt;(10);
 * for (int i = 0; i < 10; i++) {
 *     buffers.add(new NativeRamBuffer(ptr + (long) i * capacity, capacity));
 * }
 * ...
 * UnsafeHelper.unsafe.freeMemory(ptr);
 * </pre>
 * 
 * </blockquote>
 * 
 * @author zhangduo
 */
public class NativeRamBuffer {
    private final long ptr;

    private final long capacity;

    /**
     * Construct a NativeRamBuffer start at address <tt>ptr</tt> with the given
     * <tt>capacity</tt>.
     * 
     * @param ptr
     * @param capacity
     */
    public NativeRamBuffer(long ptr, long capacity) {
        if (capacity < 0) {
            throw new IllegalArgumentException();
        }
        this.ptr = ptr;
        this.capacity = capacity;
    }

    private void check(long pos, byte[] buffer, int offset, int length) {
        if (pos < 0 || offset < 0 || length < 0 || offset + length < 0
                || buffer.length < offset + length) {
            throw new IndexOutOfBoundsException();
        }
    }

    /**
     * Get the buffer contents start at pos to the given byte array.
     * 
     * @param pos
     *            relative to the start of this NativeRamBuffer, not absolute.
     * @param buffer
     * @param offset
     * @param length
     * @return
     */
    public int get(long pos, byte[] buffer, int offset, int length) {
        check(pos, buffer, offset, length);
        if (pos >= capacity || length == 0) {
            return 0;
        }
        int ret = (int) Math.min(capacity - pos, length);
        UnsafeHelper.copyToArray(ptr + pos, buffer, offset, ret);
        return ret;
    }

    /**
     * Put the byte array's contents to the buffer start at pos.
     * 
     * @param pos
     *            relative to the start of this NativeRamBuffer, not absolute.
     * @param buffer
     * @param offset
     * @param length
     */
    public void put(long pos, byte[] buffer, int offset, int length) {
        check(pos, buffer, offset, length);
        if (pos >= capacity || pos + length < 0 || pos + length > capacity) {
            throw new BufferOverflowException();
        }
        UnsafeHelper.copyFromArray(ptr + pos, buffer, offset, length);
    }

    /**
     * Copy the content of this NativeRamBuffer to dst NativeRamBuffer.
     * <p>
     * The copy is native to native.
     * 
     * @param srcPos
     * @param dst
     * @param dstPos
     * @param length
     */
    public void directCopyTo(long srcPos, NativeRamBuffer dst, long dstPos,
            long length) {
        if (srcPos < 0 || dstPos < 0 || length < 0 || srcPos + length < 0
                || dstPos + length < 0) {
            throw new IllegalArgumentException();
        }
        if (srcPos + length > capacity || dstPos + length > dst.capacity) {
            throw new BufferOverflowException();
        }
        if (ptr + srcPos < dst.ptr + dstPos
                && ptr + srcPos + length > dst.ptr + dstPos) {
            throw new IllegalArgumentException("copy region overlapped");
        }
        if (ptr + srcPos == dst.ptr + dstPos || length == 0) {
            return;
        }
        // This copy is native to native, DirectByteBuffer do it directly 
        // without splitting it into small copies, so we do it directly too. 
        UnsafeHelper.unsafe.copyMemory(ptr + srcPos, dst.ptr + dstPos, length);
    }

    /**
     * Get start postion.
     */
    public long getPtr() {
        return ptr;
    }

    /**
     * Get capacity.
     */
    public long getCapacity() {
        return capacity;
    }

    /**
     * Copy the byte array's content to several NativeRamBuffers.
     * 
     * @param buffers
     * @param arr
     * @param off
     * @param len
     */
    public static void copyFromArray(NativeRamBuffer[] buffers, byte[] arr,
            int off, int len) {
        if (off < 0 || len < 0 || off + len < 0 || arr.length < off + len) {
            throw new IndexOutOfBoundsException();
        }
        if (len == 0) {
            return;
        }
        for (NativeRamBuffer buffer: buffers) {
            int toCopy = (int) Math.min(len, buffer.capacity);
            UnsafeHelper.copyFromArray(buffer.getPtr(), arr, off, toCopy);
            off += toCopy;
            len -= toCopy;
            if (len == 0) {
                return;
            }
        }
    }

    /**
     * Copy several NativeRamBuffers' content to the given byte array.
     * 
     * @param buffers
     * @param arr
     * @param off
     * @param len
     */
    public static void copyToArray(NativeRamBuffer[] buffers, byte[] arr,
            int off, int len) {
        if (off < 0 || len < 0 || off + len < 0 || arr.length < off + len) {
            throw new IndexOutOfBoundsException();
        }
        if (len == 0) {
            return;
        }
        for (NativeRamBuffer buffer: buffers) {
            int toCopy = (int) Math.min(len, buffer.capacity);
            UnsafeHelper.copyToArray(buffer.getPtr(), arr, off, toCopy);
            off += toCopy;
            len -= toCopy;
            if (len == 0) {
                return;
            }
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        return "[NativeRamBuffer offset=" + HexString.longToPaddedHex(ptr)
                + " length=" + capacity + "]";
    }

}
