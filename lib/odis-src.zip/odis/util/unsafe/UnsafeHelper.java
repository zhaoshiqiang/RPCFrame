/**
 * @(#)UnsafeHelper.java, 2012-2-23. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.util.unsafe;

import java.lang.reflect.Field;

import sun.misc.Unsafe;

/**
 * Helper of sun.misc.Unsafe.
 * <p>
 * You should use copy method in this class instead of using unsafe's copy
 * method directly. The method in this class does some extra work when the
 * copied content is too small or too large.
 * <p>
 * If too small, direct unsafe.putByte will be faster than a jni call. See
 * {@link #JNI_COPY_ARRAY_THRESHOLD}
 * <p>
 * If too large, a single jni copy call will block gc for a long time, we should
 * split into several copies. See {@link #UNSAFE_COPY_THRESHOLD}
 * 
 * @author zhangduo
 */
public class UnsafeHelper {
    /**
     * Instance of sun.misc.Unsafe.
     */
    public static final Unsafe unsafe;

    /**
     * unsafe.arrayBaseOffset(byte[].class)
     */
    public static final long BYTE_ARRAY_BASE_OFFSET;

    /**
     * This number limits the number of bytes to copy per call to Unsafe's
     * copyMemory method. A limit is imposed to allow for safepoint polling
     * during a large copy
     */
    public static final long UNSAFE_COPY_THRESHOLD = 1024L * 1024L;

    /**
     * We only use jni array copy when the copied bytes length larger than this
     * value.
     */
    public static final long JNI_COPY_ARRAY_THRESHOLD = 8;

    static {
        try {
            Field field = Unsafe.class.getDeclaredField("theUnsafe");
            field.setAccessible(true);
            unsafe = (Unsafe) field.get(null);
            BYTE_ARRAY_BASE_OFFSET = unsafe.arrayBaseOffset(byte[].class);
        } catch (NoSuchFieldException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Test whether addr1 is lower than addr2
     */
    public static boolean lower(long addr1, long addr2) {
        return addr1 < addr2 ^ (addr1 < 0) ^ (addr2 < 0);
    }

    /**
     * Test whether addr1 is lower than addr2
     */
    public static boolean higher(long addr1, long addr2) {
        return addr1 > addr2 ^ (addr1 < 0) ^ (addr2 < 0);
    }

    /**
     * Found the nearest address higher than
     * <tt>addr<tt> that with alignment <tt>align</tt>.
     * 
     * @param addr
     * @param align
     *            must be power of 2.
     * @return
     */
    public static long align(long addr, int align) {
        return ((addr - 1) & ~(align - 1)) + align;
    }

    /**
     * Copy native content to byte array.
     * <p>
     * No range check, and len must be greater than 0.
     * 
     * @param addr
     * @param arr
     * @param off
     * @param len
     */
    public static void copyToArray(long addr, byte[] arr, int off, int len) {
        if (len > JNI_COPY_ARRAY_THRESHOLD) {
            off += BYTE_ARRAY_BASE_OFFSET;
            while (len > 0) {
                long size = Math.min(len, UNSAFE_COPY_THRESHOLD);
                unsafe.copyMemory(null, addr, arr, off, size);
                addr += size;
                off += size;
                len -= size;
            }
        } else {
            for (int i = off, end = off + len; i < end; i++, addr++) {
                arr[i] = unsafe.getByte(addr);
            }
        }
    }

    /**
     * Copy byte array content to native.
     * <p>
     * No range check, and len must be greater than 0.
     * 
     * @param addr
     * @param arr
     * @param off
     * @param len
     */
    public static void copyFromArray(long addr, byte[] arr, int off, int len) {
        if (len > JNI_COPY_ARRAY_THRESHOLD) {
            off += BYTE_ARRAY_BASE_OFFSET;
            while (len > 0) {
                long size = Math.min(len, UNSAFE_COPY_THRESHOLD);
                unsafe.copyMemory(arr, off, null, addr, size);
                addr += size;
                off += size;
                len -= size;
            }
        } else {
            for (int i = off, end = off + len; i < end; i++, addr++) {
                unsafe.putByte(addr, arr[i]);
            }
        }
    }

    /**
     * Read int with <tt>len</tt> bytes.
     * <p>
     * The int is little endian.
     * 
     * @param addr
     * @param len
     *            should be in range [1..3]
     * @return
     */
    public static int readPartialInt(long addr, int len) {
        int v = 0;
        switch (len) {
            case 3:
            case 1:
                v = UnsafeHelper.unsafe.getByte(addr) & 0xFF;
                if (len == 1) {
                    break;
                }
                addr++;
            case 2:
                v |= (UnsafeHelper.unsafe.getShort(addr) & 0xFFFF) << (8 * (len - 2));
                break;
            default:
                throw new IllegalArgumentException(len
                        + " is out of range [1,3]");
        }
        return v;
    }

    /**
     * Write int <tt>v</tt>'s lower <tt>len</tt> bytes.
     * 
     * @param v
     * @param addr
     * @param len
     *            should be in range [1..3]
     */
    public static void writePartialInt(int v, long addr, int len) {
        switch (len) {
            case 3:
            case 1:
                UnsafeHelper.unsafe.putByte(addr, (byte) v);
                if (len == 1) {
                    break;
                }
                v >>>= 8;
                addr++;
            case 2:
                UnsafeHelper.unsafe.putShort(addr, (short) v);
                break;
            default:
                throw new IllegalArgumentException(len
                        + " is out of range [1,3]");
        }
    }

    /**
     * Read long with <tt>len</tt> bytes.
     * <p>
     * The long is little endian.
     * 
     * @param addr
     * @param len
     *            should be in range [1..7]
     * @return
     */
    public static long readPartialLong(long addr, int len) {
        long v = 0;
        switch (len) {
            case 7:
            case 5:
            case 3:
            case 1:
                v = UnsafeHelper.unsafe.getByte(addr) & 0xFF;
                if (len == 1) {
                    break;
                }
                addr++;
            case 6:
            case 2:
                if (len != 5) {
                    v |= (UnsafeHelper.unsafe.getShort(addr) & 0xFFFF) << (8 * ((len & 3) - 2));
                    addr += 2;
                }
                if (len == 2 || len == 3) {
                    break;
                }
            case 4:
                v |= (((long) UnsafeHelper.unsafe.getInt(addr)) & 0xFFFFFFFFL) << (8 * (len - 4));
                break;
            default:
                throw new IllegalArgumentException(len
                        + " is out of range [1,7]");
        }
        return v;
    }

    /**
     * Write long <tt>v</tt>'s lower <tt>len</tt> bytes.
     * 
     * @param v
     * @param addr
     * @param len
     *            should be in range [1..7]
     */
    public static void writePartialLong(long v, long addr, int len) {
        switch (len) {
            case 7:
            case 5:
            case 3:
            case 1:
                UnsafeHelper.unsafe.putByte(addr, (byte) v);
                if (len == 1) {
                    break;
                }
                v >>>= 8;
                addr++;
            case 6:
            case 2:
                if (len != 5) {
                    UnsafeHelper.unsafe.putShort(addr, (short) v);
                    v >>>= 16;
                    addr += 2;
                }
                if (len == 2 || len == 3) {
                    break;
                }
            case 4:
                UnsafeHelper.unsafe.putInt(addr, (int) v);
                break;
            default:
                throw new IllegalArgumentException(len
                        + " is out of range [1,7]");
        }
    }
}
