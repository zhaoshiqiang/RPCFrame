/**
 * @(#)NativeRamBufferCDataInputStream.java, 2012-3-19. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.util.unsafe;

import java.io.DataInput;
import java.io.EOFException;
import java.io.InputStream;

import odis.io.CDataInputStream;
import odis.io.Seekable;
import odis.serialize.lib.StringWritable;

/**
 * A CDataInputStream with several NativeRamBuffer as its buffer.
 * 
 * @author zhangduo
 */
public class NativeRamBufferCDataInputStream extends InputStream implements
        DataInput, Seekable {

    private NativeRamBuffer[] buffers;

    private int indexOfBufferShift;

    private long offsetInBufferMask;

    private long count;

    private long mark;

    private long pos;

    /**
     * Construct a NativeRamBufferCDataInputStream.
     * <p>
     * Count should be less than or equal to sum of buffers' length.
     * <p>
     * The buffer size should be a power of 2 unless you have only one buffer,
     * and all the buffers' length should be bufferSize.
     * 
     * @param buffers
     * @param bufferSize
     * @param count
     */
    public NativeRamBufferCDataInputStream(NativeRamBuffer[] buffers,
            long bufferSize, long count) {
        resetBuffers(buffers, bufferSize, count);
    }

    /**
     * Reconstruct the InputStream.
     * <p>
     * Note that the <tt>pos</tt> will not be changed after this call, you
     * should call {@link #seek(long)} if you want to reset it to 0.
     * 
     * @param buffers
     * @param bufferSize
     * @param count
     */
    public void resetBuffers(NativeRamBuffer[] buffers, long bufferSize,
            long count) {
        if (buffers.length > 1 && bufferSize < Long.SIZE / Byte.SIZE) {
            throw new IllegalArgumentException(
                    "bufferSize is too small(less than long size)");
        }
        for (NativeRamBuffer buffer: buffers) {
            if (buffer.getCapacity() != bufferSize) {
                throw new IllegalArgumentException();
            }
        }
        if (count > bufferSize * buffers.length) {
            throw new IllegalArgumentException();
        }
        if (buffers.length <= 1) {
            this.indexOfBufferShift = 63;
            this.offsetInBufferMask = -1L;
            this.count = count;
        } else {
            int indexOfBufferShift = 0;
            for (long tmp = bufferSize; tmp > 1; indexOfBufferShift++) {
                if ((tmp & 1) != 0) {
                    throw new IllegalArgumentException();
                }
                tmp >>>= 1;
            }
            this.indexOfBufferShift = indexOfBufferShift;
            this.offsetInBufferMask = bufferSize - 1;
            this.count = count;
        }
        this.buffers = buffers;
    }

    /**
     * Get the back buffers directly.
     * <p>
     * This operation is not safe, change the returned buffers will effect the
     * InputStream.
     */
    public NativeRamBuffer[] getBuffers() {
        return buffers;
    }

    /**
     * Get current position.
     * 
     * @return
     */
    public long getPos() {
        return pos;
    }

    /**
     * Get the total bytes count.
     */
    public long getCount() {
        return count;
    }

    private int indexOfBuffer() {
        return (int) (pos >>> indexOfBufferShift);
    }

    private long offsetInBuffer() {
        return pos & offsetInBufferMask;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int read() {
        if (pos >= count) {
            return -1;
        }
        NativeRamBuffer buffer = buffers[indexOfBuffer()];
        long offsetInBuffer = offsetInBuffer();
        pos++;
        return UnsafeHelper.unsafe.getByte(buffer.getPtr() + offsetInBuffer) & 0xFF;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int read(byte[] b) {
        return read(b, 0, b.length);
    }

    private int readInternal(byte[] b, int off, int len) {
        int remaining = len;
        do {
            NativeRamBuffer buffer = buffers[indexOfBuffer()];
            long offsetInBuffer = offsetInBuffer();
            long bufferRemaining = Math.min(count - pos, buffer.getCapacity()
                    - offsetInBuffer);
            int toRead = (int) Math.min(remaining, bufferRemaining);
            UnsafeHelper.copyToArray(buffer.getPtr() + offsetInBuffer, b, off,
                    toRead);
            pos += toRead;
            off += toRead;
            remaining -= toRead;
        } while (pos < count && remaining > 0);
        return len - remaining;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int read(byte[] b, int off, int len) {
        if ((off < 0) || (off > b.length) || (len < 0)
                || ((off + len) > b.length) || ((off + len) < 0)) {
            throw new IndexOutOfBoundsException();
        }
        if (len == 0) {
            return 0;
        }
        if (pos >= count) {
            return -1;
        }
        return readInternal(b, off, len);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public long skip(long n) {
        long originPos = pos;
        pos = Math.min(count, originPos + n);
        return pos - originPos;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int available() {
        int remaining = (int) Math.min(count - pos, Integer.MAX_VALUE);
        return remaining;
    }

    /**
     * Set the current marked position in the stream. ByteArrayInputStream
     * objects are marked at position zero by default when constructed. They may
     * be marked at another position within the buffer by this method.
     * <p>
     * If no mark has been set, then the value of the mark is the offset passed
     * to the constructor (or 0 if the offset was not supplied).
     * <p>
     * Note: The <code>readAheadLimit</code> for this class has no meaning.
     * 
     * @since JDK1.1
     */
    @Override
    public void mark(int readlimit) {
        mark = pos;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void reset() {
        pos = mark;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean markSupported() {
        return true;
    }

    /**
     * Does nothing.
     */
    @Override
    public void close() {}

    /**
     * {@inheritDoc}
     */
    @Override
    public void readFully(byte[] b) throws EOFException {
        readFully(b, 0, b.length);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void readFully(byte[] b, int off, int len) throws EOFException {
        if ((off < 0) || (off > b.length) || (len < 0)
                || ((off + len) > b.length) || ((off + len) < 0)) {
            throw new IndexOutOfBoundsException();
        }
        if (len == 0) {
            return;
        }
        if (len > count - pos) {
            throw new EOFException();
        }
        readInternal(b, off, len);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int skipBytes(int n) {
        long originPos = pos;
        pos = Math.min(count, originPos + n);
        return (int) (pos - originPos);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean readBoolean() throws EOFException {
        return readByte() != 0;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public byte readByte() throws EOFException {
        return (byte) readUnsignedByte();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int readUnsignedByte() throws EOFException {
        if (pos >= count) {
            throw new EOFException();
        }
        NativeRamBuffer buffer = buffers[indexOfBuffer()];
        long offsetInBuffer = offsetInBuffer();
        pos++;
        return UnsafeHelper.unsafe.getByte(buffer.getPtr() + offsetInBuffer) & 0xFF;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public short readShort() throws EOFException {
        return (short) readUnsignedShort();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int readUnsignedShort() throws EOFException {
        if (pos >= count - 1) {
            throw new EOFException();
        }
        int bufferIndex = indexOfBuffer();
        NativeRamBuffer buffer = buffers[bufferIndex];
        long offsetInBuffer = offsetInBuffer();
        pos += 2;

        if (offsetInBuffer < buffer.getCapacity() - 1) {
            return UnsafeHelper.unsafe.getShort(buffer.getPtr()
                    + offsetInBuffer) & 0xFFFF;
        } else {
            int v1 = UnsafeHelper.unsafe.getByte(buffer.getPtr()
                    + offsetInBuffer) & 0xFF;
            buffer = buffers[bufferIndex + 1];
            int v2 = UnsafeHelper.unsafe.getByte(buffer.getPtr()) & 0xFF;
            return (v2 << 8 | v1);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public char readChar() throws EOFException {
        return (char) readUnsignedShort();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int readInt() throws EOFException {
        if (pos >= count - 3) {
            throw new EOFException();
        }
        int bufferIndex = indexOfBuffer();
        NativeRamBuffer buffer = buffers[bufferIndex];
        long offsetInBuffer = offsetInBuffer();
        pos += 4;

        if (offsetInBuffer < buffer.getCapacity() - 3) {
            return UnsafeHelper.unsafe.getInt(buffer.getPtr() + offsetInBuffer);
        } else {
            int firstPart = (int) (buffer.getCapacity() - offsetInBuffer);
            int v1 = UnsafeHelper.readPartialInt(buffer.getPtr()
                    + offsetInBuffer, firstPart);
            buffer = buffers[bufferIndex + 1];
            int secondPart = 4 - firstPart;
            int v2 = UnsafeHelper.readPartialInt(buffer.getPtr(), secondPart);
            return v2 << (firstPart * 8) | v1;
        }
    }

    /**
     * @see CDataInputStream#readVInt()
     */
    public int readVInt() throws EOFException {
        byte b = readByte();
        int i = b & 0x7F;
        for (int shift = 7; (b & 0x80) != 0; shift += 7) {
            b = readByte();
            i |= (b & 0x7F) << shift;
        } // for shift
        return i;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public long readLong() throws EOFException {
        if (pos >= count - 7) {
            throw new EOFException();
        }
        int bufferIndex = indexOfBuffer();
        NativeRamBuffer buffer = buffers[bufferIndex];
        long offsetInBuffer = offsetInBuffer();
        pos += 8;

        if (offsetInBuffer < buffer.getCapacity() - 7) {
            return UnsafeHelper.unsafe.getLong(buffer.getPtr() + offsetInBuffer);
        } else {
            int firstPart = (int) (buffer.getCapacity() - offsetInBuffer);
            long v1 = UnsafeHelper.readPartialLong(buffer.getPtr()
                    + offsetInBuffer, firstPart);
            buffer = buffers[bufferIndex + 1];
            int secondPart = 8 - firstPart;
            long v2 = UnsafeHelper.readPartialLong(buffer.getPtr(), secondPart);
            return v2 << (firstPart * 8) | v1;
        }
    }

    /**
     * @see CDataInputStream#readVLong()
     */
    public long readVLong() throws EOFException {
        byte b = readByte();
        long l = b & 0x7F;
        for (int shift = 7; (b & 0x80) != 0; shift += 7) {
            b = readByte();
            l |= ((long) (b & 0x7F)) << shift;
        } // for shift
        return l;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public float readFloat() throws EOFException {
        return Float.intBitsToFloat(readInt());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public double readDouble() throws EOFException {
        return Double.longBitsToDouble(readLong());
    }

    /**
     * Not implemented.
     */
    @Override
    public String readLine() throws EOFException {
        throw new UnsupportedOperationException();
    }

    /**
     * Not implemented.
     * <p>
     * Use {@link StringWritable#readString(DataInput)}
     */
    @Override
    public String readUTF() throws EOFException {
        throw new UnsupportedOperationException();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void seek(long pos) {
        this.pos = (int) Math.min(pos, count);
    }
}
