/**
 * @(#)NativeRamBufferCDataOutputStream.java, 2012-4-7. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.util.unsafe;

import java.io.DataOutput;
import java.io.OutputStream;
import java.util.Arrays;

import odis.io.BufferOverflowException;
import odis.io.CDataOutputStream;
import odis.serialize.lib.StringWritable;
import odis.serialize.lib.UTF16Writable;

/**
 * A CDataOutputStream with several NativeRamBuffer as its buffer.
 * 
 * @author zhangduo
 */
public class NativeRamBufferCDataOutputStream extends OutputStream implements
        DataOutput {

    private NativeRamBuffer[] buffers;

    private int indexOfBufferShift;

    private long offsetInBufferMask;

    private long pos;

    private long capacity;

    /**
     * Construct a NativeRamBufferCDataOutputStream.
     * <p>
     * Count should be less than or equal to sum of buffers' length.
     * <p>
     * The buffer size should be a power of 2 unless you have only one buffer,
     * and all the buffers' length should be bufferSize.
     * 
     * @param buffers
     * @param bufferSize
     */
    public NativeRamBufferCDataOutputStream(NativeRamBuffer[] buffers,
            long bufferSize) {
        resetBuffers(buffers, bufferSize);
    }

    /**
     * Append the <tt>newBuffers</tt> to the end of original buffers.
     * <p>
     * Each buffer in <tt>newBuffers</tt> should have the same size which is
     * equal to the original bufferSize.
     * 
     * @param newBuffers
     */
    public void appendBuffers(NativeRamBuffer[] newBuffers) {
        if (newBuffers.length == 0) {
            return;
        }
        NativeRamBuffer[] buffers = Arrays.copyOf(this.buffers,
                this.buffers.length + newBuffers.length);
        System.arraycopy(newBuffers, 0, buffers, this.buffers.length,
                newBuffers.length);
        resetBuffers(buffers, buffers[0].getCapacity());
    }

    /**
     * Reconstruct the OutputStream.
     * <p>
     * Note that the <tt>pos</tt> will not be changed after this call, you
     * should call {@link #resetToPos(long)} if you want to reset it to 0.
     * 
     * @param buffers
     * @param bufferSize
     */
    public void resetBuffers(NativeRamBuffer[] buffers, long bufferSize) {
        if (buffers.length > 1 && bufferSize < Long.SIZE / Byte.SIZE) {
            throw new IllegalArgumentException(
                    "bufferSize is too small(less than long size)");
        }
        for (NativeRamBuffer buffer: buffers) {
            if (buffer.getCapacity() != bufferSize) {
                throw new IllegalArgumentException();
            }
        }
        if (buffers.length <= 1) {
            this.indexOfBufferShift = 63;
            this.offsetInBufferMask = -1L;
        } else {
            int indexOfBufferShift = 0;
            for (long tmp = bufferSize; tmp > 1; indexOfBufferShift++) {
                if ((tmp & 1) != 0) {
                    throw new IllegalArgumentException();
                }
                tmp >>>= 1;
            }
            this.indexOfBufferShift = indexOfBufferShift;
            this.offsetInBufferMask = bufferSize - 1;
        }
        this.capacity = bufferSize * buffers.length;
        this.buffers = buffers;
    }

    /**
     * Get the back buffers directly.
     * <p>
     * This operation is not safe, change the returned buffers will effect the
     * OutputStream.
     */
    public NativeRamBuffer[] getBuffers() {
        return buffers;
    }

    /**
     * Get current position.
     * 
     * @return
     */
    public long getPos() {
        return pos;
    }

    /**
     * Reset position to the given <tt>pos</tt>.
     */
    public void resetToPos(long pos) {
        if (pos > capacity) {
            this.pos = capacity;
        } else if (pos < 0) {
            this.pos = 0;
        } else {
            this.pos = pos;
        }
    }

    /**
     * Get the total buffer size of this OutputStream.
     */
    public long getCapacity() {
        return capacity;
    }

    private void checkBound(int writeSize) {
        if (pos + writeSize > capacity) {
            throw new BufferOverflowException();
        }
    }

    private int indexOfBuffer() {
        return (int) (pos >>> indexOfBufferShift);
    }

    private long offsetInBuffer() {
        return pos & offsetInBufferMask;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void write(int b) {
        checkBound(1);
        NativeRamBuffer buffer = buffers[indexOfBuffer()];
        long offsetInBuffer = offsetInBuffer();
        pos++;
        UnsafeHelper.unsafe.putByte(buffer.getPtr() + offsetInBuffer, (byte) b);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void write(byte[] b) {
        write(b, 0, b.length);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void write(byte[] b, int off, int len) {
        if ((off < 0) || (off > b.length) || (len < 0)
                || ((off + len) > b.length) || ((off + len) < 0)) {
            throw new IndexOutOfBoundsException();
        }
        if (len == 0) {
            return;
        }
        checkBound(len);
        int remaining = len;
        do {
            NativeRamBuffer buffer = buffers[indexOfBuffer()];
            long offsetInBuffer = offsetInBuffer();
            int toWrite = (int) Math.min(remaining, buffer.getCapacity()
                    - offsetInBuffer);
            UnsafeHelper.copyFromArray(buffer.getPtr() + offsetInBuffer, b,
                    off, toWrite);
            pos += toWrite;
            off += toWrite;
            remaining -= toWrite;
        } while (remaining > 0);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeBoolean(boolean v) {
        write(v ? 1 : 0);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeByte(int v) {
        write(v);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeShort(int v) {
        checkBound(2);
        int bufferIndex = indexOfBuffer();
        NativeRamBuffer buffer = buffers[bufferIndex];
        long offsetInBuffer = offsetInBuffer();
        pos += 2;
        if (offsetInBuffer < buffer.getCapacity() - 1) {
            UnsafeHelper.unsafe.putShort(buffer.getPtr() + offsetInBuffer,
                    (short) v);
        } else {
            byte v1 = (byte) v;
            UnsafeHelper.unsafe.putByte(buffer.getPtr() + offsetInBuffer, v1);
            buffer = buffers[bufferIndex + 1];
            byte v2 = (byte) (v >>> 8);
            UnsafeHelper.unsafe.putByte(buffer.getPtr(), v2);
        }

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeChar(int v) {
        writeShort(v);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeInt(int v) {
        checkBound(4);
        int bufferIndex = indexOfBuffer();
        NativeRamBuffer buffer = buffers[bufferIndex];
        long offsetInBuffer = offsetInBuffer();
        pos += 4;

        if (offsetInBuffer < buffer.getCapacity() - 3) {
            UnsafeHelper.unsafe.putInt(buffer.getPtr() + offsetInBuffer, v);
        } else {
            int firstPart = (int) (buffer.getCapacity() - offsetInBuffer);
            int secondPart = 4 - firstPart;
            int firstShift = 8 * secondPart;
            int v1 = (v << firstShift) >>> firstShift;
            UnsafeHelper.writePartialInt(v1, buffer.getPtr() + offsetInBuffer,
                    firstPart);
            buffer = buffers[bufferIndex + 1];
            int secondShift = 8 * firstPart;
            int v2 = v >>> secondShift;
            UnsafeHelper.writePartialInt(v2, buffer.getPtr(), secondPart);
        }
    }

    /**
     * @see CDataOutputStream#writeVInt(int)
     */
    public int writeVInt(int v) {
        int size = 0;
        while ((v & ~0x7F) != 0) {
            write((byte) ((v & 0x7f) | 0x80));
            v >>>= 7;
            size++;
        }
        write((byte) v);
        return size + 1;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeLong(long v) {
        checkBound(8);
        int bufferIndex = indexOfBuffer();
        NativeRamBuffer buffer = buffers[bufferIndex];
        long offsetInBuffer = offsetInBuffer();
        pos += 8;

        if (offsetInBuffer < buffer.getCapacity() - 7) {
            UnsafeHelper.unsafe.putLong(buffer.getPtr() + offsetInBuffer, v);
        } else {
            int firstPart = (int) (buffer.getCapacity() - offsetInBuffer);
            int secondPart = 8 - firstPart;
            int firstShift = 8 * secondPart;
            long v1 = (v << firstShift) >>> firstShift;
            UnsafeHelper.writePartialLong(v1, buffer.getPtr() + offsetInBuffer,
                    firstPart);
            buffer = buffers[bufferIndex + 1];
            int secondShift = 8 * firstPart;
            long v2 = v >>> secondShift;
            UnsafeHelper.writePartialLong(v2, buffer.getPtr(), secondPart);
        }
    }

    /**
     * @see CDataOutputStream#writeVLong(long)
     */
    public int writeVLong(long v) {
        int size = 0;
        while ((v & ~(long) 0x7F) != 0) {
            write((byte) ((v & 0x7f) | 0x80));
            v >>>= 7;
            size++;
        }
        write((byte) v);
        return size + 1;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeFloat(float v) {
        writeInt(Float.floatToIntBits(v));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeDouble(double v) {
        writeLong(Double.doubleToLongBits(v));
    }

    /**
     * Not implemented.
     */
    @Override
    public void writeBytes(String s) {
        throw new UnsupportedOperationException();
    }

    /**
     * Not implemented.
     * <p>
     * Use {@link UTF16Writable#writeString(DataOutput, String)} instead.
     */
    @Override
    public void writeChars(String s) {
        throw new UnsupportedOperationException();
    }

    /**
     * Not implemented.
     * <p>
     * Use {@link StringWritable#writeString(DataOutput, String)} instead.
     */
    @Override
    public void writeUTF(String s) {
        throw new UnsupportedOperationException();
    }

}
