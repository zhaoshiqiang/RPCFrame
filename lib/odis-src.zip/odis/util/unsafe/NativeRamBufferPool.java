/**
 * @(#)NativeRamBufferPool.java, 2012-3-19. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.util.unsafe;

import java.util.ArrayList;
import java.util.BitSet;
import java.util.List;

/**
 * Manages {@link NativeRamBuffer} with a total size limit and chunk size.
 * <p>
 * This class is not thread safe.
 * 
 * @author zhangduo
 */
public class NativeRamBufferPool {

    private final long ptr;

    private final long maxBufferSize;

    private final long chunkSize;

    private final int totalChunk;

    private final BitSet usedBitSet;

    private long allocatedBufferSize;

    /**
     * Construct a NativeRamBufferPool start at address <tt>ptr</tt>.
     * <p>
     * The <tt>maxBufferSize</tt> should be divided with no remainder by
     * <tt>chunkSize</tt>.
     * 
     * @param ptr
     * @param maxBufferSize
     * @param chunkSize
     */
    public NativeRamBufferPool(long ptr, long maxBufferSize, long chunkSize) {
        this.maxBufferSize = maxBufferSize;
        this.chunkSize = chunkSize;
        if (maxBufferSize % chunkSize != 0) {
            throw new IllegalArgumentException("maxBufferSize " + maxBufferSize
                    + " can not be divided with no remainder by chunkSize "
                    + chunkSize);
        }
        long totalChunk = maxBufferSize / chunkSize;
        if (totalChunk > Integer.MAX_VALUE) {
            throw new IllegalArgumentException("too many chunks");
        }
        this.totalChunk = (int) totalChunk;
        this.ptr = ptr;
        usedBitSet = new BitSet(this.totalChunk);
    }

    /**
     * Return buffers which total size is larger than or equal to the given
     * <tt>size</tt> unless we do not have enough space.
     * <p>
     * Each will be <tt>chunkSize</tt> bytes, addresses may not be continuous.
     * 
     * @param size
     * @return
     */
    public NativeRamBuffer[] newBuffer(long size) {
        long leftSize = maxBufferSize - allocatedBufferSize;
        if (leftSize == 0) {
            return new NativeRamBuffer[0];
        } else if (leftSize < size) {
            size = leftSize;
        }
        List<NativeRamBuffer> buffers = new ArrayList<NativeRamBuffer>();
        int freeChunk = -1;
        long allocatedSize = 0;
        while (allocatedSize < size) {
            freeChunk = usedBitSet.nextClearBit(freeChunk + 1);
            if (freeChunk >= totalChunk) {
                break;
            }
            usedBitSet.set(freeChunk);
            allocatedSize += chunkSize;
            buffers.add(new NativeRamBuffer(ptr + (long) chunkSize * freeChunk,
                    chunkSize));
        }
        this.allocatedBufferSize += allocatedSize;
        return buffers.toArray(new NativeRamBuffer[0]);
    }

    private boolean managed(NativeRamBuffer buf) {
        if (UnsafeHelper.lower(buf.getPtr(), ptr)) {
            return false;
        }
        if (UnsafeHelper.higher(buf.getPtr() + buf.getCapacity(), ptr
                + maxBufferSize)) {
            return false;
        }
        if (buf.getCapacity() != chunkSize) {
            return false;
        }
        if ((buf.getPtr() - ptr) % chunkSize != 0) {
            return false;
        }
        return true;
    }

    /**
     * Release the NativeRamBuffer's space in the given <tt>bufs</tt>.
     * <p>
     * All the NativeRamBuffer in <tt>bufs</tt> should be managed by this pool.
     * 
     * @param bufs
     */
    public void releaseBuffer(NativeRamBuffer[] bufs) {
        int size = 0;
        for (NativeRamBuffer buf: bufs) {
            if (!managed(buf)) {
                throw new IllegalArgumentException(buf
                        + " is not managed by me");
            }
            size += buf.getCapacity();
            int usedSegment = (int) ((buf.getPtr() - ptr) / chunkSize);
            usedBitSet.clear(usedSegment);
        }
        allocatedBufferSize -= size;
    }

    /**
     * Get current used size.
     */
    public long getAllocatedBufferSize() {
        return allocatedBufferSize;
    }

    /**
     * Get max size.
     */
    public long getMaxBufferSize() {
        return maxBufferSize;
    }

    /**
     * Get chunk size.
     */
    public long getChunkSize() {
        return chunkSize;
    }

    /**
     * Get the chunk number we have.
     * <p>
     * The number should be getMaxBufferSize() / getChunkSize().
     */
    public int getTotalChunk() {
        return totalChunk;
    }
}
