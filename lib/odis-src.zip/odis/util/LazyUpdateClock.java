/**
 * @(#)LazyUpdateClock.java, 2009-2-25. 
 * 
 * Copyright 2009 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.util;

/**
 * An inaccurate clock which update its value from System.currentTimeMillis() in
 * a specified interval. It's less expensive than System.currentTimeMillis(),
 * therefore suitable in cases which need frequent checking of current system
 * time while accuracy is not so important.
 * 
 * @author zhangkun
 */
public class LazyUpdateClock extends Thread {
    private volatile long currentTimeMillis = System.currentTimeMillis();

    private final int updateInterval;

    /**
     * Constructor with initial updateInterval.
     * 
     * @param updateInterval
     */
    public LazyUpdateClock(int updateInterval) {
        this.setDaemon(true);
        this.setName("LazyUpdateClock" + this.hashCode());
        this.updateInterval = updateInterval;
    }

    public long getCurrentTimeMillis() {
        return currentTimeMillis;
    }

    @Override
    public void run() {
        while (true) {
            try {
                this.currentTimeMillis = System.currentTimeMillis();
                Thread.sleep(updateInterval);
            } catch (InterruptedException e) {
                return;
            }
        }
    }
}
