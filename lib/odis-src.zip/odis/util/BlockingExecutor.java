/*
 * Copyright (c) 2005,
 *  Yitao Duan, Jimmy Su, Feng Zhou and Li Zhuang
 *
 * Created on Jul 10, 2005
 */
package odis.util;

import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Logger;

import toolbox.misc.LogFormatter;

/**
 * Util class to create a ThreadPoolExecutor that blocks when there is no more
 * room in the queue.
 * 
 * @author zf
 */
public class BlockingExecutor {
    private final static Logger LOG = LogFormatter.getLogger(BlockingExecutor.class);

    /**
     * Stupid ThreadPoolExecutor does not allow blocking execute(). According to
     * Doug Lea, this is because blocking is bad. This class blocks enqueueing
     * when the queue is full.
     */
    private static class BlockingPolicy implements RejectedExecutionHandler {
        public void rejectedExecution(Runnable r, ThreadPoolExecutor executor) {
            for (;;)
                try {
                    if (!executor.isShutdown()) {
                        BlockingQueue<Runnable> q = executor.getQueue();
                        q.put(r);
                        return;
                    } else
                        return;
                } catch (InterruptedException e) {}
        }
    }

    // thread factory which returns daemon threads
    private static class DaemonThreadFactory implements ThreadFactory {
        static final AtomicInteger poolNumber = new AtomicInteger(1);

        final ThreadGroup group;

        final AtomicInteger threadNumber = new AtomicInteger(1);

        final String namePrefix;

        public DaemonThreadFactory() {
            SecurityManager s = System.getSecurityManager();
            group = (s != null) ? s.getThreadGroup()
                    : Thread.currentThread().getThreadGroup();
            namePrefix = "pool-" + poolNumber.getAndIncrement() + "-thread-";
        }

        @Override
        public Thread newThread(Runnable r) {
            Thread t = new Thread(group, r, namePrefix
                    + threadNumber.getAndIncrement(), 0);
            if (!t.isDaemon())
                t.setDaemon(true); // daemon threads
            if (t.getPriority() != Thread.NORM_PRIORITY)
                t.setPriority(Thread.NORM_PRIORITY);
            return t;
        }
    }

    /**
     * Create a blocking executor.
     * 
     * @param poolSize
     * @param queue
     * @return
     */
    public static ThreadPoolExecutor createExecutor(int poolSize,
            BlockingQueue<Runnable> queue) {
        ThreadPoolExecutor ex = new ThreadPoolExecutor(poolSize, poolSize,
                1000, TimeUnit.MILLISECONDS, queue, new DaemonThreadFactory());
        ex.setRejectedExecutionHandler(new BlockingPolicy());
        return ex;
    }

    /**
     * Create a blocking executor.
     * 
     * @param coreSize
     * @param maxSize
     * @param queue
     * @return
     */
    public static ThreadPoolExecutor createExecutor(int coreSize, int maxSize,
            BlockingQueue<Runnable> queue) {
        ThreadPoolExecutor ex = new ThreadPoolExecutor(coreSize, maxSize, 1000,
                TimeUnit.MILLISECONDS, queue, new DaemonThreadFactory());
        ex.setRejectedExecutionHandler(new BlockingPolicy());
        return ex;
    }

    /**
     * Wait for <code>ex</code> terminate using
     * {@link ThreadPoolExecutor#isTerminated()}. If wait for
     * <code>timeout</code> milliseconds, then force shutdown of the executor.
     * 
     * @param ex
     * @param timeout
     */
    public static void waitForTermination(ThreadPoolExecutor ex, long timeout) {
        long start = System.currentTimeMillis();
        while (!ex.isTerminated()) {
            try {
                Thread.sleep(timeout > 200 ? 200 : timeout);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if (!ex.isTerminated()) {
                if (timeout != 0
                        && System.currentTimeMillis() - start > timeout) {
                    // force shutdown
                    LOG.warning("Thread pool still not finished, force shutdown.");
                    List<Runnable> notstarted = ex.shutdownNow();
                    if (notstarted.size() > 0)
                        LOG.info(notstarted.size()
                                + " working thread-entries never started.");
                    if (ex.getActiveCount() > 0)
                        LOG.info("After force shutdown, " + ex.getActiveCount()
                                + " threads still active. Ignoring.");
                    return;
                }
            }
        }
    }

    /**
     * Wait for <code>ex</code> terminate by check its queue size. If wait for
     * <code>timeout</code> milliseconds, then force shutdown of the executor.
     * 
     * @param ex
     * @param timeout
     */
    public static void shutdownForTermination(ThreadPoolExecutor ex,
            long timeout) {
        long start = System.currentTimeMillis();
        while (ex.getQueue().size() != 0) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if (timeout != 0 && System.currentTimeMillis() - start > timeout)
                break;
        }
        LOG.warning("Thread pool still not finished, force shutdown.");
        List<Runnable> notstarted = ex.shutdownNow();
        if (notstarted.size() > 0)
            LOG.info(notstarted.size() + " fetch entries never started.");
        if (ex.getActiveCount() > 0)
            LOG.info("After force shutdown, " + ex.getActiveCount()
                    + " threads still active. Ignoring.");
    }
}
