/**
 * @(#)FileRecordQueue.java, 2007-6-10. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.logging.Logger;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.IWritable;
import toolbox.misc.LogFormatter;

/**
 * 基于文件的 [key, val] 队列，这个工具是为单线程使用实现的，多线程使用可能会 有问题. <br>
 * 存储的时候可以设置每个文件最大可以保存的记录的个数，这保证长期运行的情况下不会出现特别大的文件.
 * 
 * @author river
 */
public class FileRecordQueue<K extends IWritable, V extends IWritable> {
    private static final Logger LOG = LogFormatter.getLogger(FileRecordQueue.class);

    private static final int DEFAULT_READ_BUFFER_SIZE = 8192;

    private static final int DEFAULT_MAX_RECORDS_PER_FILE = 100000;

    private File dir;

    private int maxRecordsPerFile;

    private int readBufferSize;

    private CDataInputStream is = null;

    private long currentReadFileNo = -1;

    private long readIdx = 0;

    private CDataOutputStream os = null;

    private long writeIdx = 0;

    private long currentWriteFileNo = -1;

    private boolean dataNotFlushed = false;

    /**
     * 创建一个FileRecordQueue,并且将数据保存在指定的目录下. 默认情况一个文件中最大容纳100000个记录，读缓冲的大小为8192字节.
     * 
     * @param file
     * @throws IOException
     */
    public FileRecordQueue(File dir) throws IOException {
        this(dir, DEFAULT_MAX_RECORDS_PER_FILE, DEFAULT_READ_BUFFER_SIZE);
    }

    /**
     * 创建一个FileRecordQueue，将数据保存在指定的目录下，并且使用给定的最大文件中记录数以及 读缓冲的大小.
     * 
     * @param dir
     * @param maxRecordsPerFile
     * @param readBufferSize
     * @throws IOException
     */
    public FileRecordQueue(File dir, int maxRecordsPerFile, int readBufferSize)
            throws IOException {
        this.dir = dir;
        if (!dir.exists()) {
            if (!dir.mkdirs()) {
                throw new IOException("Mkdir " + dir + " failed");
            }
        }
        this.readBufferSize = readBufferSize;
        this.maxRecordsPerFile = maxRecordsPerFile;
    }

    /**
     * 将[key, value]放入队列.
     * 
     * @param key
     * @param value
     * @throws IOException
     */
    public synchronized void put(K key, V value) throws IOException {
        long fileNo = writeIdx / maxRecordsPerFile;
        if (fileNo != currentWriteFileNo) {
            if (os != null) {
                os.close();
                os = null;
                dataNotFlushed = false;
            }

            os = new CDataOutputStream(
                    new BufferedOutputStream(new FileOutputStream(new File(dir,
                            String.valueOf(fileNo)))));
            currentWriteFileNo = fileNo;
        }

        key.writeFields(os);
        value.writeFields(os);
        writeIdx++;
        dataNotFlushed = true;
    }

    /**
     * 从队列中读出[key, value].
     * 
     * @param key
     * @param value
     * @return
     * @throws IOException
     */
    public synchronized boolean poll(K key, V value) throws IOException {
        if (readIdx == writeIdx) {
            return false;
        }

        long fileNo = readIdx / maxRecordsPerFile;
        if (fileNo != currentReadFileNo) {
            if (is != null) {
                is.close();
                is = null;
                File currentReadFile = new File(dir,
                        Long.toString(currentReadFileNo));
                if (!currentReadFile.delete()) {
                    LOG.warning("Delete " + currentReadFile
                            + " failed when polling");
                }
            }
            is = new CDataInputStream(new BufferedInputStream(
                    new FileInputStream(new File(dir, String.valueOf(fileNo))),
                    readBufferSize));
            currentReadFileNo = fileNo;
        }

        if (currentReadFileNo == currentWriteFileNo && dataNotFlushed) {
            os.flush();
            dataNotFlushed = false;
        }

        readIdx++;
        key.readFields(is);
        value.readFields(is);
        return true;
    }

    /**
     * Close the queue and delete the queue files.
     */
    public void close() {
        try {
            is.close();
        } catch (IOException e) {}
        try {
            os.close();
        } catch (IOException e) {}

        File[] childs = dir.listFiles();
        if (childs != null) {
            for (File c: childs) {
                if (!c.delete()) {
                    LOG.warning("Delete " + c + " failed when closing");
                }
            }
        }
        if (dir.delete()) {
            LOG.warning("Delete " + dir + " failed when closing");
        }

    }

}
