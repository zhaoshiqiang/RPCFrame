/**
 * @(#)MountPoints.java, Jul 27, 2010. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

import odis.io.Path;

/**
 * Get mount points from 'mount' command.
 * 
 * @author zhangkun
 */
public class MountPoints {
    private Map<String, String> mountPointToDev;

    private Map<String, String> devToMountPoint;

    /**
     * Default constructor.
     * 
     * @throws IOException
     */
    public MountPoints() throws IOException {
        Process process = Runtime.getRuntime().exec(new String[] {
            "mount"
        });
        BufferedReader lines = null;
        try {
            if (process.waitFor() == 0) {
                lines = new BufferedReader(new InputStreamReader(
                        process.getInputStream()));
                mountPointToDev = new HashMap<String, String>();
                devToMountPoint = new HashMap<String, String>();
                for (String line; (line = lines.readLine()) != null;) {
                    String[] split = line.split(" ");
                    String dev = split[0];
                    if (dev.equals("none")) {
                        continue;
                    }
                    String mountPoint = split[2];
                    mountPointToDev.put(mountPoint, dev);
                    devToMountPoint.put(dev, mountPoint);
                }
            } else {
                lines = new BufferedReader(new InputStreamReader(
                        process.getErrorStream()));
                throw new IOException(lines.readLine());
            }
        } catch (InterruptedException e) {
            throw new IOException(e);
        } finally {
            MiscUtils.safeClose(lines);
            process.destroy();
        }

    }

    /**
     * Get mount point -> device mapping.
     * 
     * @return
     */
    public Map<String, String> getMountPointToDevMap() {
        return mountPointToDev;
    }

    /**
     * Get device -> mount point mapping.
     * 
     * @return
     */
    public Map<String, String> getDevToMountPointMap() {
        return devToMountPoint;
    }

    /**
     * Try to find which device the given path locates on, based on the mount
     * points.
     * 
     * @param path
     * @return the device's full path, like "/dev/sda1"
     */
    public String getDevFromPath(String path) {
        Path p = new Path(path);
        while (p != null) {
            String dev = mountPointToDev.get(p.getAbsolutePath());
            if (dev != null) {
                return dev;
            }
            p = p.getParentFile();
        }
        // this should not happen, because any path should find its device
        throw new RuntimeException("Could not find device for " + path);
    }
}
