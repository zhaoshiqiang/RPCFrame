/**
 * @(#)ByteArrayBufferPool.java, 2011-7-28. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.util;

/**
 * Pool for bytes arrays.
 * 
 * @author zhangduo
 */
public interface ByteArrayBufferPool {
    /**
     * get a byte array with length larger than or equal to size
     * 
     * @param size
     * @return
     */
    byte[] allocate(int size);

    /**
     * return the byte array to pool
     * 
     * @param buffer
     */
    void release(byte[] buffer);
}
