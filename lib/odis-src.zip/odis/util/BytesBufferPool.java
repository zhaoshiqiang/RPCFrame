/**
 * @(#)BytesBufferPool.java, 2007-8-29. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.util;

import java.util.Iterator;
import java.util.LinkedList;

import odis.io.Limit;

/**
 * Pool for bytes arrays.
 * 
 * @author river
 */
public class BytesBufferPool {

    private LinkedList<byte[]> freeList = new LinkedList<byte[]>();

    private int createdCount = 0;

    private int maxPoolSize = 0;

    private int maxResidentBufferSize = Integer.MAX_VALUE;

    /**
     * Create pool which holds at most maxPoolSize buffers.
     * 
     * @param maxPoolSize
     */
    public BytesBufferPool(int maxPoolSize) {
        this(maxPoolSize, Integer.MAX_VALUE);
    }

    /**
     * Create pool which holds at most maxPoolSize buffers, and the max size of
     * each buffer should be no larger than maxResidentBufferSize.
     * 
     * @param maxPoolSize
     * @param maxResidentBufferSize
     */
    public BytesBufferPool(int maxPoolSize, int maxResidentBufferSize) {
        this.maxPoolSize = maxPoolSize;
        this.maxResidentBufferSize = maxResidentBufferSize;
    }

    /**
     * Allocate one buffer whose size is equal or greater than given size.
     * 
     * @param size
     * @return
     */
    public synchronized byte[] allocate(int size) {
        while (true) {
            for (Iterator<byte[]> it = freeList.iterator(); it.hasNext();) {
                byte[] b = it.next();
                if (b.length >= size) {
                    it.remove();
                    return b;
                }
            }
            if (createdCount < maxPoolSize) {
                createdCount++;
                return Limit.createBuffer(size);
            } else if (!freeList.isEmpty()) {
                freeList.remove();
                return Limit.createBuffer(size);
            }
            try {
                this.wait();
            } catch (InterruptedException e) {}
        }
    }

    /**
     * Release buffer into the pool.
     * 
     * @param buf
     */
    public synchronized void release(byte[] buf) {
        if (buf.length > maxResidentBufferSize) {
            createdCount--;
        } else {
            freeList.add(buf);
        }

        this.notify();
    }

    /**
     * Return the actural size of pool.
     * 
     * @return
     */
    public synchronized int getPoolSize() {
        return freeList.size();
    }

}
