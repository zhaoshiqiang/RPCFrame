/*
 * Copyright (c) 2006, Outfox Team. Created on Aug 1, 2006
 */
package odis.rpc;

/**
 * All kinds of constants for the RPC package.
 * 
 * @author zf
 */
@Deprecated
public class RpcConstants {
    public final static long CLIENT_CONNECTION_STACK_SIZE = 512 * 1024;

    public final static long SERVER_CONNECTION_STACK_SIZE = 512 * 1024;

    public final static String CALL_PROPERTY_DOMAIN = "DOMAIN";

    public final static String CALL_PROPERTY_TIMEOUT = "TIMEOUT";
}
