/**
 * @(#)WritableArrayProtocol.java, 2010-8-18. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc.bench;

import java.io.IOException;

import odis.serialize.lib.LongWritable;
import odis.serialize.lib.StringWritable;

/**
 * Test Protocol
 * 
 * @author zhangduo
 */
public interface WritableArrayProtocol {

    /**
     * put test method
     * 
     * @param array
     * @throws IOException
     */
    void put(LongWritable[] array) throws IOException;

    /**
     * getLong test method
     * 
     * @param size
     * @return
     * @throws IOException
     */
    LongWritable[] getLong(int size) throws IOException;

    /**
     * put test method
     * 
     * @param array
     * @throws IOException
     */
    void put(StringWritable[] array) throws IOException;

    /**
     * getString test method
     * 
     * @param size
     * @return
     * @throws IOException
     */
    StringWritable[] getString(int size) throws IOException;

    /**
     * put test method
     * 
     * @param array
     * @throws IOException
     */
    void put(SimpleWritable[] array) throws IOException;

    /**
     * getSimple test method
     * 
     * @param size
     * @return
     * @throws IOException
     */
    SimpleWritable[] getSimple(int size) throws IOException;
}
