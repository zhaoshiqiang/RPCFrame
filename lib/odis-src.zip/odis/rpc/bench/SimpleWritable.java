/**
 * @(#)SimpleWritable.java, 2010-8-18. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc.bench;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.IWritable;

/**
 * @author zhangduo
 */
public class SimpleWritable implements IWritable {

    private int i;

    private long l;

    public SimpleWritable() {}

    public SimpleWritable(int i, long l) {
        this.i = i;
        this.l = l;
    }

    public int getI() {
        return i;
    }

    public void setI(int i) {
        this.i = i;
    }

    public long getL() {
        return l;
    }

    public void setL(long l) {
        this.l = l;
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        i = in.readInt();
        l = in.readLong();

    }

    @Override
    public void writeFields(DataOutput out) throws IOException {
        out.writeInt(i);
        out.writeLong(l);
    }

    @Override
    public IWritable copyFields(IWritable value) {
        SimpleWritable v = (SimpleWritable) value;
        i = v.i;
        l = v.l;
        return this;
    }

}
