/**
 * @(#)MultiThreadBenchmarkString.java, 2010-8-18. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc.bench;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.logging.Logger;

import odis.rpc2.RPC;
import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
public class MultiThreadBenchmarkString {

    private static final Logger LOG = LogFormatter.getLogger(MultiThreadBenchmarkString.class);

    private StringProtocol client;

    private int n = 10000;

    private int threadNumber = 50;

    private class ClientThread extends Thread {

        private String str;

        private long time;

        public ClientThread(int index) {
            super("ClientThread-" + index);
            str = RandomUtils.getString(RandomUtils.rand.nextInt(50));
        }

        @Override
        public void run() {
            LOG.info(getName() + " started");
            try {
                for (int i = 0; i < n; i++) {
                    long start = System.currentTimeMillis();
                    client.echo(str);
                    time += System.currentTimeMillis() - start;
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            LOG.info(getName() + " ended, total time " + time + "ms");
        }
    }

    private ClientThread[] threads;

    public void run() throws InterruptedException {
        threads = new ClientThread[threadNumber];
        for (int i = 0; i < threadNumber; i++) {
            threads[i] = new ClientThread(i);
        }
        for (int i = 0; i < threadNumber; i++) {
            threads[i].start();
        }
        for (int i = 0; i < threadNumber; i++) {
            threads[i].join();
        }
    }

    public static void main(String[] args) throws IOException,
            InterruptedException {
        String[] ss = args[0].split(":");
        String host = ss[0];
        int port = Integer.parseInt(ss[1]);
        MultiThreadBenchmarkString bench = new MultiThreadBenchmarkString();
        if (args[1].equals("rpc2")) {
            bench.client = (StringProtocol) RPC.getProxy(StringProtocol.class,
                    new InetSocketAddress(host, port));
        } else {
            bench.client = (StringProtocol) odis.rpc.RPC.getProxy(
                    StringProtocol.class, new InetSocketAddress(host, port));
        }
        bench.threadNumber = Integer.parseInt(args[2]);
        bench.n = Integer.parseInt(args[3]);
        bench.run();
    }
}
