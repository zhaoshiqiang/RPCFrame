/**
 * @(#)ByteArrayProtocolImpl.java, 2010-8-17. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc.bench;

import java.io.IOException;

import odis.rpc.RpcServer;
import odis.rpc2.AbstractRpcServer;
import odis.rpc2.RPC;

/**
 * @author zhangduo
 */
public class ByteArrayProtocolImpl implements ByteArrayProtocol {

    @Override
    public byte[] get(int size) throws IOException {
        return new byte[size];
    }

    @Override
    public void put(byte[] bytes) throws IOException {}

    public static void main(String[] args) throws Exception {
        int port = Integer.parseInt(args[0]);
        if (args[1].equals("rpc2")) {
            AbstractRpcServer server = RPC.getServer(ByteArrayProtocol.class,
                    new ByteArrayProtocolImpl(), port, 20, 1000, 2, 0);
            server.start();
            server.join();
        } else if (args[1].equals("nio")) {
            AbstractRpcServer server = RPC.getNIOServer(
                    ByteArrayProtocol.class, new ByteArrayProtocolImpl(), port,
                    20, 1000, 2, 0);
            server.start();
            server.join();
        } else {
            RpcServer server = odis.rpc.RPC.getServer(
                    new ByteArrayProtocolImpl(), port, 20, false);
            server.start();
            server.join();
        }
    }

}
