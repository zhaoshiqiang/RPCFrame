/**
 * @(#)StringProtocol.java, 2010-8-18. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc.bench;

import java.io.IOException;

/**
 * Test Protocol
 * 
 * @author zhangduo
 */
public interface StringProtocol {

    /**
     * echo test method
     * 
     * @param str
     * @return
     * @throws IOException
     */
    String echo(String str) throws IOException;
}
