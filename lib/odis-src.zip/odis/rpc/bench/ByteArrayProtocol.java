/**
 * @(#)ByteArrayProtocol.java, 2010-8-17. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc.bench;

import java.io.IOException;

/**
 * Test Protocol
 * 
 * @author zhangduo
 */
public interface ByteArrayProtocol {
    /**
     * get test method
     * 
     * @param size
     * @return
     * @throws IOException
     */
    byte[] get(int size) throws IOException;

    /**
     * put test method
     * 
     * @param bytes
     * @throws IOException
     */
    void put(byte[] bytes) throws IOException;
}
