/**
 * @(#)ServerCallListenerImpl.java, 2010-8-17. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc.bench;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.logging.Logger;

import odis.rpc2.PermissionManager.PermitType;
import odis.rpc2.ClientInfo;
import odis.rpc2.ServerCallListener;
import toolbox.misc.LogFormatter;

/**
 * @author zhangduo
 */
public class ServerCallListenerImpl implements ServerCallListener {

    private static final Logger LOG = LogFormatter.getLogger(ServerCallListener.class);

    @Override
    public void callTimeout(Method method, Object returnValue, Throwable error,
            Object attach) {
        LOG.info("callTimeout method = " + method + " returnValue = "
                + returnValue + " error = " + error + " attach = " + attach);
    }

    @Override
    public Object createAttach(ClientInfo clientInfo) {
        return clientInfo;
    }

    @Override
    public void endCall(Method method, Object returnValue, Throwable error,
            Object attach) {
        LOG.info("endCall method = " + method + " returnValue = " + returnValue
                + " error = " + error + " attach = " + attach);

    }

    @Override
    public void endReceive(Method method, Object[] args, Object attach) {
        LOG.info("endReceive method = " + method + " args = "
                + Arrays.toString(args) + " attach = " + attach);

    }

    @Override
    public void endSend(Method method, Object attach) {
        LOG.info("endSend method = " + method + " attach = " + attach);

    }

    @Override
    public void getPermit(Method method, PermitType permit, Object attach) {
        LOG.info("getPermit method = " + method + " permit = " + permit
                + " attach = " + attach);
    }

    @Override
    public void startCall(Method method, Object attach) {
        LOG.info("startCall method = " + method + " attach = " + attach);

    }

    @Override
    public void startReceive(Method method, Object attach) {
        LOG.info("startReceive method = " + method + " attach = " + attach);

    }

    @Override
    public void startSend(Method method, Object attach) {
        LOG.info("startSend method = " + method + " attach = " + attach);

    }

}
