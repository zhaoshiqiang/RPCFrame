/**
 * @(#)UDPCallClient.java, 2008-6-17. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;

import odis.io.DataOutputBuffer;
import odis.serialize.IWritable;

/**
 * UDP 请求的客户端.
 * 
 * @author river
 *
 */
public class UDPCallClient {
    private InetSocketAddress addr;
    private DatagramSocket socket;
    
    protected UDPCallClient(InetSocketAddress addr) throws IOException {
        this.addr = addr;
        this.socket = new DatagramSocket();
    }
    
    protected void call(IWritable param) throws RpcException {
        DataOutputBuffer obuf = new DataOutputBuffer();
        try {
            param.writeFields(obuf);
        } catch(IOException e) {
            throw new RpcException("write param failed", e);
        }
        
        try {
            DatagramPacket packet = new DatagramPacket(obuf.getData(), obuf.size());
            packet.setSocketAddress(addr);
            socket.send(packet);
        } catch(IOException e) {
            throw new RpcException("send udp request failed", e);
        }
        
    }
    
}
