/*
 * Copyright (c) 2006, Outfox Team.
 *
 * Created on May 21, 2006
 */
package odis.rpc;

/**
 * Thrown when an RPC method fails due to serializationi exceptions of 
 * parameters or the return value, e.g. when <code>readFields()</code> of
 * a parameter Writable throws an exception.
 *  
 * @author zf
 */
@Deprecated
public class RpcWritableException extends RpcException {
    private static final long serialVersionUID = 1L;

    public RpcWritableException(String message, Throwable e) {
        super(message, e);
    }
}
