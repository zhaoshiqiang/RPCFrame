/**
 * Copyright 2005 The Apache Software Foundation Licensed under the Apache
 * License, Version 2.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0 Unless required by applicable law
 * or agreed to in writing, software distributed under the License is
 * distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

package odis.rpc;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Stack;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;
import odis.serialize.lib.UTF8Writable;
import odis.serialize.toolkit.WritableMap;
import odis.util.DaemonTracker;
import toolbox.collections.ArrayQueue;
import toolbox.misc.LogFormatter;

/**
 * An abstract IPC service. IPC calls take a single {@link IWritable} as a
 * parameter, and return a {@link IWritable} as their value. A service runs on a
 * port and is defined by a parameter class and a value class.
 * <p>
 * The client maintains a long-running connection to the server in normal cases.
 * The server can get notified if a client disconnect itself from the server,
 * which is useful for detecting unexpected client failures. This is set up by
 * {@link #addClientDisconnectListener(ClientDisconnectListener)}.
 * <p>
 * Note: you generally do not want to construct this by hand. See
 * {@link odis.rpc.RPC#getServer(Object, int)} for the easy-to-use RPC server
 * interface.
 * 
 * @author Doug Cutting
 * @author Feng Zhou (client disconnect notification)
 * @see RpcClient
 */
@Deprecated
public abstract class RpcServer {
    public static final Logger LOG = LogFormatter.getLogger(RpcServer.class.getName());

    public static final Logger CALL_LOG = LogFormatter.getLogger("rpcserver.call");

    /**
     * sign no error occur
     */
    public static final byte ERROR_SUCCESS = 0;

    /**
     * sign a exception throwed
     */
    public static final byte ERROR_EXCEPTION = 1;

    // public static final byte ERROR_APPLICATION = 2;

    private static final int MIN_QUEUE_SIZE = 100;

    private int port; // port we listen on

    private int handlerCount; // number of handler threads

    private int reservedHandlerCount; // max number of idle handler threads

    // before starting inhibition

    private int maxQueuedCalls; // max number of queued calls

    private Class<?> paramClass; // class of call parameters

    private volatile boolean running = true; // true while server runs

    // The callQueue and waitingQueue work together.
    // Reading and writing of the both queues should be inside synchronized(callQueue).
    // Writing of the 2 queues should be followed by callQueue.notify(). 
    private final Queue<Call> callQueue;

    private final Queue<Call> waitingQueue;

    private ClientDisconnectListener clientDisconnectListener;

    // private LinkedList<Call> callQueue = new LinkedList<Call>(); // queued
    // calls
    // private Object callDequeued = new Object(); // used by wait/notify

    public int getPort() {
        return port;
    }

    /** A call queued for handling. */
    static class Call {
        private int id; // the client's call id

        private long receiveStart; // when first byte of the call is received,

        // for tracing

        private long receiveEnd; // when last byte of the call is received,

        // for tracing

        private WritableMap<StringWritable, StringWritable> pptMap;

        private IWritable param; // the parameter passed

        private Connection connection; // connection to client

        public Call(int id, WritableMap<StringWritable, StringWritable> pptMap,
                IWritable param, Connection connection, long receiveStart,
                long receiveEnd) {
            this.id = id;
            this.pptMap = pptMap;
            this.param = param;
            this.connection = connection;
            this.receiveStart = receiveStart;
            this.receiveEnd = receiveEnd;
        }

        public boolean hasProperties() {
            return pptMap != null;
        }

        public String getProperty(String pptName) {
            StringWritable value = (StringWritable) pptMap.get(new StringWritable(
                    pptName));
            return value.get();
        }

        public String toString() {
            return id + "[" + pptMap.toString() + "]:" + param + " from "
                    + connection.socket.getRemoteSocketAddress();
        }
    }

    /** Listens on the socket, starting new connection threads. */
    private class Listener extends Thread {
        private ServerSocket socket;

        public Listener() throws IOException {
            synchronized (System.out) {
                this.socket = new ServerSocket(port);
            } // synchronized System.out
              // David: In multi-threaded program, no sychronizing this causes a
              // SocketException
              // instead of a BindException is thrown when two threads are trying
              // bind the
              // the same port.
            port = this.socket.getLocalPort();
            // David: get back port in case that port is set to ZERO.
            this.setDaemon(true);
            this.setName("Server listener on "
                    + socket.getInetAddress().getHostAddress() + ":" + port);
        }

        public void run() {
            LOG.info(getName() + ": starting");
            DaemonTracker tr = new DaemonTracker();
            while (running) {
                try {
                    Connection con = new Connection(socket.accept());
                    Thread t = new Thread(null, con, "Server connection on "
                            + port + " from "
                            + con.socket.getInetAddress().getHostAddress()
                            + ":" + con.socket.getPort(),
                            RpcConstants.SERVER_CONNECTION_STACK_SIZE);
                    t.setDaemon(true);
                    con.thread = t; // record thread for use during shutdown
                    synchronized (activeConnections) {
                        activeConnections.add(con);
                    }
                    t.start(); // start a new connection
                } catch (EOFException e) { // zf: eof for linux according to
                    // orig nutch code
                } catch (SocketException e) { // zf: eof for windows
                } catch (Throwable e) { // log all other exceptions
                    tr.gotThrowable(e);
                }
            }
            try {
                socket.close();
            } catch (IOException e) {
                LOG.log(Level.WARNING, "close listener socket failed", e);
            }
            if (LOG.isLoggable(Level.FINE)) {
                LOG.fine(getName() + ": exiting");
            }
        }
    }

    // current active connection, used for shutting down the server
    List<Connection> activeConnections = new ArrayList<Connection>();

    /** Reads calls from a connection and queues them for handling. */
    class Connection implements Runnable {
        private static final int BUFFER_SIZE = 8 * 1024;

        private static final boolean TCP_NO_DELAY = true;

        protected Socket socket;

        private CDataInputStream in;

        private CDataOutputStream out;

        private Thread thread;

        private boolean receiveCallProperties = false;

        // private String clientName; // for reporting errors

        List<String> clientNames = new ArrayList<String>();

        public String toString() {
            return "[Connection addr=" + socket.getRemoteSocketAddress()
                    + " callProps=" + receiveCallProperties + "]";
        }

        // Multiple clients/datanodes may multiplex on the same
        // connection. Remember them all and treat them as all
        // dead when the connection disconnects.

        public Connection(Socket socket) throws IOException {
            this.socket = socket;
            // socket.setSoTimeout(timeout);
            socket.setTcpNoDelay(TCP_NO_DELAY);
            this.in = new CDataInputStream(new BufferedInputStream(
                    socket.getInputStream(), BUFFER_SIZE));
            this.out = new CDataOutputStream(new BufferedOutputStream(
                    socket.getOutputStream(), BUFFER_SIZE));
        }

        public void run() {
            String threadName = Thread.currentThread().getName();
            if (LOG.isLoggable(Level.FINE)) {
                LOG.fine(threadName + ": starting");
            }
            try {
                while (running) {
                    int id;
                    long receiveStart;
                    try {
                        id = in.readInt(); // try to read an id
                        receiveStart = System.currentTimeMillis();
                    } catch (SocketTimeoutException e) {
                        continue;
                    }

                    // zf: process setting of clientName
                    if (id == RpcClient.ID_CLIENTNAME) {
                        String clientName = UTF8Writable.readString(in);
                        LOG.info("Got client name: " + clientName + " from "
                                + socket.getRemoteSocketAddress());
                        clientNames.add(clientName);
                        continue;
                    }

                    if (id == RpcClient.ID_HASCALLPROPERTIES) {
                        LOG.info("Enabled call properties (protocol version 2) for "
                                + socket.getRemoteSocketAddress());
                        receiveCallProperties = true;
                        continue;
                    }

                    if (LOG.isLoggable(Level.FINE)) {
                        LOG.fine(threadName + " got #" + id);
                    }

                    // read properties map
                    WritableMap<StringWritable, StringWritable> pptMap = null;
                    if (receiveCallProperties) {
                        pptMap = WritableMap.get(StringWritable.class,
                                StringWritable.class);
                        try {
                            pptMap.readFields(in);
                        } catch (Throwable e) {
                            synchronized (out) {
                                out.writeInt(id); // write call id
                                out.writeByte(ERROR_EXCEPTION); // write error
                                // flag
                                writeException(out, new RpcWritableException(
                                        "Error reading RPC properties", e));
                                out.flush();
                            }
                            throw e;
                        }
                    }

                    IWritable param = makeParam(); // read param
                    try {
                        param.readFields(in);
                    } catch (Throwable e) {
                        synchronized (out) {
                            out.writeInt(id); // write call id
                            out.writeByte(ERROR_EXCEPTION); // write error flag
                            writeException(out, new RpcWritableException(
                                    "Error reading RPC parameters", e));
                            out.flush();
                        }
                        throw e;
                    }

                    Call call = new Call(id, pptMap, param, this, receiveStart,
                            System.currentTimeMillis());

                    try {
                        // will throw Exception immediately if queue is full
                        synchronized (callQueue) {
                            callQueue.add(call);
                            callQueue.notifyAll();
                        }
                    } catch (IllegalStateException ise) {
                        synchronized (out) {
                            out.writeInt(call.id); // write call id
                            out.writeByte(ERROR_EXCEPTION); // write error flag
                            out.flush(); // make sure the client get these in
                            // time
                            writeException(out, new RpcException("Queue full",
                                    ise));
                            out.flush();
                        }
                    }
                }
            } catch (EOFException eof) {
                // This is what happens on linux when the other side or server
                // shuts down
                LOG.info("Client " + socket.getRemoteSocketAddress()
                        + " disconnected");
                if (running && clientDisconnectListener != null) {
                    for (String clientName: clientNames) {
                        clientDisconnectListener.clientDisconnect(clientName);
                    }
                }
            } catch (SocketException eof) {
                // This is what happens on Win32 when the other side or server
                // shuts down
                LOG.info("Client " + socket.getRemoteSocketAddress()
                        + " disconnected");
                if (running && clientDisconnectListener != null) {
                    for (String clientName: clientNames) {
                        clientDisconnectListener.clientDisconnect(clientName);
                    }
                }
            } catch (Throwable e) {
                LOG.log(Level.WARNING,
                        "Connection to " + socket.getRemoteSocketAddress()
                                + " with thread " + threadName + " caught: "
                                + e, e);
                if (running && clientDisconnectListener != null) {
                    for (String clientName: clientNames) {
                        clientDisconnectListener.clientDisconnect(clientName);
                    }
                }
            } finally {
                try {
                    in.close();
                } catch (IOException e) {} finally {
                    try {
                        out.close();
                    } catch (IOException e) {} finally {
                        try {
                            socket.close();
                        } catch (IOException e) {}
                    }
                }

                if (LOG.isLoggable(Level.FINE)) {
                    LOG.fine(threadName + ": exiting");
                }

                synchronized (activeConnections) {
                    activeConnections.remove(this);
                }
            }
        }

    }

    /** Handles queued calls . */
    private class Handler extends Thread {
        public Handler() {
            this.setDaemon(true);
            this.setName("Server handler on " + port);
        }

        public void run() {
            if (LOG.isLoggable(Level.FINE)) {
                LOG.fine(getName() + ": starting");
            }
            while (running) {
                try {
                    Call call;
                    synchronized (callQueue) {
                        if (callQueue.isEmpty()) {
                            if (waitingQueue.isEmpty()) {
                                // both callQueue and waitingQueue are empty
                                callQueue.wait();
                                continue;
                            } else {
                                // callQueue is empty, waitingQueue is not empty
                                if (handlerManager.inhibitState()) {
                                    // In inhibit state, I will not poll from waitingQueue,
                                    // because calls from waitingQueue may be put back in waitingQueue again
                                    // in this state, resulting in an infinite putting/polling loop.
                                    // Therefore only when handlerManager is not in inhibit state 
                                    // will waitingQueue be read.
                                    callQueue.wait();
                                    continue;
                                } else {
                                    call = waitingQueue.poll();
                                }
                            }
                        } else {
                            // callQueue is not empty
                            call = callQueue.poll();
                        }
                    }
                    if (call == null) {
                        continue;
                    }
                    long callStart = System.currentTimeMillis();

                    if (LOG.isLoggable(Level.FINE)) {
                        LOG.fine(getName()
                                + ": has #"
                                + call.id
                                + " from "
                                + call.connection.socket.getInetAddress().getHostAddress());
                    }

                    Throwable error = null;
                    IWritable value = null;
                    try {
                        PermitType permitType = handlerManager.getPermission(call);
                        if (permitType == PermitType.PERMIT) {
                            try {
                                value = call(
                                        call.connection.socket.getRemoteSocketAddress(),
                                        call.param); // make the call
                            } finally {
                                handlerManager.finished(call);
                            }
                        } else if (permitType == PermitType.REFUSE_WAIT) {
                            synchronized (callQueue) {
                                try {
                                    waitingQueue.add(call);
                                    callQueue.notifyAll();
                                    continue;
                                } catch (IllegalStateException e) {
                                    error = new RpcException(
                                            "waitingQueue is full");
                                }
                            }
                        } else if (permitType == PermitType.REFUSE_TIMEOUT) {
                            error = new RpcException(
                                    "Call was discarded for timeout.");
                        } else {
                            LOG.log(Level.SEVERE,
                                    "Error getting permission for calls.");
                            error = new RpcException(
                                    "System error getting permission for the call.");
                        }
                    } catch (Throwable e) {
                        if (e instanceof Error) {
                            LOG.log(Level.INFO, getName()
                                    + " unexpected call error: " + e, e);
                            LOG.log(Level.INFO, getName() + " call param: "
                                    + call.param);
                        } else if (e instanceof RpcException) {
                            LOG.log(Level.INFO, getName()
                                    + " cannot invoke RPC method", e);
                            LOG.log(Level.INFO, getName() + " call param: "
                                    + call.param);
                        }
                        error = e;
                    }
                    long callEnd = System.currentTimeMillis();

                    CDataOutputStream out = call.connection.out;
                    synchronized (out) {
                        out.writeInt(call.id); // write call id
                        out.writeByte(error != null ? ERROR_EXCEPTION
                                : ERROR_SUCCESS); // write error flag
                        out.flush(); // make sure the client get these in
                        // time
                        if (error == null) {
                            // FIXME: we cannot report serialization errors here
                            // because the status bit is already sent, unless we
                            // buffer the serialized return value, which could
                            // be
                            // too long.
                            value.writeFields(out); // write value
                        } else {
                            writeException(out, error);
                        }
                        out.flush();
                    }
                    // log timing information
                    if (CALL_LOG.isLoggable(Level.FINE)) {
                        long sendEnd = System.currentTimeMillis();
                        int qlen = callQueue.size();
                        String msg = String.format(
                                "RPC: %4dms(start:%6dms receive:%4dms queue:%4dms call:%4dm send:%4dm) on %s%s",
                                callEnd - call.receiveStart,
                                LogFormatter.rtime(call.receiveStart),
                                call.receiveEnd - call.receiveStart,
                                callStart - call.receiveEnd,
                                callEnd - callStart, sendEnd - callEnd, call,
                                qlen > 0 ? ". RPC queue length=" + qlen : "").toString();
                        CALL_LOG.fine(msg);
                    }
                } catch (InterruptedException e) {
                    // nothing
                } catch (Exception e) {
                    LOG.log(Level.INFO, getName() + " caught: " + e, e);
                }
            }
            if (LOG.isLoggable(Level.FINE)) {
                LOG.fine(getName() + ": exiting");
            }
        }
        // private String convertExceptionToString(Exception e) {
        // StringBuffer sb = new StringBuffer();
        // sb.append(e.getMessage()+'\n');
        // sb.append("-- Server-side backtrace --\n");
        // StackTraceElement st[] = e.getStackTrace();
        // for(int i=0; i<st.length ;i++)
        // sb.append(" at "+st[i].toString()+"\n");
        // sb.append("-- End of server-side backtrace --\n");
        // return sb.toString();
        // }
    }

    enum PermitType {
        PERMIT, REFUSE_WAIT, REFUSE_TIMEOUT
    };

    /** Manages the use of the handlers */
    protected class HandlerManager {

        /** Manages a domain tree */
        private class DomainManager {
            private class DomainNode {
                private String domain;

                private int count;

                private Map<String, DomainNode> subMap;

                public DomainNode(String domain) {
                    this.domain = domain;
                    this.count = 0;
                    this.subMap = new HashMap<String, DomainNode>();
                }
            }

            private static final String DOMAIN_SEPERATOR = "\\.";

            private DomainNode root = new DomainNode("root");

            private Stack<DomainNode> domainPath = new Stack<DomainNode>();

            public synchronized void add(String callDomain) {
                DomainNode curNode = root;
                curNode.count += 1;

                for (String domain: callDomain.split(DOMAIN_SEPERATOR)) {

                    if (curNode.subMap.containsKey(domain)) {
                        curNode = curNode.subMap.get(domain);
                    } else {
                        DomainNode newNode = new DomainNode(domain);
                        curNode.subMap.put(domain, newNode);
                        curNode = newNode;
                    }

                    curNode.count += 1;
                }
            }

            public synchronized void remove(String callDomain) {
                domainPath.clear();
                DomainNode curNode = root;
                domainPath.push(root);

                for (String domain: callDomain.split(DOMAIN_SEPERATOR)) {
                    if (curNode.subMap.containsKey(domain)) {
                        curNode = curNode.subMap.get(domain);
                        domainPath.push(curNode);
                    } else {
                        LOG.log(Level.WARNING, "Warning not found id ["
                                + callDomain + "] to remove.");
                        return;
                    }
                }

                String subDomain = null;
                while (!domainPath.isEmpty()) {
                    curNode = domainPath.pop();
                    if (subDomain != null) {
                        curNode.subMap.remove(subDomain);
                    }

                    curNode.count -= 1;
                    if (curNode.count <= 0) {
                        subDomain = curNode.domain;
                    } else {
                        subDomain = null;
                    }
                }
            }

            public synchronized int totalCount() {
                return root.count;
            }

            /**
             * Estimate the demanded capacity of the handler pool according to
             * the current number of handlers used by the calling domain.
             * 
             * @param callDomain
             * @return
             */
            public synchronized int estimateDemandedCapacity(String callDomain) {
                DomainNode curNode = root;
                int rate = 1;

                for (String domain: callDomain.split(DOMAIN_SEPERATOR)) {
                    if (curNode.subMap.containsKey(domain)) {
                        rate *= curNode.subMap.size();
                        curNode = curNode.subMap.get(domain);
                    } else {
                        return 0;
                    }
                }

                return curNode.count * rate;
            }
        }

        private final int INHIBIT_LIMIT = handlerCount - reservedHandlerCount;

        private DomainManager domainManager = new DomainManager();

        public PermitType getPermission(Call call) {
            if (!call.hasProperties()) {
                return PermitType.PERMIT;
            }

            final String clientDomain = call.getProperty(RpcConstants.CALL_PROPERTY_DOMAIN);
            // check if the call is timeout
            final long timeout = Long.parseLong(call.getProperty(RpcConstants.CALL_PROPERTY_TIMEOUT));
            int handlersInUse = domainManager.totalCount();
            if (timeout > 0
                    && System.currentTimeMillis() - call.receiveStart > timeout) {
                int callQueueSize;
                int waitingQueueSize;
                synchronized (callQueue) {
                    callQueueSize = callQueue.size();
                    waitingQueueSize = waitingQueue.size();
                }
                LOG.info("Timed out call " + call.param + "(id=" + call.id
                        + ") from " + call.connection + " for domain '"
                        + clientDomain + "', timeout=" + timeout + ", queued="
                        + callQueueSize + ", waiting=" + waitingQueueSize);
                return PermitType.REFUSE_TIMEOUT;
            }

            // check if the call should be inhibited
            int demandedCap = domainManager.estimateDemandedCapacity(clientDomain);
            if (inhibitState() && demandedCap >= INHIBIT_LIMIT) {
                LOG.info("Delayed call " + call.param + "(id=" + call.id
                        + ") from " + call.connection + " for domain '"
                        + clientDomain + "', handlersInUse=" + handlersInUse
                        + ", demandedCap=" + demandedCap + ", queued="
                        + callQueue.size() + ", waiting=" + waitingQueue.size());
                return PermitType.REFUSE_WAIT;
            }

            domainManager.add(clientDomain);
            return PermitType.PERMIT;
        }

        public boolean inhibitState() {
            int handlersInUse = domainManager.totalCount();
            return handlersInUse >= INHIBIT_LIMIT;
        }

        public void finished(Call call) {
            boolean inhibitState = inhibitState();
            if (call.hasProperties()) {
                domainManager.remove(call.getProperty(RpcConstants.CALL_PROPERTY_DOMAIN));
            }
            if (inhibitState != inhibitState()) {
                // inhibit state has changed, need to notify waiting handlers
                synchronized (callQueue) {
                    callQueue.notifyAll();
                }
            }
        }
    }

    /**
     * Constructs a server listening on the named port. Parameters passed must
     * be of the named class. The <code>handlerCount</handlerCount> determines
     * the number of handler threads that will be used to process calls.
     */
    protected RpcServer(int port, Class<?> paramClass, int handlerCount,
            int inhibitHandlerCount, int queueSize) {
        this.port = port;
        this.paramClass = paramClass;
        this.handlerCount = handlerCount;
        this.reservedHandlerCount = inhibitHandlerCount;
        this.maxQueuedCalls = Math.max(queueSize, MIN_QUEUE_SIZE);
        callQueue = new ArrayQueue<Call>(maxQueuedCalls);
        waitingQueue = new ArrayQueue<Call>(maxQueuedCalls);
    }

    Listener listener;

    HandlerManager handlerManager;

    Handler[] handlers;

    /** Starts the service. Must be called before any calls will be handled. */
    public synchronized void start() throws IOException {
        listener = new Listener();
        listener.start();

        handlerManager = new HandlerManager();

        handlers = new Handler[handlerCount];
        for (int i = 0; i < handlerCount; i++) {
            handlers[i] = new Handler();
            handlers[i].start();
        }
    }

    /**
     * Stops the service. No calls will be handled after this is called. All
     * threads will exit.
     */
    public synchronized void stop() {
        if (LOG.isLoggable(Level.FINE)) {
            LOG.fine("Stopping server on " + port);
        }
        running = false;

        // first shutdown listener and all handlers
        try {
            listener.socket.close();
        } catch (IOException e) {
            LOG.log(Level.WARNING, "close listener socket failed", e);
        }
        for (int i = 0; i < handlers.length; i++) {
            handlers[i].interrupt();
        }
        // zf: join on the worker threads
        try {
            // listener checks for 'running' every 1 second
            listener.join();
            if (LOG.isLoggable(Level.FINE)) {
                LOG.fine("Listener stopped");
            }
            for (int i = 0; i < handlers.length; i++) {
                handlers[i].join();
                if (LOG.isLoggable(Level.FINE)) {
                    LOG.fine("Handler " + i + " stopped");
                }
            }
        } catch (InterruptedException e) {}

        // now shutdown all connections still running
        ArrayList<Connection> active = new ArrayList<Connection>();
        // make a copy of the active connections list because we cannot lock the
        // list
        // while shutting down
        synchronized (activeConnections) {
            if (activeConnections.size() > 0)
                active.addAll(activeConnections);
        }
        if (LOG.isLoggable(Level.FINE)) {
            LOG.fine("Stopping " + active.size() + " connections.");
        }
        for (Connection con: active) {
            try {
                con.socket.close();
            } catch (IOException e) {}
        }
        for (Connection con: active) {
            try {
                con.thread.join();
                if (LOG.isLoggable(Level.FINE)) {
                    LOG.fine(con.thread.getName() + ": stopped");
                }
            } catch (InterruptedException e) {}
        }
        // zf: now that we removed timeouts, there's no point to wait here
        // try {
        // Thread.sleep(timeout); // let all threads exit
        // } catch (InterruptedException e) {}
        LOG.info("RPC server " + port + " stopped");
        notify();
    }

    /** Wait for the server to be stopped. */
    public synchronized void join() throws InterruptedException {
        while (running) {
            wait();
        }
    }

    /** Called for each call. */
    public abstract IWritable call(SocketAddress remoteAddr, IWritable param)
            throws Throwable;

    private IWritable makeParam() {
        IWritable param; // construct param
        try {
            param = (IWritable) paramClass.newInstance();
        } catch (InstantiationException e) {
            throw new RuntimeException(e.toString());
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e.toString());
        }
        return param;
    }

    /**
     * Add a listener that will be notified when a client disconnects due to
     * network error or client process error.
     * 
     * @param l
     */
    public void addClientDisconnectListener(ClientDisconnectListener l) {
        if (clientDisconnectListener == null) {
            clientDisconnectListener = l;
        } else {
            throw new RuntimeException(
                    "Not implemented. Only support one listener now!");
        }
    }

    private void writeException(CDataOutputStream out, Throwable error)
            throws IOException {
        // We use Java serialization to transmit exceptions
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        ObjectOutputStream oo = new ObjectOutputStream(bo);
        boolean failure = false;
        try {
            oo.writeObject(error);
            oo.close();
            bo.close();
        } catch (IOException e) {
            LOG.log(Level.WARNING,
                    "Cannot serialize exception to write to RPC client. Ignoring it.",
                    e);
            out.writeInt(0); // 0 length indicate no info
            failure = true;
        }
        if (!failure) {
            byte[] b = bo.toByteArray();
            out.writeInt(b.length);
            out.write(b);
        }
    }

    protected ServerCallListener serverCallListener;

    public void setServerCallListener(ServerCallListener serverCallListener) {
        this.serverCallListener = serverCallListener;
    }

    public int getPendingCalls() {
        synchronized (callQueue) {
            return callQueue.size() + waitingQueue.size();
        }
    }

}
