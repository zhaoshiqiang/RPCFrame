package odis.rpc;

/**
 * Listener for disconnection events between RPC server and client, reported to
 * the server. This gets called whener a client disconnects, due to the client
 * closing the connection either normally or erroneously. This is called in the
 * connection's thread.
 * 
 * @deprecated
 * @author zf
 */
@Deprecated
public interface ClientDisconnectListener {
    /**
     * Informs the listener that client disconnected.
     * 
     * @param clientName  the name of the disconnecting client
     */
    public void clientDisconnect(String clientName);
}
