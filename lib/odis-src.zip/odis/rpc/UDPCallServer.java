/**
 * @(#)UDPCallServer.java, 2008-6-17. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package odis.rpc;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketAddress;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.io.DataInputBuffer;
import odis.serialize.IWritable;
import odis.util.BlockingExecutor;
import toolbox.misc.LogFormatter;
import toolbox.misc.UnitUtils;

/**
 * 基于UDP协议的RPC服务器实现，和 {@link RpcServer} 不同的地方在于，
 * 这里所有的请求都没有返回，所以仅仅适合幂等的操作，例如<code>heartbeat</code>
 * 这样的操作.
 * 
 * 另外一个需要注意的是，这里没有考虑udp分包的情况，所以要求每个udp请求的大小都能够
 * 被包装在一个udp packet中.
 * 
 * @author river
 *
 */
public abstract class UDPCallServer {
    private static final Logger LOG = LogFormatter.getLogger(UDPCallServer.class);
    
    private static final Logger CALL_LOG = LogFormatter.getLogger("rpcserver.call");
    
    private static final int MAX_DATAGRAM_SIZE = (int)(64 * UnitUtils.K);
    
    private int port;
    private Class paramClass;
    private int handleCount;
    private boolean running;
    
    private ThreadPoolExecutor threadPool;
    private Listener listener;
    
    protected UDPCallServer(int port, Class paramClass, int handleCount) {
        this.port = port;
        this.paramClass = paramClass;
        this.handleCount = handleCount;
    }

    /**
     * 启动任务处理线程池，并且开始监听udp端口，接受请求.
     * @throws IOException
     */
    public void start() throws IOException {
        running = true;
        
        threadPool = BlockingExecutor.createExecutor(handleCount, 
                new ArrayBlockingQueue<Runnable>(handleCount));
        
        listener = new Listener();
        listener.start();
    }
    
    /**
     * 停止服务器.
     * @throws IOException
     */
    public void stop() throws IOException {
        running = false;
        
        listener.serverSocket.close();
        threadPool.shutdownNow();
    }
    
    /**
     * 请求处理的实现.
     * @param param
     * @throws Throwable
     */
    protected abstract void call(IWritable param) throws Throwable;

    /**
     * 请求数据，每个请求读出以后保存在请求队列中等待处理.
     * @author river
     */
    private class Call implements Runnable {
        private long receive;  // when the call received
        private IWritable param; // the parameter passed
        private SocketAddress remote; // where this call from

        public Call(IWritable param, long receive, SocketAddress remote) {
            this.param = param;
            this.receive = receive;
            this.remote = remote;
        }

        public void run() {
            try {
                call(param);
            } catch(Throwable e) {
                LOG.log(Level.WARNING, "execute request " + this.toString() + " failed", e);
            }
            
            if (CALL_LOG.isLoggable(Level.FINE)) {
                long end = System.currentTimeMillis();
                CALL_LOG.fine("UDP CALL: [from:" + remote + ",received:" + receive + 
                        ",end:" + end + "]" + param);
            }
            
        }
        
        public String toString() {
            return remote + " [recieve=" + receive + "]" + param.toString();
        }
        
    }

    /**
     * 创建一个参数的实例.
     * @return
     */
    private IWritable makeParam() {
        IWritable param; // construct param
        try {
            param = (IWritable) paramClass.newInstance();
        } catch (InstantiationException e) {
            throw new RuntimeException(e.toString());
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e.toString());
        }
        return param;
    }
    
    /**
     * 等待请求数据并且完成请求读取的线程，所有的请求被读出以后加入到请求队列中等待处理.
     * @author river
     */
    private class Listener extends Thread {
        private DatagramSocket serverSocket;
        
        public Listener() throws IOException {
            super("udp-call-listener");
            this.setDaemon(true);
            
            serverSocket = new DatagramSocket(port);
        }
        
        @Override
        public void run() {
            byte [] datagramBuffer = new byte[MAX_DATAGRAM_SIZE];
            
            while (running) {
                DatagramPacket packet = new DatagramPacket(datagramBuffer, datagramBuffer.length);
                try {
                    serverSocket.receive(packet);
                    IWritable param = makeParam();
                    DataInputBuffer ibuf = new DataInputBuffer(packet.getData(), 
                            packet.getOffset(), packet.getLength());
                    param.readFields(ibuf);
                    threadPool.execute(new Call(param, System.currentTimeMillis(), 
                            packet.getSocketAddress()));
                } catch(IOException e) {
                    LOG.log(Level.WARNING, "io exception during udp call", e);
                }
            }
        }
    }
    
}
