package odis.conf;

import org.apache.commons.configuration.Configuration;

/**
 * Any class implements this class must configurate himself when configure is
 * called.
 * 
 * @author Zig
 * @version 2006-2-16
 */
public interface Configurable {
    /**
     * Configure this object.
     * 
     * @param config
     *            The config to read from.
     */
    void configure(Configuration config);
}
