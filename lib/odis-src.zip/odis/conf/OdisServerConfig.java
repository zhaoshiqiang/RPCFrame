package odis.conf;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;
import java.util.logging.Level;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.SystemConfiguration;

/**
 * Odis configuration for starting ODIS services like cowork, odfs, etc.
 * 
 * @author Li Zhuang (zl@cs.berkeley.edu, zl@rd.netease.com) Created on Oct 8,
 *         2006 Copyright (c) 2006 Outfox Team
 */

public class OdisServerConfig extends OdisLibConfig {

    private static final HashMap<String, Integer> tmInstanceMap = new HashMap<String, Integer>();

    private static OdisServerConfig instance = new OdisServerConfig();

    /**
     * Returns the OdisServerConfig instance
     */
    public static OdisServerConfig get() {
        return instance;
    }

    /**
     * Returns the OdisLibConfig.conf instance
     */
    public static Configuration conf() {
        get();
        return config;
    }

    static {
        try {
            String local = System.getProperty("odis.local");
            if (local == null) {
                local = System.getenv("ODIS_LOCAL");
            }
            if (local == null) { // default: /tmp/{user.name}/odis
                local = File.separator + "tmp" + File.separator
                        + System.getProperty("user.name") + File.separator
                        + "odis";
            }
            // load service configuration
            Configuration svrConfig = ConfigUtils.parseXmlConfig(
                    getConfigDir(), new String[] {
                        "service.xml"
                    });
            // clear those loaded properties from service configurations 
            Iterator it = config.getKeys();
            while (it.hasNext())
                svrConfig.clearProperty((String) (it.next()));
            // add other service configuration
            config.addConfiguration(svrConfig);
            // add system configuration
            config.addConfiguration(new SystemConfiguration());
            config.setProperty("odis.local", local);
            // load cowork instance map
            String[] tmInstances = config.getStringArray("cowork.taskmaster.instance.name");
            for (int i = 0; i < tmInstances.length; i++) {
                tmInstanceMap.put(tmInstances[i], i);
                LOG.fine("Loading taskmaster instance " + i + " of \""
                        + tmInstances[i] + "\"");
            }
        } catch (ConfigurationException e) {
            LOG.log(Level.WARNING,
                    "Error reading configuration file service.xml in "
                            + getConfigDir(), e);
            throw new RuntimeException("Error loading service.xml in "
                    + getConfigDir());
        }
    }

    ///////////////////////////////////////////////////////////////////////////
    // Basic service configurations
    ///////////////////////////////////////////////////////////////////////////

    public String getOdisServiceLocal() {
        return config.getString("odis.local");
    }

    public File getOdisTmpDir() {
        return new File(getOdisServiceLocal(), "tmp");
    }

    public File getOdisLogRootDir() {
        return new File(getOdisServiceLocal(), "log");
    }

    public File getCoworkLogDir() {
        return new File(getOdisLogRootDir(), "cowork");
    }

    public File getOdfsLogDir() {
        return new File(getOdisLogRootDir(), "odfs");
    }

    public Properties getServiceLogLevel() {
        return config.getProperties("log.debug-level");
    }

    ///////////////////////////////////////////////////////////////////////////
    // CoWork instance related configurations
    ///////////////////////////////////////////////////////////////////////////

    public int getJobMasterPort() {
        return config.getInt("cowork.jobmaster.port", 4848);
    }

    public String[] getTaskMasterTmpDir(String tmName) {
        String defaultTmp = getOdisServiceLocal();
        if ("local".equals(tmName))
            return new String[] {
                new File(defaultTmp, "cowork").getPath()
            };
        // distributed case
        Integer idx = tmInstanceMap.get(tmName);
        assert idx != null;
        String[] tmps = config.getStringArray("cowork.taskmaster.instance("
                + idx + ")" + ".local-dir.tmp");
        if (tmps == null || tmps.length == 0) {
            return new String[] {
                new File(defaultTmp, "cowork").getPath()
            };
        } else
            return tmps;
    }

    public int getTaskMasterTaskLimit(String tmName) {
        if ("local".equals(tmName))
            throw new IllegalArgumentException(
                    "No task limit for \"local\" case");
        // distributed case
        Integer idx = tmInstanceMap.get(tmName);
        if (idx == null)
            throw new RuntimeException("Cannot find task master instance "
                    + tmName);
        return config.getInt("cowork.taskmaster.instance(" + idx + ")"
                + ".task-limit", 2);
    }

    public int getTaskMasterFileLimit(String tmName) {
        if ("local".equals(tmName))
            throw new IllegalArgumentException(
                    "No file limit for \"local\" case");
        // distributed case
        Integer idx = tmInstanceMap.get(tmName);
        if (idx == null)
            throw new RuntimeException("Cannot find task master instance "
                    + tmName);
        return config.getInt("cowork.taskmaster.instance(" + idx + ")"
                + ".file-limit", 16);
    }

    public int getTaskHeapLimit(String tmName) {
        if ("local".equals(tmName)) {
            throw new IllegalArgumentException(
                    "No heap limit for \"local\" case");
        }
        // distributed case
        Integer idx = tmInstanceMap.get(tmName);
        if (idx == null) {
            throw new RuntimeException("Cannot find task master instance "
                    + tmName);
        }
        return config.getInt("cowork.taskmaster.instance(" + idx + ")"
                + ".heap-limit", 800);
    }

    ///////////////////////////////////////////////////////////////////////////
    // Deprecated set methods for test case only
    ///////////////////////////////////////////////////////////////////////////

    /**
     * @deprecated for test-case only
     */
    @Deprecated
    public void setInt(String name, int value) {
        config.setProperty(name, value + "");
    }

    /**
     * @deprecated for test-case only
     */
    @Deprecated
    public void setLong(String name, long value) {
        config.setProperty(name, value + "");
    }

    /**
     * @deprecated for test-case only
     */
    @Deprecated
    public void setString(String name, String value) {
        config.setProperty(name, value);
    }
}
