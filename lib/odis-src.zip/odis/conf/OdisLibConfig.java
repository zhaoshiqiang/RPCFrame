package odis.conf;

import java.io.File;
import java.io.FilenameFilter;
import java.net.InetSocketAddress;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.configuration.CompositeConfiguration;
import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.SystemConfiguration;

import toolbox.misc.LogFormatter;

/**
 * Abstract class for loading configurations. The default configuration to be
 * load is $ODIS_HOME/conf/odis.xml (or ${odis.home}/conf/odis.xml).
 * 
 * @author Li Zhuang (zl@cs.berkeley.edu, zl@rd.netease.com) Created on Oct 8,
 *         2006 Copyright (c) 2006 Outfox Team
 */

public abstract class OdisLibConfig {

    protected static final Logger LOG = LogFormatter.getLogger(OdisLibConfig.class);

    protected static final String home;

    protected static final CompositeConfiguration config;

    static {
        try {
            String oh = System.getProperty("odis.home");
            if (oh == null) {
                oh = System.getenv("ODIS_HOME");
            }
            if (oh == null) {
                oh = ".";
            }
            home = new File(oh).getAbsolutePath();
            File[] files = getConfigDir().listFiles(new FilenameFilter() {
                public boolean accept(File dir, String name) {
                    return name.endsWith("-site.xml");
                }
            });
            if (files == null)
                files = new File[0];
            if (files.length > 1)
                throw new RuntimeException("Expect one *-site.xml, but got "
                        + files.length);
            String[] names = new String[files.length];
            for (int i = 0; i < files.length; i++)
                names[i] = files[i].getName().toString();
            config = ConfigUtils.parseXmlConfig(getConfigDir(), names);
            config.setProperty("odis.home", home);
            System.setProperty("odis.home", home);
        } catch (ConfigurationException e) {
            LOG.log(Level.WARNING,
                    "Error reading configuration file *-site.xml in "
                            + getConfigDir(), e);
            throw new RuntimeException("Error loading *-site.xml in "
                    + getConfigDir());
        }
    }

    /**
     * Load configuration files with specified suffix.
     * 
     * @param suffix
     *            the suffix of the accepted files.
     */
    public static void load(final String suffix) {
        try {
            File[] files = getConfigDir().listFiles(new FilenameFilter() {
                public boolean accept(File dir, String name) {
                    return name.endsWith(suffix);
                }
            });
            if (files != null && files.length > 0) {
                // get file names
                String[] names = new String[files.length];
                for (int i = 0; i < files.length; i++)
                    names[i] = files[i].getName().toString();
                Configuration defConf = ConfigUtils.parseXmlConfig(
                        getConfigDir(), names);
                // clear those loaded properties from service configurations 
                Iterator it = config.getKeys();
                while (it.hasNext())
                    defConf.clearProperty((String) (it.next()));
                // add new configuration
                config.addConfiguration(defConf);
            }
        } catch (ConfigurationException e) {
            LOG.log(Level.WARNING, "Error reading configuration file *"
                    + suffix + " in " + getConfigDir(), e);
            throw new RuntimeException("Error loading *" + suffix + " in "
                    + getConfigDir());
        }
        // add system configuration
        config.addConfiguration(new SystemConfiguration());
    }

    ///////////////////////////////////////////////////////////////////////////
    // Methods for access distribution directories
    ///////////////////////////////////////////////////////////////////////////

    /**
     * Returns the Configuration instance
     */
    public static Configuration conf() {
        return config;
    }

    /**
     * Returns the root directory
     */
    public static File getHomeDir() {
        return new File(home);
    }

    /**
     * Returns the conf directory
     */
    public static File getConfigDir() {
        return new File(home, "conf");
    }

    /**
     * Returns the lib directory
     */
    public static File getLibraryDir() {
        return new File(home, "lib");
    }

    /**
     * Returns the web directory
     */
    public static File getWebDir() {
        return new File(home, "web");
    }

    ///////////////////////////////////////////////////////////////////////////
    // Methods to access service addresses
    ///////////////////////////////////////////////////////////////////////////
    /**
     * Returns the InetSocketAddress from and address string
     */
    public static InetSocketAddress getAddress(String addStr) {
        if ("local".equals(addStr)) {
            return null;
        }
        if (addStr == null) {
            throw new NullPointerException("Null net address");
        }
        String[] jmStr = addStr.split(":");
        if (jmStr.length != 2) {
            throw new RuntimeException("Invalid net address: " + addStr);
        }
        return new InetSocketAddress(jmStr[0], Integer.parseInt(jmStr[1]));
    }

    ///////////////////////////////////////////////////////////////////////////
    // Load native library
    ///////////////////////////////////////////////////////////////////////////
    /**
     * Load a native lib, on windows os, load "lib/lib*name*.dll"; on linux os,
     * load "lib*name*.*arch*.so".
     * 
     * @param name
     *            name of library, not including "lib"
     */
    public static void loadNativeLib(String name) {
        String os = System.getProperty("os.name", "linux");
        String libName;
        File libFile = null;
        String oh = System.getProperty("odis.home");
        if (oh == null)
            oh = System.getenv("ODIS_HOME");
        if (oh == null)
            oh = ".";
        String home = new File(oh).getAbsolutePath();

        if (os.toLowerCase().contains("win")) {
            if (System.getProperty("sun.arch.data.model", "32").equals("32")) {
                libName = "lib" + name + ".dll";
            } else {
                libName = "lib" + name + ".x64.dll";
            }
        } else if (os.toLowerCase().contains("mac")) {
            libName = "lib" + name + ".macosx.so";
        } else {
            String arch = System.getProperty("os.arch", "i386");
            libName = "lib" + name + "." + arch + ".so";
        }

        String[] pathPrefix = new String[] {
            "lib", "native", "nativelib"
        };
        for (String prefix: pathPrefix) {
            libFile = new File(home, prefix + "/" + libName);
            if (libFile.exists()) {
                break;
            }
        }

        if (!libFile.exists()) {
            throw new RuntimeException("cannot find native lib "
                    + libFile.getAbsolutePath());
        } else {
            try {
                System.load(libFile.getCanonicalPath());
            } catch (Exception e) {
                throw new RuntimeException("cannot load native lib "
                        + libFile.getAbsolutePath());
            }
        }
    }

}
