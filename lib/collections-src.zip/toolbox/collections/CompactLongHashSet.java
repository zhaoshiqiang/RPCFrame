package toolbox.collections;

import java.util.NoSuchElementException;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * An efficient long-hash-set implementation that does not generate small
 * objects at all.
 * 
 * Implementation:
 *   Two arrays are allocated long[] keys and int[] nexts. The first half of the
 *   arrays are the hash-table and the second half are used for collision
 *   handling.
 * 
 * @author David
 *
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class CompactLongHashSet {
    private static final int MAX_CAPACITY = 1 << 30;
    private static final int DEFAULT_INITIAL_CAPACITY = 16;
    private static final float DEFAULT_LOAD_FACTOR = 1.5f;
    
    private static int CURR_EMPTY = 0;
    private static int NEXT_NULL = -1;
    
    private long[] keys;
    private int[] nexts;
    
    private int size;
    private int freeTop;
    private int minHeap;
    
    private float loadFactor;
    private int expandSize;
    
    /**
     * The constructor with default initial capacity and load-factor
     *
     */
    public CompactLongHashSet() {
        this(DEFAULT_INITIAL_CAPACITY, DEFAULT_LOAD_FACTOR);
    }
    /**
     * The constructor with specified initial capacity and default load-factor
     * 
     * @param capacity  the intial capacity 
     */
    public CompactLongHashSet(int capacity) {
        this(capacity, DEFAULT_LOAD_FACTOR);
    }
    /**
     * The constructor with specified initial capacity and load-factor
     * @param capacity
     * @param loadFactor
     */
    public CompactLongHashSet(int capacity, float loadFactor) {
        int realSize = 1;
        while (realSize < capacity) {
            realSize = realSize << 1;
        } // while
        if (realSize > MAX_CAPACITY) 
            realSize = MAX_CAPACITY;
        
        keys = new long[realSize * 2];
        nexts = new int[keys.length];
        freeTop = keys.length / 2;  minHeap = freeTop;
        expandSize = (int) (keys.length / 2.0f * loadFactor);
        size = 0;
        
        this.loadFactor = loadFactor;
    }
    
    private void resize(int capacity) {
        long[] newKeys = new long[capacity * 2];
        int[] newNexts = new int[newKeys.length];
        int newFreeTop = capacity;
        
        int cnt = keys.length / 2;
        for (int i = 0; i < cnt; i ++) {
            if (nexts[i] != CURR_EMPTY) {
                int cur = i;
                while (cur != NEXT_NULL) {
                    int index = index(keys[cur], capacity);
                    
                    if (newNexts[index] == CURR_EMPTY) {
                        newKeys[index] = keys[cur];
                        newNexts[index] = NEXT_NULL;
                    } else {
                        newKeys[newFreeTop] = keys[cur];
                        newNexts[newFreeTop] = newNexts[index];
                        
                        newNexts[index] = newFreeTop;
                        
                        newFreeTop ++;
                    } // else
                    
                    cur = nexts[cur];
                } // while
            } // if
        } // for entry

        keys = newKeys;
        nexts = newNexts;
        freeTop = newFreeTop;  minHeap = freeTop;
        expandSize = (int) (keys.length / 2.0f * loadFactor);
    }
    
    /**
     * Calculate the index of a given long key. This code was migrated from 
     * jdk source.
     * 
     * @param key  the long key
     * @param size  the total size of the hash-table
     * @return  the computed hash-index
     */
    protected int index(long key, long size) {
        int h = (int) (key ^ (key >>> 32));
        h += ( h << 9);
        h ^= ( h >>> 14);
        h += ( h << 4);
        h ^= ( h >> 10);
        return (int)(h & (size-1));
    }
    /**
     * Whether the set contains specified key.
     * 
     * @param key  the key to be tested
     * @return  true if the set contains <key>, false otherwise
     */
    public boolean contains(long key) {
        int index = index(key, keys.length / 2);
        if (nexts[index] == CURR_EMPTY)
            return false;
        while (index != NEXT_NULL) {
            if (keys[index] == key)
                return true;
            
            index = nexts[index];
        } // while

        return false;
    }
    /**
     * Add a key to the set. Nothing happens if the set has already contained
     * this key.
     * 
     * @param key  the key to be added
     */
    public void add(long key) {
        if ((size >= expandSize || freeTop == keys.length) && 
                keys.length < MAX_CAPACITY) {
            resize(keys.length);
        } // if
        
        int index = index(key, keys.length / 2);
        if (nexts[index] == CURR_EMPTY) {
            /*
             * Head node is empty, put it here
             */
            keys[index] = key;
            nexts[index] = NEXT_NULL;
            size ++;
            return;
        } // if
        /*
         * Try find it
         */
        int cur = index;
        while (cur != NEXT_NULL) {
            if (keys[cur] == key)
                return;
            
            cur = nexts[cur];
        } // while
        /*
         * Not found, allocate a new position
         */
        int newIndex = freeTop;
        if (freeTop == minHeap) {
            freeTop ++;  minHeap ++;
        } else {
            freeTop = nexts[freeTop];
        } // else
        /*
         * Insert the key to the head
         */
        keys[newIndex] = key;

        nexts[newIndex] = nexts[index];
        nexts[index] = newIndex;
        /*
         * increase size
         */
        size ++;
    }
    private void freeEntry(int index) {
        nexts[index] = freeTop;
        freeTop = index;
    }
    /**
     * Remove a key from the set. Nothing happens if the set does not contains
     * the key. 
     * 
     * @param key  the key to be removed
     */
    public void remove(long key) {
        int index = index(key, keys.length / 2);
        if (nexts[index] == CURR_EMPTY)
            /*
             * No entries for this hash-index
             */
            return;
        
        int next = nexts[index];
        if (keys[index] == key) {
            /*
             * Head entry is the one
             */
            if (next == NEXT_NULL) {
                /*
                 * Only the head entry, simply set it to be empty
                 */
                nexts[index] = CURR_EMPTY;
            } else {
                /*
                 * Otherwise, copy <next> entry to head,
                 */
                keys[index] = keys[next];
                nexts[index] = nexts[next];
                /*
                 * and free <next> entry
                 */
                freeEntry(next);
            } // else

            size --;
            return;
        }
        /*
         * Try find the entry in non-head entries
         */
        while (next != NEXT_NULL) {
            if (keys[next] == key) {
                /*
                 * Found it, skip it and free it
                 */
                nexts[index] = nexts[next];
                freeEntry(next);
                size --;
                return;
            } // if
            
            index = next;
            next = nexts[index];
        } // while
    }

    /**
     * Return a LongHashIterator instance for enumerating all elements in this
     * set.
     */
    public LongHashSetIterator iterator() {
        return new LongHashSetIterator();
    }

    /**
     * Return the number of elements in this set
     */
    public int size() {
        return size;
    }

    /**
     * Return whether the map is empty
     */
    public boolean isEmpty() {
        return size == 0;
    }

    /**
     * Remove all elements in this set. NOTE: calling to this method does not
     * change the capacity of this set
     */
    public void clear() {
        for (int i = nexts.length - 1; i >= 0; i --)
            nexts[i] = 0;
        
        freeTop = keys.length / 2;  minHeap = freeTop;
        size = 0;
    }
    
    /**
     * Return a string representation for all the elements in this set.
     */
    @Override
    public String toString() {
        StringBuilder str = new StringBuilder(size * (8 + 2));
        str.append("[");
        LongHashSetIterator iter = iterator();
        boolean first = true;
        while (iter.hasNext()) {
            if (!first) {
                str.append(", ");
            } else {
                first = false;
            } // else
            
            str.append(iter.next());
        } // while
        str.append("]");
        return "";
    }

    /**
     * A iterator class for enumerating elements in a CompactLongHashSet.
     * 
     * @author David
     */
    @InterfaceAudience.Public
    @InterfaceStability.Stable
    public class LongHashSetIterator {
        private int index;  // current slot
        private int current, next;
        /**
         * The constructor.
         * Call remove() after calling next() at least once
         */
        LongHashSetIterator() {
            current = NEXT_NULL;
            
            int[] n = nexts;
            index = keys.length / 2 - 1;
            if (size != 0) {
                while (n[index] == CURR_EMPTY)
                    index --;
                next = index;
                index --;
            } else {
                next = NEXT_NULL;
            } // else
        }

        /**
         * Return whether more element can be got by calling next()
         * 
         * @return whether more element can be got by calling next()
         */
        public boolean hasNext() {
            return next != NEXT_NULL;
        }

        /**
         * Move to the next element and return the value. An
         * NoSuchElementException will be thrown if no more elements in this
         * iterator are available. Please check this by calling hasNext().
         * 
         * @return the next element
         */
        public long next() {
            int c = next;
            if (c == NEXT_NULL)
                throw new NoSuchElementException();
            
            next = nexts[next];
            if (next <= 0) {
                while (index >= 0 && nexts[index] == CURR_EMPTY)
                    index --;
                if (index >= 0) {
                    next = index;
                    index --;
                } else {
                    next = NEXT_NULL;
                } // else
            } // if
            current = c;
            return keys[c];
        }
        /**
         * Remove the current element in the corresponding set.
         */
        public void remove() {
            if (current == NEXT_NULL) 
                throw new IllegalStateException();

            if (current >= keys.length / 2) {
                /*
                 * current not in main-table, remove it will not change
                 * the value of this.next
                 */
                CompactLongHashSet.this.remove(keys[current]);
            } else {
                int next = nexts[current];
                if (next == NEXT_NULL) {
                    nexts[current] = CURR_EMPTY;
                } else {
                    keys[current] = keys[next];
                    nexts[current] = nexts[next];
                    
                    freeEntry(next);
                    this.next = current;
                } // else
                size --;
            } // else
            
            current = NEXT_NULL;
        }
    }
}
