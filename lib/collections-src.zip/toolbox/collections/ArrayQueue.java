package toolbox.collections;

import java.util.AbstractCollection;
import java.util.AbstractQueue;
import java.util.Iterator;
import java.util.NoSuchElementException;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * A round-robin queue. NOTE: this queue is not thread-safe.
 * 
 * @author david
 * @param <E>
 *            the type of elements
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class ArrayQueue<E> extends AbstractQueue<E> {
    private int size = 0;

    private int head;

    private int tail;

    Object[] q;

    /**
     * The constructor.
     * 
     * @param capacity
     *            the maximum number of elements that can be put in this queue
     */
    public ArrayQueue(int capacity) {
        q = new Object[capacity];
        head = 0;
        tail = 0;
    }

    /**
     * Returns an iterator over the elements in this deque. The elements will be
     * ordered from first (head) to last (tail). Note that the remove method is
     * not implemented.
     * 
     * @return an iterator over the elements in this queue
     * @see AbstractCollection#iterator()
     */
    @Override
    public Iterator<E> iterator() {
        if (isEmpty()) {
            return new Iterator<E>() {

                public boolean hasNext() {
                    return false;
                }

                public E next() {
                    throw new NoSuchElementException();
                }

                public void remove() {
                    throw new UnsupportedOperationException();

                }
            };
        } else {
            return new Iterator<E>() {
                int cur = tail;

                public boolean hasNext() {
                    return cur >= 0;
                }

                @SuppressWarnings("unchecked")
                public E next() {
                    if (cur < 0)
                        throw new NoSuchElementException();

                    E res = (E) q[cur];
                    cur++;
                    if (cur == q.length)
                        cur = 0;

                    if (cur == head)
                        cur = -1;

                    return res;
                }

                public void remove() {
                    throw new UnsupportedOperationException();
                }
            };
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int size() {
        return size;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean offer(E o) {
        if (size >= q.length)
            return false;

        q[head] = o;
        head++;
        if (head == q.length)
            head = 0;
        size++;

        return true;
    }

    /**
     * {@inheritDoc}
     */
    @SuppressWarnings("unchecked")
    @Override
    public E peek() {
        if (size == 0)
            return null;
        else
            return (E) q[tail];
    }

    /**
     * {@inheritDoc}
     */
    @SuppressWarnings("unchecked")
    @Override
    public E poll() {
        if (size == 0)
            return null;
        E res = (E) q[tail];
        q[tail] = null; // for java gc
        tail++;
        if (tail == q.length)
            tail = 0;
        size--;
        return res;
    }

    /**
     * Returns true if this queue cannot put more elements.
     * 
     * @return true if this queue cannot put more elements.
     */
    public boolean isFull() {
        return size == q.length;
    }
}
