/**
 * @(#)CacheHashMap.java, 2009-4-17. 
 * 
 * Copyright 2009 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.collections;

import java.util.Map;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * A cache map hold some latest objects with strong references and other with
 * WeakReference.
 * 
 * @author zhangduo
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class CacheHashMap<K, V> extends OutfoxWeakHashMap<K, V> {

    private final Object DUMMY = new Object();

    private final CacheMap<K, Object> cache;

    /**
     * Construct an empty CacheHashMap with the given max strong cache size.
     * 
     * @param maxCacheSize
     */
    public CacheHashMap(int maxCacheSize) {
        if (maxCacheSize <= 0) {
            throw new IllegalArgumentException();
        }
        this.cache = new CacheMap<K, Object>(true, maxCacheSize);
    }

    /**
     * Construct an empty CacheHashMap with the given initial capacity, load
     * factor and max strong cache size.
     * 
     * @param initialCapacity
     * @param loadFactor
     * @param maxCacheSize
     */
    public CacheHashMap(int initialCapacity, float loadFactor, int maxCacheSize) {
        super(initialCapacity, loadFactor);
        if (maxCacheSize <= 0) {
            throw new IllegalArgumentException();
        }
        this.cache = new CacheMap<K, Object>(true, maxCacheSize);
    }

    /**
     * Constructs an empty <tt>CacheMap</tt> instance with the same mappings as
     * the specified map and max strong cache size.
     * 
     * @param m
     * @param maxCacheSize
     */
    public CacheHashMap(Map<? extends K, ? extends V> m, int maxCacheSize) {
        super(m);
        if (maxCacheSize <= 0) {
            throw new IllegalArgumentException();
        }
        this.cache = new CacheMap<K, Object>(true, maxCacheSize);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public V put(K key, V value) {
        if (key == null) {
            throw new NullPointerException();
        }
        addToCache(key);
        return super.put(key, value);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public V get(Object key) {
        if (key == null) {
            throw new NullPointerException();
        }
        Entry<K, V> entry = getEntry(key);
        if (entry != null) {
            addToCache(entry.getKey());
            return entry.getValue();
        } else {
            return null;
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void clear() {
        super.clear();
        cache.clear();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public V remove(Object key) {
        if (key == null) {
            throw new NullPointerException();
        }
        removeFromCache(key);
        return super.remove(key);
    }

    private synchronized void addToCache(K key) {
        cache.put(key, DUMMY);
    }

    private synchronized void removeFromCache(Object key) {
        cache.remove(key);
    }
}
