package toolbox.collections;

import java.util.ArrayList;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * A map whose value is an ArrayList. See HashCollectionMap for more details.
 * 
 * @author david
 * @param <K>
 *            the type of the key
 * @param <V>
 *            the type of the element of the array-list.
 * @see HashCollectionMap
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class HashArrayListMap<K, V> extends
        HashCollectionMap<K, V, ArrayList<V>> {
    /**
     * Default Constructor.
     */
    @SuppressWarnings({
        "unchecked", "rawtypes"
    })
    public HashArrayListMap() {
        super((Class) ArrayList.class);
    }

    private static final long serialVersionUID = 2987671419942317669L;
}
