package toolbox.collections;

import java.util.Map;
import java.util.Set;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * Some utils for collections.
 * 
 * @author zhangduo
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class CollectionUtils {

    /**
     * Fast clear a map/set object. If the object contains less number of
     * objects then the specified threshold, Map/Set.clear() is called and the
     * input instance is returned. Otherwise a new instance of the object is
     * returned;
     * 
     * @param <T>
     *            The type of the object.
     * @param obj
     *            The intance of the object to be cleared.
     * @param thres
     *            The threshold of new instance.
     * @return Return the input instance if its size is smaller then threshold.
     *         Otherwise a new created instance is created.
     */
    @SuppressWarnings({
        "unchecked", "rawtypes"
    })
    public static <T> T fastClear(T obj, int thres) {
        if (obj instanceof Map) {
            if (((Map) obj).size() < thres) {
                ((Map) obj).clear();
            } else {
                try {
                    return (T) obj.getClass().newInstance();
                } catch (Exception e) {
                    return obj;
                }
            }
        } else if (obj instanceof Set) {
            if (((Set) obj).size() < thres) {
                ((Set) obj).clear();
            } else
                try {
                    return (T) obj.getClass().newInstance();
                } catch (Exception e) {
                    return obj;
                }
        } else {
            try {
                return (T) obj.getClass().newInstance();
            } catch (Exception e) {
                return obj;
            }
        }
        return obj;
    }

}
