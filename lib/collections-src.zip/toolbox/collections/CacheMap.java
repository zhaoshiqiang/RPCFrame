package toolbox.collections;

import java.util.LinkedHashMap;
import java.util.Map;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * LinkedHashMap with size limit.
 * 
 * @author river
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class CacheMap<K, V> extends LinkedHashMap<K, V> {
    private static final long serialVersionUID = 7177261808110411817L;

    private int limit;

    /**
     * Constructs an empty <tt>CacheMap</tt> instance with specified max size
     * limit.
     * 
     * @param limit
     *            the max size
     * @see LinkedHashMap#LinkedHashMap()
     */
    public CacheMap(int limit) {
        this.limit = limit;
    }

    /**
     * Constructs an empty <tt>CacheMap</tt> instance with specified ordering
     * mode and max size limit.
     * 
     * @param accessOrder
     *            the ordering mode - <tt>true</tt> for access-order,
     *            <tt>false</tt> for insertion-order
     * @param limit
     *            the max size
     * @see LinkedHashMap#LinkedHashMap(int, float, boolean)
     */
    public CacheMap(boolean accessOrder, int limit) {
        super(16, .75f, accessOrder);
        this.limit = limit;
    }

    /**
     * Constructs an empty <tt>CacheMap</tt> instance with the specified initial
     * capacity, load factor, ordering mode and max size.
     * 
     * @param initialCapacity
     *            the initial capacity
     * @param loadFactor
     *            the load factor
     * @param accessOrder
     *            the ordering mode - <tt>true</tt> for access-order,
     *            <tt>false</tt> for insertion-order
     * @param limit
     *            the max size
     * @see LinkedHashMap#LinkedHashMap(int, float, boolean)
     */
    public CacheMap(int initialCapacity, float loadFactor, boolean accessOrder,
            int limit) {
        super(initialCapacity, loadFactor, accessOrder);
        this.limit = limit;
    }

    /**
     * Constructs an empty <tt>CacheMap</tt> instance with the specified initial
     * capacity, load factor, and max size.
     * 
     * @param initialCapacity
     *            the initial capacity
     * @param loadFactor
     *            the load factor
     * @param limit
     *            the max size
     * @see LinkedHashMap#LinkedHashMap(int, float)
     */
    public CacheMap(int initialCapacity, float loadFactor, int limit) {
        super(initialCapacity, loadFactor);
        this.limit = limit;
    }

    /**
     * Constructs an empty <tt>CacheMap</tt> instance with the same mappings as
     * the specified map and max size.
     * 
     * @param m
     *            the map whose mappings are to be placed in this map
     * @param limit
     *            the max size
     * @see LinkedHashMap#LinkedHashMap(Map)
     */
    public CacheMap(Map<? extends K, ? extends V> m, int limit) {
        super(m);
        this.limit = limit;
    }

    /**
     * @see #removeEldestEntry(java.util.Map.Entry)
     */
    @Override
    protected boolean removeEldestEntry(Map.Entry<K, V> eldest) {
        return (limit > 0 && size() > limit);
    }

}
