/**
 * @(#)FloatBytePair.java, 2010-10-20. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.collections.primitive;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * A pair of values.
 *
 * @author zhangduo
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class FloatBytePair {
    private float first;

    private byte second;

    /**
     * Default constructor.
     */
    public FloatBytePair() {}

    /**
     * Construct a pair with given values.
     * 
     * @param first
     * @param second
     */
    public FloatBytePair(float first, byte second) {
        this.first = first;
        this.second = second;
    }

    /**
     * Get first value.
     * 
     * @return
     */
    public float getFirst() {
        return first;
    }

    /**
     * Set first value.
     * 
     * @param first
     */
    public void setFirst(float first) {
        this.first = first;
    }

    /**
     * Get second value.
     * 
     * @return
     */
    public byte getSecond() {
        return second;
    }

    /**
     * Set second value.
     * 
     * @param second
     */
    public void setSecond(byte second) {
        this.second = second;
    }

    /**
     * @see Object#hashCode()
     */
    @Override
    public int hashCode() {
        return Hash.hashCode(first) ^ Hash.hashCode(second);
    }

    /**
     * Return <code>true</code> iff the two parts are both equal.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        FloatBytePair that = (FloatBytePair) obj;
        return first == that.first && second == that.second;
    }

    /**
     * Return a string representation.
     */
    @Override
    public String toString() {
        return "<" + first + ", " + second + ">";
    }
}
