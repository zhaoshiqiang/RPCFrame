/**
 * @(#)FloatCharacterKeyValueIterator.java, 2011-12-8. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.collections.primitive;

import java.util.NoSuchElementException;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * An key value iterator over a collection.
 * 
 * @author zhangduo
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public interface FloatCharacterKeyValueIterator {
    /**
     * Returns <code>true</code> if the iteration has more elements.
     * 
     * @return
     */
    boolean hasNext();

    /**
     * Move to the next element in the iteration.
     * 
     * @exception NoSuchElementException
     *                iteration has no more elements.
     */
    void next();

    /**
     * Get the current Key.
     * 
     * @return
     * @exception IllegalStateException
     *                if the <tt>next</tt> method has not yet been called
     */
    float getKey();

    /**
     * Get the current Value.
     * 
     * @return
     * @exception IllegalStateException
     *                if the <tt>next</tt> method has not yet been called
     */
    char getValue();

    /**
     * Removes from the underlying collection the last element returned by the
     * iterator.
     * 
     * @exception IllegalStateException
     *                if the <tt>next</tt> method has not yet been called, or
     *                the <tt>remove</tt> method has already been called after
     *                the last call to the <tt>next</tt> method.
     */
    void remove();
}
