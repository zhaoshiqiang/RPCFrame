/**
 * @(#)ShortStaticSet.java, 2011-12-8. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.collections.primitive;

import java.util.Arrays;
import java.util.Iterator;
import java.util.NoSuchElementException;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * A static set.
 * <p>
 * This class is mainly used to providing a static(read-only) set. The keys are
 * stored using a sorted array and found using binary-search, so it is memory
 * efficiency compared with other set.
 * 
 * @author zhangduo
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class ShortStaticSet implements Iterable<Short> {

    private final short[] keys;
    
    /**
     * Construct a static set from existing set.
     * 
     * @param set
     *            contains the elements you want to contain in the static set.
     */
    public ShortStaticSet(ShortClosedHashSet set) {
        keys = set.toArray();
        Arrays.sort(keys);
    }

    /**
     * Construct a static set from existing set.
     * 
     * @param set
     *            contains the elements you want to contain in the static set.
     */
    public ShortStaticSet(ShortHashSet set) {
        keys = set.toArray();
        Arrays.sort(keys);
    }

    /**
     * Returns the number of elements in this set (its cardinality).
     * 
     * @return the number of elements in this set (its cardinality)
     */
    public int size() {
        return keys.length;
    }
    
    /**
     * Returns <tt>true</tt> if this set contains the specified element.
     * 
     * @param key
     *            element whose presence in this set is to be tested
     * @return <tt>true</tt> if this set contains the specified element
     */
    public boolean contains(short key) {
        return Arrays.binarySearch(keys, key) >= 0;
    }
    
    /**
     * Returns <tt>true</tt> if this set contains no elements.
     * 
     * @return <tt>true</tt> if this set contains no elements
     */
    public boolean isEmpty() {
        return keys.length == 0;
    }
    
    /**
     * Returns an iterator over all of the elements. Note that element removal
     * is not implemented.
     */
    @Override
    public Iterator<Short> iterator() {
        return new Iterator<Short>() {

            private int index = 0;

            @Override
            public boolean hasNext() {
                return index < keys.length;
            }

            @Override
            public Short next() {
                if (!hasNext()) {
                    throw new NoSuchElementException();
                }
                return keys[index++];
            }

            @Override
            public void remove() {
                throw new UnsupportedOperationException();
            }
        };
    }
}