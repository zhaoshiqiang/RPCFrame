/**
 * @(#)LongByteStaticMap.java, 2011-12-8. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.collections.primitive;

import java.util.Arrays;
import java.util.Iterator;
import java.util.NoSuchElementException;

import toolbox.collections.ArrayUtils;
import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * A static map.
 * <p>
 * This class is mainly used to providing a static(read-only) set. The keys and
 * values are stored using sorted arrays and found using binary-search, so it is
 * memory efficiency compared with other set.
 * 
 * @author zhangduo
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class LongByteStaticMap {

    private final long[] keys;

    private final byte[] values;

    /**
     * Construct a static map from existing map.
     * 
     * @param map
     *            contains the keys and values you want to contain in the static
     *            set.
     */
    public LongByteStaticMap(LongByteHashMap map) {
        keys = new long[map.size()];
        values = new byte[map.size()];
        Iterator<LongByteHashMap.Entry> iter = map.iterator();
        for (int i = 0; i < map.size(); i++) {
            LongByteHashMap.Entry entry = iter.next();
            keys[i] = entry.getKey();
            values[i] = entry.getValue();
        }
        ArrayUtils.sortArrays(keys, values);
    }

    /**
     * Construct a static map from existing map.
     * 
     * @param map
     *            contains the keys and values you want to contain in the static
     *            set.
     */
    public LongByteStaticMap(LongByteClosedHashMap map) {
        keys = new long[map.size()];
        values = new byte[map.size()];
        LongByteKeyValueIterator iter = map.iterator();
        for (int i = 0; i < map.size(); i++) {
            iter.next();
            keys[i] = iter.getKey();
            values[i] = iter.getValue();
        }
        ArrayUtils.sortArrays(keys, values);
    }

    /**
     * get value for this key in the map.
     * 
     * @param key
     *            key to find map
     * @param def
     * @return value for this key if key found in map, or def if not found
     */
    public byte get(long key, byte def) {
        int index = Arrays.binarySearch(keys, key);
        if (index < 0) {
            return def;
        } else {
            return values[index];
        }
    }

    /**
     * Check if a key is present in the table.
     * 
     * @param key
     *            key to be found
     * @return <code>true</code> if key found in table, <code>false</code> if
     *         not
     */
    public boolean containsKey(long key) {
        return Arrays.binarySearch(keys, key) >= 0;
    }

    /**
     * Check if a value is present in the table.
     * 
     * @param value
     *            value to be found
     * @return <code>true</code> if value found in table, <code>false</code> if
     *         not
     */
    public boolean containsValue(byte value) {
        for (byte v: values) {
            if (v == value) {
                return true;
            }
        }
        return false;
    }

    /**
     * Returns the number of key-value mappings in this map.
     * 
     * @return the number of key-value mappings in this map
     */
    public int size() {
        return keys.length;
    }

    /**
     * Returns <tt>true</tt> if this map contains no key-value mappings.
     * 
     * @return <tt>true</tt> if this map contains no key-value mappings
     */
    public boolean isEmpty() {
        return keys.length == 0;
    }

    /**
     * Returns an iterator over all of the key-value mappings. Note that element
     * removal is not implemented.
     */
    public LongByteKeyValueIterator iterator() {
        return new LongByteKeyValueIterator() {

            private int pos = -1;

            @Override
            public void remove() {
                throw new UnsupportedOperationException();
            }

            @Override
            public void next() {
                if (!hasNext()) {
                    throw new NoSuchElementException();
                }
                pos++;
            }

            @Override
            public boolean hasNext() {
                return pos < keys.length - 1;
            }

            @Override
            public byte getValue() {
                if (pos < 0) {
                    throw new IllegalStateException();
                }
                return values[pos];
            }

            @Override
            public long getKey() {
                if (pos < 0) {
                    throw new IllegalStateException();
                }
                return keys[pos];
            }
        };
    }
}