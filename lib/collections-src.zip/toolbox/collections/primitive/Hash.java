/**
 * @(#)Hash.java, 2010-7-28. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.collections.primitive;

/**
 * @author zhangduo
 */
final class Hash {

    static int hashCode(boolean b) {
        return b ? 1231 : 1237;
    }

    static int hashCode(byte b) {
        return (int) b;
    }

    static int hashCode(char c) {
        return (int) c;
    }

    static int hashCode(short s) {
        return (int) s;
    }

    static int hashCode(int i) {
        return i;
    }

    static int hashCode(long l) {
        return (int) (l ^ (l >>> 32));
    }

    static int hashCode(float f) {
        return Float.floatToIntBits(f);
    }

    static int hashCode(double d) {
        return hashCode(Double.doubleToLongBits(d));
    }

    static <T> int hashCode(T t) {
        return t.hashCode();
    }
}
