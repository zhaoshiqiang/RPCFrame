/**
 * @(#)CharacterFloatPair.java, 2010-10-20. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.collections.primitive;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * A pair of values.
 *
 * @author zhangduo
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class CharacterFloatPair {
    private char first;

    private float second;

    /**
     * Default constructor.
     */
    public CharacterFloatPair() {}

    /**
     * Construct a pair with given values.
     * 
     * @param first
     * @param second
     */
    public CharacterFloatPair(char first, float second) {
        this.first = first;
        this.second = second;
    }

    /**
     * Get first value.
     * 
     * @return
     */
    public char getFirst() {
        return first;
    }

    /**
     * Set first value.
     * 
     * @param first
     */
    public void setFirst(char first) {
        this.first = first;
    }

    /**
     * Get second value.
     * 
     * @return
     */
    public float getSecond() {
        return second;
    }

    /**
     * Set second value.
     * 
     * @param second
     */
    public void setSecond(float second) {
        this.second = second;
    }

    /**
     * @see Object#hashCode()
     */
    @Override
    public int hashCode() {
        return Hash.hashCode(first) ^ Hash.hashCode(second);
    }

    /**
     * Return <code>true</code> iff the two parts are both equal.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        CharacterFloatPair that = (CharacterFloatPair) obj;
        return first == that.first && second == that.second;
    }

    /**
     * Return a string representation.
     */
    @Override
    public String toString() {
        return "<" + first + ", " + second + ">";
    }
}
