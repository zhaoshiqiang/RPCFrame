/**
 * @(#)ClosedHashSet.java, 2010-8-4. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.collections;

import java.lang.reflect.Array;
import java.util.AbstractSet;
import java.util.Arrays;
import java.util.BitSet;
import java.util.Iterator;
import java.util.Set;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * A hash set using closed hash.
 * 
 * @author zhangduo
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class ClosedHashSet<E> extends AbstractSet<E> implements Set<E> {

    /** Default fill fraction allowed before growing table. */
    private static final double DEFAULT_FILL = 0.5d; // zf: original value: 0.3d

    /** Minimum size used for table. */
    private static final int MINIMUM_SIZE = 31;

    /** Hash value multiplier to scramble bits before calculating slot. */
    private static final int KEY_MULTIPLIER = 517;

    /** Fill fraction allowed for table. */
    private double fill;

    /** Number of entries present in table. */
    private int size;

    /** Entries allowed before growing table. */
    private int limit;

    /** Offset added (modulo table size) to slot number on collision. */
    private int hitOffset;

    /** Array of key table slots. */
    private Object[] table;

    /** Array of slot occupied flags. */
    private BitSet flag;

    /**
     * Constructor with full specification.
     * 
     * @param capacity
     *            number of values to assume in initial sizing of table
     * @param fill
     *            fraction full allowed for table before growing
     */
    public ClosedHashSet(int capacity, double fill) {
        // check the passed in fill fraction
        if (fill <= 0.0d || fill >= 1.0d) {
            throw new IllegalArgumentException("fill value out of range");
        }
        this.fill = fill;

        // compute initial table size (ensuring odd)
        capacity = Math.max((int) (capacity / fill), MINIMUM_SIZE);
        capacity += (capacity + 1) % 2;

        // initialize the table information
        limit = (int) (capacity * fill);
        hitOffset = capacity / 2;
        flag = new BitSet(capacity);
        table = new Object[capacity];
    }

    /**
     * Constructor with only size supplied. Uses default value for fill
     * fraction.
     * 
     * @param capacity
     *            number of values to assume in initial sizing of table
     */

    public ClosedHashSet(int capacity) {
        this(capacity, DEFAULT_FILL);
    }

    /**
     * Default constructor.
     */

    public ClosedHashSet() {
        this(0, DEFAULT_FILL);
    }

    /**
     * Step the slot number for an entry. Adds the collision offset (modulo the
     * table size) to the slot number.
     * 
     * @param slot
     *            slot number to be stepped
     * @return stepped slot number
     */
    private int stepSlot(int slot) {
        return (slot + hitOffset) % table.length;
    }

    /**
     * Find free slot number for entry. Starts at the slot based directly on the
     * hashed key value. If this slot is already occupied, it adds the collision
     * offset (modulo the table size) to the slot number and checks that slot,
     * repeating until an unused slot is found.
     * 
     * @param slot
     *            initial slot computed from key
     * @return slot at which entry was added
     */
    private int freeSlot(int slot) {
        while (flag.get(slot)) {
            slot = stepSlot(slot);
        }
        return slot;
    }

    /**
     * Compute the base slot for a key.
     * 
     * @param key
     *            key value to be computed
     * @return base slot for key
     */
    private int computeSlot(E key) {
        int k = key.hashCode();
        return (k * KEY_MULTIPLIER & Integer.MAX_VALUE) % table.length;
    }

    /**
     * Assign slot for key. Starts at the slot found by the hashed key value. If
     * this slot is already occupied, it steps the slot number and checks the
     * resulting slot, repeating until an unused slot is found. This method does
     * not check for duplicate keys, so it should only be used for internal
     * reordering of the tables.
     * 
     * @param key
     *            key to be added to table
     * @return slot at which key was added
     */
    private int assignSlot(E key) {
        int slot = freeSlot(computeSlot(key));
        flag.set(slot);
        table[slot] = key;
        return slot;
    }

    /**
     * Internal find key in table.
     * 
     * @param key
     *            to be found in table
     * @return index of matching key, or <code>-index-1</code> of slot to be
     *         used for inserting key in table if not already present (always
     *         negative)
     */

    private int internalFind(E key) {
        int slot = computeSlot(key);
        while (flag.get(slot)) {
            if (key.equals(table[slot])) {
                return slot;
            }
            slot = stepSlot(slot);
        }
        return -slot - 1;
    }

    /**
     * Reinsert a key into the hash map. This method is designed for internal
     * use when the table is being modified, and does not adjust the count
     * present or check the table capacity.
     * 
     * @param slot
     *            position of key to be reinserted into hash map
     * @return <code>true</code> if the slot number used by the key has has
     *         changed, <code>false</code> if not
     */

    @SuppressWarnings("unchecked")
    private boolean reinsert(int slot) {
        flag.clear(slot);
        E e = (E) table[slot];
        table[slot] = null;
        return assignSlot(e) != slot;
    }

    /**
     * Resize the base arrays after a size change. This implementation of the
     * abstract base class method allocates the new arrays and then calls
     * another method for handling the actual transfer of the key set from the
     * old arrays to the new ones.
     * 
     * @param newCapacity
     *            new size for base arrays
     */
    @SuppressWarnings("unchecked")
    private void resize(int newCapacity) {
        // allocate the larger arrays
        BitSet oldFlag = flag;
        flag = new BitSet(newCapacity);
        Object[] oldTable = table;
        table = new Object[newCapacity];

        // reinsert all entries into new arrays
        for (int i = 0; i < oldTable.length; i++) {
            if (oldFlag.get(i)) {
                assignSlot((E) oldTable[i]);
            }
        }
    }

    /**
     * Ensure that the table has the capacity for at least the specified number
     * of keys.
     * 
     * @param minCapacity
     *            minimum capacity to be guaranteed
     */
    private void ensureCapacity(int minCapacity) {
        if (minCapacity > limit) {
            // find the array size required
            int newCapacity = table.length;
            int newLimit = limit;
            while (newLimit < minCapacity) {
                newCapacity = newCapacity * 2 + 1;
                newLimit = (int) (newCapacity * fill);
            }

            // set parameters for new array size
            limit = newLimit;
            hitOffset = newCapacity / 2;

            // let the subclass handle the adjustments to data
            resize(newCapacity);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean add(E e) {
        ensureCapacity(size + 1);
        int slot = internalFind(e);
        if (slot < 0) {
            size++;
            slot = -slot - 1;
            flag.set(slot);
            table[slot] = e;
            return true;
        } else {
            return false;
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void clear() {
        flag.clear();
        Arrays.fill(table, null);
        size = 0;
    }

    /**
     * {@inheritDoc}
     */
    @SuppressWarnings("unchecked")
    @Override
    public boolean contains(Object o) {
        return internalFind((E) o) >= 0;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Iterator<E> iterator() {
        return new Iterator<E>() {
            int returnedCount;

            int i;

            public void remove() {
                throw new UnsupportedOperationException();
            }

            @SuppressWarnings("unchecked")
            public E next() {
                if (hasNext()) {
                    while (!flag.get(i)) {
                        i++;
                    }
                    returnedCount++;
                    return (E) table[i++];
                } else
                    return null;
            }

            public boolean hasNext() {
                return returnedCount < size;
            }

        };
    }

    /**
     * {@inheritDoc}
     */
    @SuppressWarnings("unchecked")
    @Override
    public boolean remove(Object o) {
        int slot = internalFind((E) o);
        if (slot >= 0) {
            flag.clear(slot);
            table[slot] = null;
            size--;
            while (flag.get(slot = stepSlot(slot))) {
                reinsert(slot);
            }
            return true;
        } else {
            return false;
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int size() {
        return size;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Object[] toArray() {
        Object[] a = new Object[size];
        int j = 0;
        for (int i = 0; i < table.length; i++) {
            if (flag.get(i)) {
                a[j++] = table[i];
            }
        }
        return a;
    }

    /**
     * {@inheritDoc}
     */
    @SuppressWarnings("unchecked")
    @Override
    public <T> T[] toArray(T[] a) {
        int size = size();
        T[] r = a.length >= size ? a : (T[]) Array.newInstance(
                a.getClass().getComponentType(), size);
        int j = 0;
        for (int i = 0; i < table.length; i++) {
            if (flag.get(i)) {
                r[j++] = (T) table[i];
            }
        }
        return r;
    }

    /**
     * Trim the capacity of this instance if its current fill rate is smaller
     * than the given <code>fill</code>.
     * 
     * @param fill
     */
    public void trim(double fill) {
        if (fill >= this.fill) {
            return;
        }
        double currentFill = (double) size / table.length;
        if (currentFill < fill) {
            // calculate expected capacity
            int capacity = Math.max((int) (size / fill), MINIMUM_SIZE);
            capacity += (capacity + 1) % 2;
            limit = (int) (capacity * this.fill);
            hitOffset = capacity / 2;
            resize(capacity);
        }
    }

    /**
     * Trim the capacity of this instance to the given <code>capacity</code>.
     * 
     * @param capacity
     */
    public void trim(int capacity) {
        if (capacity < size) {
            return;
        }
        capacity = Math.max((int) (capacity / fill), MINIMUM_SIZE);
        capacity += (capacity + 1) % 2;
        if (capacity < table.length) {
            limit = (int) (capacity * fill);
            hitOffset = capacity / 2;
            resize(capacity);
        }
    }

    /**
     * Get current bucket count(the underly array length) of this hash set.
     * 
     * @return
     */
    public int getBucketSize() {
        return table.length;
    }
}
